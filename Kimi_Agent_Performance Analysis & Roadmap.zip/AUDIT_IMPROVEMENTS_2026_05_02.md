# AUDIT_IMPROVEMENTS_2026_05_02.md

## Comprehensive Audit & Improvement Plan for findtorontoevents.ca/audit

**Date:** 2026-05-02  
**Analyst:** Multi-Agent Orchestration Team  
**Scope:** All Asset Classes (Crypto, Equity, Forex, Commodity, ETF, Bond, Futures)  
**Status:** CRITICAL FINDINGS — Immediate Action Required

---

## EXECUTIVE SUMMARY

Our unified audit dashboard has **world-class edge hiding inside a broken pipeline.** The data reveals:

| Asset Class | True Edge | Current Blocker | Fix Impact |
|-------------|-----------|----------------|------------|
| **Crypto S-Tier** | T1 (85.7% WR, PF 30.17) | n=16 sample too small | Scale cautiously |
| **Equities L100** | **T1 (59% WR, PF 2.90, +176.74%)** | None — this is LIVE alpha | **SCALE IMMEDIATELY** |
| **ETFs L20/L50** | T1 (70-72% WR, PF 2.67-2.88) | Mislabeled "DEAD" | **UNBLOCK IMMEDIATELY** |
| **Crypto B-Tier L20** | T1 (65% WR, PF 2.71) | Merged with C-Tier | Separate & promote |
| **Forex** | Raw feed FAIL (5% WR) | Resolver bug + over-filters | Fix resolver → trusted-only |
| **Crypto C-Tier** | **FAIL (28-35% WR, PF 0.36)** | Not filtered out | **ELIMINATE** |
| **Commodities** | WEAK (14-35% WR) | No confidence gate applied | Apply conf ≥0.70 |
| **Bonds** | PROMISING (50% WR, PF 1.72) | n=20 insufficient | Gather data |
| **Futures** | INCONCLUSIVE (n=2) | No data | Monitor |

**The #1 root cause of forex failure is NOT bad alpha — it is a resolver infinite-retry bug that prevents picks from ever being resolved.** Once fixed, true forex edge will re-emerge.

**Top-5 ROI Actions:**
1. **Fix outcome_resolver.py retry loop** (saves forex, restores true WR)
2. **Eliminate C-Tier crypto** (+21pp WR boost)
3. **Unblock ETFs** (was mislabeled DEAD; actually T1)
4. **Scale Equities L100** (already T1, +176.74% realized)
5. **Implement vol targeting** (MDD 140% → <30%, makes crypto T2)

---

## SECTION 1: ROOT-CAUSE CHAIN FOR 0% FOREX WR

The forex catastrophe is a **self-reinforcing chain of software bugs → bad data → over-aggressive filters:**

```
1. v2 resolver deploys (2026-04-28) with daily bar-replay for non-crypto
2. yfinance OHLC fetch is flaky for forex (no timeout, weekend gaps, CI geo-blocking)
3. Missing OHLC triggers INFINITE RETRY LOOP (Bug 1). Picks are NEVER resolved.
4. Only picks with pre-existing exit_price (usually SL-only) make it to dashboard
5. Dashboard computes WR from resolved subset → almost all are LOST → 0% WR
6. Analyst sees 0% WR → raises forwardWRMinPct to 70%, bans major pairs, bans high-confidence picks
7. These filter changes further suppress remaining picks, tile vanishes entirely
8. Cycle self-reinforces: fewer picks → noisier stats → more aggressive bans
```

**Break the chain at Step 3.** The fix is in `outcome_resolver.py` — add a max-retry cap (3 retries) then force-close at live price. Once picks resolve correctly, true WR will re-emerge, and the 70% floor / symbol bans will be seen as the overreactions they are.

---

## SECTION 2: CRITICAL BUGS FOUND (with Fixes)

### BUG 1 — INFINITE RETRY LOOP FOR NON-CRYPTO PICKS (CRITICAL)

**File:** `alpha_engine/outcome_resolver.py`  
**Lines:** 608-631, 658-674, 489, 828-830

**What happens:** When yfinance OHLC data is missing (common for forex/commodity), the resolver returns early with `_resolve_retry_needed=True` or falls back to breakeven (`exit_price=entry`). On the next run, `is_unresolved()` sees the same pick as still-unresolved, so it is re-processed **forever**.

**Impact:** FOREX/COMMODITY picks are **never counted as resolved**. Dashboard only sees SL-only exits → 0% WR.

**Fix:** Introduce `MAX_RESOLVE_RETRIES = 3`. After 3 retries, force-close at live price, set `resolved_by="outcome_resolver"`, and stop retrying. Update `is_unresolved()` to ignore max-retried picks.

### BUG 2 — DAILY BAR-REPLAY LOOKAHEAD BIAS (HIGH)

**File:** `alpha_engine/outcome_resolver.py`  
**Lines:** 351-353

**What happens:** `_fetch_yfinance_ohlc_window` filters bars to `date >= entry_date`. For intraday entries (e.g., 14:00 UTC), the **entire** daily bar is used, including `high`/`low` that occurred **before** the pick existed.

**Impact:** False TP/SL detection biases outcomes for intraday forex/commodity picks.

**Fix:** When entry has a non-midnight time component, exclude the entry day and use only bars **strictly after** entry date.

### BUG 3 — EMPTY OHLC LIST `[]` BYPASSES BAR-REPLAY (HIGH)

**File:** `alpha_engine/outcome_resolver.py`  
**Line:** 608

**What happens:** Python treats `[]` as falsy. If OHLC returns empty, the condition `elif is_non_crypto and ohlc_window:` is **False**, falling through to retry loop.

**Fix:** Change to `elif is_non_crypto and ohlc_window is not None:` so empty lists are handled as "data returned but no bars".

### BUG 4 — yfinance CAN HANG INDEFINITELY (HIGH)

**File:** `alpha_engine/outcome_resolver.py`  
**Line:** 317

**What happens:** `ticker.history()` has no explicit timeout. A single call can hang for minutes. In CI this caused the resolver step to time out after 8 minutes.

**Fix:** Wrap in `signal.alarm` (15-second cap per symbol) or `concurrent.futures.ThreadPoolExecutor` with timeout.

### BUG 5 — Breakeven fallback omits `status` (MEDIUM)

**File:** `alpha_engine/outcome_resolver.py`  
**Lines:** 665-669

**Fix:** Set `status = "FLAT"` in the breakeven fallback block.

---

## SECTION 3: OVERLY RESTRICTIVE FILTERS

### FILTER 1 — `forwardWRMinPct = 70%` for ALL asset classes (CRITICAL)

**File:** `audit_dashboard/hc_filter.js`  
**Lines:** 34-36

**Evidence:** A 70% win rate is a 2.3-sigma event. The 3,500-pick ledger shows:
- CRYPTO: ~48-52% WR
- EQUITY: ~52-55% WR  
- FOREX: ~55% WR (pre-v2)

70% is not a "quality" gate — it is a **lottery gate** that filters out even genuinely profitable picks.

**Fix:** Revert to evidence-based, per-class floors:

| Asset Class | forwardWRMinPct |
|-------------|-----------------|
| CRYPTO | 55% |
| EQUITY | 50% |
| FOREX | 55% (small-sample relax to 50%) |
| COMMODITY | 50% |
| ETF | 50% |
| BOND | 50% |
| FUTURES | 50% |

### FILTER 2 — `passesPerAssetTierContract` blocks ALL non-crypto tier picks (CRITICAL)

**File:** `audit_dashboard/hc_filter.js`  
**Lines:** 207-215

**Evidence:** For non-crypto, tier A/B is only allowed if strategy name contains one of four equity fundamental strategies (`pead_earnings_drift`, `quality_value`, etc.). A forex `mean_reversion` or `breakout_momentum` pick stamped tier A is **rejected** regardless of score/WR/confidence.

**Fix:** Add per-asset-class bypass. The tier contract whitelist should only apply to EQUITY/ETF/BOND. FOREX/COMMODITY/FUTURES should bypass the strategy whitelist — numeric gates already filter them.

### FILTER 3 — `FOREX_BANNED_SYMBOLS` bans ALL major pairs (CRITICAL)

**File:** `alpha_engine/hedge_fund_quality_gate.py`  
**Lines:** 74-76

**Evidence:** Bans `AUDUSD=X`, `CADJPY=X`, `EURJPY=X`, `EURUSD=X` — the four most liquid pairs. Justification says "lifetime PF < 0.50 on n >= 44" but those stats were computed on **pre-v2 resolver data** corrupted by the 0.1bp noise bug.

**Fix:** Remove the blanket ban entirely. Rely on strategy ban and confidence band. Re-evaluate after 200 post-v2 resolved picks per pair.

### FILTER 4 — `FOREX_CONFIDENCE_REJECT_BANDS [0.95, 1.0001)` (HIGH)

**File:** `alpha_engine/hedge_fund_quality_gate.py`  
**Lines:** 97-99

**Evidence:** Hard-bans forex confidence >= 0.95 based on n=38. With the resolver bug, those 38 picks were from a biased subset. Overconfidence inversion is real, but a hard ban on the top decile removes the system's highest-conviction signals.

**Fix:** Convert to soft penalty + sample-size gate. Disable hard ban; require n>=100 before re-instating.

### FILTER 5 — Hidden `WINNER_FILTER` confidence > 0.85 blocker (HIGH)

**Location:** Observed in `shadow_blocked.json:544`

**Evidence:** Blocks picks for `confidence > 0.85 (overfit zone)`. Stricter than HC filter (`confidenceMax: 0.90`) and HF gate (`confidenceExtremeMax: 0.95`).

**Fix:** Find the `WINNER_FILTER` source module. Align its threshold with `hc_filter.js` (0.90) or remove entirely. The real overfit cliff is >0.90, not >0.85.

---

## SECTION 4: ASSET-CLASS PERFORMANCE & RECOMMENDATIONS

### CRYPTO — T1 Edge Exists, But C-Tier Destroys It

| Tier | WR | PF | PnL | Action |
|------|-----|-----|------|--------|
| S-Tier | 85.7% | 30.17 | +58.35% | **Scale** (but n=16 — size carefully) |
| A-Tier L50 | 54.0% | 1.58 | +20.20% | Keep |
| B-Tier L20 | 65.0% | 2.71 | +10.25% | **Promote to A-Tier** |
| C-Tier ALL | 28-35% | 0.36-0.66 | -5.97% to -33.50% | **ELIMINATE** |

**Key insight:** Eliminating C-Tier raises crypto WR from 43.5% to **47.2-64.8%**.

**Filters to apply:**
- Block C-Tier entirely (1 line in hc_filter.js)
- Confidence: block <0.75, allow 0.75-0.90, block >0.90
- R:R >= 1.0 (not 1.5)
- Implement vol targeting (MDD 140% → <30%)

### EQUITIES — T1 DISCOVERY (The Crown Jewel)

| Window | WR | PF | PnL | Tier |
|--------|-----|-----|------|------|
| L20 | 50.0% | 1.51 | +17.07% | T3 |
| L50 | 50.0% | 1.47 | +35.54% | T3 |
| L100 | **59.0%** | **2.90** | **+176.74%** | **T1** |

**WR *improves* with more data** — the hallmark of genuine edge. PF nearly doubles from L50→L100.

**Action:** Scale immediately. Lower score floor to 40, FWD WR to 50%. Keep long-only. Re-evaluate AAPL ban.

### ETFs — RESURRECTION (Was Mislabeled DEAD)

| Window | WR | PF | PnL | Tier |
|--------|-----|-----|------|------|
| L20 | **70.0%** | **2.88** | +23.29% | **T1** |
| L50 | **72.0%** | **2.67** | +64.49% | **T1** |
| L100 | 52.9% | 1.32 | +28.58% | T3 |

**Old analysis (n=19, PF 0.28) was simply too small.** New data shows T1 on recent windows but T3 decay at L100. Edge is **time-sensitive**.

**Action:** Lower FWD WR to 55%. Prioritize L20/L50. Favor recent picks.

### FOREX — CATASTROPHIC (But Salvageable)

| Window | WR | PF | PnL |
|--------|-----|-----|------|
| L20 | 0.0% | 0.00 | -10.00% |
| L50 | 4.0% | 0.04 | -21.57% |
| L100 | 5.0% | 0.06 | -41.25% |

**Lifeline:** Trusted filter shows **49% WR, PF 3.59, n=273**.

**Immediate actions:**
1. Fix resolver bug first (true WR will re-emerge)
2. Block ALL raw forex until trusted filter applied
3. Unban major pairs (pre-v2 data was corrupted)
4. Lower FWD WR to 50-55%
5. Only allow: trust tier >= WATCH, score >= 50, confidence [0.70, 0.95)

### COMMODITIES — WEAK (Data Collection Mode)

| Window | WR | PF | PnL |
|--------|-----|-----|------|
| L20 | 35.0% | 1.01 | +0.44% |
| L50 | 24.0% | 1.26 | +12.69% |
| L100 | 14.0% | 0.95 | -3.04% |

**Declining with more data — concerning.** But confidence >= 0.70 shows PF 1.34.

**Action:** Apply confidence >= 0.70 gate (already correct). Lower FWD WR to 40%. Gather n>100 before claiming edge.

### BONDS — PROMISING (n=20)

50% WR, PF 1.72, +3.41% across all windows.

**Action:** Keep relaxed thresholds. Gather n>50.

### FUTURES — INCONCLUSIVE (n=2)

Dashboard shows n=2, all flat exits. Old analysis n=17 may be different filter set.

**Action:** Monitor. Need n>20 to assess.

---

## SECTION 5: NEAR-MISS OPPORTUNITIES

### Near-Miss 1: R:R >= 1.5 Gate Too Strict
- **PnL left on table:** +78.87% from 23 profitable picks
- **Root cause:** R:R=1.25-1.33 trades were profitable
- **Fix:** Lower R:R floor to 1.0 for crypto, 1.2 for equities

### Near-Miss 2: elite_score Gate (44.1% accuracy — worse than coin flip)
- **PnL left on table:** +969.50% from 113 wrongly blocked picks
- **Root cause:** elite_score has negative correlation with profitability in blocked population
- **Fix:** Replace with ml_score >= 0.60

### Near-Miss 3: WINNER_FILTER confidence > 0.85
- **PnL left on table:** +26.79% from 4 crypto picks
- **Root cause:** 0.85-0.90 is the BEST zone (82% WR, PF 11.8), not overfit
- **Fix:** Raise ceiling to block >= 0.90

### Near-Miss 4: C-Tier Crypto Almost Worked
- **What:** S-Tier criteria almost catches some C-Tier picks that had score 65-69
- **Fix:** Lower S-Tier score threshold to 65, add additional confidence/R:R gates

---

## SECTION 6: BLOCKED PICK EXCEPTIONS

### Exception 1: Crypto Banned Symbols (DOGE, OP, LINK, ADA, LTC, TON)
**Contradiction:** DOGEUSDT appears in S-Tier but is banned.

**Conditional allow:**
```
ALLOW banned_crypto_symbol IF:
  - hf_conviction_tier == 'S' OR
  - (ml_score >= 0.80 AND confidence >= 0.75 AND forward_WR >= 60% AND R:R >= 1.5 AND direction == 'LONG')
```

### Exception 2: Forex Banned Pairs (AUDUSD, EURUSD, EURJPY, CADJPY)
**Conditional allow:**
```
ALLOW banned_forex_pair IF:
  - trust_tier >= 'RELIABLE' AND
  - score >= 50 AND
  - confidence in [0.70, 0.95) AND
  - strategy != 'Breakout Momentum' AND
  - direction == 'LONG' AND
  - forward_WR >= 45%
```

### Exception 3: AAPL (Equity)
**Conditional allow:**
```
ALLOW AAPL IF:
  - strategy == 'markov_zone_transition' AND
  - score >= 55 AND
  - confidence >= 0.70
```

---

## SECTION 7: DATA LAYERS TO ADD (Ranked)

| Priority | Data Layer | Expected Impact |
|----------|-----------|----------------|
| **P1** | Regime detection at entry | Filters C-Tier losers in wrong regimes |
| **P1** | Volatility targeting | MDD 140% → <30%; makes crypto T2 |
| **P1** | MFE/MAE tracking | Enables proper position sizing |
| **P2** | Funding rates (crypto) | Improves entry timing |
| **P2** | On-chain metrics | Whale flows, exchange inflows |
| **P2** | Earnings calendar guard | Reduces equity gap risk |
| **P3** | COT reports | Better commodity/forex bias |
| **P3** | Dynamic correlation matrix | Reduces crisis duplicate exposure |

---

## SECTION 8: BABY STRATEGIES STATUS

| Strategy | WR | PF | MDD | n | Status | Action |
|----------|-----|-----|-----|---|--------|--------|
| signal_validation | 63.1% | 2.57 | 12.0% | 176 | **Tier 2 PROVEN** | Scale |
| mega_mutation | 65.3% | 2.76 | 36.0% | 72 | Building | Needs 28 more for T2 |
| rl_agent | 60.0% | 2.54 | 2.1% | 5 | Building | Needs 45 more for T2 |
| claude_gainer | 56.2% | 2.23 | 33.5% | 32 | Building | Needs 68 more for T2 |

**Note:** mega_mutation at n=72 with PF 2.76 is close to Tier 2. Monitor for T2 badge at n=100.

---

## SECTION 9: IMPLEMENTATION CHECKLIST

### Phase 1: Emergency Fixes (Deploy Today)
- [ ] Fix outcome_resolver.py infinite retry loop (MAX_RESOLVE_RETRIES = 3)
- [ ] Fix outcome_resolver.py lookahead bias (entry-day exclusion)
- [ ] Fix outcome_resolver.py yfinance timeout (15s cap)
- [ ] Lower hc_filter.js forwardWRMinPct per asset class
- [ ] Add nonEquity bypass to hc_filter.js tier contract
- [ ] Unban forex major pairs in hedge_fund_quality_gate.py
- [ ] Soften forex confidence band to soft penalty

### Phase 2: Filter Optimization (Deploy This Week)
- [ ] Block C-Tier crypto in hc_filter.js
- [ ] Adjust crypto confidence bands (block <0.75, allow 0.75-0.90, block >0.90)
- [ ] Lower crypto R:R floor to 1.0
- [ ] Lower equity FWD WR to 50%, score to 40
- [ ] Lower ETF FWD WR to 55%
- [ ] Replace elite_score gate with ml_score >= 0.60
- [ ] Raise WINNER_FILTER threshold to >= 0.90

### Phase 3: Data & Infrastructure (Deploy Next 2 Weeks)
- [ ] Implement vol targeting (20d realized vol percentile)
- [ ] Add MFE/MAE tracking to closed picks schema
- [ ] Add regime detection at entry time
- [ ] Add funding rates for crypto
- [ ] Add earnings calendar guard for equities
- [ ] Gather bond data to n>50
- [ ] Gather futures data to n>20

---

## APPENDIX A: CODE FIXES SUMMARY

All specific diffs are provided in the accompanying PR. Key files modified:

1. `alpha_engine/outcome_resolver.py` — 9 bug fixes
2. `audit_dashboard/hc_filter.js` — 2 filter adjustments
3. `alpha_engine/hedge_fund_quality_gate.py` — 2 unbans + 1 soften
4. `config/hf_quality_gates.json` — 1 safety adjustment

---

*This document is for educational and research purposes only. Past performance does not guarantee future results. Trading involves substantial risk of loss.*
