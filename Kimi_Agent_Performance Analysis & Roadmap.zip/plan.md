# FindTorontoEvents Audit & Improvement Plan

## Objective
Comprehensive audit of findtorontoevents.ca/audit prediction performance across all asset classes (Crypto, Equity, Forex, Commodity, Bond, ETF, Futures). Identify hidden insights, near-misses, blocked picks, and create actionable improvements to reach hedge-fund-grade performance.

## Stage 1 — Repository Analysis & Data Extraction
- Clone GitHub repo using provided PAT
- Map codebase structure: alpha_engine, outcome_resolver, signal validation, filters
- Extract key files: audit scripts, config files, resolver logic, quality gates, blocked symbols
- Identify the `resolver-noise` bug in alpha_engine/outcome_resolver.py
- Document current tier definitions and badge system

## Stage 2 — Performance Analysis & Near-Miss Detection
- Analyze active picks vs closed picks data
- Identify near-misses: picks that almost triggered but failed strict criteria
- Identify picks blocked by quality gates that should have exceptions
- Analyze blocked symbols/strategies and baby strategies missing backtest data
- Cross-reference asset class performance gaps:
  - Forex: 0% WR (last 20) — critical issue
  - Futures: 0% WR (last 20) — kill list candidate
  - Commodities: 35% WR — underperforming
  - Crypto: PF 1.140 edge real but MDD 140% lethal
  - Equity: Tier 2 franchise (PF 1.385) — scale opportunity

## Stage 3 — Pattern Discovery & Edge Enhancement
- Find top REAL MONEY picks and usable patterns
- Layer additional data points on current data for better picks
- Analyze R:R patterns by asset class
- Analyze confidence thresholds by asset class (not global)
- Evaluate "Smart Picks", "Verified Alpha", "High Conviction" tab effectiveness
- Propose per-asset-class filter adjustments

## Stage 4 — Fix Implementation & PR Creation
- Create fixes for resolver bug
- Adjust quality gates with per-asset-class exceptions
- Propose blocked symbol/strategy adjustments
- Create improvement recommendations document
- Open PR on GitHub with fixes and .MD recommendations

## Stage 5 — Synthesis & Roadmap
- Compile Top-5 ROI actions across all asset classes
- Define concrete tier progression path (T1/T2/T3)
- Write final AUDIT_IMPROVEMENTS_2026_05_02.md
- Summarize all findings for user

## Key Issues to Investigate
1. **Resolver bug** in alpha_engine/outcome_resolver.py blocking FOREX/COMMODITY evaluation
2. **Quality gates too strict** — near-miss profitable trades excluded
3. **Blocked symbols/strategies** — profitable picks blocked unnecessarily
4. **Baby strategies** missing backtest data
5. **Global confidence threshold** failing per-asset-class (FX peak 0.75-0.80, Equity bipolar)
6. **Crypto MDD 140%** — vol targeting needed
7. **ETF n<100** — need more sources
8. **Bond n=17** insufficient
9. **Futures 6.3% WR** — kill or fix

## Deliverables
1. GitHub PR with code fixes
2. AUDIT_IMPROVEMENTS_2026_05_02.md with full analysis
3. Top-5 ROI action roadmap
