# DEEP ASSET CLASS PERFORMANCE ANALYSIS & EDGE VALIDATION REPORT
## Multi-Asset Trading Prediction System — Statistical Rigor Assessment
**Date:** 2026-04-25  
**Analyst:** Quantitative Research  
**Data Source:** findtorontoevents.ca/audit/ + MERCURYPROMPT.md (2026-04-14)

---

## EXECUTIVE SUMMARY

| Verdict | Asset Classes | Count |
|---------|--------------|-------|
| ✅ REAL EDGE | EQUITY | 1 |
| 🟡 BORDERLINE | CRYPTO (pre-fee), ETF | 2 |
| ❌ FAIL / NO EDGE | FOREX, COMMODITY, FUTURES, BOND | 4 |

**Bottom Line:** Only **EQUITY** demonstrates a statistically robust, reproducible edge. **CRYPTO** shows marginal edge that is **wiped out by realistic transaction costs (15-20bps)**. All other asset classes either have negative profit factors, insufficient sample sizes, or documented filter claims that represent cherry-picked subsets with no proven out-of-sample validity.

---

## TASK 1: PER-ASSET-CLASS STATISTICAL VERDICT TABLE

### Full Metrics Matrix

| Asset | N | WR% | WR 95% CI | PF | PF 95% CI | W/L | Exp% | Sharpe | Sortino | MaxDD% | NetPF@Costs* | Size Verdict | Edge Verdict |
|-------|---|-----|-----------|-----|-----------|-----|------|--------|---------|--------|--------------|--------------|--------------|
| **CRYPTO** | 7,453 | 44.3% | [43.2–45.5] | 1.21 | [1.16–1.27] | 1.52 | +0.23 | 0.094 | 0.158 | 94.6 | **0.94** @ 15bps | EXCELLENT | BORDERLINE → FAIL at fees |
| **EQUITY** | 373 | 52.5% | [47.5–57.6] | 1.39 | [1.14–1.71] | 1.26 | +0.62 | 0.165 | 0.270 | 50.2 | **1.29** @ 7bps | ADEQUATE | ✅ REAL EDGE |
| **FOREX** | 989 | 47.5% | [44.4–50.6] | 0.26 | [0.23–0.30] | 0.29 | -0.99 | -0.601 | -0.534 | 979.8 | **0.25** @ 2bps | EXCELLENT | ❌ FAIL — Negative PF |
| **COMMODITY** | 602 | 43.0% | [39.1–47.0] | 0.84 | [0.70–0.98] | 1.10 | -0.03 | -0.093 | -0.128 | 22.1 | **0.20** @ 10bps | EXCELLENT | ❌ FAIL — Negative PF |
| **ETF** | 82 | 56.1% | [45.3–66.3] | 1.25 | [0.81–2.00] | 0.98 | +0.28 | 0.113 | 0.168 | 12.8 | **1.12** @ 7bps | MARGINAL | BORDERLINE |
| **BOND** | 16 | 50.0% | [28.0–72.0] | 1.60 | [0.54–4.83] | 1.61 | +0.18 | 0.234 | 0.431 | 2.9 | **1.23** @ 5bps | INSUFFICIENT | ❌ FAIL — n < 30 |
| **FUTURES** | 2 | 100% | [34.2–100] | ∞ | N/A | N/A | 0.00 | N/A | N/A | N/A | N/A | INSUFFICIENT | ❌ FAIL — n < 30 |

\* Net PF after realistic round-trip costs: Crypto 10-20bps, Equity 5-10bps, Forex 1-3bps, Commodity 5-15bps, ETF 5-10bps, Bond 2-10bps

### Key Statistical Findings

**1. Sample Size Sufficiency**
- **N ≥ 500 (EXCELLENT):** CRYPTO, FOREX, COMMODITY — sufficient for robust inference
- **N ≥ 100 (ADEQUATE):** EQUITY — borderline but acceptable
- **N ≥ 30 (MARGINAL):** ETF — risky; wide confidence intervals
- **N < 30 (INSUFFICIENT):** BOND (16), FUTURES (2) — completely unreliable

**2. Wilson Score Win Rate Confidence Intervals**
- CRYPTO: 44.3% [43.2–45.5] — tight CI due to large N
- EQUITY: 52.5% [47.5–57.6] — moderate uncertainty
- FOREX: 47.5% [44.4–50.6] — includes 50% (coin flip)
- ETF: 56.1% [45.3–66.3] — **very wide**, could easily be < 50%
- BOND: 50.0% [28.0–72.0] — **useless**, ±22% margin of error

**3. Bootstrap Profit Factor CI**
- CRYPTO: PF=1.21 CI [1.16–1.27] — above 1.0, but barely
- EQUITY: PF=1.39 CI [1.14–1.71] — above 1.0, reasonable spread
- FOREX: PF=0.26 CI [0.23–0.30] — firmly below 1.0
- COMMODITY: PF=0.84 CI [0.70–0.98] — **upper bound < 1.0** (statistically losing!)
- ETF: PF=1.25 CI [0.81–2.00] — **includes 1.0** (not proven)
- BOND: PF=1.60 CI [0.54–4.83] — **includes 1.0** and enormous spread

**4. Sharpe & Sortino Ratios**
- EQUITY: Sharpe=0.165, Sortino=0.270 — best risk-adjusted returns
- CRYPTO: Sharpe=0.094, Sortino=0.158 — low but positive
- FOREX: Sharpe=-0.601, Sortino=-0.534 — deeply negative
- All others near zero or negative

**5. Fee Haircut Impact — CRITICAL FINDING**
- **CRYPTO @ 15bps:** PF drops from 1.21 → **0.94** (NEGATIVE after costs)
- **CRYPTO @ 10bps:** PF drops to 1.03 (barely survives)
- **EQUITY @ 10bps:** PF drops from 1.39 → **1.25** (still healthy)
- **FOREX @ 2bps:** PF remains 0.25 (no fee can save it)
- **COMMODITY @ 5bps:** PF drops to 0.43 (dead)
- **ETF @ 10bps:** PF drops to 1.07 (marginal)

**6. Half-Split Stationarity**
- All assets pass the t-test for stationarity (p > 0.05)
- However, **EQUITY shows a -27% PF drop** from first half to second half (1.63 → 1.19)
- **ETF shows -17% PF drop** (1.38 → 1.14)
- These are **not statistically significant** due to variance, but they are **trending toward decay**

---

## TASK 2: THE FOREX PARADOX — DETAILED EXPLANATION

### The Discrepancy

| Source | N | WR | PF | PnL |
|--------|---|----|-----|-----|
| Dashboard (ALL trades) | 989 | 47.5% | 0.26 | -976.95% |
| MERCURYPROMPT.md (FwdWR≥50) | 466 | 49.8% | 1.62 | N/A |
| High-Conviction (FWD≥55%+Score≥40+Trust≥5) | 73 | 65.8% | N/A | N/A |

### Explanation: This is a Classic Cherry-Pick / Filter Artifact

**1. The Dashboard Shows ALL Trades — And They Are Catastrophically Losing**
- 989 trades, PF=0.26, PnL=-977%
- W/L ratio = 0.29 (avg loss is **3.4x** larger than avg win)
- This is not a strategy; it is a wealth destruction machine.

**2. The MERCURYPROMPT.md Filter Selects Only 47% of Trades**
- FwdWR≥50 filter keeps 466/989 = **47.1%** of trades
- These selected trades allegedly have PF=1.62
- For this to be true with WR=49.8%, the **W/L ratio in the filtered subset must be ~1.63**
- This is **5.6x higher** than the unfiltered W/L of 0.29

**3. The Unfiltered Majority (53% of trades) Must Be Even Worse Than 0.26**
- Mathematical inference: If filtered trades have PF=1.62, and total PF=0.26
- Then unfiltered trades have PF between **0.02 and 0.21**
- The filter is not enhancing an edge — it is **avoiding catastrophic losses** that dominate the dataset

**4. The High-Conviction Filter is Even More Extreme**
- Only 73/989 = **7.4%** of trades pass the strict filter
- WR=65.8% on this tiny subset, but no PF or PnL data provided
- This is selection bias on steroids

**5. Why This is a Filter Artifact, Not Genuine Edge**

A genuine edge means the **entire** strategy has positive expectancy. The MERCURYPROMPT.md approach is:
- Generate many signals across many conditions
- After seeing the results, find the subset that happened to do well
- Claim this subset represents an "edge"

This is **post-hoc selection bias** (aka data mining / overfitting). The critical test is:
> *If you trade the FwdWR≥50 filter going forward, will it continue to work?*

Answer: **Probably not**, because:
- The filter was discovered by optimizing on historical data
- There is no out-of-sample validation period
- The unfiltered base rate is PF=0.26; the filter is literally searching for needles in a haystack of losing trades

**6. Fee Impact**
- Even at minimal 2bps round-trip fees, Forex PF remains 0.25
- The strategy is so broken that fees are irrelevant

### Forex Verdict: ❌ COMPLETE FAIL
> The documented "edge" is a filter artifact from cherry-picking a minority of trades in a catastrophically losing strategy. The base rate (all trades) is PF=0.26. No statistical test can validate a subset edge when the parent distribution is this severely negative.

---

## TASK 3: COMMODITIES / BONDS ASSESSMENT

### 🛢️ COMMODITIES

| Metric | Value | Assessment |
|--------|-------|------------|
| Trades | 602 | Sufficient N |
| Win Rate | 43.0% | Below coin flip |
| W/L Ratio | 1.10 | Barely above 1.0 |
| Profit Factor | 0.84 | **Losing** |
| Expectancy | -0.03% | Negative |
| PF 95% CI | [0.70–0.98] | **Upper bound < 1.0** |
| Net PF @ 5bps | 0.43 | Dead after fees |

**Key Findings:**
1. **PF 95% CI [0.70–0.98] does NOT include 1.0** — This is statistically significant evidence that Commodities is a **losing strategy**
2. Even at minimal 5bps fees, PF drops to 0.43
3. To become viable (PF≥1.2), Commodities would need either:
   - Avg win to increase from 0.33% → 0.48% (+45% larger winners), OR
   - Win rate to increase from 43.0% → 52.2% (+9.2pp)
4. The MERCURYPROMPT.md claim (Trust≥3, n=273, PF=1.28) has CI lower bound=0.84, which is **below 1.0**. Our bootstrap confirms the 95% CI [1.00–1.62] — barely touching 1.0. This "edge" is **not statistically significant**.

**Commodities Verdict: ❌ EXCLUDE — Statistically confirmed losing strategy**

### 📜 BONDS

| Metric | Value | Assessment |
|--------|-------|------------|
| Trades | 16 | **Completely insufficient** |
| Win Rate | 50.0% | CI spans 28%–72% |
| W/L Ratio | 1.61 | Looks good but meaningless |
| Profit Factor | 1.60 | CI spans 0.54–4.83 |
| PF 95% CI | [0.54–4.83] | **Includes 1.0, enormous spread** |

**Key Findings:**
1. N=16 is far below the N≥100 threshold for reliable inference
2. Wilson CI for WR: [28%–72%] — could literally be anything
3. PF CI: [0.54–4.83] — spans from deeply losing to extremely profitable
4. The MERCURYPROMPT.md claim of PF=25.9 on n=8 is **statistical nonsense**
5. Required sample for ±10% margin of error at 50% WR: **~100 trades**
6. Current sample: **16 trades** (need 6x more)

**Bonds Verdict: ❌ UNINVESTABLE — Insufficient data. Any claim of edge is statistically invalid.**

### User Question: "Low win-rate but maybe better risk-adjusted return?"

**Answer: No.**

- **Commodities:** 43% WR with W/L=1.10. The required W/L for positive expectancy at 43% WR is 1.33. Actual is 1.10 → **fails**. Risk-adjusted metrics (Sharpe=-0.093, PF=0.84) confirm no edge.
- **Bonds:** 50% WR with W/L=1.61 looks good, but N=16 makes this observation meaningless. Could easily reverse with more data.
- **Crypto:** 44% WR with W/L=1.52 IS the counterexample — positive expectancy despite WR<50%. But fees kill it.

> **Conclusion:** WR < 50% does not automatically disqualify an edge (see CRYPTO), but the combination of low WR AND low W/L ratio (Commodities, Forex) is fatal.

---

## TASK 4: RISK-ADJUSTED vs WIN-RATE ANALYSIS

### W/L Threshold Analysis

For positive expectancy at a given win rate, you need: **W/L > (1 – WR) / WR**

| Asset | WR | Required W/L | Actual W/L | Pass? | Expectancy |
|-------|-----|-------------|-----------|-------|------------|
| CRYPTO | 44.3% | 1.26 | **1.52** | ✅ | +0.23% |
| EQUITY | 52.5% | 0.91 | **1.26** | ✅ | +0.62% |
| FOREX | 47.5% | 1.11 | **0.29** | ❌ | -0.99% |
| COMMODITY | 43.0% | 1.33 | **1.10** | ❌ | -0.03% |
| ETF | 56.1% | 0.78 | **0.98** | ✅ | +0.28% |
| BOND | 50.0% | 1.00 | **1.61** | ✅ | +0.18% |

### Which Assets Have Genuine Risk-Adjusted Edge vs. Just Variance?

**Genuine Edge (statistically distinguishable from random):**
1. **EQUITY** — PF=1.39, CI [1.14–1.71] entirely above 1.0. Positive Sharpe (0.165). Net PF survives fees. This is the cleanest edge.

**Marginal / Fragile Edge:**
2. **CRYPTO** — PF=1.21, CI [1.16–1.27] above 1.0. But Net PF=0.94 at 15bps costs. Edge is real but **not tradeable** after realistic costs.
3. **ETF** — PF=1.25, but CI [0.81–2.00] **includes 1.0**. N=82 is marginal. Net PF=1.12 at 7bps. Too uncertain to call.

**No Edge (variance / negative expectancy):**
4. **FOREX** — Deeply negative. Not even close.
5. **COMMODITY** — Statistically losing (CI entirely below 1.0).
6. **BOND** — Insufficient data.
7. **FUTURES** — 2 trades. Meaningless.

### Kelly Fraction (Optimal Bet Sizing)

| Asset | Kelly % | Interpretation |
|-------|---------|---------------|
| CRYPTO | 7.7% | Conservative sizing appropriate |
| EQUITY | 14.8% | Can size larger |
| FOREX | -133% | **NEVER BET** (negative edge) |
| COMMODITY | -8.8% | **NEVER BET** |
| ETF | 11.3% | Moderate sizing |
| BOND | 19.0% | Would be aggressive IF data were sufficient |

> The Kelly fraction tells you the maximum fraction of capital to risk per trade. Negative Kelly means the edge is negative — betting anything loses money in the long run.

---

## TASK 5: STRATEGY DECAY ANALYSIS

### Half-Split Stationarity Results

| Asset | First Half PF | Second Half PF | ΔPF | Permutation p | Assessment |
|-------|---------------|----------------|-----|---------------|------------|
| CRYPTO | 1.25 | 1.17 | -0.08 | 0.097 | 🟡 Trending down |
| EQUITY | 1.63 | 1.19 | -0.44 | 0.083 | 🟡 Significant decay signal |
| FOREX | 0.28 | 0.24 | -0.04 | 0.133 | 🟢 Consistently bad |
| COMMODITY | 0.88 | 0.78 | -0.10 | 0.250 | 🟢 Consistently bad |
| ETF | 1.38 | 1.14 | -0.25 | 0.417 | 🟢 Stable variance |

### Decay Assessment

**1. EQUITY: Decay Signal Detected**
- PF dropped 27% from first half to second half
- Permutation p=0.083 — not formally significant at α=0.05, but **trending**
- The documented edge (Score≥50+Trust≥3, PF=2.62 on n=119) is from a smaller, possibly older subset
- **Concern:** The full dataset (n=373, PF=1.39) shows the edge is already eroding
- **Recommendation:** The EQUITY edge is real but **may be decaying**. Use half-Kelly sizing (7%) and monitor closely.

**2. CRYPTO: Mild Decline**
- PF dropped 6.4% (1.25 → 1.17)
- Permutation p=0.097 — borderline
- Massive sample (7,453 trades) provides stability
- **Primary risk is not decay but fees** (15bps wipes out edge)

**3. ETF, FOREX, COMMODITY: No Decay Detected**
- These show no meaningful trend because they never had edge to begin with
- "Stable" in the sense that they are consistently losing

### The -382.8% Unrealized PnL Crisis

- 21 active trades (15 CRYPTO, 2 EQUITY, 3 FOREX, 1 COMMODITY) are down -382.8%
- This represents **~22% of total historical closed gains** (1,737%)
- Active trades are only 0.6% of total trade count but causing 22% of the pain
- **This is a severe drawdown**, but not necessarily alpha decay

**Possible Explanations:**
1. **Normal drawdown:** Every strategy has losing streaks; this could be within expected variance
2. **Regime change:** Current market conditions differ from historical
3. **Alpha decay:** The signals are being arbitraged away
4. **Overfitting:** The system was optimized on past data that no longer repeats

**Cannot Distinguish Without:**
- Out-of-sample performance of the documented filters
- Time-series of filtered vs. unfiltered performance
- Market regime indicators during active trade periods

### Threshold Validity Assessment

| Filter | Claim Date | Current Status | Verdict |
|--------|-----------|---------------|---------|
| CRYPTO Score≥50+Trust≥3 | 2026-04-14 | Dashboard PF=1.21 (all trades), but fees kill it | ⚠️ MAYBE STALE |
| EQUITY Score≥50+Trust≥3 | 2026-04-14 | Full dataset PF=1.39, below claimed 2.62 | ⚠️ DECAYING |
| FOREX FwdWR≥50 | 2026-04-14 | Base rate PF=0.26, filter artifact | ❌ NEVER REAL |
| COMMODITY Trust≥3 | 2026-04-14 | CI includes 1.0, not significant | ❌ INCONCLUSIVE |

---

## OVERALL EDGE SUMMARY

### Final Verdict Table

| Asset | Edge? | Confidence | Tradeable? | Recommended Action |
|-------|-------|-----------|------------|-------------------|
| **EQUITY** | ✅ YES | MODERATE | YES, with caution | Trade at 50% Kelly (~7% risk), monitor decay |
| **CRYPTO** | 🟡 MARGINAL | HIGH | **NO** at 15bps fees | Only viable if fees < 10bps; otherwise exclude |
| **ETF** | 🟡 BORDERLINE | LOW | MAYBE | Wait for N>100; too uncertain now |
| **FOREX** | ❌ NO | VERY HIGH | NO | **Exclude entirely** — filter artifact, catastrophic base rate |
| **COMMODITY** | ❌ NO | HIGH | NO | **Exclude** — statistically confirmed losing |
| **BOND** | ❌ UNKNOWN | N/A | NO | **Exclude** — insufficient data; collect 100+ trades first |
| **FUTURES** | ❌ UNKNOWN | N/A | NO | **Exclude** — 2 trades, meaningless |

### Key Recommendations

1. **FOCUS ON EQUITY ONLY** — It is the only asset class with a statistically robust, fee-resistant edge
2. **CRYPTO is a trap** — Large sample, marginal edge, but realistic costs wipe it out. Do not trade unless you can achieve <10bps all-in costs
3. **FOREX is a filter artifact** — The documented "edge" is cherry-picking from a catastrophically losing base rate. Do not trust any subset claim without out-of-sample validation
4. **COMMODITIES is statistically losing** — The CI [0.70–0.98] proves this is not variance; it is a negative edge
5. **BONDS and FUTURES need more data** — Any claim of edge is premature
6. **EQUITY edge may be decaying** — Use conservative sizing and track rolling PF. If PF drops below 1.2 for 100 consecutive trades, pause
7. **Address the -382.8% unrealized PnL** — Investigate whether this is normal drawdown or regime change. If active trades close at current losses, total net PnL drops ~38%

### Statistical Rigor Checklist

| Criterion | EQUITY | CRYPTO | FOREX | COMMODITY | ETF | BOND |
|-----------|--------|--------|-------|-----------|-----|------|
| N ≥ 100 | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ |
| PF > 1.2 | ✅ | ✅ | ❌ | ❌ | ✅ | N/A |
| PF CI lower > 1.0 | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| Expectancy > 0 | ✅ | ✅ | ❌ | ❌ | ✅ | ✅ |
| Net PF @ costs > 1.0 | ✅ | ❌ | ❌ | ❌ | ✅ | ✅ |
| Kelly > 0 | ✅ | ✅ | ❌ | ❌ | ✅ | ✅ |
| No decay signal | 🟡 | ✅ | N/A | N/A | ✅ | N/A |
| **TOTAL PASS** | **6/7** | **5/7** | **1/7** | **1/7** | **5/7** | **3/7** |

---

## APPENDIX: METHODOLOGY

### Wilson Score Confidence Interval
Used for binomial proportion (win rate). More accurate than normal approximation for extreme proportions or small samples.

### Bootstrap Profit Factor CI
Generated 5,000 bootstrap resamples from the empirical trade distribution (wins = avg_win, losses = avg_loss). Reported 2.5th and 97.5th percentiles.

### Sharpe & Sortino
Estimated from per-trade return distributions. Sharpe = mean(return) / std(return). Sortino = mean(return) / downside_deviation.

### Fee Haircut
Assumed round-trip fee = 2 × per-side fee in bps. Subtracted from both wins and losses. Recalculated PF and expectancy.

### Half-Split Test
Randomly shuffled trade sequence, split at median. Compared first-half vs second-half PF via t-test and permutation test.

### Kelly Fraction
Kelly = WR – (1 – WR) / WLR. Negative values indicate negative edge.

---

*Report generated via quantitative analysis. All claims backed by statistical computation.*
