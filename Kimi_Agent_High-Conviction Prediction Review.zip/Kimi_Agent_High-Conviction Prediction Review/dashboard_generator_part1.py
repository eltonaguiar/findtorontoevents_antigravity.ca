#!/usr/bin/env python3
"""
Unified Audit Dashboard Generator.
Reads ALL pick/trade/portfolio data sources and outputs a single JSON payload.

Usage:  python -m audit_trail.dashboard_generator

Sources:
  - 30+ JSON pick files (active + closed from all systems)
  - 16 SQLite databases (audit trail, paper trading, KIMI, etc.)
  - Portfolio JSONs and DB tables
  - Baby strategy bundles
  - Audit events and filter logs
"""

import glob
import json
import logging
import math
import os
import re
import sqlite3
import subprocess
import sys
import traceback
import urllib.request
from collections import defaultdict
from datetime import datetime, timezone, timedelta
from pathlib import Path
from urllib.parse import quote

# Trade timeframe classification
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from cross_aggregation.timeframe_classifier import classify_timeframe
from cross_aggregation.performance_alerts import check_all_alerts
try:
    from alpha_engine.risk_policy_loader import load_risk_policy
except Exception:  # pragma: no cover - optional import
    def load_risk_policy(*args, **kwargs):
        return {}

from audit_trail.pnl_ingest_sanity import clamp_pnl_pct_for_pick

# Direction conflict resolver — filters self-hedging LONG+SHORT pairs
try:
    from audit_trail.direction_conflict_resolver import filter_direction_conflicts
    _CONFLICT_RESOLVER_AVAILABLE = True
except ImportError:
    _CONFLICT_RESOLVER_AVAILABLE = False
    def filter_direction_conflicts(picks, strategy="trust_weighted"):
        return picks

# Quality gates for high-quality picks filtering
try:
    from audit_trail.quality_gates import (
        passes_active_gate,
        passes_smart_gate,
        calculate_smart_score,
        classify_pick_quality,
        get_pick_rationale,
        _compute_cross_asset_confluence,
        normalize_exit_reason,
        is_corrupted_outcome_row,
        CRYPTO_MAX_AGE_HOURS,
        NON_CRYPTO_MAX_AGE_HOURS,
    )

    _QUALITY_GATES_AVAILABLE = True
except ImportError as _qge:
    # CRITICAL: If quality_gates fails to import, we MUST NOT silently let
    # all picks through. The fallback implements the absolute minimum safety
    # checks so that corrupt / zero-score picks never reach the dashboard.
    logging.warning("quality_gates import failed: %s — using SAFE fallback", _qge)
    _QUALITY_GATES_AVAILABLE = False
    CRYPTO_MAX_AGE_HOURS = 168
    NON_CRYPTO_MAX_AGE_HOURS = 240
    is_corrupted_outcome_row = lambda p: False  # type: ignore[assignment]

    def passes_active_gate(p):
        """Safe fallback: reject null symbol, missing entry, score <= 0, closed status."""
        if not isinstance(p, dict):
            return False
        symbol = str(p.get("symbol", "") or "").strip()
        if not symbol:
            return False
        status = str(p.get("status", "") or "").upper().strip()
        if status and status not in {"OPEN", "ACTIVE", "PENDING", "LIVE", ""}:
            return False
        entry = float(p.get("entry_price", 0) or 0)
        if entry <= 0:
            return False
        score = float(p.get("score", 0) or 0)
        if score <= 0:
            return False
        return True

    def passes_smart_gate(p):
        return False

    def calculate_smart_score(p):
        return 0

    def classify_pick_quality(p):
        return "ACTIVE"

    def _compute_cross_asset_confluence(all_picks):  # type: ignore
        return {}

    def get_pick_rationale(p):
        return {}

    def normalize_exit_reason(p):  # type: ignore
        return str(p.get("exit_reason") or "UNKNOWN")


ROOT = Path(__file__).resolve().parent.parent
_GHOST_SYSTEMS: set[str] = set()
LOCK_FILE = ROOT / "audit_trail" / "data" / ".generator.lock"
MAX_CLOSED_PICKS = 3500  # v105: bumped to accommodate 365-day audit
RESERVED_TRACK_RECORD_CLOSED_PICKS = 500
RESERVED_NON_CRYPTO_CLOSED_PICKS = 2000  # Guarantee non-crypto picks survive the cap
PAYLOAD_SIZE_WARN_KB = 4096  # Warn if payload exceeds 4MB

# v101: Strip heavy fields from closed picks to reduce payload size
_CLOSED_PICK_KEEP_FIELDS = {
    "symbol", "direction", "strategy", "entry_price", "exit_price", "close_price", "take_profit",
    "stop_loss", "pnl_pct", "net_pnl_pct", "score", "timestamp", "closed_at",
    "exit_reason", "status", "source_system", "asset_class", "category", "confidence",
    "trust_score", "trust_tier", "trade_timeframe", "timeframe", "id",
    "elite_score", "elite_grade", "grade", "forward_wr", "forward_trades",
    "strat_fwd_wr", "strat_fwd_pf", "strat_fwd_trades", "track_record",
    "strong", "wf_verdict", "wf_p_value", "age_hours", "rr_ratio",
    "_direction_conflict", "has_conflict",
    "tv_edge_score", "tv_edge_bonus", "tv_edge_meta",
    "exit_reason_raw",
    # ── At-issue snapshot fields: values at time pick was issued ──
    "at_issue_strat_fwd_wr", "at_issue_strat_fwd_trades",
    "at_issue_trust_score", "at_issue_trust_tier",
    # ── At-issue feed-membership fields (2026-04-20 effectiveness audit
    #    recommendation #2). Retained on closed picks so Smart Picks / HC /
    #    Verified Alpha / Track% cohorts can be audited retroactively. Also
    #    pulls in ml_score (predictive feature) and entry_time (staleness
    #    detection), both flagged as 0% populated by the additional-fixes
    #    survey. ──
    "ml_score", "hf_conviction_tier", "va_cohort_id",
    "sym_track_wr", "paper_trade", "entry_time",
    "is_smart_pick", "is_verified_alpha", "hc_tier",
}


def _slim_closed_pick(pick: dict) -> dict:
    """Strip heavy fields from closed picks to reduce payload size."""
    slim = {k: v for k, v in pick.items() if k in _CLOSED_PICK_KEEP_FIELDS}
    # Truncate reason if present
    reason = pick.get("reason", "")
    if reason and len(str(reason)) > 120:
        slim["reason"] = str(reason)[:120]
    elif reason:
        slim["reason"] = reason
    return slim


def _snapshot_at_issue_for_recent_closed(
    recent_closed: list[dict], *, pre_leaderboard: bool
) -> None:
    """Populate at_issue_* on published closed rows for dashboard delta columns.

    * ``pre_leaderboard=True``: run immediately before the leaderboard merge loop
      copies ``strat_fwd_*`` / ``forward_*`` and any existing trust fields from the
      raw row so post-merge values can be compared to pre-merge.
    * ``pre_leaderboard=False``: run after that loop, immediately before
      ``enrich_picks_with_trust_score(recent_closed)``, to capture ``trust_tier`` /
      ``trust_score`` when they were still missing from the first snapshot.

    See ``updates/2026-04-15-audit-trust-edge-lev-tooltips-closed-snapshot.md``.
    """
    for pick in recent_closed or []:
        if not isinstance(pick, dict):
            continue
        if pre_leaderboard:
            if pick.get("at_issue_strat_fwd_wr") is None:
                v = pick.get("strat_fwd_wr")
                if v is None:
                    v = pick.get("forward_wr")
                if v is not None:
                    pick["at_issue_strat_fwd_wr"] = v
            if pick.get("at_issue_strat_fwd_trades") is None:
                v = pick.get("strat_fwd_trades")
                if v is None:
                    v = pick.get("forward_trades")
                if v is not None:
                    pick["at_issue_strat_fwd_trades"] = int(v)
            if pick.get("at_issue_trust_score") is None and pick.get(
                "trust_score"
            ) is not None:
                pick["at_issue_trust_score"] = pick["trust_score"]
            tt = pick.get("trust_tier")
            if pick.get("at_issue_trust_tier") is None and tt:
                pick["at_issue_trust_tier"] = str(tt).strip()
        else:
            tt = pick.get("trust_tier")
            if pick.get("at_issue_trust_tier") is None and tt:
                pick["at_issue_trust_tier"] = str(tt).strip()
            if pick.get("at_issue_trust_score") is None and pick.get(
                "trust_score"
            ) is not None:
                pick["at_issue_trust_score"] = pick["trust_score"]


UNIVERSAL_RESOLVER_MAX_AGE_MINUTES = 30
UNIVERSAL_RESOLVER_WATCH_FILES = (
    "predictions/data/active_predictions.json",
    "rapid_fire_data/active_picks.json",
    "quan_engine/data/active_signals.json",
)


def _write_text_file(path: Path, text: str) -> None:
    """Atomic text write — writes to temp file in same directory, then os.replace.

    2026-04-17 (per dashboard_payload_health + low_score_tracker failure reports):
    concurrent readers were hitting JSONDecodeError mid-write on the 25MB payload
    file. Switch to temp-file + os.replace for cross-process safety. Same pattern
    as alpha_engine/atomic_json.atomic_write_json (which we don't import directly
    here to avoid a circular: dashboard_generator is imported by many paths).
    """
    import os as _os
    import tempfile as _tempfile
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = _tempfile.NamedTemporaryFile(
        mode="w", dir=str(path.parent), prefix=path.name + ".",
        suffix=".tmp", delete=False, encoding="utf-8", newline="\n",
    )
    try:
        tmp.write(text)
        tmp.flush()
        try:
            _os.fsync(tmp.fileno())
        except OSError:
            pass  # not fatal on some filesystems
        tmp.close()
        _os.replace(tmp.name, path)
    except Exception:
        try:
            tmp.close()
        except Exception:
            pass
        try:
            _os.unlink(tmp.name)
        except OSError:
            pass
        raise


def _git_head_meta(repo_root: Path) -> tuple[str | None, str | None, str | None]:
    """Return (sha, commit_iso_utc, error). Never raises."""
    try:
        sha = subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=str(repo_root), text=True
        ).strip()
        ts = subprocess.check_output(
            ["git", "log", "-1", "--format=%cI"], cwd=str(repo_root), text=True
        ).strip()
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return sha, dt.astimezone(timezone.utc).isoformat(), None
    except Exception as e:  # pragma: no cover - non-fatal metadata path
        return None, None, str(e)


def _compute_payload_lag_seconds(generated_at_iso: str, commit_iso: str | None) -> float | None:
    if not generated_at_iso or not commit_iso:
        return None
    try:
        g = datetime.fromisoformat(str(generated_at_iso).replace("Z", "+00:00"))
        c = datetime.fromisoformat(str(commit_iso).replace("Z", "+00:00"))
        if g.tzinfo is None:
            g = g.replace(tzinfo=timezone.utc)
        if c.tzinfo is None:
            c = c.replace(tzinfo=timezone.utc)
        return (g.astimezone(timezone.utc) - c.astimezone(timezone.utc)).total_seconds()
    except Exception:
        return None


def _pick_pnl_pct(pick: dict) -> float | None:
    """Best-effort extraction of pnl% for active/closed picks."""
    for k in ("pnl_pct", "unrealized_pnl_pct", "realized_pnl_pct"):
        v = pick.get(k)
        if v is not None:
            try:
                return float(v)
            except (TypeError, ValueError):
                continue
    entry = pick.get("entry_price") or pick.get("entry")
    live = pick.get("current_price") or pick.get("last_price") or pick.get("live")
    try:
        e = float(entry)
        l = float(live)
    except (TypeError, ValueError):
        return None
    if e <= 0:
        return None
    return ((l - e) / e) * 100.0


def _summarize_big_movers(active: list[dict], closed: list[dict], threshold_pct: float = 3.0) -> dict:
    def _collect(rows: list[dict], cohort: str) -> list[dict]:
        out = []
        for p in rows:
            if not isinstance(p, dict):
                continue
            pnl = _pick_pnl_pct(p)
            if pnl is None or abs(pnl) < threshold_pct:
                continue
            out.append(
                {
                    "symbol": str(p.get("symbol") or ""),
                    "asset_class": str(p.get("asset_class") or p.get("category") or "UNKNOWN").upper(),
                    "strategy": str(p.get("strategy") or p.get("source_system") or "unknown").lower(),
                    "system": str(p.get("source_system") or p.get("system") or "unknown").lower(),
                    "pnl_pct": round(float(pnl), 4),
                    "cohort": cohort,
                }
            )
        return out

    records = _collect(active, "active") + _collect(closed, "closed")
    winners = [r for r in records if r["pnl_pct"] > 0]
    losers = [r for r in records if r["pnl_pct"] < 0]

    def _rollup(rows: list[dict], key: str) -> dict:
        bucket = defaultdict(lambda: {"count": 0, "avg_pnl_pct": 0.0})
        for r in rows:
            b = bucket[str(r.get(key) or "unknown")]
            b["count"] += 1
            b["avg_pnl_pct"] += float(r["pnl_pct"])
        out = {}
        for name, agg in bucket.items():
            count = int(agg["count"])
            out[name] = {
                "count": count,
                "avg_pnl_pct": round(float(agg["avg_pnl_pct"]) / max(1, count), 4),
            }
        return out

    winners.sort(key=lambda x: x["pnl_pct"], reverse=True)
    losers.sort(key=lambda x: x["pnl_pct"])
    return {
        "threshold_pct": threshold_pct,
        "total_movers": len(records),
        "winners": len(winners),
        "losers": len(losers),
        "top_winners": winners[:25],
        "top_losers": losers[:25],
        "winners_by_strategy": _rollup(winners, "strategy"),
        "losers_by_strategy": _rollup(losers, "strategy"),
        "winners_by_system": _rollup(winners, "system"),
        "losers_by_system": _rollup(losers, "system"),
        "winners_by_asset_class": _rollup(winners, "asset_class"),
        "losers_by_asset_class": _rollup(losers, "asset_class"),
    }


def _concentration_summary_from_active(active: list[dict]) -> dict:
    total = len(active)
    if total <= 0:
        return {
            "total_active": 0,
            "top_symbol_share_pct": 0.0,
            "top_strategy_share_pct": 0.0,
            "top_system_share_pct": 0.0,
        }

    by_symbol = defaultdict(int)
    by_strategy = defaultdict(int)
    by_system = defaultdict(int)
    for p in active:
        if not isinstance(p, dict):
            continue
        by_symbol[str(p.get("symbol") or "").upper()] += 1
        by_strategy[str(p.get("strategy") or p.get("source_system") or "unknown").lower()] += 1
        by_system[str(p.get("source_system") or p.get("system") or "unknown").lower()] += 1

    def _top_share(bucket: dict) -> tuple[str, int, float]:
        if not bucket:
            return "", 0, 0.0
        name, count = max(bucket.items(), key=lambda x: x[1])
        return str(name), int(count), round((float(count) / max(1, total)) * 100.0, 2)

    sym_name, sym_count, sym_share = _top_share(by_symbol)
    strat_name, strat_count, strat_share = _top_share(by_strategy)
    sys_name, sys_count, sys_share = _top_share(by_system)
    return {
        "total_active": total,
        "top_symbol": {"name": sym_name, "count": sym_count, "share_pct": sym_share},
        "top_strategy": {"name": strat_name, "count": strat_count, "share_pct": strat_share},
        "top_system": {"name": sys_name, "count": sys_count, "share_pct": sys_share},
    }


def _probation_quarantine_summary(smart_picks_feed: dict) -> dict:
    picks = smart_picks_feed.get("picks") if isinstance(smart_picks_feed, dict) else []
    picks = picks if isinstance(picks, list) else []
    excluded = smart_picks_feed.get("excluded_reasons") if isinstance(smart_picks_feed, dict) else {}
    excluded = excluded if isinstance(excluded, dict) else {}
    control = smart_picks_feed.get("concentration_probation_stats") if isinstance(smart_picks_feed, dict) else {}
    control = control if isinstance(control, dict) else {}

    quarantine_counts = defaultdict(int)
    probation_count = 0
    for p in picks:
        if not isinstance(p, dict):
            continue
        q = str(p.get("quarantine") or "").strip().lower()
        if q:
            quarantine_counts[q] += 1
        if p.get("probation_flag"):
            probation_count += 1

    total_picks = len([p for p in picks if isinstance(p, dict)])
    return {
        "total_smart_picks": total_picks,
        "quarantine_counts": dict(quarantine_counts),
        "probation_tagged_in_output": probation_count,
        "probation_filtered_count": int(excluded.get("probation_concentration", 0) or 0),
        "non_crypto_probation_filtered": int(excluded.get("non_crypto_probation", 0) or 0),
        "concentration_controls": control,
    }

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)
log = logging.getLogger("audit_dashboard")

# ── Trust registry for conflict resolution ──
try:
    from cross_aggregation.system_trust_registry import (
        get_tier,
        get_vote_weight,
        resolve_conflict,
        normalize_system_name,
    )

    _TRUST_AVAILABLE = True
except ImportError:
    _TRUST_AVAILABLE = False

    def get_tier(s):
        return "WATCH"

    def get_vote_weight(s):
        return 1.0

    def resolve_conflict(l, s):
        return ("CONTESTED", "Trust registry unavailable", 0.0)

    def normalize_system_name(s):
        return s


_EQUITY_SYMBOLS = {
    "SPY", "QQQ", "AAPL", "MSFT", "GOOGL", "GOOG", "AMZN", "TSLA", "META", "NVDA", "AMD", "NFLX",
    "DIS", "BA", "JPM", "GS", "V", "MA", "PYPL", "SQ", "COIN", "MSTR", "RIOT", "MARA", "HUT", "BITF",
    "IWM", "DIA", "VTI", "VOO", "ARKK", "XLF", "XLE", "XLK", "GLD", "SLV", "USO", "TLT", "VIX",
    "UVXY", "SQQQ", "TQQQ", "INTC", "CSCO", "ORCL", "ADBE", "CRM", "SAP", "ASML", "AVGO", "TXN",
    "QCOM", "MU", "AMAT", "LRCX", "ADI", "KLAC", "SNPS", "CDNS", "MRVL", "NXPI", "MCHP", "ON",
    "TER", "ENTP", "SMH", "SOXX", "XBI", "KRE", "GDX", "GDXJ", "TLT", "SHV", "IEI", "IEF", "TLH",
    "BIL", "VGK", "EWJ", "EEM", "EFA", "VWO", "IYW", "IYT", "IBB", "XOP", "XRT", "XME", "XHB",
    "XLP", "XLV", "XLY", "XLU", "XLB", "XLI", "VGT", "VFH", "VNQ", "VNQI", "SCHD", "VYM", "DGRO",
    "IBM", "ORCL", "CSCO", "INTC", "QCOM", "TXN", "MU", "AMD", "ADI", "LRCX", "AMAT", "KLAC",
    "SNPS", "CDNS", "PANW", "FTNT", "CRWD", "DDOG", "NET", "SNOW", "PLTR", "ZS", "OKTA", "NET",
    "SHOP", "SQ", "U", "TWLO", "DOCU", "ZM", "PYPL", "V", "MA", "AXP", "DFS", "COF", "JPM",
    "BAC", "WFC", "C", "GS", "MS", "BLK", "SCHW", "TROW", "KRE", "KBE", "XLF", "XLI", "XLY",
    "CAT", "DE", "HON", "GE", "UPS", "FDX", "MMM", "LMT", "RTX", "NOC", "GD", "BA", "JNJ",
    "UNH", "PFE", "ABBV", "BMY", "MRK", "MRNA", "AMGEN", "GILD", "VRTX", "ISRG", "TMO", "DHR",
    "ABT", "MDT", "SYK", "STR", "ZTS", "PG", "KO", "PEP", "COST", "WMT", "TGT", "PM", "MO",
    "MDLZ", "CL", "KMB", "HSY", "STZ", "XLP", "XLU", "XLE", "XOP", "XME", "FCX", "NEM", "GOLD",
    "EUG", "OXY", "CVX", "XOM", "COP", "SLB", "HAL", "MPC", "PSX", "VLO",
    "SOFI", "NIO", "AMC", "GME", "RIVN", "LCID", "GRAB", "SE", "BABA", "JD", "PDD", "LI", "XPEV",
}


def _normalize_symbol(sym: str) -> str:
    """Normalize symbol strings so BTC-USD, BTCUSD, BTCUSDT all become BTCUSDT.

    Handles:
      - Crypto: BTC-USD → BTCUSDT, BTC/USD → BTCUSDT, BTC-USDT → BTCUSDT
      - Equity: SPY, QQQ, AAPL stay as-is (no suffix mangling)
      - Forex: EURUSD=X → EURUSD, GBPJPY=X → GBPJPY
      - Stablecoins: BTCBUSD stays BTCBUSD, ETHUSDC stays ETHUSDC
    """
    if not sym:
        return sym
    s = sym.strip().upper()
    if not s:
        return s

    # Strip Yahoo Finance suffix (=X for forex)
    if s.endswith("=X"):
        s = s[:-2]

    # Remove separators
    s = s.replace("-", "").replace("_", "").replace("/", "")

    # Known equity/index symbols — don't append crypto suffixes
    if s in _EQUITY_SYMBOLS:
        return s

    # Known forex pairs (6 chars, no crypto suffix) — don't append USDT
    _FOREX_BASES = {
        "EUR",
        "GBP",
        "JPY",
        "AUD",
        "NZD",
        "CAD",
        "CHF",
        "SGD",
        "HKD",
        "NOK",
        "SEK",
        "DKK",
        "ZAR",
        "MXN",
        "TRY",
        "CNY",
        "CNH",
        "INR",
    }
    if len(s) == 6:
        base, quote = s[:3], s[3:]
        if base in _FOREX_BASES or quote in _FOREX_BASES:
            # It's a forex pair like EURUSD, GBPJPY — keep as-is
            if (
                base == "USD"
                or quote == "USD"
                or (base in _FOREX_BASES and quote in _FOREX_BASES)
            ):
                return s

    # Crypto normalization: ensure consistent suffix
    # If ends with USD but not USDT, append T (BTC-USD → BTCUSD → BTCUSDT)
    if s.endswith("USD") and not s.endswith("USDT") and not s.endswith("BUSD"):
        s += "T"

    return s


# Multi-asset / UI labels that map to canonical survivor leaderboard keys
_STRATEGY_BT_ALIAS_TO_CANONICAL: dict[str, str] = {
    "multi_asset_futures_connors_rsi2": "connors_rsi2",
}



# ── ML strategy grouping ──
# ML sub-strategies like "ml_enhanced_BTCUSDT_1h_B_lightgbm" have only 1-2 trades
# each, making individual forward stats meaningless. We group them into
# "ml_enhanced_group" (and similar) so picks inherit meaningful aggregate stats.
_ML_GROUP_PATTERNS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"^ml_enhanced_", re.IGNORECASE), "ml_enhanced_group"),
    (re.compile(r"^ml_crypto_predictor", re.IGNORECASE), "ml_crypto_predictor_group"),
]


def _ml_group_name(strategy: str) -> str | None:
    """Return the ML group name for an ML sub-strategy, or None if not an ML strat.

    E.g. "ml_enhanced_BTCUSDT_1h_B_lightgbm" -> "ml_enhanced_group".
    """
    if not strategy:
        return None
    for pat, group in _ML_GROUP_PATTERNS:
        if pat.match(strategy):
            return group
    return None


def _normalize_strategy_tooltip_key(name: str) -> str:
    """Match audit_dashboard/template.html normalizeStrategyName (collapse _- and space)."""
    if not name:
        return ""
    return re.sub(r"[_\-\s]+", "", name.lower()).strip()


def _leaderboard_name_candidates_for_pick(pick: dict, strat_name: str) -> list[str]:
    """Ordered keys to resolve collect_strategy_leaderboard rows (display label vs id prefix)."""
    out: list[str] = []
    seen: set[str] = set()

    def add(x: str) -> None:
        x = (x or "").strip()
        if not x or x in seen:
            return
        seen.add(x)
        out.append(x)

    add(strat_name)
    pid = str(pick.get("id") or "")
    if "::" in pid:
        prefix = pid.split("::", 1)[0].strip()
        if prefix and re.match(r"^[A-Za-z][A-Za-z0-9_]*$", prefix):
            add(prefix)
    for key in list(out):
        alias = _STRATEGY_BT_ALIAS_TO_CANONICAL.get(key)
        if alias:
            add(alias)
    # ML group fallback: if strategy is an ML sub-strategy,
    # also try the ML group name (e.g. "ml_enhanced_group")
    ml_group = _ml_group_name(strat_name)
    if ml_group:
        add(ml_group)

    return out


def _resolve_leaderboard_row(strat_lookup: dict, pick: dict, strat_name: str) -> dict:
    for cand in _leaderboard_name_candidates_for_pick(pick, strat_name):
        row = strat_lookup.get(cand)
        if row:
            return row
        nk = _normalize_strategy_tooltip_key(cand)
        if nk:
            row = strat_lookup.get(nk)
            if row:
                return row
    return {}


_OPEN_ACTIVE_STATUSES = {"", "OPEN", "ACTIVE", "PENDING", "LIVE"}


def _is_active_pick(pick: dict) -> bool:
    status = str(pick.get("status", "") or "").upper().strip()
    return status in _OPEN_ACTIVE_STATUSES


def _has_tradeable_entry(pick: dict) -> bool:
    entry = _float(pick.get("entry_price", 0))
    return entry > 0


def _extract_freshness_timestamp_str(pick: dict) -> str:
    """Best-effort timestamp for staleness; aligns with quality_gates age fields."""
    if not isinstance(pick, dict):
        return ""
    for key in (
        "timestamp",
        "entry_time",
        "created_at",
        "generated_at",
        "entry_time_est",
        "signal_time",
        "opened_at",
        "entryDate",
    ):
        v = pick.get(key)
        if v is not None and str(v).strip():
            return str(v).strip()
    return ""


def _parse_pick_timestamp_utc(ts_raw: str):
    """Return aware UTC datetime or None."""
    if not ts_raw or not str(ts_raw).strip():
        return None
    _tz_map = {
        "EST": "-05:00",
        "EDT": "-04:00",
        "CST": "-06:00",
        "CDT": "-05:00",
        "PST": "-08:00",
        "PDT": "-07:00",
        "UTC": "+00:00",
    }
    try:
        ts_clean = ts_raw.strip()
        for abbr, offset in _tz_map.items():
            if ts_clean.endswith(" " + abbr):
                ts_clean = ts_clean[: -len(abbr) - 1].strip() + offset
                break
        ts_clean = ts_clean.replace("Z", "+00:00")
        if "+" not in ts_clean and "-" not in ts_clean[10:] and len(ts_clean) >= 19:
            ts_clean += "+00:00"
        if " " in ts_clean and "T" not in ts_clean:
            ts_clean = ts_clean.replace(" ", "T")
            if "+" not in ts_clean and "-" not in ts_clean[10:]:
                ts_clean += "+00:00"
        pick_time = datetime.fromisoformat(ts_clean)
        if pick_time.tzinfo is None:
            pick_time = pick_time.replace(tzinfo=timezone.utc)
        return pick_time
    except (ValueError, TypeError, IndexError):
        return None


_HARD_BLOCKED_TRUST_TIERS = {"BANNED", "AVOID"}
_HARD_BLOCKED_TRUST_LABELS = {"BANNED", "AVOID"}


def _is_pre_score_active_candidate(pick: dict) -> bool:
    """Keep scorable active candidates alive until score-based gates can run.

    passes_active_gate() enforces final score floors, so calling it before
    elite scoring/score_booster collapses the active book prematurely.
    Trust-tier/label BANNED/AVOID picks are hard-blocked here regardless of
    score stage — trust is system-level metadata, not pick-derived.
    """
    trust_tier = str(pick.get("trust_tier", "") or "").strip().upper()
    trust_label = str(pick.get("trust_label", "") or "").strip().upper()
    if trust_tier in _HARD_BLOCKED_TRUST_TIERS or trust_label in _HARD_BLOCKED_TRUST_LABELS:
        return False
    strategy = str(pick.get("strategy", "") or "").strip().lower()
    return bool(strategy) and strategy not in {"", "none", "null", "unknown"}


def _extract_normalized_source_scores(raw: dict, source_system: str) -> dict:
    """Preserve upstream scoring metadata without mistaking probabilities for scores."""
    source_key = str(source_system or "").lower()

    def _rounded_positive(value, digits: int = 2):
        parsed = _float(value)
        return round(parsed, digits) if parsed > 0 else None

    ml_composite_score = _rounded_positive(raw.get("ml_composite_score"), 1)
    elite_score = _rounded_positive(raw.get("elite_score"), 1)
    method_a_score = _rounded_positive(raw.get("method_a_score"), 1)

    # Some feeds use `score` for a 0-100 display score, others use it as a 0-1
    # probability. Only preserve obviously score-scaled values here.
    raw_score_val = _float(raw.get("score"))
    score = None
    for candidate in (ml_composite_score, elite_score, method_a_score):
        if candidate is not None:
            score = candidate
            break
    if score is None and raw_score_val >= 10:
        score = round(raw_score_val, 1)

    # KIMI emits integer confluence scores (50/65/etc.), while other systems use
    # low decimal multipliers. Only lift the KIMI-style integer scores.
    confluence_score = _rounded_positive(raw.get("confluence_score"), 1)
    if (
        score is None
        and source_key in {"kimi_riseoftheclaw", "riseoftheclaw", "kimi_live_signals"}
        and confluence_score is not None
        and confluence_score >= 10
    ):
        score = confluence_score

    source_grade = (
        raw.get("grade")
        or raw.get("ml_composite_grade")
        or raw.get("elite_grade")
        or raw.get("method_a_grade")
    )

    return {
        "score": score,
        "elite_score": elite_score,
        "ml_score": _rounded_positive(raw.get("ml_score"), 4),
        "ml_composite_score": ml_composite_score,
        "method_a_score": method_a_score,
        "precursor_score": _rounded_positive(raw.get("precursor_score"), 1),
        "confluence_score": confluence_score,
        "safety_score": _rounded_positive(raw.get("safety_score"), 1),
        "elite_grade": str(source_grade) if source_grade else None,
        "grade": str(source_grade) if source_grade else None,
        "trust_label": raw.get("trust_label") or raw.get("trust_level"),
        "trust_tier": raw.get("trust_tier"),
        "_source_score_breakdown": raw.get("ml_composite_breakdown")
        or raw.get("elite_breakdown"),
    }


# ── External Source Quality Gates ──
# These gates apply to picks from external sources (contrarian_consensus, tsmom, genome, etc.)
# that bypass the production_scanner pipeline. They ensure basic quality standards.

# External sources that bypass production_scanner (from HANDOFF_OPUS_SESSION.MD)
_EXTERNAL_SOURCES = {
    "contrarian_consensus",
    "contrarian",
    "tsmom",
    "genome",
    "genetic_programmer",
    "audit_ensemble",
    "mape_evolver",
    "ensemble_evolver",
    "neat_neural",
    "hyperparam_dna",
    "failure_evolver",
    "momentum_evolver",
    "multitf_evolver",
    "contrarian_evolver",
    "macd_dna_mutations",
    "mutation_lab",
    "short_engine",
}

# R:R floor — below this we tag _low_rr but don't hard-block
_EXTERNAL_RR_FLOOR = 0.8
# Stale threshold — picks older than this get _stale tag + score penalty
_EXTERNAL_STALE_DAYS = 7
_EXTERNAL_STALE_SCORE_PENALTY = 30

# Lazy-loaded kill list from core_whitelist.json (populated on first call)
_ext_kill_set_cache = None


def _load_external_kill_set():
    """Load kill list from core_whitelist.json, cache for reuse."""
    global _ext_kill_set_cache
    if _ext_kill_set_cache is not None:
        return _ext_kill_set_cache
    _ext_kill_set_cache = set()
    try:
        kl_path = (
            Path(__file__).resolve().parent.parent
            / "alpha_engine"
            / "data"
            / "core_whitelist.json"
        )
        if kl_path.exists():
            kl_data = json.loads(kl_path.read_text(encoding="utf-8", errors="replace"))
            core_strats = {s.lower() for s in kl_data.get("core_strategies", [])}
            for s in kl_data.get("kill_list", []):
                _ext_kill_set_cache.add(s.lower())
                # Also add the bare name after :: prefix, unless it's a core strategy
                if "::" in s:
                    bare = s.split("::", 1)[1].lower()
                    if bare not in core_strats:
                        _ext_kill_set_cache.add(bare)
    except Exception as e:
        log.warning("[DASHBOARD GATE] Failed to load kill list: %s", e)
    return _ext_kill_set_cache


def _apply_external_source_gate(pick: dict, source_system: str):
    """
    Lightweight quality gate for external source picks that bypass production_scanner.

    Instead of hard-blocking on R:R / staleness, this gate:
      - Removes picks from killed strategies (returns "killed")
      - Tags _low_rr if R:R > 0 but < 0.8
      - Normalizes confidence (>1.0 divide by 100, cap at 0.95)
      - Tags _stale and reduces score by 30 if age > 7 days

    Returns: (action, reason)
      action = "pass" | "killed" | "tagged"
      reason = human-readable explanation
    """
    # Only apply to known external sources
    if source_system not in _EXTERNAL_SOURCES:
        return "pass", "not external source"

    tags = []

    # 1. Kill list filter — load from core_whitelist.json
    kill_set = _load_external_kill_set()
    strategy = str(pick.get("strategy", "") or "").lower()
    # Strip :: prefix for matching (e.g. "aggregated_picks::foo" -> "foo")
    bare_strategy = strategy.split("::")[-1] if "::" in strategy else strategy
    if strategy in kill_set or bare_strategy in kill_set:
        return "killed", f"strategy '{pick.get('strategy')}' in kill list"

    # 2. Confidence normalization — before any confidence-based checks
    conf = _float(pick.get("confidence", 0))
    if conf > 1.0:
        conf = conf / 100.0
    conf = min(conf, 0.95)
    pick["confidence"] = round(conf, 4)

    # 3. R:R floor — tag but don't hard-block
    rr = _float(pick.get("rr_ratio", 0))
    if rr <= 0:
        # Compute from entry/tp/sl if rr_ratio not set
        entry = _float(pick.get("entry_price", 0))
        tp = _float(pick.get("take_profit", 0))
        sl = _float(pick.get("stop_loss", 0))
        if entry > 0 and tp > 0 and sl > 0 and abs(entry - sl) > 0:
            rr = abs(tp - entry) / abs(entry - sl)
    # Cap R:R at 10 — values above indicate SL too close to entry (data quality issue)
    if rr > 10.0:
        rr = 10.0
        pick["rr_ratio"] = 10.0
    if 0 < rr < _EXTERNAL_RR_FLOOR:
        pick["_low_rr"] = True
        tags.append(f"low_rr={rr:.2f}")

    # 4. Stale pick filter — age > 7 days
    age_hours = pick.get("age_hours")
    if age_hours is not None and age_hours > _EXTERNAL_STALE_DAYS * 24:
        pick["_stale"] = True
        # Reduce score by penalty (score may be set later; store penalty for downstream)
        existing_score = _float(pick.get("score", 0))
        if existing_score > 0:
            pick["score"] = max(0, existing_score - _EXTERNAL_STALE_SCORE_PENALTY)
        pick["_stale_penalty"] = _EXTERNAL_STALE_SCORE_PENALTY
        tags.append(f"stale={age_hours:.0f}h")

    if tags:
        return "tagged", ", ".join(tags)
    return "pass", "all checks passed"


# ── Live price enrichment for active picks ──
def _fetch_prices_with_failover(crypto_symbols: set) -> dict:
    """Fetch prices from multiple APIs with failover. Returns {SYMBOL: price}.

    Strategy: try Binance first (all endpoints), then fill remaining gaps with
    CoinGecko.  Never return early after partial results — always attempt to
    fill every requested symbol.
    """
    prices = {}

    # ── k-prefix / 1000-prefix mapping ──
    # Some systems emit kPEPEUSDT (= PEPEUSDT * 1000) or 1000SHIBUSDT.
    # Binance lists 1000PEPEUSDT, 1000SHIBUSDT, 1000FLOKIUSDT natively.
    _K_PREFIX_MAP = {}  # kPEPEUSDT -> PEPEUSDT  (multiply by 1000 later)
    _1000_PREFIX_MAP = {}  # 1000SHIBUSDT -> SHIBUSDT (divide by 1000 later)
    _binance_syms = set()  # what we actually request from Binance

    for sym in crypto_symbols:
        if (
            sym.startswith("K")
            and len(sym) > 5
            and sym[1:].replace("USDT", "").isalpha()
        ):
            # kPEPEUSDT → Binance has 1000PEPEUSDT; we also try the base
            base = sym[1:]  # PEPEUSDT
            binance_1000 = "1000" + base  # 1000PEPEUSDT
            _K_PREFIX_MAP[sym] = (base, binance_1000)
            _binance_syms.add(base)
            _binance_syms.add(binance_1000)
        elif sym.startswith("1000") and len(sym) > 8:
            base = sym[4:]  # SHIBUSDT
            _1000_PREFIX_MAP[sym] = base
            _binance_syms.add(sym)  # Binance lists 1000SHIBUSDT natively
            _binance_syms.add(base)  # also try the base
        else:
            _binance_syms.add(sym)

    # 1. Try Binance endpoints (primary + vision)
    _binance_all = {}  # cache ALL Binance prices for prefix lookups
    for base_url in (
        "https://api.binance.com",
        "https://data-api.binance.vision",
        "https://api.binance.us",
    ):
        if len(prices) >= len(crypto_symbols):
            break
        try:
            url = f"{base_url}/api/v3/ticker/price"
            req = urllib.request.Request(
                url, headers={"User-Agent": "AuditDashboard/1.0"}
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())
            for item in data:
                s = item.get("symbol", "")
                p = float(item.get("price", 0))
                if p > 0:
                    _binance_all[s] = p
                    if s in _binance_syms and s not in prices:
                        prices[s] = p
            log.info(
                "Fetched from %s: %d prices cached, %d matched so far",
                base_url,
                len(_binance_all),
                len(prices),
            )
            break  # one successful Binance endpoint is enough
        except Exception as e:
            log.warning("Binance %s failed: %s", base_url, e)

    # Resolve k-prefix and 1000-prefix symbols from Binance cache
    for orig_sym, (base_sym, binance_1000) in _K_PREFIX_MAP.items():
        if orig_sym in prices:
            continue
        # kPEPEUSDT: try 1000PEPEUSDT (price / 1000) or PEPEUSDT directly
        if binance_1000 in _binance_all:
            prices[orig_sym] = _binance_all[binance_1000] / 1000.0
        elif base_sym in _binance_all:
            prices[orig_sym] = _binance_all[base_sym]

    for orig_sym, base_sym in _1000_PREFIX_MAP.items():
        if orig_sym in prices:
            continue
        # 1000SHIBUSDT: Binance has it natively
        if orig_sym in _binance_all:
            prices[orig_sym] = _binance_all[orig_sym]
        elif base_sym in _binance_all:
            prices[orig_sym] = _binance_all[base_sym] * 1000.0

    # Also map any direct Binance hits back to the original requested symbols
    for sym in crypto_symbols:
        if sym not in prices and sym in _binance_all:
            prices[sym] = _binance_all[sym]

    # 2. CoinGecko for remaining symbols (always attempted for gaps)
    missing = crypto_symbols - set(prices.keys())
    if missing:
        try:
            _CG_MAP = {
                "BTCUSDT": "bitcoin",
                "ETHUSDT": "ethereum",
                "SOLUSDT": "solana",
                "BNBUSDT": "binancecoin",
                "XRPUSDT": "ripple",
                "DOGEUSDT": "dogecoin",
                "ADAUSDT": "cardano",
                "AVAXUSDT": "avalanche-2",
                "DOTUSDT": "polkadot",
                "LINKUSDT": "chainlink",
                "MATICUSDT": "matic-network",
                "LTCUSDT": "litecoin",
                "NEARUSDT": "near",
                "ATOMUSDT": "cosmos",
                "APTUSDT": "aptos",
                "ARBUSDT": "arbitrum",
                "OPUSDT": "optimism",
                "SUIUSDT": "sui",
                "TRXUSDT": "tron",
                "SHIBUSDT": "shiba-inu",
                "PEPEUSDT": "pepe",
                "RENDERUSDT": "render-token",
                "FETUSDT": "fetch-ai",
                "INJUSDT": "injective-protocol",
                "FILUSDT": "filecoin",
                "GALAUSDT": "gala",
                "WLDUSDT": "worldcoin-wld",
                "HYPEUSDT": "hyperliquid",
                "TAOUSDT": "bittensor",
                "KASUSDT": "kaspa",
                "ONDOUSDT": "ondo-finance",
                "ICPUSDT": "internet-computer",
                "XLMUSDT": "stellar",
                "ETCUSDT": "ethereum-classic",
                # Extended map for commonly missing symbols
                "IPUSDT": "story-protocol",
                "TONUSDT": "the-open-network",
                "RUNEUSDT": "thorchain",
                "PENDLEUSDT": "pendle",
                "BERAUSDT": "berachain-bera",
                "MNTUSDT": "mantle",
                "XMRUSDT": "monero",
                "DYDXUSDT": "dydx-chain",
                "GMXUSDT": "gmx",
                "JUPUSDT": "jupiter-exchange-solana",
                "WUSDT": "wormhole",
                "STXUSDT": "blockstack",
                "TIAUSDT": "celestia",
                "SEIUSDT": "sei-network",
                "MANTAUSDT": "manta-network",
                "ZETAUSDT": "zetachain",
                "PYTHUSDT": "pyth-network",
                "JTOUSDT": "jito-governance-token",
                "BLURUSDT": "blur",
                "STRKUSDT": "starknet",
                "ZKUSDT": "zksync",
                "EIGENUSDT": "eigenlayer",
                "ENAUSDT": "ethena",
                "AEVOUSDT": "aevo-exchange",
                "WIFUSDT": "dogwifcoin",
                "BOMEUSDT": "book-of-meme",
                "PEOPLEUSDT": "constitutiondao",
                "MOVRUSDT": "moonriver",
                "MOVEUSDT": "movement",
                "LAYERUSDT": "solayer",
                "ORCAUSDT": "orca",
                "POLUSDT": "matic-network",
                "FLOKIUSDT": "floki",
                "BONKUSDT": "bonk",
                "ORDIUSDT": "ordinals",
                "AKTUSDT": "akash-network",
                "ARUSDT": "arweave",
                "RNDRUSDT": "render-token",
                "AGIXUSDT": "singularitynet",
                "OCEANUSDT": "ocean-protocol",
                "CFXUSDT": "conflux-token",
                "EGLDUSDT": "elrond-erd-2",
                "FLOWUSDT": "flow",
                "SANDUSDT": "the-sandbox",
                "MANAUSDT": "decentraland",
                "AXSUSDT": "axie-infinity",
                "CRVUSDT": "curve-dao-token",
                "MKRUSDT": "maker",
                "COMPUSDT": "compound-governance-token",
                "SNXUSDT": "havven",
                "LDOUSDT": "lido-dao",
                "RPLETH": "rocket-pool",
                "FTMUSDT": "fantom",
                "ALGOUSDT": "algorand",
                "VETUSDT": "vechain",
                "THETAUSDT": "theta-token",
                "QNTUSDT": "quant-network",
                "HBARUSDT": "hedera-hashgraph",
                "XTZUSDT": "tezos",
                "EOSUSDT": "eos",
                "IOTAUSDT": "iota",
                "KLAYUSDT": "klay-token",
                "LRCUSDT": "loopring",
                "APEUSDT": "apecoin",
                "CHZUSDT": "chiliz",
                "IMXUSDT": "immutable-x",
                "RONINUSDT": "ronin",
                "SUPERUSDT": "superfarm",
            }
            needed_ids = []
            id_to_sym = {}
            for sym in missing:
                cg_id = _CG_MAP.get(sym)
                if cg_id and cg_id not in id_to_sym:
                    needed_ids.append(cg_id)
                    id_to_sym[cg_id] = sym
            if needed_ids:
                # CoinGecko allows ~250 IDs per request; batch in chunks of 50
                for i in range(0, len(needed_ids), 50):
                    chunk = needed_ids[i : i + 50]
                    ids_str = ",".join(chunk)
                    url = f"https://api.coingecko.com/api/v3/simple/price?ids={ids_str}&vs_currencies=usd"
                    req = urllib.request.Request(
                        url, headers={"User-Agent": "AuditDashboard/1.0"}
                    )
                    with urllib.request.urlopen(req, timeout=15) as resp:
                        data = json.loads(resp.read())
                    for cg_id, price_data in data.items():
                        sym = id_to_sym.get(cg_id)
                        if sym and "usd" in price_data:
                            prices[sym] = float(price_data["usd"])
                cg_filled = len(prices) - len(prices.keys() - crypto_symbols)
                log.info(
                    "CoinGecko filled %d additional prices for missing symbols",
                    len(needed_ids),
                )
        except Exception as e:
            log.warning("CoinGecko fallback failed: %s", e)

    # 3. XAGUSDT (silver) — not on crypto exchanges; use a metals API or hardcode
    if "XAGUSDT" in crypto_symbols and "XAGUSDT" not in prices:
        try:
            # Try metals.live free API
            url = "https://api.metals.live/v1/spot"
            req = urllib.request.Request(
                url, headers={"User-Agent": "AuditDashboard/1.0"}
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())
            for metal in data:
                if metal.get("gold") is not None:
                    continue
                if metal.get("silver") is not None:
                    prices["XAGUSDT"] = float(metal["silver"])
                    log.info(
                        "Fetched silver price from metals.live: $%.2f",
                        prices["XAGUSDT"],
                    )
                    break
        except Exception:
            pass
        if "XAGUSDT" not in prices:
            try:
                # Fallback: goldapi.io free endpoint
                url = "https://www.goldapi.io/api/XAG/USD"
                req = urllib.request.Request(
                    url,
                    headers={
                        "User-Agent": "AuditDashboard/1.0",
                        "x-access-token": "goldapi-demo",
                    },
                )
                with urllib.request.urlopen(req, timeout=10) as resp:
                    data = json.loads(resp.read())
                if data.get("price"):
                    prices["XAGUSDT"] = float(data["price"])
                    log.info(
                        "Fetched silver price from goldapi: $%.2f", prices["XAGUSDT"]
                    )
            except Exception:
                pass
        if "XAGUSDT" not in prices:
            # Last resort hardcoded recent silver price (updated periodically)
            prices["XAGUSDT"] = 33.50
            log.info("Using hardcoded silver price: $33.50")

    # Similarly handle XAUUSDT (gold) if requested
    if "XAUUSDT" in crypto_symbols and "XAUUSDT" not in prices:
        if "XAUUSDT" in _binance_all:
            prices["XAUUSDT"] = _binance_all["XAUUSDT"]
        else:
            prices["XAUUSDT"] = 3050.0  # hardcoded fallback
            log.info("Using hardcoded gold price: $3050.00")

    filled = len(set(prices.keys()) & crypto_symbols)
    still_missing = crypto_symbols - set(prices.keys())
    log.info(
        "Price enrichment complete: %d/%d symbols resolved, %d still missing",
        filled,
        len(crypto_symbols),
        len(still_missing),
    )
    if still_missing:
        log.warning("Missing prices for: %s", ", ".join(sorted(still_missing)[:20]))

    return prices


def _fetch_equity_prices(equity_symbols: set) -> dict:
    """Fetch prices for yfinance/FMP-addressable non-crypto symbols.

    Priority:
      0. Read audit_trail/data/stock_prices.json (written by fetch_stock_prices.py in CI)
      1. yfinance batch download for any symbols not found in cache
      2. FMP free API for remaining misses
    Returns {SYMBOL: price}.
    """
    prices = {}
    if not equity_symbols:
        return prices

    invalid_symbols = {
        sym for sym in equity_symbols if not _looks_like_quote_symbol(sym)
    }
    if invalid_symbols:
        equity_symbols = equity_symbols - invalid_symbols
        log.info(
            "Skipping %d non-quote symbols from equity price lookup",
            len(invalid_symbols),
        )
    if not equity_symbols:
        return prices

    # 0. Read pre-cached stock prices (fetch_stock_prices.py writes this before us in CI)
    stock_prices_path = ROOT / "audit_trail" / "data" / "stock_prices.json"
    try:
        if stock_prices_path.exists():
            cached_text = stock_prices_path.read_text(encoding="utf-8", errors="replace")
            try:
                cached = json.loads(cached_text)
            except json.JSONDecodeError:
                # Runtime data files occasionally pick up git conflict markers.
                # Strip marker lines so we can still salvage the last valid JSON body.
                cleaned = "\n".join(
                    line
                    for line in cached_text.splitlines()
                    if not line.lstrip().startswith(("<<<<<<<", "=======", ">>>>>>>"))
                )
                cached = json.loads(cleaned)
                log.warning(
                    "Recovered stock_prices.json after stripping conflict markers"
                )
            cached_prices = cached.get("prices", {})
            for sym in equity_symbols:
                if (
                    sym in cached_prices
                    and cached_prices[sym]
                    and cached_prices[sym] > 0
                ):
                    prices[sym] = float(cached_prices[sym])
            if prices:
                log.info(
                    "Loaded %d/%d equity prices from stock_prices.json cache",
                    len(prices),
                    len(equity_symbols),
                )
    except Exception as e:
        log.warning("Failed to read stock_prices.json cache: %s", e)

    # If all symbols resolved from cache, skip network calls entirely
    remaining = equity_symbols - set(prices.keys())
    if not remaining:
        return prices

    # 1. Try yfinance batch download for remaining symbols (threads=True for parallel fetching)
    try:
        import yfinance as yf

        syms_list = list(remaining)
        try:
            # Batch download: one HTTP call for all symbols — much faster than per-symbol
            data = yf.download(syms_list, period="1d", progress=False, threads=True)
            if data is not None and not data.empty:
                close = data.get("Close", data)
                if hasattr(close, "columns"):
                    # Multi-ticker: columns are symbol names
                    for sym in syms_list:
                        try:
                            col = close[sym] if sym in close.columns else None
                            if col is not None and not col.dropna().empty:
                                prices[sym] = float(col.dropna().iloc[-1])
                        except Exception:
                            continue
                else:
                    # Single-ticker: flat Series
                    sym = syms_list[0]
                    if not close.dropna().empty:
                        prices[sym] = float(close.dropna().iloc[-1])
        except Exception:
            pass
        # Fall back to per-symbol for any missed from the batch
        still_missing = remaining - set(prices.keys())
        for sym in still_missing:
            try:
                ticker = yf.Ticker(sym)
                hist = ticker.history(period="1d")
                if not hist.empty:
                    prices[sym] = float(hist["Close"].iloc[-1])
            except Exception:
                continue
        yf_count = len(remaining & set(prices.keys()))
        if yf_count:
            log.info(
                "Fetched %d/%d equity prices from yfinance (batch+fallback)",
                yf_count,
                len(remaining),
            )
    except ImportError:
        log.warning("yfinance not installed — trying FMP fallback")
    except Exception as e:
        log.warning("yfinance failed: %s", e)

    # 2. Fallback: FMP free API for any symbols still missing
    missing = equity_symbols - set(prices.keys())
    if missing:
        for sym in missing:
            try:
                url = f"https://financialmodelingprep.com/api/v3/quote-short/{sym}?apikey=demo"
                req = urllib.request.Request(
                    url, headers={"User-Agent": "AuditDashboard/1.0"}
                )
                with urllib.request.urlopen(req, timeout=10) as resp:
                    data = json.loads(resp.read())
                if data and isinstance(data, list) and data[0].get("price"):
                    prices[sym] = float(data[0]["price"])
            except Exception:
                continue
        if missing & set(prices.keys()):
            log.info(
                "Fetched %d equity prices from FMP fallback",
                len(missing & set(prices.keys())),
            )

    return prices


def _enrich_live_pnl(picks: list) -> list:
    """Fetch current prices from multiple APIs and compute unrealized PnL for active picks."""
    if not picks:
        return picks

    # Collect unique symbols — crypto (USDT/BUSD/USD suffix, k-prefix, 1000-prefix,
    # commodities like XAGUSDT) and equity tickers
    crypto_symbols = set()
    equity_symbols = set()
    source_prices = {}
    market_asset_classes = {"EQUITY", "ETF", "FOREX", "FUTURES", "COMMODITY", "BOND"}
    _EQUITY_TICKERS = {
        "SPY",
        "QQQ",
        "AAPL",
        "MSFT",
        "GOOGL",
        "GOOG",
        "AMZN",
        "TSLA",
        "META",
        "NVDA",
        "AMD",
        "NFLX",
        "DIS",
        "BA",
        "JPM",
        "GS",
        "V",
        "MA",
        "PYPL",
        "SQ",
        "COIN",
        "MSTR",
        "RIOT",
        "MARA",
        "HUT",
        "BITF",
        "IWM",
        "DIA",
        "VTI",
        "VOO",
        "ARKK",
        "XLF",
        "XLE",
        "XLK",
        "GLD",
        "SLV",
        "USO",
        "TLT",
        "VIX",
        "UVXY",
        "SQQQ",
        "TQQQ",
        "BAC",
    }
    for p in picks:
        raw_sym = str(p.get("symbol") or "").upper().strip()
        sym = raw_sym.replace("-", "").replace("_", "").replace("/", "")
        if not raw_sym:
            continue
        if not _looks_like_quote_symbol(raw_sym):
            continue
        current_price = _float(p.get("current_price", 0))
        if current_price and current_price > 0:
            source_prices[raw_sym] = current_price
            source_prices[sym] = current_price
            continue
        if raw_sym in source_prices or sym in source_prices:
            continue
        asset_class = (
            str(p.get("asset_class") or p.get("category") or "").upper().strip()
        )
        # Explicit equity tickers
        if raw_sym in _EQUITY_TICKERS or sym in _EQUITY_TICKERS:
            equity_symbols.add(raw_sym)
        elif asset_class in {"FOREX", "COMMODITY"} and len(sym) == 6 and sym.isalpha():
            fx_lookup = f"{sym}=X"
            equity_symbols.add(fx_lookup)
            p["_price_lookup_sym"] = fx_lookup
        # Crypto: USDT, BUSD, or USD-suffix (will be normalized to USDT)
        elif sym.endswith(("USDT", "BUSD")) and len(sym) > 4:
            crypto_symbols.add(sym)
        elif sym.endswith("USD") and not sym.endswith("USDT") and len(sym) > 3:
            # e.g., BTCUSD -> BTCUSDT for Binance lookup
            crypto_symbols.add(sym + "T")
            # Also store original -> normalized mapping for later
            p["_price_lookup_sym"] = sym + "T"
        elif sym.startswith(("K", "1000")) and sym.endswith(("USDT", "BUSD")):
            # k-prefix (kPEPEUSDT) or 1000-prefix (1000SHIBUSDT)
            crypto_symbols.add(sym)
        elif sym in ("XAGUSDT", "XAUUSDT"):
            crypto_symbols.add(sym)
        elif raw_sym.endswith(("=X", "=F")) or raw_sym.startswith("^"):
            equity_symbols.add(raw_sym)
        elif asset_class in market_asset_classes:
            equity_symbols.add(raw_sym)
        elif sym and len(sym) <= 5 and sym.isalpha():
            # Likely an equity ticker (e.g., AAPL, NVDA, MSFT)
            equity_symbols.add(raw_sym)

    if not crypto_symbols and not equity_symbols and not source_prices:
        return picks

    prices = dict(source_prices)
    if crypto_symbols:
        for sym, price in _fetch_prices_with_failover(crypto_symbols).items():
            prices.setdefault(sym, price)
    if equity_symbols:
        for sym, price in _fetch_equity_prices(equity_symbols).items():
            prices.setdefault(sym, price)
    if not prices:
        return picks

    # Enrich each pick with live PnL
    updated = 0
    for p in picks:
        raw_symbol = str(p.get("symbol") or "").upper().strip()
        raw_sym = raw_symbol.replace("-", "").replace("_", "").replace("/", "")
        # Try direct lookup, then normalized USDT form, then _price_lookup_sym
        price = prices.get(raw_symbol)
        if price is None:
            price = prices.get(raw_sym)
        if price is None and raw_sym.endswith("USD") and not raw_sym.endswith("USDT"):
            price = prices.get(raw_sym + "T")
        if (
            price is None
            and raw_symbol.endswith("USD")
            and not raw_symbol.endswith("USDT")
        ):
            price = prices.get(raw_symbol + "T")
        if price is None and "_price_lookup_sym" in p:
            price = prices.get(p["_price_lookup_sym"])
        if price is None:
            continue
        entry = _float(p.get("entry_price", 0))
        if not entry or entry == 0:
            if _is_prediction_market_pick(
                str(p.get("source_system", "") or ""),
                str(p.get("source_system", "") or ""),
                p,
                str(p.get("strategy", "") or ""),
            ):
                _snapshot_prediction_market_entry(p, price)
                entry = _float(p.get("entry_price", 0))
        if not entry or entry == 0:
            continue
        direction = (p.get("direction") or "").upper()
        if direction == "SHORT":
            pnl = ((entry - price) / entry) * 100
        else:
            pnl = ((price - entry) / entry) * 100

        # Check if TP/SL breached by live price
        tp = _float(p.get("take_profit", 0))
        sl = _float(p.get("stop_loss", 0))
        if direction == "SHORT":
            if tp and price <= tp * 1.001:
                p["_tp_breached"] = True
                p["status"] = "TP_HIT"
            elif sl and price >= sl * 0.999:
                p["_sl_breached"] = True
                p["status"] = "SL_HIT"
        else:  # LONG
            if tp and price >= tp * 0.999:
                p["_tp_breached"] = True
                p["status"] = "TP_HIT"
            elif sl and price <= sl * 1.001:
                p["_sl_breached"] = True
                p["status"] = "SL_HIT"

        # Sanity check: if |P/L| > 500%, entry price is likely corrupt
        # (e.g., stored at wrong decimal scale). Flag but don't display garbage.
        if abs(pnl) > 500:
            p["pnl_pct"] = None
            p["pnl_flagged"] = True
            p["pnl_raw"] = round(pnl, 2)
            p["current_price"] = price
            log.warning(
                "PnL sanity fail: %s entry=%.6f current=%.2f pnl=%.1f%% — flagged as corrupt",
                p.get("symbol"),
                entry,
                price,
                pnl,
            )
            continue

        # Entry price validation gate: flag picks with |PnL| > 200% as suspicious
        # These are not corrupt (that's the >500% check above) but warrant verification.
        if abs(pnl) > 200:
            p["_suspicious_entry"] = True
            p["_entry_validation"] = f"unrealized PnL {pnl:.1f}% exceeds 200% — verify entry price"
            log.warning(
                "Suspicious entry: %s entry=%.6f current=%.2f pnl=%.1f%% — flagged for review",
                p.get("symbol"),
                entry,
                price,
                pnl,
            )

        p["pnl_pct"] = round(pnl, 2)
        p["current_price"] = price
        updated += 1

    # Clean up temporary lookup keys so they don't leak into the payload
    for p in picks:
        p.pop("_price_lookup_sym", None)

    # Inject Symbol-Aware Track Stats using the user's new tool
    track_stats = _build_strategy_symbol_track_stats(
        [p for p in picks if str(p.get("status")).upper() in ("CLOSED", "RESOLVED", "WON", "LOST", "SL_HIT", "TP_HIT")]
    )
    for p in picks:
        if str(p.get("status")).upper() in ("OPEN", "ACTIVE", "LIVE", "PENDING"):
            key = _track_stats_key(str(p.get("strategy", "")), _normalize_symbol(str(p.get("symbol", ""))))
            stats = track_stats.get(key)
            if stats:
                p.update(stats)
                # Calculate a symbol-specific track score boost
                wr = stats.get("sym_track_wr")
                total = stats.get("sym_track_total", 0)
                if wr is not None and total >= 5:
                    p["sym_track_score"] = round((wr - 50) * min(total/10, 2.0), 2)

    log.info("Updated PnL and Track Stats for %d active picks with live prices", updated)
    return picks


# ── Lock file to prevent concurrent runs ──


def _acquire_lock():
    LOCK_FILE.parent.mkdir(parents=True, exist_ok=True)
    if LOCK_FILE.exists():
        try:
            age = datetime.now().timestamp() - LOCK_FILE.stat().st_mtime
            if age < 300:  # 5 min
                log.warning(
                    "Lock file exists and is %.0fs old — another run in progress?", age
                )
                return False
            log.warning("Stale lock file (%.0fs old) — removing", age)
            LOCK_FILE.unlink()
        except Exception:
            pass
    LOCK_FILE.write_text(str(os.getpid()), encoding="utf-8")
    return True


def _release_lock():
    try:
        LOCK_FILE.unlink(missing_ok=True)
    except Exception:
        pass


# ── Safe readers ──


def _load_json_resilient(path: Path):
    text = path.read_text(encoding="utf-8", errors="replace")
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        cleaned = "\n".join(
            line
            for line in text.splitlines()
            if not line.lstrip().startswith(("<<<<<<<", "=======", ">>>>>>>"))
        )
        data = json.loads(cleaned)
        log.warning("Recovered JSON after stripping conflict markers: %s", path)
        return data


def _safe_json(path: Path):
    """Load JSON file safely, return None on error."""
    if not path.exists():
        log.debug("JSON not found: %s", path)
        return None
    try:
        return _load_json_resilient(path)
    except Exception as e:
        log.warning("Failed to load JSON %s: %s", path, e)
        return None


def _safe_text(path: Path) -> str:
    """Load text file safely, return empty string on error."""
    if not path.exists():
        return ""
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception as e:
        log.warning("Failed to load text %s: %s", path, e)
        return ""


def _dashboard_href(path: Path) -> str:
    """Build a repo-relative href that works from the audit dashboard."""
    try:
        rel = path.relative_to(ROOT).as_posix()
    except ValueError:
        rel = path.as_posix()
    return "../" + quote(rel, safe="/")


def _artifact_category(path: Path) -> str:
    ext = path.suffix.lower()
    name = path.name.lower()
    if ext == ".png":
        return "chart"
    if ext == ".csv":
        return "dataset"
    if ext == ".py":
        return "code"
    if "strategy" in name:
        return "strategy"
    if "report" in name or "analysis" in name or "summary" in name:
        return "report"
    return "note"


def _extract_match(pattern: str, text: str, flags: int = 0):
    return re.search(pattern, text or "", flags)


def _extract_float(pattern: str, text: str, flags: int = 0) -> float | None:
    match = _extract_match(pattern, text, flags)
    if not match:
        return None
    try:
        return float(match.group(1))
    except Exception:
        return None


def _build_btc_strategy_replication_report(folder: Path) -> dict | None:
    """Summarize the BTC scalping replication dossier for the audit dashboard."""
    if not folder.exists() or not folder.is_dir():
        return None

    final_report_path = folder / "FINAL_INVESTIGATION_REPORT.txt"
    final_strategy_path = folder / "FINAL_STRATEGY.txt"
    backtest_path = folder / "backtest_results.txt"
    timing_path = folder / "timing_analysis_report.txt"
    discrepancy_path = folder / "bybit_price_discrepancy_investigation_report.md"
    deliverables_path = folder / "FINAL_DELIVERABLES.txt"
    synthesis_path = folder / "strategy_synthesis_summary.txt"
    microstructure_path = folder / "bybit_microstructure_scalper.py"
    production_code_path = folder / "final_strategy.py"

    final_report = _safe_text(final_report_path)
    final_strategy = _safe_text(final_strategy_path)
    backtest = _safe_text(backtest_path)
    timing = _safe_text(timing_path)
    discrepancy = _safe_text(discrepancy_path)
    deliverables = _safe_text(deliverables_path)
    synthesis = _safe_text(synthesis_path)
    microstructure_code = _safe_text(microstructure_path)

    if not any(
        [
            final_report,
            final_strategy,
            backtest,
            timing,
            discrepancy,
            deliverables,
            synthesis,
        ]
    ):
        return None

    claim_win_rate = _extract_float(r"Win Rate:\s+([0-9.]+)%", final_report)
    best_dataset_wr = None
    for dataset in ("DATASET 1", "DATASET 2"):
        match = _extract_match(
            rf"{dataset}.*?Win Rate:\s+([0-9.]+)%",
            backtest,
            flags=re.IGNORECASE | re.DOTALL,
        )
        if match:
            wr = float(match.group(1))
            best_dataset_wr = wr if best_dataset_wr is None else max(best_dataset_wr, wr)

    realistic_wr_match = _extract_match(
        r"Win Rate:\s+([0-9]+)-([0-9]+)%",
        final_strategy,
        flags=re.IGNORECASE,
    )
    realistic_wr_range = None
    if realistic_wr_match:
        realistic_wr_range = (
            f"{realistic_wr_match.group(1)}-{realistic_wr_match.group(2)}%"
        )

    matched_real = None
    matched_total = None
    match_real = _extract_match(
        r"Only\s+([0-9]+)\s+of\s+([0-9]+)\s+trades matched real BTC market (?:data|prices)",
        final_report,
        flags=re.IGNORECASE,
    )
    if match_real:
        matched_real = int(match_real.group(1))
        matched_total = int(match_real.group(2))

    automation_confidence = _extract_float(
        r"CONFIDENCE LEVEL:\s*([0-9.]+)%",
        timing,
        flags=re.IGNORECASE,
    )
    if automation_confidence is None:
        automation_confidence = _extract_float(
            r"CONFIDENCE LEVEL:\s*([0-9.]+)%",
            final_report,
            flags=re.IGNORECASE,
        )

    fee_range_match = _extract_match(
        r"Estimated \$([0-9]+)-([0-9]+) in unreported costs",
        final_report,
        flags=re.IGNORECASE,
    )
    fee_range = (
        f"${fee_range_match.group(1)}-${fee_range_match.group(2)}"
        if fee_range_match
        else None
    )

    contradiction_files = []
    for path, text in (
        (deliverables_path, deliverables),
        (synthesis_path, synthesis),
        (microstructure_path, microstructure_code),
    ):
        lowered = (text or "").lower()
        if (
            "91.67% win rate is achievable" in lowered
            or "expected win rate:         91.67%" in lowered
            or "target: 91.67% win rate replication" in lowered
        ):
            contradiction_files.append(path.name)

    artifacts = []
    for path in sorted(folder.iterdir(), key=lambda p: (p.suffix.lower(), p.name.lower())):
        if not path.is_file():
            continue
        artifacts.append(
            {
                "name": path.name,
                "category": _artifact_category(path),
                "size_kb": round(path.stat().st_size / 1024, 1),
                "href": _dashboard_href(path),
            }
        )

    recommended_names = {
        final_report_path.name,
        final_strategy_path.name,
        backtest_path.name,
        production_code_path.name,
        discrepancy_path.name,
        timing_path.name,
    }
    superseded_names = set(contradiction_files)
    final_artifacts = [a for a in artifacts if a["name"] in recommended_names]
    superseded_artifacts = [a for a in artifacts if a["name"] in superseded_names]
    chart_artifacts = [a for a in artifacts if a["category"] == "chart"]

    review_findings = []
    if contradiction_files:
        review_findings.append(
            {
                "severity": "high",
                "title": "Intermediate deliverables contradict the final verdict",
                "detail": (
                    "Several exploratory files still claim the 91.67% result is "
                    "achievable, but the final investigation, backtest, and practical "
                    "strategy all conclude the screenshot is not reproducible on real data."
                ),
                "files": contradiction_files,
            }
        )
    if best_dataset_wr is not None and claim_win_rate is not None and best_dataset_wr < claim_win_rate:
        review_findings.append(
            {
                "severity": "medium",
                "title": "Best observed backtest still missed the headline claim",
                "detail": (
                    f"The strongest backtest run reached {best_dataset_wr:.2f}% win rate, "
                    f"still below the claimed {claim_win_rate:.2f}%."
                ),
                "files": [backtest_path.name],
            }
        )

    folder_ts = datetime.fromtimestamp(folder.stat().st_mtime, tz=timezone.utc)

    return {
        "id": "btc_scalping_strategy_replication",
        "title": "BTC Scalping Strategy Replication",
        "subtitle": "Review of the claimed 91.67% BTCUSD.V win-rate screenshot",
        "folder_name": folder.name,
        "folder_href": _dashboard_href(final_report_path),
        "updated_at": folder_ts.isoformat(),
        "verdict": {
            "status": "not_replicable",
            "label": "Not Replicable",
            "summary": (
                "The claimed 91.67% win rate does not hold up under realistic market "
                "data, cost accounting, and repeatable backtesting."
            ),
        },
        "claim": {
            "win_rate_pct": claim_win_rate,
            "trade_count": matched_total or 12,
        },
        "metrics": {
            "matched_real_trades": matched_real,
            "trade_count": matched_total,
            "best_backtest_win_rate_pct": best_dataset_wr,
            "automation_confidence_pct": automation_confidence,
            "realistic_win_rate_range": realistic_wr_range,
            "unreported_cost_range": fee_range,
            "contradiction_count": len(contradiction_files),
        },
        "key_findings": [
            "Only 2 of 12 trades matched real BTC market data.",
            "The outlier 1,737-point move did not occur in real BTC price history.",
            "Reported P/L excluded exchange costs, adding roughly $216-$324 in hidden fees.",
            "The 4-second pyramid strongly implies automation rather than manual execution.",
            "The practical replacement is VWAP Scalper Pro with a 60-75% target win-rate range.",
        ],
        "review_findings": review_findings,
        "final_artifacts": final_artifacts,
        "superseded_artifacts": superseded_artifacts,
        "chart_artifacts": chart_artifacts,
        "artifacts": artifacts,
        "recommended_next_step": (
            "Use FINAL_INVESTIGATION_REPORT.txt and FINAL_STRATEGY.txt as the source of truth; "
            "treat the microstructure replication files as exploratory dead ends."
        ),
    }


def collect_research_reports() -> list[dict]:
    """Collect curated research dossiers that should surface in the audit dashboard."""
    reports = []
    btc_report = _build_btc_strategy_replication_report(
        ROOT / "Kimi_Agent_BTC Scalping Strategy Replication"
    )
    if btc_report:
        reports.append(btc_report)
    return reports


def _claude_perf_sort_ts(raw: dict) -> float:
    """Best-effort timestamp sort key for Claude tracker rows."""
    for key in (
        "exit_time",
        "resolved_at",
        "closed_at",
        "entry_time",
        "timestamp",
        "created_at",
    ):
        value = raw.get(key)
        if not value:
            continue
        try:
            dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.timestamp()
        except Exception:
            continue
    return 0.0


def _build_claude_perf_index(*datasets) -> dict[tuple[str, str], list[dict]]:
    """Index rich Claude tracker rows so recent_10 can inherit real entry/exit data."""
    index: dict[tuple[str, str], list[dict]] = {}
    seen_keys = set()
    for dataset in datasets:
        if not isinstance(dataset, list):
            continue
        for raw in dataset:
            if not isinstance(raw, dict):
                continue
            symbol = str(raw.get("symbol", "")).upper().strip()
            exit_reason = (
                str(raw.get("exit_reason", raw.get("resolved_reason", "")))
                .upper()
                .strip()
            )
            if not symbol or not exit_reason:
                continue
            dedupe_key = (
                raw.get("pick_id") or raw.get("id") or "",
                symbol,
                exit_reason,
                round(_float(raw.get("pnl_pct", 0)), 4),
                round(_claude_perf_sort_ts(raw), 0),
            )
            if dedupe_key in seen_keys:
                continue
            seen_keys.add(dedupe_key)
            index.setdefault((symbol, exit_reason), []).append(raw)

    for candidates in index.values():
        candidates.sort(key=_claude_perf_sort_ts, reverse=True)
    return index


def _match_claude_perf_row(
    summary_trade: dict, perf_index: dict[tuple[str, str], list[dict]]
) -> dict | None:
    """Find the rich history row backing a recent_10 Claude performance summary item."""
    symbol = str(summary_trade.get("symbol", "")).upper().strip()
    exit_reason = str(summary_trade.get("exit_reason", "")).upper().strip()
    target_pnl = round(_float(summary_trade.get("pnl_pct", 0)), 4)
    if not symbol:
        return None

    candidates = list(perf_index.get((symbol, exit_reason), []))
    if not candidates:
        for (candidate_symbol, _candidate_reason), rows in perf_index.items():
            if candidate_symbol == symbol:
                candidates.extend(rows)

    best = None
    best_delta = None
    for row in candidates:
        delta = abs(round(_float(row.get("pnl_pct", 0)), 4) - target_pnl)
        if best is None or delta < best_delta:
            best = row
            best_delta = delta
            if delta < 0.02:
                break

    if best is None or best_delta is None or best_delta > 0.5:
        return None
    return dict(best)


def _build_claude_perf_pick(
    summary_trade: dict, matched_row: dict | None, fallback_timestamp: str
) -> dict:
