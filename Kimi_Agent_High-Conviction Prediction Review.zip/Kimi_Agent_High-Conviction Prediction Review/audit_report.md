# Codebase Architecture Analysis and Integration Audit Report
## findtorontoevents.ca Trading Prediction System
**Audit Date**: 2026-04-23  
**Scope**: alpha_engine/, audit_trail/, audit_dashboard/, copy_trader_intel/

---

## 1. CODE ARCHITECTURE FINDINGS

### 1.1 God Object Anti-Pattern: scanner.py (~5,041 lines)
**File**: `alpha_engine/scanner.py` (5,041 lines)  
**Severity**: 🔴 Critical

`scanner.py` violates every principle of single responsibility:
- Signal generation (run_strategies)
- ML ranking (ml_ranker integration)
- Position sizing (compute_position_size, open_new_picks)
- Risk controls (kill switch check — but NOT circuit breaker or daily limits)
- Portfolio management (check_open_picks, equity tracking)
- Data export (active_picks.json, closed_picks.json, strategy_performance.json)
- External signal ingestion (OKX, copy trader, macro, gainer tracker)
- Regime detection
- Conformal prediction sizing
- Direction balance guards
- Tournament tier gates

**Impact**: A single file change can break the entire trading pipeline. No modular boundaries means no safe refactoring.

### 1.2 Circular Import Risk
**File**: `audit_trail/dashboard_generator.py` line 224  
**Severity**: 🟡 Medium

> "Same pattern as alpha_engine/atomic_json.atomic_write_json (which we don't import directly here to avoid a circular: dashboard_generator is imported by many paths)"

The dashboard_generator is imported by "many paths" but also imports from alpha_engine. This creates a fragile dependency web where `dashboard_generator` cannot safely import `atomic_json` due to circular imports. Atomic writes are re-implemented inline (lines 218-253) instead of using a shared utility.

### 1.3 Configuration Scattered Across 6+ Files
**Files**: `config.py`, `quality_gates.py`, `hc_filter.js`, `hc_gate_params.json`  
**Severity**: 🟡 Medium

Thresholds are defined in MULTIPLE places with no single source of truth:
- `config.py`: `MAX_RISK_PER_TRADE=0.02`, `MAX_ALLOCATION_PER_PICK=0.15`
- `quality_gates.py`: `SMART_PICKS_MIN_SCORE=60` (line 197), `SMART_PICKS_MIN_TRUST_SCORE=3` (line 511)
- `hc_filter.js`: `scoreCompoundFloor: 50`, `forwardWRMinPct: 70` (line 24-41)
- `quality_gates.py`: `ACTIVE_PICKS_MIN_SCORE=0` (line 196)

When thresholds change, they must be manually synced across Python backend, JS frontend, and JSON config files. The comment at `hc_filter.js:22` explicitly warns: "Embedded defaults — keep in sync with config/hc_gate_params.json" — a maintenance burden that will inevitably drift.

### 1.4 Test Coverage Inadequate
**Evidence**: `tests/test_hc_filter.js` exists, but no Python unit tests for scanner.py  
**Severity**: 🟡 Medium

- `scanner.py` (5,041 lines): No visible test suite
- `risk_controls.py` (671 lines): No visible test suite
- `dashboard_generator.py` (~4,000+ lines): No visible test suite
- Only `test_hc_filter.js` exists for frontend filter logic
- Risk control bypass (`is_daily_blocked() -> False`) would never be caught by existing tests

---

## 2. QUALITY GATES ANALYSIS

### 2.1 Shared HC Filter Logic (hc_filter.js)
**File**: `audit_dashboard/hc_filter.js`  
**Lines**: 1-500 (complete file)

The JS frontend filter implements 9 gates (evaluateHcGates1to9):
1. **scoreAbsoluteFloor** >= 40
2. **scoreCompoundFloor** >= 50 OR trust >= 8
3. **trustTierBlacklist**: SANDBOX, UNPROVEN, PROBATION, DEMOTED
4. **forwardTradesMin**: 5 (2 for COMMODITY/FUTURES/BOND/ETF)
5. **forwardWRMinPct**: 70% (all asset classes, raised 2026-04-23)
6. **scoreFloorAC**: 55 crypto, 55 equity, 45 forex, 35 commodity/futures/bond/etf
7. **trustScoreMin**: 4 crypto, 5 other
8. **confidence gates**: max 0.90 (with fwd trades < 20), extreme max 0.95 (with fwd < 30)
9. **Regime gates**: LONG blocked in bear, SHORT blocked in bull (requires PROVEN)
10. **Walk-forward**: reject FAILING
11. **Independent consensus**: 3+ independent signal groups
12. **Correlation dedup**: reject same-direction correlated symbol pairs

**Key Finding**: The `scoreCompoundFloor` in JS is 50, but Python `quality_gates.py` has `SMART_PICKS_MIN_SCORE=60` (line 197). This means frontend HC filter passes picks at score 50-59 that the backend Smart Picks gate would reject. The comment at line 197-207 admits: "At threshold=70, ZERO active picks qualify (max live score=60)" — the scoring system cannot even reach its own thresholds.

### 2.2 passes_active_gate() — Active Picks Tab Visibility
**File**: `audit_trail/quality_gates.py`, lines 3565-4126  

Controls what appears on the "Active Picks" tab. Key checks:
- Symbol must exist (line 3584-3587)
- Status must be OPEN/ACTIVE/PENDING/LIVE (line 3591)
- Trust tier must not be BANNED/AVOID (line 3597)
- Blocked symbols hard-rejected (line 3610)
- `EXEMPT_FROM_SAFETY_GATES` clone picks are hard-rejected (line 3622) — **good defense**
- Blocked strategy/asset-class pairs rejected (line 3633)
- Elite grade D/F hard-rejected (line 3648) — 871 picks (25%) losing -509% PnL
- Confidence dead-zone gate (0.65-0.75) in shadow mode for CRYPTO (line 3691)
- Time-of-day gate: blocks UTC hours 8-11 and 16-21 for CRYPTO (line 3739)
- Raw score floor: CRYPTO >= 30, non-crypto >= 55 (lines 4081, 4077)

**Critical Issue**: `ACTIVE_PICKS_MIN_SCORE = 0` (line 196). The comment explains: "REVERTED: let ALL picks through, sort by score. Hiding picks starves the dashboard." This means the Active Picks tab has NO minimum score gate — completely permissive.

### 2.3 passes_smart_gate() — Smart Picks Tab Visibility
**File**: `audit_trail/quality_gates.py`, lines 4128-4330  

Controls what appears on the "Smart Picks" tab. Key checks:
- Must pass passes_active_gate first (line 4142)
- HF Threshold A: BT/FWD decay >15pp blocks (line 4146)
- Source provenance required (line 4150)
- Concentration penalty >= 10 blocks non-verified picks (line 4158)
- **SMART_PICKS_CRYPTO_LONG_ONLY = True** (line 534) — CRYPTO SHORTs blocked (line 4176)
- Per-asset score floors (lines 4185-4204):
  - EQUITY: 50
  - FOREX: 55 (+ FwdWR >= 50% additional gate)
  - COMMODITY: 60
  - BOND: 60
  - FUTURES: 65
  - ETF: 60
  - CRYPTO: 60 (default)
- SCALP mode blocked (line 4225)
- Panic health blocked (line 4229)
- R:R must be 1.5-3.5 (lines 4233, 4238)
- Confidence 0.60-0.95 (lines 4254, 4263)
- **ml_score DISABLED** (SMART_PICKS_MIN_ML_SCORE = 0.0, line 505) — "ML scores not currently populated"
- trust_score >= 3 (line 4270)
- Direction conflict blocked (line 4277)

### 2.4 Hardcoded Bias Toward Crypto Longs
**Evidence**:
1. `SMART_PICKS_CRYPTO_LONG_ONLY = True` (quality_gates.py:534) with explicit docstring (lines 519-533): "CRYPTO SHORT picks had PF 1.54 vs LONG 1.91... LONG+Score>=50+Trust>=3 composite reached PF 5.48"
2. `hc_filter.js` lines 48-51: `longBlockedInBear: true`, `shortBlockedInBull: true`
3. `passes_smart_gate()` line 4176: SHORT crypto explicitly rejected
4. `scanner.py` line 3230-3237: ml_score < 0.90 blocks SHORTs, but no such gate for LONGs

**Analysis**: The system has a structural LONG bias. SHORT crypto is penalized at multiple layers:
- Smart Picks gate blocks all crypto shorts
- ML scoring penalizes shorts (< 0.90 threshold vs no threshold for longs)
- HC filter blocks shorts in bull regimes
- Position sizing may not account for asymmetric short risks

### 2.5 BLOCKED_SOURCE_SYSTEMS (line ~933)
**File**: `audit_trail/quality_gates.py`, lines 933-964

Systems completely hidden from all views:
- `mercury2_fast` (14 trades, 25% WR, -639% PnL, PF 0.02)
- `stocks_competition` (33.5% WR, -304.2% cum PnL, n=281)
- `fast_stocks_competition` (14.3% WR, -41.0% cum)
- `kimi_signal_tracking` (22 trades, 18.2% WR, -126% PnL)
- `ml_bg_system_a` through `ml_bg_system_f` (various, 0-10.5% WR)
- `ml_crypto_pred_v12` (117 trades, 36.8% WR, -32% PnL, PF 0.55)
- `crypto_winners` (48 trades, 39.6% WR, PF 0.30)
- `rocket_scanner` (5 active picks, 0% WR)

**Commentary**: `ml_crypto_pred_v12` is in BOTH `BLOCKED_SOURCE_SYSTEMS` (line 945) AND has a score penalty of -5 at line 3365. This is redundant — the source system block makes the penalty irrelevant.

### 2.6 BLOCKED_STRATEGIES (line ~972)
**File**: `audit_trail/quality_gates.py`, lines 972-1029

29 strategy/asset-class pairs blocked. Asset-class aware blocking is good design. Notable entries:
- `("Value + Quality", "EQUITY")` — 6.2% WR, PF 0.14
- `("enhanced_ml_A_xgboost", None)` — 28% WR, PF 0.42, 189 picks
- `("ML Ranker", None)` — 31.1% WR, PF 0.58 (line 989) — **the ML ranker itself is a blocked strategy!**
- `("claude_gainer_1h", None)` — 53 picks, 43.4% WR, PF 0.52
- `("volume_spike_breakout", None)` — 10.8% WR PF 0.136
- `("kimi_signal_tracking", "CRYPTO")` — 0% WR on crypto (but allowed on EQUITY at 54.6% WR)

**Bug**: The iteration at line 1053 uses `for blocked_strat, blocked_ac in BLOCKED_STRATEGIES:` but `BLOCKED_STRATEGIES` is a **set of tuples**. Python can iterate a set, but the order is non-deterministic. This is not a functional bug but makes debugging harder.

---

## 3. INTEGRATION AUDIT

### 3.1 Copy Trader Integration
**Files**: `scanner.py` lines 2352-2362, 4176-4204  
**Severity**: 🟡 Medium

Copy trader signals are integrated at TWO points in scanner.py:

**Integration Point 1** (lines 2352-2362, in `run_strategies` or early pipeline):
```python
from okx_consensus_signal import okx_top_trader_consensus, binance_crowd_contrarian
okx_picks = okx_top_trader_consensus(data=data)
if okx_picks:
    all_signals.extend(okx_picks)
```

**Integration Point 2** (lines 4176-4204, in main execution flow):
```python
from alpha_engine.copy_trader_analyzer import analyze_top_traders
ct_picks = analyze_top_traders()
if ct_picks:
    signals.extend(ct_picks)

from alpha_engine.copy_trader_bridge import get_copy_trader_picks
bridge_picks = get_copy_trader_picks()
if bridge_picks:
    signals.extend(bridge_picks)
```

**Attribution Issues**:
1. Copy trader picks are mixed directly into the same `signals`/`all_signals` list as alpha_engine picks
2. No visible differentiation in downstream processing — they go through the same scoring, ranking, and position sizing
3. The `source_system` field may not be reliably set to distinguish copy trader origin
4. `okx_top_trader_consensus` imports from `okx_consensus_signal` which is NOT in `copy_trader_intel/` — it's an external module not version-controlled with the copy trader system

**Validation Gap**:
- Copy trader picks are wrapped in try/except blocks that silently skip on ANY error (lines 2361-2362, 4187-4204)
- No pre-validation of copy trader data quality before extending signals
- No tracking of copy trader attribution in closed pick outcomes

### 3.2 Prediction Market Integration (Polymarket/Kalshi)
**File**: `hc_filter.js` lines 68-71  
**Severity**: 🟡 Medium

```javascript
prediction_market: [
  'pm_whale_signals', 'pm_kalshi_signals', 'prediction_market_consensus',
  'pm_momentum_signals',
],
```

Prediction markets are treated as an "independent signal group" in the HC filter consensus model. They contribute to the `independentGroupsMin >= 3` requirement.

**Findings**:
1. PM signals are used as a **consensus contributor**, not as primary features
2. `_prepare_prediction_market_consensus_signal()` exists in `dashboard_generator.py` (line 3376)
3. PM picks get special labeling (`pm_trader_label`, `pm_type_label`) in dashboard rendering
4. However, there's NO evidence that PM predictions are validated for accuracy before being included in consensus
5. The `prediction_market_consensus` source system is not in `BLOCKED_SOURCE_SYSTEMS`, implying it has not been audited for edge

### 3.3 Overfitting Risk to Copy Trader Performance
**Severity**: 🟡 Medium

The copy_trader_intel pipeline has its own data directory with 100+ JSON files (backtest results, trader profiles, scored picks, etc.). The `copy_trader_bridge.py` and `copy_trader_analyzer.py` modules are imported with try/except — if they fail, the system silently continues without copy trader signals.

**Risk**: If the copy trader bridge is working, its picks are blended with alpha_engine picks with no visible cross-validation. If copy traders have a temporary hot streak, the system may over-allocate to their signals.

---

## 4. RISK CONTROL GAPS — Why -382.8% PnL Happened

### 4.1 is_daily_blocked() Returns False Always
**File**: `alpha_engine/risk_controls.py`, lines 363-364  
**Severity**: 🔴 Critical

```python
def is_daily_blocked() -> bool:
    return False # Patched to bypass
```

The ACTUAL implementation (lines 366-377) is **dead code** — unreachable. Even if it were reachable, it checks `DAILY_PNL_PATH` for a daily tracker, but the function is never called.

### 4.2 Risk Control Functions Are NEVER Called
**File**: `alpha_engine/scanner.py`  
**Severity**: 🔴 Critical

Grep results for risk control functions in scanner.py:
- `is_daily_blocked`: **NOT CALLED** (empty grep)
- `check_circuit_breaker`: **NOT CALLED**
- `is_circuit_breaker_locked`: **NOT CALLED**
- `update_daily_pnl`: **NOT CALLED**
- `apply_daily_loss_limit`: **NOT CALLED**
- `update_consecutive_losses`: **NOT CALLED**

**Impact**: The entire risk_controls.py module is a dead library. None of its functions are invoked in the main scanner execution path. This means:
- **-15% emergency drawdown**: Never checked
- **-10% critical drawdown**: Never checked
- **-5% warning**: Never checked
- **-3% daily close**: Never checked
- **-2% daily block**: Never checked
- **5 consecutive losses per strategy**: Never checked

### 4.3 Kill Switch is Ineffective Against External Signals
**File**: `alpha_engine/scanner.py`, lines 4148-4204  
**Severity**: 🔴 Critical

The kill switch check at line 4148 sets `signals = []` when active, but then:
- Lines 4157-4174: `gainer_tracker` injects picks into `signals`
- Lines 4176-4189: `copy_trader_analyzer` injects picks into `signals`
- Lines 4191-4204: `copy_trader_bridge` injects picks into `signals`
- Lines 4206-4216: `macro_picks` injects picks into `signals`
- Lines 4219-4228: `alligator_picks` injects picks into `signals`

**All these injectors run AFTER the kill switch check and are NOT guarded by it.**

### 4.4 Position Sizing Limits Exist But May Not Prevent Catastrophe
**File**: `alpha_engine/scanner.py`, lines 3456-3492  
**Severity**: 🟡 Medium

`compute_position_size()` correctly implements:
- Risk-based sizing: `risk_amount / stop_distance`
- Cap at `MAX_ALLOCATION_PER_PICK` (15% of capital)
- Cap at `MAX_TOTAL_EXPOSURE` (80% of capital)
- Cap at `MAX_CORRELATED_EXPOSURE` (40% per asset class)

**However**:
1. The function returns a dollar allocation, but `open_new_picks()` (line 3495) uses BOTH this legacy sizing AND Kelly Criterion sizing (line 3603)
2. Kelly sizing can override the risk-based allocation — the code takes `kelly_sizing` but it's not clear which takes precedence
3. `STARTING_CAPITAL = 10_000.0` is hardcoded (config.py:65) — no dynamic equity adjustment
4. With 100 max open picks and $10K capital, average allocation is $100/pick, but the system doesn't seem to account for total portfolio heat

### 4.5 HALT Button Status
**File**: `alpha_engine/scanner.py`, lines 4024-4051  
**Severity**: 🟡 Medium

The "HALT" button on the dashboard corresponds to the kill switch. From scanner.py:
- Kill switch IS checked (line 4028)
- If triggered, it prints a message and skips `run_strategies()`
- BUT it does NOT skip external signal injectors
- The kill switch status IS exported to `active_picks.json` (lines 4997-4999)

**Assessment**: The HALT button is PARTIALLY functional. It stops alpha_engine strategy generation but does NOT stop copy traders, gainers, macro picks, or alligator signals from being opened.

---

## 5. SPECIFIC BUGS FOUND

### Bug 1: Train-Serve Feature Misalignment (39 vs 41 features)
**Status**: 🔴 Critical — Open  
**Location**: `ml_ranker.py` lines 359-422, 2462-2473 (not directly examined, referenced from MERCURYPROMPT.md)

The ML model is trained on 41 features but served on 39. This causes feature index misalignment during prediction, silently corrupting ml_score values.

### Bug 2: ml_score is 0% Populated on Closed Picks
**Status**: 🔴 Critical — Open  
**Location**: `scanner.py`  
**Evidence**: `SMART_PICKS_MIN_ML_SCORE = 0.0` (quality_gates.py:505) with comment: "Disabled - ML scores not currently populated"

The ml_score field is computed for active signals but NOT backfilled for closed picks. This means:
- ML model cannot be properly retrained (no labels with features)
- Smart Picks gate cannot use ML score (hence disabled)
- The ML ranker is essentially flying blind on historical performance

### Bug 3: sanitize_active_picks is Bypassable
**Status**: 🔴 Critical — Open  
**Location**: `scanner.py`, lines 60-62

```python
try:
    from alpha_engine.feed_hygiene import sanitize_active_picks
except ImportError:
    sanitize_active_picks = lambda picks, label="": picks
```

If `feed_hygiene` fails to import (circular import, file missing, syntax error), sanitization is completely bypassed with a no-op lambda. No error is raised — the system silently operates without data hygiene.

### Bug 4: is_daily_blocked() Returns False Always
**Status**: 🟡 Medium — Open  
**Location**: `risk_controls.py`, lines 363-364

The daily loss limit is completely bypassed. The function returns `False` unconditionally with comment "Patched to bypass". The real implementation (lines 366-377) is dead code.

### Bug 5: Risk Controls Module Completely Unused
**Status**: 🔴 Critical — Open  
**Location**: `alpha_engine/scanner.py` (entire file)

No risk control functions from `risk_controls.py` are imported or called in scanner.py. The module exists but is a dead library. The -382.8% PnL was allowed because:
1. No circuit breaker evaluation
2. No daily loss tracking
3. No consecutive loss strategy disabling
4. No drawdown-based position reduction

### Bug 6: LOST Exits Are Binary Outcome Labels, Not Exit Reasons
**Status**: 🟡 Medium — Issue #186  
**Location**: `quality_gates.py`, lines 1350-1360; `dashboard_generator.py`, lines 3238-3266

Copy-trader scrapers emit `exit_reason="LOST"` or `"WON"` which are binary outcome labels, not canonical exit reasons (TP_HIT/SL_HIT/TIME_EXIT). This corrupts stop-discipline metrics.

Forensic data (quality_gates.py:1354-1357):
- 92% of forex LOST picks have |pnl_pct| < 0.5%
- 60% exit within 0.1% of entry price
- These are mark-to-market force-closes, NOT stop-loss events

A normalization function exists (`normalize_exit_reason` at line 1414) and is wired into `dashboard_generator.py` via `_apply_issue186_exit_normalization` (line 3238). However, the raw scraper data at ingest time still carries the corrupted labels.

### Bug 7: regime_at_entry is 0% Populated
**Status**: 🟡 Medium — Open  
**Location**: `scanner.py`

The `regime_at_entry` field is supposed to record market regime when a pick is opened. It's referenced in `hc_filter.js` for regime-based gates, but:
- `hc_filter.js` line 311: `var regime = String(p.regime_at_entry || p.market_regime || p.regime || '').toLowerCase();`
- If `regime_at_entry` is missing, it falls back to current regime — this creates lookahead bias
- The regime gate decisions (longBlockedInBear, shortBlockedInBull) may use CURRENT regime, not entry regime

### Bug 8: 232 Unique exit_reason Labels (Needs Normalization)
**Status**: 🟡 Medium — Open  
**Location**: Various scrapers and strategy modules

The `_canonical_exit_reason()` function (quality_gates.py:1375) maps families, but 232 unique raw labels have been observed. The normalization only handles the most common. Unrecognized labels map to "UNKNOWN", losing information for post-trade analysis.

### Bug 9: Kill Switch Ineffective Against External Signal Sources
**Status**: 🔴 Critical — Open  
**Location**: `scanner.py`, lines 4148-4204

When kill switch is active, main strategy signals are set to `[]`, but external signals (gainer tracker, copy trader, macro, alligator) are still injected and can be opened.

### Bug 10: Three Contradictory Data Sources for Closed Picks
**Status**: 🟡 Medium — Open  
**Location**: `alpha_engine/data/` directory

Three JSON files claim to be the canonical closed pick record:
1. `dashboard_data.json` — generated by `dashboard_generator.py`, includes resolved picks from 30+ sources
2. `universal_resolved_picks.json` — from the "universal resolver" pipeline
3. `closed_picks.json` — exported by `scanner.py` from the SQLite DB

`scanner.py` line 4767 writes `closed_picks.json` directly from the DB. `dashboard_generator.py` reads from 30+ JSON files and builds its own resolved closed picks list. There is no single source of truth. The comment at `scanner.py:4744-4746` says:
> "Ensures forward_trades / forward_wr are always up-to-date in JSON and closed_picks.json is available for external consumers."

But `dashboard_generator.py` does not use `closed_picks.json` as its primary source — it has its own ingestion pipeline.

### Bug 11: Position Sizing Double-Computation with Unclear Precedence
**Status**: 🟡 Medium — Open  
**Location**: `scanner.py`, lines 3592-3614

`open_new_picks()` computes BOTH legacy risk-based sizing AND Kelly sizing:
```python
allocation = compute_position_size(entry_price, stop_loss, ...)  # line 3592
kelly_sizing = get_position_size(signal=signal, ...)  # line 3603
```

But the code does not show which one takes precedence. Both are computed but only one can be the actual position size. This ambiguity means position sizing may not be deterministic.

---

## 6. DATA PIPELINE ANALYSIS

### 6.1 Data Flow: scanner.py → dashboard_data.json

```
scanner.py main()
  ├── Fetch market data → data[symbol] = DataFrame
  ├── check_open_picks(db, data) → closed[] (TP/SL hits)
  ├── run_strategies(data, context) → signals[]
  │   ├── External injectors: OKX, copy_trader, macro, gainer, alligator
  ├── ML ranking → ranker.score_signal() → ml_score
  ├── Various gates: crypto gates, WR gate, direction guard
  ├── open_new_picks(ranked, db) → opened[]
  │   ├── compute_position_size() OR get_position_size() (ambiguous)
  │   ├── db.record_signal() / db.open_pick()
  ├── Export active_picks.json (line 5002)
  ├── Export closed_picks.json (line 4768)
  ├── Export strategy_performance.json (line 4792)
  ├── generate_recommended_portfolio()
  └── equity_tracker.record_snapshot()

dashboard_generator.py (separate process)
  ├── Read 30+ JSON files from various systems
  ├── Read SQLite databases
  ├── Normalize picks from all sources
  ├── Apply quality gates (passes_active_gate, passes_smart_gate)
  ├── Build dashboard_data.json payload
  └── Write to audit_dashboard/data/dashboard_data.json
```

### 6.2 The 30+ JSON Sources
**File**: `audit_trail/dashboard_generator.py`, header comment (lines 8-13)

From the code, sources include:
- `alpha_engine/data/active_picks.json`
- `alpha_engine/data/closed_picks.json`
- `predictions/data/active_predictions.json`
- `rapid_fire_data/active_picks.json`
- `quan_engine/data/active_signals.json`
- `copy_trader_intel/data/*` (100+ files)
- Baby strategy bundles
- Portfolio JSONs
- SQLite databases (16 of them)

### 6.3 No Single Source of Truth
**Severity**: 🔴 Critical

- `scanner.py` writes `closed_picks.json` from SQLite DB (line 4768)
- `dashboard_generator.py` builds its own `resolved_closed` from 30+ sources (lines 3127+)
- `universal_resolved_picks.json` is mentioned but not directly used by scanner.py
- `strategy_performance.json` is overwritten by scanner.py (line 4792) but also read by dashboard_generator.py

**Impact**: A pick could show different PnL, status, or exit_reason depending on which file you read. This makes debugging impossible and creates conflicting metrics on the dashboard.

### 6.4 Active Pick Sanitization Gap
**File**: `scanner.py`, lines 5000-5005

```python
active_export = sanitize_active_picks(active_export, "alpha_engine_scanner")
active_path = DATA_DIR / "active_picks.json"
with open(active_path, "w", encoding="utf-8") as f:
    json.dump(active_export, f, indent=2, ensure_ascii=False, default=str)
```

The `sanitize_active_picks` function (from `feed_hygiene`) is called, but:
1. If import fails, it's a no-op lambda (lines 60-62)
2. There's no validation that the written JSON is actually readable
3. No atomic write — concurrent readers can hit partial JSON (unlike dashboard_generator.py which learned this lesson)

---

## 7. REFACTORING RECOMMENDATIONS

### Immediate (Fix This Week)

1. **Remove the `return False` bypass in `is_daily_blocked()`**
   - File: `risk_controls.py`, line 363-364
   - Delete the bypass and restore the real implementation

2. **Wire risk controls into scanner.py main()**
   - File: `scanner.py`, before line 4148 (open picks check)
   - Add: `cb_status = check_circuit_breaker(db.get_open_picks(), db.get_closed_picks())`
   - Add: `if is_circuit_breaker_locked(): return`
   - Add: `daily_tracker = update_daily_pnl(db.get_open_picks(), db.get_closed_picks())`
   - Add: `if is_daily_blocked(): return`

3. **Guard external signal injectors with kill switch**
   - File: `scanner.py`, lines 4156-4228
   - Move ALL external injectors inside the `else` block of the kill switch check, or add `if _kill_switch_halt: continue` before each injector

4. **Fix the sanitize_active_picks fallback**
   - File: `scanner.py`, lines 60-62
   - Replace the no-op lambda with a function that raises an error if feed_hygiene is unavailable

### Short-Term (Fix This Month)

5. **Consolidate configuration into a single source of truth**
   - Create `config/thresholds.yaml` or `config/thresholds.json`
   - Have `quality_gates.py`, `hc_filter.js`, and `config.py` all read from this file
   - Add a CI check that verifies JS/Python thresholds are in sync

6. **Break up scanner.py into modules**
   - `signal_generator.py`: strategy execution
   - `risk_manager.py`: position sizing, exposure limits, circuit breakers
   - `pick_executor.py`: open_new_picks, check_open_picks
   - `data_exporter.py`: JSON export logic
   - `ml_pipeline.py`: ranker, feature computation, training

7. **Implement ml_score backfill for closed picks**
   - File: `scanner.py`, export section (lines 4742-4780)
   - When exporting closed_picks.json, recompute or preserve ml_score from the original signal
   - Enable `SMART_PICKS_MIN_ML_SCORE` once fill rate is validated

8. **Unify closed pick data sources**
   - Make `closed_picks.json` the ONLY canonical source
   - Have `dashboard_generator.py` read `closed_picks.json` instead of building its own `resolved_closed` from 30+ files
   - OR create a `canonical_closed_picks.json` that is written atomically by a single process

9. **Add deterministic exit_reason at ingest time**
   - File: `scanner.py`, when a pick is closed
   - Store canonical exit_reason (TP_HIT/SL_HIT/TIME_EXIT/FORCE_CLOSED) immediately on close
   - Do not rely on scraper-provided labels like "LOST" or "WON"

### Long-Term (Fix This Quarter)

10. **Add comprehensive test suite**
    - Unit tests for `risk_controls.py` (mock the JSON files)
    - Unit tests for `quality_gates.py` (parametrize threshold changes)
    - Integration tests for scanner.py main() with mocked market data
    - E2E tests for dashboard_generator.py with fixture JSON files

11. **Implement regime_at_entry capture**
    - File: `scanner.py`, when opening a pick
    - Snapshot the HMM regime at the moment of `db.open_pick()`
    - Store it immutably — do not allow downstream updates

12. **Remove crypto LONG bias or make it configurable**
    - File: `quality_gates.py`, line 534
    - Make `SMART_PICKS_CRYPTO_LONG_ONLY` an environment variable
    - If kept, document the statistical basis and review monthly

13. **Add copy trader attribution fields**
    - File: `scanner.py`, copy trader injectors
    - Set `source_system="copy_trader_okx"`, `source_system="copy_trader_bridge"` explicitly
    - Add `copy_trader_confidence`, `copy_trader_leader_id` fields for downstream analysis

14. **Implement atomic JSON writes in scanner.py**
    - File: `scanner.py`, lines 5002-5003, 4768-4769
    - Use the same temp-file + os.replace pattern as dashboard_generator.py

---

## 8. SUMMARY OF CRITICAL FINDINGS

| # | Finding | File | Line | Severity |
|---|---------|------|------|----------|
| 1 | `is_daily_blocked()` returns `False` always, dead code below | `risk_controls.py` | 363-364 | 🔴 Critical |
| 2 | No risk control functions called in scanner.py | `scanner.py` | entire file | 🔴 Critical |
| 3 | Kill switch ineffective vs external signals | `scanner.py` | 4148-4204 | 🔴 Critical |
| 4 | `sanitize_active_picks` bypassable on import failure | `scanner.py` | 60-62 | 🔴 Critical |
| 5 | ml_score 0% populated on closed picks | `quality_gates.py` | 505 | 🔴 Critical |
| 6 | Scanner.py is 5,041-line god object | `scanner.py` | entire file | 🔴 Critical |
| 7 | Three contradictory closed pick data sources | `data/` directory | — | 🟡 Medium |
| 8 | `SMART_PICKS_CRYPTO_LONG_ONLY = True` hardcoded | `quality_gates.py` | 534 | 🟡 Medium |
| 9 | LOST exits are binary labels from copy traders | `quality_gates.py` | 1350-1360 | 🟡 Medium |
| 10 | Position sizing double-computed, precedence unclear | `scanner.py` | 3592-3614 | 🟡 Medium |
| 11 | `ACTIVE_PICKS_MIN_SCORE = 0` (completely permissive) | `quality_gates.py` | 196 | 🟡 Medium |
| 12 | Configuration thresholds scattered in 4+ files | `config.py`, `quality_gates.py`, `hc_filter.js` | — | 🟡 Medium |
| 13 | No test coverage for risk controls or scanner | repo root | — | 🟡 Medium |

**Root Cause of -382.8% PnL**: The risk control layer (`risk_controls.py`) exists as a well-designed module with correct thresholds (-15% emergency, -10% critical, -5% warning, -2% daily block, -3% daily close), but **it is completely disconnected from the execution path**. The `is_daily_blocked()` function was intentionally patched to `return False`, and no other circuit breaker functions are ever called. The kill switch partially works but does not guard external signal sources. Position sizing limits exist in code but may be overridden by Kelly sizing with unclear precedence.

---

*Report generated from direct source code analysis of https://github.com/eltonaguiar/findtorontoevents_antigravity.ca/*
