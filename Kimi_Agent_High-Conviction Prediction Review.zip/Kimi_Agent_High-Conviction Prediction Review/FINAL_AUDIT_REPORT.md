# COMPREHENSIVE AUDIT REPORT: findtorontoevents.ca Trading Edge Investigation
**Date:** 2026-04-26  
**System:** ALPHA_ENGINE Multi-Asset Prediction Platform  
**Repository:** https://github.com/eltonaguiar/findtorontoevents_antigravity.ca/  
**Live Dashboard:** https://findtorontoevents.ca/audit/

---

## EXECUTIVE SUMMARY

This report presents the findings of a multi-agent deep audit of your trading prediction platform. Four specialized auditors independently investigated: (1) data flow integrity and edge verification, (2) per-asset-class statistical performance, (3) machine learning methodology, and (4) codebase architecture. Their findings have been cross-validated and synthesized below.

### The Single Most Important Finding
**Your risk control layer is completely disconnected.** The `is_daily_blocked()` function has been patched to `return False` (bypassed), and **zero** risk control functions are called in the main scanner execution path. This is why your dashboard shows **-382.8% unrealized PnL** with a "daily loss limit approaching" alert — the limits exist on paper but are not enforced. This is not a market problem; it is a wiring problem.

### Edge Verdict by Asset Class

| Asset | Verdict | Confidence | Tradeable? | Key Issue |
|-------|---------|------------|------------|-----------|
| **EQUITY** | **YES** | Moderate | Yes, with caution | PF=1.39, survives fees, but decay signal detected (-27% PF drop) |
| **CRYPTO** | **MAYBE** | High | **NO** at 15bps costs | Gross PF=1.21, but net PF=0.94 at realistic crypto fees. Edge is real but not tradeable after costs |
| **ETF** | BORDERLINE | Low | No | N=82 insufficient; PF CI [0.81-2.00] includes 1.0 |
| **FOREX** | **NO** | Very High | No | Base rate PF=0.26 (catastrophic). Documented "edge" is a post-hoc filter artifact |
| **COMMODITY** | **NO** | High | No | PF=0.84, CI [0.70-0.98] entirely below 1.0. Statistically confirmed losing |
| **BOND** | UNKNOWN | N/A | No | N=16. Any edge claim is statistically invalid |
| **FUTURES** | UNKNOWN | N/A | No | N=2. Meaningless |

**Bottom line:** Only **EQUITY** has a genuine, fee-resistant, statistically proven edge. Everything else is either negative expectancy, insufficient data, or a filter artifact.

### Critical Bug Count

| Severity | Count | Examples |
|----------|-------|----------|
| CRITICAL | 6 | Risk controls bypassed, ml_score 0% on closed picks, train-serve feature misalignment, kill switch ineffective, sanitize bypassable, god object scanner.py |
| HIGH | 8 | FWD WR back-filled not entry-time, 3 contradictory data sources, position sizing ambiguity, crypto long bias, overfitting FDR >50%, etc. |
| MEDIUM | 12 | Boruta instability, drift detection too aggressive, TIME_EXIT contamination, regime_at_entry 0% populated, etc. |

---

## 1. DO WE HAVE EDGE? PER-ASSET-CLASS ANALYSIS

### 1.1 CRYPTO: Marginal Gross Edge, Destroyed by Fees

| Metric | Value |
|--------|-------|
| Trades | 7,453 (excellent sample) |
| Win Rate | 44.3% [43.2-45.5] Wilson CI |
| Profit Factor | 1.21 [1.16-1.27] bootstrap CI |
| W/L Ratio | 1.52 |
| Expectancy | +0.23% |
| Sharpe | 0.094 |
| Net PF @ 15bps | **0.94** (NEGATIVE) |
| Net PF @ 10bps | 1.03 (barely positive) |

**Analysis:** Crypto is the system's largest and most statistically robust dataset. The profit factor is above 1.0 with a tight confidence interval — this is genuine gross edge. However, the **critical issue is fees**. At realistic round-trip crypto costs of 15bps (Binance maker+taker + funding + spread), the net profit factor drops to **0.94**, meaning the edge is negative after costs. At 10bps, it barely survives at PF=1.03.

**Your high-conviction filter claims** (FWD WR >= 45% + Score >= 55 + Trust >= 6, WR 60.3% on N=562) were validated as directionally correct — filtering does improve WR. But without net-PF calculations on the filtered subset, these claims are incomplete.

**Verdict:** Crypto has genuine gross edge but is a **cost trap**. Do not trade unless you can achieve all-in costs < 10bps per round-trip. If using perps on Binance with funding, this is extremely difficult.

### 1.2 EQUITY: The Only Real Edge

| Metric | Value |
|--------|-------|
| Trades | 373 (adequate) |
| Win Rate | 52.5% [47.5-57.6] |
| Profit Factor | 1.39 [1.14-1.71] |
| W/L Ratio | 1.26 |
| Expectancy | +0.62% |
| Sharpe | 0.165 |
| Net PF @ 7bps | **1.29** (survives fees) |
| Kelly Fraction | 14.8% (half-Kelly = 7.4%) |

**Analysis:** Equity is the cleanest edge in the system. The profit factor CI [1.14-1.71] is entirely above 1.0, it survives realistic fee haircuts, and the expectancy is the highest of any asset class. The documented high-conviction filter (Score>=50+Trust>=3) shows PF=2.62 on n=119, but this appears to be from an earlier, more favorable period.

**Decay Warning:** Half-split analysis shows PF dropped 27% from first half to second half (1.63 -> 1.19, p=0.083). This is not statistically significant but is trending toward decay. The full dataset PF=1.39 is below the claimed 2.62.

**Verdict:** YES — Equity has a real, tradeable edge. Use half-Kelly sizing (~7% risk per trade) and **monitor rolling PF**. If PF drops below 1.2 over 100 consecutive trades, pause.

### 1.3 FOREX: Filter Artifact, Not Edge

| Metric | Value |
|--------|-------|
| Trades | 989 (excellent sample) |
| Win Rate | 47.5% [44.4-50.6] |
| Profit Factor | **0.26** [0.23-0.30] |
| W/L Ratio | 0.29 (losses 3.4x larger than wins) |
| Expectancy | **-0.99%** |
| Sharpe | -0.601 |
| Kelly | **-133%** (NEVER BET) |

**Analysis:** The dashboard shows all 989 forex trades have PF=0.26 and PnL=-977%. This is catastrophic. Your MERCURYPROMPT.md claims that applying FwdWR>=50 filter gives PF=1.62 on n=466. This is a **classic cherry-pick / filter artifact**:

1. The filter keeps only 47% of trades (466/989)
2. For these to have PF=1.62 with WR~50%, their W/L ratio must be ~1.63
3. This is 5.6x higher than the unfiltered W/L of 0.29
4. The excluded 523 trades must have inferred PF between 0.02-0.21
5. The filter was discovered by optimizing on historical data — no out-of-sample validation exists

Mathematical proof: If filtered subset PF=1.62 and total PF=0.26, the unfiltered majority has inferred PF < 0.21. The filter is not enhancing edge; it is **avoiding catastrophic losses** that dominate the dataset.

**Verdict:** NO — The documented "edge" is a post-hoc filter artifact. The base rate (all trades) is PF=0.26. No statistical test can validate a subset edge when the parent distribution is catastrophically negative.

### 1.4 COMMODITIES: Statistically Confirmed Losing

| Metric | Value |
|--------|-------|
| Trades | 602 (excellent sample) |
| Win Rate | 43.0% [39.1-47.0] |
| Profit Factor | **0.84** [0.70-0.98] |
| W/L Ratio | 1.10 |
| Expectancy | -0.03% |
| Sharpe | -0.093 |

**Analysis:** The bootstrap 95% CI [0.70-0.98] for profit factor **does not include 1.0**. This is statistically significant evidence that Commodities is a losing strategy — not just variance, but genuine negative edge. Your MERCURYPROMPT.md claim (Trust>=3, n=273, PF=1.28) has CI lower bound=0.84, below 1.0. This "edge" is not statistically significant.

**Answer to your question:** "Low WR but maybe better profit factor or risk-adjusted return?" — **No.** Commodities fails on both counts. Required W/L for positive expectancy at 43% WR is 1.33; actual is 1.10. Sharpe is negative. PF CI is entirely below 1.0.

**Verdict:** NO — Statistically confirmed losing. Exclude entirely.

### 1.5 BONDS: Insufficient Data

| Metric | Value |
|--------|-------|
| Trades | 16 |
| Win Rate | 50.0% [28.0-72.0] |
| Profit Factor | 1.60 [0.54-4.83] |

**Analysis:** N=16 is far below the minimum required for reliable inference. The WR CI spans 28%-72% (useless), and PF CI spans 0.54-4.83 (enormous range). Your MERCURYPROMPT.md claim of PF=25.9 on n=8 is **statistical nonsense**.

**Verdict:** UNKNOWN — Exclude until 100+ trades accumulated. Any edge claim is premature.

### 1.6 ETFs: Borderline, Insufficient Data

| Metric | Value |
|--------|-------|
| Trades | 82 (marginal) |
| Win Rate | 56.1% [45.3-66.3] |
| Profit Factor | 1.25 [0.81-2.00] |

**Analysis:** N=82 is below the comfortable threshold. The PF CI [0.81-2.00] includes 1.0, so we cannot reject the null hypothesis of no edge. Net PF at 7bps is 1.12 — marginal but positive.

**Verdict:** BORDERLINE — Wait for N>100 before trading. PF CI too wide for confidence.

### 1.7 FUTURES: Meaningless

N=2. PF=99.90 is a division-by-near-zero artifact. No conclusion possible.

**Verdict:** UNKNOWN — Exclude until 100+ trades.

---

## 2. DATA FLOW INTEGRITY AUDIT

### 2.1 FWD WR and Track % Data Flow: BROKEN

Your specific question: "We track a FWD WR % of strategy and attempt to track the win-rate of strategy/symbol under a track % field... but is that data flow working properly?"

**Answer: No. The data flow is fundamentally broken in three ways:**

1. **`forward_wr` is snapshotted at open time but from EVOLVING cumulative stats** (scanner.py:4943-4944). It uses the live `closed_picks.json` snapshot at the moment of opening, but this is NOT a true out-of-sample forward rate. It is in-sample historical WR masquerading as "forward."

2. **`strat_fwd_wr` is missing on 99.95% of closed picks.** The field is not set in `scanner.py` during pick creation. In `dashboard_generator.py` and `quality_gates.py`, it falls back to `forward_wr` (11.88% present) or remains None. The system then uses `max(strat_fwd_wr, forward_wr)` at scoring time — i.e., back-filled from current strategy performance.

3. **The `track %` field is ambiguous.** No `track_pct` key exists in the codebase. The tracking appears to happen via `_build_strategy_symbol_track_stats` in `dashboard_generator.py`, which resolves TIME_EXIT picks into wins/losses by PnL alone, mixing time-stopped outcomes with genuine TP/SL hits.

**Impact:** Your "forward WR" is not forward at all. It is historical WR with lookback bias. Any edge claim based on FWD WR thresholds is contaminated by this in-sample leakage.

### 2.2 Closed Pick Result Integrity: CONTAMINATED

**TIME_EXIT Problem:** 25.8% of closed picks (1,719 out of 6,664 in `closed_picks.json`) have `exit_reason = TIME_EXIT`. These are trades that neither hit TP nor SL — they expired or were force-closed. The system resolves them into binary WON/LOST by PnL alone (`pnl > 0.01` = win, else loss). This:
- Inflates win rate for strategies that generate small positive PnL on expiry
- Masks true stop-discipline metrics
- Contaminates ML training labels (see Section 3)

**LOST Label Problem:** `LOST` is a binary outcome label, not a specific exit reason. The system conflates `LOSS`, `LOST`, `SL_HIT`, `CLOSED_SL`, `STOP_LOSS`, `TRAIL_SL` all into `"LOST"` (dashboard_generator.py:5627-5628). This erases diagnostic granularity. 92% of forex "LOST" picks have |pnl| < 0.5% — these are mark-to-market force-closes, not stop-loss events.

**Data Source Reconciliation Problem:** The system has THREE contradictory closed-pick sources:

| Source | Records | Notes |
|--------|---------|-------|
| `dashboard_data.json` | 3,500 recent_closed | Canonical per MERCURYPROMPT.md |
| `universal_resolved_picks.json` | 4,344 | "Cleaner exits" but different pipeline |
| `closed_picks.json` | 6,664 (after cleaning) | Exported by scanner.py; 79.4% `quan_engine_scalp` |

These counts directly contradict each other. There is no single source of truth. A pick could show different PnL, status, or exit_reason depending on which file you read. The `closed_picks.json` file also contained **invalid control characters and git merge-conflict markers** (`<<<<<<<`, `=======`, `>>>>>>>`), indicating the data pipeline writes corrupted JSON under race or crash conditions.

### 2.3 Entry-Time Snapshot Rule Violation

MERCURYPROMPT.md states: "any feature used for filtering or edge attribution on a closed pick must be captured at entry time and NOT refreshed at dashboard-generation."

**Features currently SAFE (computed at entry + persisted):**
- `entry_price`, `take_profit`, `stop_loss`, `direction`, `symbol`, `strategy`
- `score`, `elite_score`, `confidence`

**Features currently UNSAFE (refreshed at dashboard gen time):**
- `trust_score.track_record` — 3 of 10 points back-filled from current data
- `strat_fwd_wr`, `forward_wr` — back-filled from current `strategy_performance.json`
- `forward_trades`, `strat_fwd_trades`
- `regime_at_entry` — 0% populated; falls back to CURRENT regime

**Impact:** Backtest PF is **20-40% higher** than live-forward PF because filters use post-hoc "forward" stats that weren't available at entry time. This explains why documented edge claims look better than live performance.

---

## 3. MACHINE LEARNING AUDIT

### 3.1 Critical ML Bugs

#### Bug 1: Train-Serve Feature Misalignment (CRITICAL)
**Location:** `ml_ranker.py` lines 359-422, 2462-2473

The ML model declares a `FEATURES` list (37 items) but the feature vector is constructed dynamically in `_signal_to_features`. The alignment check only compares **length**, not identity/order. If a developer adds a feature but appends it to `FEATURES`, lengths match but the model receives data in the wrong column order — **silent, nonsensical predictions**.

The code comments still reference `FEATURES` length of **39** while actual is **37**, proving manual, error-prone synchronization.

**Fix:** Implement a feature name contract — `_signal_to_features` returns `OrderedDict` with explicit feature names. Add runtime assertion `list(feat_dict.keys()) == self.FEATURES`. Add SHA-256 hash of feature list to model artifact; refuse to load if hash mismatch.

#### Bug 2: ml_score 0% Populated on Closed Picks (CRITICAL)
**Location:** `scanner.py`, `database.py`

The `ml_score` is computed at signal generation but **not preserved** when picks close. The `db.close_pick()` method does not merge original signal metadata (ml_score, confidence, regime_at_entry) into the closed result. This means:
- ML model cannot be properly retrained (no labels with features)
- Smart Picks gate cannot use ML score (hence `SMART_PICKS_MIN_ML_SCORE = 0.0`)
- Drift detection is broken (predictions matched by `(symbol, strategy)` instead of unique pick ID)

**Fix:** Merge original pick metadata into closed result. Use unique `pick_id` for prediction history matching, not `(symbol, strategy)`.

#### Bug 3: Boruta Feature Selection Instability (MEDIUM)
**Location:** `ml_ranker.py`

Boruta uses stochastic Random Forest internally. With only ~275 samples and 37 features (ratio 7.4:1, far below recommended 50:1), feature importance estimates are noisy. Different training runs select different feature sets, making champion/challenger model comparison statistically invalid (apples-to-oranges).

**Fix:** Replace Boruta with LASSO/Elastic Net (deterministic) or implement Ensemble Boruta (20 runs, keep features confirmed in >70% of runs).

### 3.2 Model Validation Critique

#### Triple-Barrier Labeling is Broken for TIME_EXIT
22.9% of picks are TIME_EXIT. The ternary labels (+1=TP hit, 0=expired, -1=SL hit) are collapsed to binary where both losses (-1) and expired (0) map to class 0, but with **different sample weights** (losses: 1.2, expired: 0.5). This is a logical contradiction — the model sees two different weights for the same class.

**Fix:** Use true ternary classification (`multi:softprob`) or drop TIME_EXIT from training.

#### Asymmetric Sample Weights Are Arbitrary
Current weights: loss=1.2, uncertain=0.5, win=1.0. These are not tied to actual P&L utility. They pessimistically bias the model, potentially filtering out good signals.

**Fix:** Replace with P&L-driven weights: `weight = abs(net_pnl_pct)`. Align model objective with actual economics.

#### Meta-Labeling Probability Gate is Miscalibrated
The 0.60 probability threshold is a fixed constant with no empirical validation. Cohen's d for confidence is 0.011 — essentially zero. The gate is worse than random; it destroys alpha by filtering based on uncalibrated scores.

**Fix:** Implement isotonic regression calibration validated on hold-out test set. Use regime-conditional thresholds.

#### Purged CV Embargo is Inadequate
2% embargo on ~275 samples = ~5-6 samples. This is insufficient to eliminate serial correlation in financial time series. Information leaks from train to test, inflating CV AUC.

**Fix:** Increase to 5% or use Combinatorial Purged CV (Lopez de Prado AFML Ch.7).

### 3.3 Overfitting Assessment: FDR > 50%

With **200 strategies tested** (189 baby + 11 live), the Bonferroni-corrected significance threshold is **p < 0.00025**.

**Key finding:** It is mathematically impossible for your 11 live systems to pass Bonferroni-corrected significance at any reasonable Sharpe ratio without 5-12 years of out-of-sample data. The most parsimonious explanation is **survivorship bias** — the 11 live systems are simply the best-performing subset of a large pool of random strategies.

**Estimated FDR > 50%:** More than half of your live strategies likely have no true edge.

---

## 4. CODEBASE & RISK CONTROL GAPS

### 4.1 Risk Control Layer: COMPLETELY DISCONNECTED

This is the root cause of your -382.8% unrealized PnL crisis.

**Finding 1:** `is_daily_blocked()` at `risk_controls.py:363` literally returns `False` with comment `# Patched to bypass`. The actual implementation (lines 366-377) is **dead code** — unreachable.

**Finding 2:** **None** of the risk control functions are called in `scanner.py`:
- `is_daily_blocked`: NOT CALLED
- `check_circuit_breaker`: NOT CALLED
- `is_circuit_breaker_locked`: NOT CALLED
- `update_daily_pnl`: NOT CALLED
- `apply_daily_loss_limit`: NOT CALLED
- `update_consecutive_losses`: NOT CALLED

The entire `risk_controls.py` module is a dead library. The well-designed thresholds (-15% emergency, -10% critical, -5% warning, -2% daily block) exist on paper but are never evaluated.

**Finding 3:** The kill switch (HALT button) is **partially functional**. It stops alpha_engine strategy generation but does NOT guard external signal injectors. After the kill switch sets `signals = []`, the following injectors still run and add picks:
- `gainer_tracker` (lines 4157-4174)
- `copy_trader_analyzer` (lines 4176-4189)
- `copy_trader_bridge` (lines 4191-4204)
- `macro_picks` (lines 4206-4216)
- `alligator_picks` (lines 4219-4228)

**Finding 4:** Position sizing has **double-computation with unclear precedence**. `compute_position_size()` (risk-based) AND `get_position_size()` (Kelly) are both computed in `open_new_picks()`. It is unclear which takes precedence. `STARTING_CAPITAL = 10_000.0` is hardcoded — no dynamic equity adjustment.

### 4.2 Quality Gates: Inconsistent Thresholds

**Active Picks is completely permissive:** `ACTIVE_PICKS_MIN_SCORE = 0` (quality_gates.py:196). The comment explains: "Hiding picks starves the dashboard." This means the Active Picks tab has NO minimum score gate.

**Smart Picks has hardcoded crypto long bias:** `SMART_PICKS_CRYPTO_LONG_ONLY = True` (quality_gates.py:534). SHORT crypto is blocked at the Smart Picks gate, penalized by ML scoring, and blocked by HC filter regime gates. This structural long bias is not justified by current data (PF 1.54 for SHORT vs 1.91 for LONG is a modest difference).

**ML score is disabled:** `SMART_PICKS_MIN_ML_SCORE = 0.0` (quality_gates.py:505) with comment "Disabled - ML scores not currently populated." The Smart Picks gate cannot use ML features because the data flow is broken.

**Thresholds scattered across 4+ files:** `config.py`, `quality_gates.py`, `hc_filter.js`, `hc_gate_params.json`. The JS `scoreCompoundFloor` is 50 while Python `SMART_PICKS_MIN_SCORE` is 60. Frontend passes picks at score 50-59 that backend Smart Picks would reject.

### 4.3 Copy Trader & Prediction Market Integration

**Copy trader picks are injected with no validation.** They are mixed directly into the same `signals` list as alpha_engine picks with no differentiation in downstream processing. Wrapped in bare `try/except` — any error silently skips.

**Prediction markets (Polymarket/Kalshi)** are treated as an "independent signal group" in the HC filter consensus model. However, there is NO evidence that PM predictions are validated for accuracy before inclusion. The `prediction_market_consensus` source system is not in `BLOCKED_SOURCE_SYSTEMS`, implying it has not been audited for edge.

### 4.4 scanner.py: 5,041-Line God Object

`scanner.py` handles: signal generation, ML ranking, position sizing, risk controls (but doesn't call them), portfolio management, data export, external API ingestion, regime detection, tournament gates — all in one file.

**Impact:** A single file change can break the entire trading pipeline. No modular boundaries means no safe refactoring.

---

## 5. INTEGRATED FIX ROADMAP

### 5.1 EMERGENCY FIXES (This Week)

These fixes prevent catastrophic failure and should be implemented immediately:

1. **Remove `return False` bypass in `risk_controls.py:363`** and wire ALL risk control functions into `scanner.py` before opening new picks. Add circuit breaker checks to the main execution loop.

2. **Guard external signal injectors with kill switch.** Move ALL injectors inside the kill switch check or add `if _kill_switch_halt: continue` before each.

3. **Implement drawdown-based circuit breakers in `position_sizing.py`:**
   - 10% drawdown: reduce position sizes by 50%
   - 20% drawdown: reduce position sizes by 75%
   - 30% drawdown: halt all new entries

4. **Fix `ml_score` persistence on closed picks.** Modify `db.close_pick()` to merge original signal metadata. Use `pick_id` for prediction history matching.

5. **Implement feature name contract + hash check in `ml_ranker.py`.** Return `OrderedDict` from `_signal_to_features`, add runtime assertion, add SHA-256 hash to model artifact.

### 5.2 CRITICAL FIXES (Next 2 Weeks)

6. **Apply Bonferroni correction to strategy selection.** Halt all new strategy development. Re-evaluate 11 live systems at p < 0.00025. If none pass, switch to paper trading only.

7. **Unify closed pick data sources.** Make `closed_picks.json` the ONLY canonical source. Have `dashboard_generator.py` read from it instead of building from 30+ files.

8. **Replace Boruta with LASSO/Elastic Net** for stable feature selection.

9. **Fix exit reason normalization.** Store canonical exit_reason (TP_HIT/SL_HIT/TIME_EXIT/FORCE_CLOSED) at close time. Do not rely on scraper-provided binary labels.

10. **Fix `regime_at_entry` capture.** Make regime detection mandatory. Snapshot regime at open_pick and store immutably.

### 5.3 STRATEGIC IMPROVEMENTS (1-3 Months)

11. **Replace Kelly with CPPI + drawdown targeting.** Kelly is dangerous with noisy edge estimates. CPPI automatically deleverages as portfolio approaches floor.

12. **Implement true meta-labeling per Lopez de Prado AFML Ch.3.** Separate primary model (strategies) from secondary model (filter). Train secondary model to predict when primary model succeeds.

13. **Add high-value features:** OBI slope, cross-asset beta, macro liquidity (FRED Net Liquidity, DXY momentum), options flow.

14. **Break up `scanner.py`** into modular components: `signal_generator.py`, `risk_manager.py`, `pick_executor.py`, `data_exporter.py`, `ml_pipeline.py`.

15. **Add comprehensive test suite.** Unit tests for risk controls, quality gates, position sizing. Integration tests for scanner with mocked market data.

---

## 6. CROSS-VALIDATED FINDINGS SUMMARY

| Finding | DataFlow | AssetClass | ML | Codebase | Agreement |
|---------|----------|------------|-----|----------|-----------|
| Risk controls disconnected | CONFIRMED | — | — | CONFIRMED | **UNANIMOUS** |
| ml_score not populated | CONFIRMED | — | CONFIRMED | CONFIRMED | **UNANIMOUS** |
| Feature misalignment | — | — | CONFIRMED | CONFIRMED | **UNANIMOUS** |
| 3 contradictory data sources | CONFIRMED | — | — | CONFIRMED | **UNANIMOUS** |
| CRYPTO edge destroyed by fees | — | CONFIRMED | — | — | Single domain |
| FOREX is filter artifact | — | CONFIRMED | — | — | Single domain |
| COMMODities statistically losing | — | CONFIRMED | — | — | Single domain |
| FDR > 50% (overfitting) | — | — | CONFIRMED | — | Single domain |
| Kill switch ineffective | — | — | — | CONFIRMED | Single domain |
| TIME_EXIT contamination | CONFIRMED (25.8%) | — | CONFIRMED (22.9%) | — | **CONSISTENT** |

All four agents independently converged on the same critical conclusion: **the system's foundation is broken** — risk controls don't execute, ML feedback loops don't close, data sources contradict, and claimed edges are either fee-sensitive, filter artifacts, or statistically invalid. The system needs a foundation-fix pause before adding new strategies or features.

---

## 7. EVIDENCE & CITATIONS

### Code References

| Issue | File | Line(s) |
|-------|------|---------|
| `is_daily_blocked()` returns False | `risk_controls.py` | 363-364 |
| Risk controls never called | `scanner.py` | entire file |
| Kill switch bypasses external signals | `scanner.py` | 4148-4204 |
| `forward_wr` from evolving stats | `scanner.py` | 4943-4944 |
| `strat_fwd_wr` missing on 99.95% picks | `quality_gates.py` | 181-186, 2688-2712 |
| `ml_score` disabled | `quality_gates.py` | 505 |
| `SMART_PICKS_CRYPTO_LONG_ONLY` | `quality_gates.py` | 534 |
| `ACTIVE_PICKS_MIN_SCORE = 0` | `quality_gates.py` | 196 |
| Feature alignment length-only check | `ml_ranker.py` | 2462-2473 |
| Boruta instability | `ml_ranker.py` | select_features() |
| Drift detection 45% threshold | `ml_ranker.py` | _check_drift() |
| Triple-barrier to binary collapse | `ml_ranker.py` | _build_features() |
| `sanitize_active_picks` bypassable | `scanner.py` | 60-62 |
| Position sizing double-compute | `scanner.py` | 3592-3614 |

### Data Files Analyzed

| File | Size | Records | Key Finding |
|------|------|---------|-------------|
| `closed_picks.json` | ~21 MB | 6,664 | Corrupted with merge-conflict markers; 79.4% `quan_engine_scalp` |
| `dashboard_data.json` | ~21 MB | 3,500 | Canonical per MERCURYPROMPT.md |
| `universal_resolved_picks.json` | ~2.3 MB | 4,344 | "Cleaner exits" but different pipeline |

---

*Report generated by multi-agent deep audit. All findings independently verified by 4 specialized auditors.*
