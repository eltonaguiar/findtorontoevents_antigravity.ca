# Investigation Plan: findtorontoevents.ca/audit/ Trading Edge Analysis

## Objective
Comprehensive technical investigation of the prediction/trading platform to:
1. Validate edge claims by asset class
2. Audit data flow integrity (FWD WR, closed pick tracking, track %)
3. Analyze ML algorithms and propose enhancements
4. Integrate hedge fund/quant risk management concepts
5. Fix flawed edge identification logic
6. Assess profit factor vs win-rate by asset class (especially Commodities/Bonds)

## Stage 1 — Reconnaissance & Documentation Collection
Load: `deep-research-swarm`, `batch-download`
- Visit website and capture all documentation links
- Clone GitHub repo and analyze structure
- Extract all .MD files (MERCURYPROMPT.md, what-if analyses, guides)
- Map the data pipeline: picks → closed picks → FWD WR → track %
- Identify all asset classes and their data sources

## Stage 2 — Parallel Deep Analysis
Load: `deep-research-swarm` (continued)
Sub-agents deployed in parallel:
### Agent A: Data Flow & Edge Verification Auditor
- Audit FWD WR calculation methodology
- Check closed pick result tracking integrity
- Verify if closed picks properly show results vs stuck in "open" state
- Analyze track % field data flow
- Validate Profit Factor vs Win Rate by asset class
- Check for survivorship bias, lookahead bias, data snooping

### Agent B: Asset Class Performance Analyst  
- Deep dive per asset class (Crypto, Equity, Forex, Commodity, Bond, ETF, Futures)
- Compare Win Rate vs Profit Factor vs Risk-Adjusted Returns
- Analyze why Commodities/Bonds show low WR but might have PF edge
- Evaluate sample sizes (N) and statistical significance
- Bootstrap confidence interval analysis

### Agent C: Machine Learning & Quant Methodology Investigator
- Analyze current ML algorithms in codebase
- Review feature engineering, target labeling, train/test splits
- Check for overfitting, regime detection, ensemble methods
- Identify enhancements from hedge fund/quant literature
- Evaluate position sizing, risk management (Kelly, CPPI, drawdown controls)

### Agent D: GitHub Codebase & Integration Analyst
- Full repo structure analysis
- Identify hc_filter.js logic and thresholds
- Check Polymarket/Kalshi integration points
- Review copy trader pick integration
- Find bugs in edge calculation logic

## Stage 3 — Cross-Validation & Synthesis
- Cross-validate findings from all 4 agents
- Reconcile contradictory assessments
- Identify highest-confidence edge claims
- Flag data integrity issues requiring immediate fixes

## Stage 4 — Recommendations & Fix Specifications
- Specific code fixes for flawed logic
- ML enhancement roadmap
- Risk management framework improvements
- Asset class-specific strategy adjustments
- Data pipeline integrity fixes

## Stage 5 — Final Report
- Convert to formatted deliverable
- Include evidence screenshots, code snippets, citations
- Actionable priority matrix (Quick Wins vs Strategic Initiatives)
