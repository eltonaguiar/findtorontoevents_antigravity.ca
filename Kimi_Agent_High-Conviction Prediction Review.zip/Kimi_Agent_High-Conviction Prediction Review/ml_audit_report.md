I am writing this technical report to conduct a comprehensive audit of your trading system's Machine Learning (ML) infrastructure, quantitative methodologies, and data integrity. I have completed a thorough review of the core engine files, including `ml_ranker.py`, `scanner.py`, `elite_scorer.py`, and `position_sizing.py`. My analysis focuses on identifying critical bugs, evaluating the robustness of the current modeling approach, and providing a strategic roadmap for enhancement based on established best practices in quantitative finance and academic research (specifically referencing Marcos Lopez de Prado's 'Advances in Financial Machine Learning' and the works of Ernie Chan).

This report is structured into five key areas of investigation:
1.  **ML Bug Findings**: Specific, actionable bug reports with severity ratings, focusing on the train-serve feature misalignment, missing ML scores on historical picks, and instability in feature selection.
2.  **Model Validation Critique**: An evaluation of the current methodology, including the appropriateness of triple-barrier labeling, the bias introduced by asymmetric sample weights, and the adequacy of the cross-validation process.
3.  **Enhancement Roadmap**: Prioritized recommendations for feature engineering, model architecture, and advanced ensemble methods to improve predictive power and stability.
4.  **Risk Management Recommendations**: Critical analysis of the Kelly Criterion implementation and suggestions for drawdown-based deleveraging and circuit breakers to protect against negative expectancy crises.
5.  **Overfitting Assessment**: A statistical examination of your "edge" claims, applying Bonferroni and False Discovery Rate (FDR) corrections to determine if your live strategies represent genuine alpha or are simply the best-performing subset of a large, tested pool (survivorship bias).

Each section is accompanied by specific code references, mathematical explanations, and concrete examples of how to implement the recommended fixes. This report is designed to provide you with a clear, prioritized path to transform your current system from a fragile, research-phase project into a robust, production-ready quantitative engine.

# Machine Learning Audit and Quantitative Enhancement Report

**Date:** 2026-05-23
**Audited System:** ALPHA_ENGINE Multi-Asset Trading System
**Source Repository:** `https://github.com/eltonaguiar/findtorontoevents_antigravity.ca/`
**Auditor:** Senior Machine Learning Engineer / Quantitative Researcher
**Academic Foundation:** Lopez de Prado (AFML), Chan (Algorithmic Trading), Kursa & Rudnicki (Boruta), Liu et al. (JFE 2022)

---

## 1. ML Bug Findings: Specific Bugs with Severity Ratings

This section identifies critical bugs in the machine learning pipeline, data flow, and model execution. Each bug is rated by severity and includes specific file references and root cause analysis. Immediate remediation is recommended for all 🔴 CRITICAL and 🟡 MEDIUM severity issues.

### 1.1 🔴 CRITICAL: Train-Serve Feature Misalignment

**Bug ID:** FEAT-001 | **Severity:** 🔴 CRITICAL | **Status:** OPEN (Partially Mitigated but Structurally Fragile)

#### 1.1.1 Root Cause: Drift Between `FEATURES` Declaration and `_signal_to_features` Output

The core of this bug lies in a fundamental structural fragility within the `MLSignalRanker` class in `ml_ranker.py`. The system declares a canonical list of features in the `FEATURES` class attribute, but the actual feature vector is constructed dynamically in the `_signal_to_features` method. While the current code (as of the latest commit) appears to have synchronized the `FEATURES` list (37 items) with the `feat` array (37 elements) after previous discrepancies, the mechanism that guards against future misalignment is dangerously brittle.

The `score_signal` method contains a "Feature alignment check" (`ml_ranker.py`, near line 2462-2473) that is intended to catch mismatches. However, this check is fundamentally flawed in its logic:

```python
# From ml_ranker.py, score_signal() method
_expected_len = len(self.FEATURES) if self.selected_feature_indices is not None else len(self.trained_feature_names)
if self.trained_feature_names and len(feat) != _expected_len:
    print(f"[WARN] Feature count mismatch: expected {_expected_len} features, got {len(feat)}. "
          f"Falling back to heuristic scoring.")
    return self._heuristic_score(signal, strategy_stats, convergence)
```

**The critical flaw is twofold:**

1.  **False Negative on Active Feature Mask:** The check only compares the length of the incoming `feat` vector against `len(self.FEATURES)`. It does **not** verify that the *identity* and *order* of the features match the model's training expectations. If a developer adds a new feature to the `feat` array but appends it to the end of the `FEATURES` list, the lengths will match, but the model will be fed data in the wrong column order, leading to silent, nonsensical predictions.

2.  **Commented Legacy Code and Stale References:** The code comments within `score_signal` still reference a `FEATURES` length of **39**, while the actual list contains **37**. This indicates a history of frequent modification without rigorous synchronization. The comment states: `# When Boruta is active, feat has full FEATURES length (39) but trained_feature_names has the reduced count.` This stale reference proves the synchronization process is manual and error-prone.

Furthermore, the `_build_features` method contains a hack to handle situations where the feature matrix `X` has more columns than the `FEATURES` list, which occurs when the (now-disabled) backtest bridge adds extra columns. This hack simply pads the feature names with generic labels like `feat_37`, `feat_38`, which destroys any possibility of meaningful feature selection or importance analysis on those columns.

```python
# From ml_ranker.py, train() method
# Pad _active_features if X has more columns than FEATURES
# (happens after backtest bridge augmentation adds extra columns)
while len(_active_features) < X.shape[1]:
    _active_features.append(f"feat_{len(_active_features)}")
```

This structural fragility means that any future addition, removal, or reordering of features by a developer will almost certainly break the model's predictive capability without raising a hard error, causing the system to silently fall back to a less sophisticated heuristic scorer.

#### 1.1.2 Impact: Silent Fallback to Heuristic Scoring, Model Performance Degradation

The immediate impact of this bug is that the system operates without a functioning ML model for a non-trivial portion of its execution time. When a feature count or identity mismatch is detected (or, more dangerously, *not* detected due to the flawed length-only check), the `score_signal` method silently routes all incoming signals to the `_heuristic_score` fallback.

The heuristic scorer (`ml_ranker.py`, lines ~2480-2550) is a rules-based system that assigns scores based on simple thresholds (e.g., `rsi_val > 75` -> `-0.10`, `funding > 0.0001` and `direction == SHORT` -> `+0.06`). While this provides a baseline, it completely negates the purpose of the sophisticated gradient boosting ensemble, which is designed to learn complex, non-linear interactions between microstructure, funding, and cross-sectional features.

**Operational Consequences:**
*   **Loss of Alpha:** The primary source of the system's claimed edge—the ML ensemble—is bypassed. The scanner falls back to a pre-defined rule set that cannot adapt to changing market regimes.
*   **Unpredictable Behavior:** Because the fallback is silent (it only prints a `[WARN]` message), operators may not realize the ML model is offline for hours or days. The dashboard would still show `ml_score` values, but they would be derived from the heuristic, not the trained model.
*   **Training Data Corruption:** If the misalignment occurs during the training phase (e.g., `_build_features` produces a different matrix than the saved `trained_feature_names` suggest), the saved model artifact will be internally inconsistent. Loading this model later will lead to persistent prediction errors.

#### 1.1.3 Fix: Implement Feature Name Contract, Hash Verification, and Automated Alignment

To permanently resolve this issue, a multi-layered defensive strategy must be implemented. The goal is to make feature misalignment **impossible** or, at minimum, **immediately and loudly fatal**.

**Layer 1: The Feature Name Contract (Hard Enforcement)**

Instead of relying on implicit order, `_signal_to_features` must return an **ordered dictionary** (or a named tuple) that explicitly maps feature names to their computed values. This decouples the feature vector from positional indexing.

```python
# --- RECOMMENDED FIX FOR ml_ranker.py ---

# 1. Modify _signal_to_features to return an OrderedDict
from typing import OrderedDict

def _signal_to_features(self, signal: dict) -> Optional[np.ndarray]:
    # ... (existing computation logic) ...
    
    feat_dict = OrderedDict()
    feat_dict['confidence'] = float(signal.get("confidence", 0.5) or 0.5)
    feat_dict['volume_ratio'] = _vol_ratio_norm
    feat_dict['direction_market_alignment'] = _dma
    # ... populate all features explicitly by name ...
    feat_dict['btc_24h_change_norm'] = max(-1.0, min(1.0, _safe(signal.get("btc_24h_change") or mf.get("btc_24h_change"), 0.0) / 10.0))
    
    # 2. Ensure the dictionary keys match the FEATURES list exactly
    if list(feat_dict.keys()) != self.FEATURES:
        missing = set(self.FEATURES) - set(feat_dict.keys())
        extra = set(feat_dict.keys()) - set(self.FEATURES)
        raise RuntimeError(
            f"CRITICAL FEATURE MISMATCH: Missing={missing}, Extra={extra}. "
            f"The _signal_to_features output does not match the FEATURES contract."
        )
    
    arr = np.array(list(feat_dict.values()), dtype=np.float64)
    np.nan_to_num(arr, copy=False, nan=0.0, posinf=0.0, neginf=0.0)
    return arr
```

**Layer 2: Feature Hash Verification (Model Artifact Integrity)**

When a model is trained, a cryptographic hash (e.g., SHA-256) of the `FEATURES` list should be computed and saved alongside the model artifact. At load time, the hash is verified. If the current code's `FEATURES` list does not match the hash of the list the model was trained with, the system must refuse to load the model.

```python
# --- RECOMMENDED FIX FOR ml_ranker.py ---
import hashlib
import joblib

class MLSignalRanker:
    # ...
    
    def _compute_feature_hash(self) -> str:
        """Compute a SHA-256 hash of the canonical FEATURES list."""
        feature_string = json.dumps(self.FEATURES, sort_keys=False)
        return hashlib.sha256(feature_string.encode()).hexdigest()

    def train(self, db) -> dict:
        # ... after training is complete ...
        feature_hash = self._compute_feature_hash()
        artifact = {
            "model": self.model,
            # ... other fields ...
            "feature_hash": feature_hash, # <-- ADD THIS
            "feature_names": list(self.FEATURES), # <-- ADD THIS explicitly
        }
        joblib.dump(artifact, str(ML_MODEL_PATH))
        
    def _load_model(self):
        if ML_MODEL_PATH.exists():
            try:
                saved = joblib.load(str(ML_MODEL_PATH))
                # --- HASH VERIFICATION ---
                current_hash = self._compute_feature_hash()
                saved_hash = saved.get("feature_hash")
                if saved_hash and saved_hash != current_hash:
                    print(f"  [ML] FATAL: Feature hash mismatch! Model trained with different features."
                          f" Model hash: {saved_hash}, Current hash: {current_hash}."
                          f" Forcing full retrain.")
                    self.is_trained = False
                    return # Do not load the incompatible model
                # ... rest of loading logic ...
```

**Layer 3: Boruta Alignment Safety**

The Boruta feature selection logic must also be made robust. The `selected_feature_indices` are indices into the `FEATURES` list. If the `feat` array is produced by iterating over the `FEATURES` list (as in the recommended `OrderedDict` approach), the indices will always be correct.

```python
# In score_signal:
if self.selected_feature_indices is not None:
    # Ensure indices are valid for the current feature vector
    if max(self.selected_feature_indices) >= len(feat):
        raise IndexError("Boruta selected indices out of bounds for current feature vector.")
    _feat = feat[self.selected_feature_indices]
```

By implementing these three layers, the system moves from a fragile, manual synchronization process to a hardened, self-verifying pipeline where any feature drift is caught immediately, either at development time (via the contract check) or at runtime (via the hash verification).

### 1.2 🔴 CRITICAL: `ml_score` is 0% Populated on Closed Picks

**Bug ID:** DATA-001 | **Severity:** 🔴 CRITICAL | **Status:** OPEN

#### 1.2.1 Root Cause: `ml_score` Not Persisted in `closed_picks.json` or ML Training Data

The `ml_score` is correctly computed at signal generation time in `scanner.py` (`rank_and_filter_signals`) and is correctly passed into `db.open_pick()` when a new position is opened. However, there is a critical break in the data persistence loop: the `ml_score` is **not** being preserved when the pick is subsequently closed and exported to `closed_picks.json`, nor is it being retrieved by `db.get_ml_training_data()`.

In `scanner.py`, the `check_open_picks` function closes positions and appends the result to the `closed` list:

```python
# From scanner.py, check_open_picks()
result = db.close_pick(
    pick["id"], exit_price, exit_reason, hwm,
    transaction_cost_pct=cost_data["transaction_cost_pct"],
    cost_model=cost_data["cost_model"],
)
closed.append(result)
```

The `result` dictionary returned by `db.close_pick()` typically contains the `pick_id`, `status` (WON/LOST), `pnl_pct`, and `exit_reason`. **Crucially, it does not merge in the original signal metadata** such as `ml_score`, `confidence`, `regime_at_entry`, or any of the `extra_json` fields that were stored when the pick was opened. This means the `closed_picks.json` file, which is the primary data source for ML training, contains trade outcomes but **lacks the ML score that was assigned at entry time**.

Furthermore, the `update_prediction_outcomes` method in `ml_ranker.py`, which is intended to backfill the prediction history for drift detection, also has a related flaw:

```python
# From ml_ranker.py, update_prediction_outcomes()
def update_prediction_outcomes(self, closed_picks: list) -> int:
    # ...
    outcome_map: dict[tuple[str, str], int] = {}
    for pick in closed_picks:
        sym = pick.get("symbol", "")
        strat = pick.get("strategy", "")
        # ... maps to binary outcome ...
        outcome_map[(sym, strat)] = 1 if label == 1 else 0
```

This function matches predictions to outcomes using only `(symbol, strategy)` as a key. If the same strategy fires multiple signals on the same symbol (which is common), this matching is **ambiguous**. The `ml_score` from the pick is not used to match the specific prediction, and the prediction history only stores `predicted_prob`, not the pick's unique ID.

#### 1.2.2 Impact: ML Model Cannot Learn From Its Own Predictions; No Historical Validation

This bug creates a catastrophic disconnect between the model's predictions and the system's ability to evaluate them. The consequences are severe and multi-faceted:

1.  **No Feedback Loop for Calibration:** The Isotonic Regression calibrator (`self.calibrator`) is trained on `val_proba` vs. `y_val_binary` from a single validation split. It is **never updated** with the model's actual out-of-sample performance on live data. Because the `ml_score` at entry is not linked to the outcome at exit, the system cannot recalibrate probabilities based on real-world results. This directly contributes to the reported issue that "Confidence doesn't predict outcomes (Cohen's d = 0.011)."
2.  **Impossible to Compute Strategy-Specific ML Performance:** You cannot answer the most basic question: "Does the ML model perform better on signals from Strategy A than Strategy B?" Without the `ml_score` on closed picks, you cannot segment your P&L by ML score deciles to see if the model is actually adding value.
3.  **Broken Drift Detection:** The `_check_drift` method monitors the accuracy of the model's predictions over a rolling window. However, `record_prediction` stores predictions by `(symbol, strategy)`, and `update_prediction_outcomes` matches them back the same way. If a strategy generates multiple signals on the same symbol, or if the matching fails for any reason, the `actual_outcome` field in the prediction history remains `None`. The drift detector then evaluates a dataset with a large proportion of missing outcomes, making it statistically noisy and prone to false negatives (missing real drift) or false positives (triggering unnecessary full retrains).
4.  **Inability to Perform Meta-Labeling Validation:** Lopez de Prado's meta-labeling framework requires a primary model (the strategies) and a secondary model (the ML) that learns to predict *when* the primary model will succeed. Without the `ml_score` on every closed pick, you cannot train or validate this secondary model. The current system is attempting to do this but is learning on a dataset where the ML labels are missing.

#### 1.2.3 Fix: Store `ml_score` in `extra_json`; Update `get_ml_training_data` to Join and Export

The fix requires changes in three places: the database write path, the database read path, and the prediction history tracking.

**Fix 1: Ensure `ml_score` is Preserved in `closed_picks.json`**

The `db.close_pick()` method (presumably in `database.py`, though not shown in the provided snippets) must be modified to merge the original pick's metadata into the returned result. A simpler approach, given the existing architecture, is to ensure the `ml_score` is explicitly included in the data saved to `closed_picks.json`. If the scanner controls the export, it should enrich the `closed` list before export.

```python
# --- RECOMMENDED FIX FOR scanner.py, check_open_picks() ---
# BEFORE: closed.append(result)
# AFTER:
# Merge original pick metadata into the closed result
original_pick = db.get_pick_by_id(pick["id"]) # Assuming a method to fetch original pick data
if original_pick:
    result["ml_score"] = original_pick.get("ml_score")
    result["confidence"] = original_pick.get("confidence")
    result["regime_at_entry"] = original_pick.get("regime_at_entry")
    result["strategy"] = original_pick.get("strategy")
    result["symbol"] = original_pick.get("symbol")
    # ... merge any other fields needed for ML training ...
closed.append(result)
```

**Fix 2: Update `get_ml_training_data` to Include `ml_score`**

The `SQLiteStore.get_ml_training_data()` method must perform a SQL JOIN or a post-processing merge to attach the `ml_score` from the original `open_pick` record to the training DataFrame. The training data should look like this:

| `symbol` | `strategy` | `ml_score` | `pnl_pct` | `status` | `feature_1` | ... |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| BTC | strat_A | 0.82 | 5.2 | WON | ... | ... |
| ETH | strat_B | 0.45 | -2.1 | LOST | ... | ... |

**Fix 3: Fix Prediction History Matching**

The prediction history should use a unique pick ID instead of `(symbol, strategy)`.

```python
# --- RECOMMENDED FIX FOR ml_ranker.py ---
def record_prediction(self, pick_id: str, symbol: str, strategy: str, predicted_prob: float) -> None:
    history = self._load_prediction_history()
    entry = {
        "pick_id": pick_id, # <-- ADD UNIQUE ID
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "symbol": symbol,
        "strategy": strategy,
        "predicted_prob": round(predicted_prob, 4),
        "actual_outcome": None,
    }
    history.append(entry)
    self._save_prediction_history(history)

def update_prediction_outcomes(self, closed_picks: list) -> int:
    history = self._load_prediction_history()
    if not history:
        return 0
    # Build lookup by pick_id
    outcome_map: dict[str, int] = {}
    for pick in closed_picks:
        pick_id = pick.get("pick_id", "")
        if not pick_id:
            continue
        label, _ = _compute_triple_barrier_label(pick)
        outcome_map[pick_id] = 1 if label == 1 else 0
    
    filled = 0
    for entry in history:
        if entry.get("actual_outcome") is not None:
            continue
        key = entry.get("pick_id", "")
        if key in outcome_map:
            entry["actual_outcome"] = outcome_map[key]
            filled += 1
    # ...
```

By implementing these fixes, the system gains a closed loop: the ML model makes a prediction, the prediction is stored with a unique ID, the trade outcome is recorded, and the outcome is linked back to the specific prediction. This enables proper calibration, drift detection, and meta-labeling.

### 1.3 🟡 MEDIUM: Boruta Feature Selection Instability

**Bug ID:** FEAT-002 | **Severity:** 🟡 MEDIUM | **Status:** MITIGATED but NOT RESOLVED

#### 1.3.1 Root Cause: Stochastic RF Underlying Boruta; Small Sample Size (275 samples, 37 features)

The Boruta algorithm (Kursa & Rudnicki, 2010) is a powerful method for feature selection, but its stability is highly dependent on the estimator used to judge feature importance. In this implementation, Boruta uses a `RandomForestClassifier` as its internal engine. Random Forests are stochastic algorithms: their feature importance scores can vary significantly between runs due to the random subsampling of features and data points at each split.

In `ml_ranker.py`, the Boruta selector is initialized with `random_state=42`, which should make the RF deterministic *for a given dataset*. However, the stability of the selected features across different training datasets (e.g., as new closed picks are added) is not guaranteed. With a small dataset of approximately 275 samples and 37 features (a ratio of roughly 7.4:1, far below the recommended 50:1 for robust ML), the feature importance estimates from the internal RF are noisy.

The current code includes a safety net:

```python
# From ml_ranker.py, select_features()
if len(selected_idx) < 5:
    print(f"  [BORUTA] Only {len(selected_idx)} features selected "
          f"-- Boruta not discriminative enough, using ALL features")
    selected_idx = list(range(len(feature_names)))
```

While this prevents the model from collapsing to an extremely small feature set, it does not address the core issue: **if Boruta selects, say, 15 features on one training run and a different set of 15 features on the next run (after 20 new picks are added), the model's architecture changes structurally.** This makes A/B testing, performance attribution, and debugging extremely difficult.

#### 1.3.2 Impact: Model Retrains With Different Feature Sets, Breaking Champion/Challenger Logic

The system's "Champion/Challenger" model promotion logic (`_champion_challenger_eval`) is designed to compare a new model against the incumbent production model. However, if the two models were trained on different feature sets (because Boruta selected different features), the comparison is no longer apples-to-apples.

Consider this scenario:
1.  **Champion Model:** Trained with Boruta selecting features `{confidence, direction_market_alignment, funding_rate_raw, obi_delta_5, cs_momentum_rank, mom30, rsi30}`.
2.  **Challenger Model:** Trained on the same data plus 30 new picks. Boruta now selects `{confidence, sl_distance_pct, vpin_toxicity, cs_leader_lag, mom30, btc_correlation}`.

The `_champion_challenger_eval` function attempts to score the challenger on the validation set `X_val`. But `X_val` is constructed from the *current* `FEATURES` list. If the challenger was trained with a subset, it expects a different number of columns than the champion. The code tries to handle this, but if the feature sets are truly disjoint, the validation metrics (AUC, Brier score) are not comparable because the models are making predictions based on fundamentally different information.

This instability undermines the entire purpose of the champion/challenger framework, which is to ensure that only demonstrably superior models are promoted to production.

#### 1.3.3 Fix: Stabilize with Ensemble Boruta or Use Penalized GLM for Feature Selection

To fix this, the system should move away from a single, stochastic Boruta run and toward a more stable feature selection methodology.

**Option A: Ensemble Boruta (Recommended for Medium-Term)**

Instead of running Boruta once, run it `N` times (e.g., `N=20`) on different bootstrap samples of the training data. A feature is only selected if it is confirmed in a majority (e.g., >70%) of the runs. This creates a much more stable consensus.

```python
# --- RECOMMENDED FIX FOR ml_ranker.py ---
from collections import Counter
from sklearn.utils import resample

def select_features_ensemble(self, X: np.ndarray, y: np.ndarray, 
                             feature_names: list[str], n_runs: int = 20, 
                             threshold: float = 0.7) -> tuple[list[int], list[str]]:
    """Stable feature selection using ensemble Boruta."""
    if not _HAS_BORUTA:
        return list(range(len(feature_names))), list(feature_names)
    
    confirmation_counts = Counter()
    
    for i in range(n_runs):
        # Bootstrap sample
        X_boot, y_boot = resample(X, y, random_state=42+i)
        
        rf = RandomForestClassifier(n_jobs=-1, max_depth=5, n_estimators=100,
                                    class_weight="balanced", random_state=42+i)
        selector = BorutaPy(rf, n_estimators="auto", max_iter=50, 
                              random_state=42+i, verbose=0)
        selector.fit(X_boot, y_boot)
        
        confirmed = np.where(selector.support_)[0].tolist()
        tentative = np.where(selector.support_weak_)[0].tolist()
        
        for idx in confirmed:
            confirmation_counts[idx] += 1
        for idx in tentative:
            confirmation_counts[idx] += 0.5 # Tentative gets half weight
    
    # Select features confirmed in > threshold % of runs
    selected_idx = [i for i, count in confirmation_counts.items() 
                    if count / n_runs >= threshold]
    
    # Fallback if too few selected
    if len(selected_idx) < 5:
        print(f"  [BORUTA-ENSEMBLE] Only {len(selected_idx)} features stable, using all.")
        return list(range(len(feature_names))), list(feature_names)
    
    selected_names = [feature_names[i] for i in selected_idx]
    print(f"  [BORUTA-ENSEMBLE] Stable features: {len(selected_idx)}/{len(feature_names)} "
          f"(threshold={threshold}, runs={n_runs})")
    return selected_idx, selected_names
```

**Option B: Use Penalized Logistic Regression for Feature Selection (Recommended for Immediate Fix)**

Given the small sample size, a more statistically principled approach is to use a regularized logistic regression (e.g., LASSO or Elastic Net) for feature selection. The regularization path provides a deterministic ranking of feature importance, and cross-validation can be used to select the optimal regularization strength (`C`). This is far more stable than Boruta with a small sample.

```python
from sklearn.linear_model import LogisticRegressionCV
from sklearn.preprocessing import StandardScaler

# Standardize features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# L1-penalized logistic regression with cross-validated C
selector = LogisticRegressionCV(
    penalty='l1', 
    solver='saga', # or 'liblinear' for small data
    Cs=20, 
    cv=5, 
    random_state=42, 
    max_iter=1000,
    class_weight='balanced'
)
selector.fit(X_scaled, y)

# Features with non-zero coefficients are selected
coef = selector.coef_[0]
selected_idx = np.where(np.abs(coef) > 1e-6)[0].tolist()
```

LASSO is particularly well-suited here because it performs feature selection and model fitting simultaneously, and its deterministic nature eliminates the stochastic instability of Boruta. For a system at this stage of maturity, replacing Boruta with LASSO-based selection would significantly improve pipeline stability.

### 1.4 🟡 MEDIUM: Drift Detection Threshold Too Aggressive

**Bug ID:** MODEL-001 | **Severity:** 🟡 MEDIUM | **Status:** OPEN

#### 1.4.1 Root Cause: Fixed 45% Accuracy Threshold Over Rolling Window of 50

The drift detection mechanism (`_check_drift` in `ml_ranker.py`) is a lightweight, accuracy-based monitor. It calculates the rolling accuracy of the model's predictions over the last `window=50` predictions. If this accuracy drops below a hard-coded threshold of **45%**, a full retrain is triggered.

```python
# From ml_ranker.py, _check_drift()
def _check_drift(self, recent_predictions: list, recent_outcomes: list, window: int = 50) -> bool:
    if len(recent_predictions) < window:
        return False
    correct = sum(1 for p, o in zip(recent_predictions[-window:], recent_outcomes[-window:]) 
                  if (p > 0.5) == (o > 0))
    accuracy = correct / window
    if accuracy < 0.45:
        return True
    return False
```

**Why is this problematic?**

1.  **Statistical Significance:** With a window of 50, an accuracy of 45% is only 2.5 standard deviations below the null hypothesis of 50% (random guessing). In a binomial distribution `B(n=50, p=0.5)`, the probability of getting 22 or fewer correct (44% accuracy) by chance alone is approximately **13.9%**. This means the system will trigger a false drift alarm roughly **once every 7 windows** purely due to random noise, even if the model has not actually drifted.
2.  **Ignoring Base Rate:** The threshold does not account for the model's *expected* accuracy. If the model's baseline accuracy on validation was 55%, a drop to 45% is significant. But if the baseline was 52%, a drop to 45% is catastrophic. The threshold should be relative to the model's established performance, not an absolute constant.
3.  **No Account for Class Imbalance:** If the market regime shifts and the system enters a period where most trades are losers (e.g., a strong bear market for long-only strategies), the model's accuracy might legitimately drop even if its *ranking* ability (AUC) remains intact. A model can have 40% accuracy but an AUC of 0.65, meaning it is still useful for ranking. Firing a retrain based on raw accuracy alone discards a potentially still-valuable model.

#### 1.4.2 Impact: Unnecessary Full Retrains, Wasted Compute, Model Churn

The primary impact is **model churn**. The system is likely performing full retrains far more often than necessary. Each full retrain:
*   Discards the existing model's learned parameters.
*   Re-runs the expensive Boruta feature selection.
*   Re-evaluates the champion/challenger logic, which may reject the new model, leading to wasted effort.
*   Introduces instability into the production pipeline.

In a resource-constrained or latency-sensitive environment, this unnecessary churn can cause the system to be in a constant state of retraining, never stabilizing enough to make consistent predictions.

#### 1.4.3 Fix: Use AUC-Based Drift with Sequential Hypothesis Testing (ADWIN or Page-Hinkley)

The drift detector should be upgraded to use a more statistically robust method that monitors the model's **AUC** or **Brier Score** rather than raw accuracy, and uses a sequential hypothesis test rather than a fixed threshold.

**Recommended Fix: Page-Hinkley Test on Brier Score**

The Brier score (`E[(p - o)^2]`) is a proper scoring rule that evaluates both calibration and discrimination. A drift in the Brier score is a much stronger signal of model degradation than a drop in accuracy.

```python
# --- RECOMMENDED FIX FOR ml_ranker.py ---
class PageHinkleyDriftDetector:
    """Page-Hinkley test for detecting drift in a sequence of scores."""
    def __init__(self, min_instances: int = 30, delta: float = 0.005, threshold: float = 50.0):
        self.min_instances = min_instances
        self.delta = delta  # Magnitude of changes that are allowed
        self.threshold = threshold
        self.reset()
    
    def reset(self):
        self.x_mean = 0.0
        self.sample_count = 0
        self.ph_sum = 0.0
        self.min_ph = float('inf')
    
    def add_element(self, score: float) -> bool:
        """Add a new Brier score. Returns True if drift is detected."""
        self.sample_count += 1
        self.x_mean += (score - self.x_mean) / self.sample_count
        self.ph_sum += score - self.x_mean - self.delta
        self.min_ph = min(self.min_ph, self.ph_sum)
        
        if self.sample_count < self.min_instances:
            return False
        
        return (self.ph_sum - self.min_ph) > self.threshold

# Usage in smart_train:
# Maintain a persistent PageHinkley detector instance
# For each new closed pick with a backfilled prediction:
#   brier = (predicted_prob - actual_outcome)**2
#   if detector.add_element(brier):
#       trigger full retrain
```

**Alternative: ADWIN (Adaptive Windowing)**

ADWIN (Bifet & Gavalda, 2007) is a well-established algorithm for detecting change in a data stream. It maintains a sliding window and automatically shrinks it when drift is detected. Implementations are available in the `scikit-multiflow` library.

```python
# Using scikit-multiflow
from skmultiflow.drift_detection import ADWIN
adwin = ADWIN(delta=0.002) # Smaller delta = more sensitive

for each new prediction-outcome pair:
    absolute_error = abs(predicted_prob - actual_outcome)
    adwin.add_element(absolute_error)
    if adwin.detected_change():
        trigger_full_retrain()
```

By moving to a sequential test on a proper scoring rule like Brier score or log-loss, the system will only trigger expensive full retrains when there is statistically significant evidence of model degradation, rather than reacting to the natural variance of a small-sample binomial process.

## 2. Model Validation Critique: What's Wrong with Current Methodology

This section provides a critical evaluation of the core ML methodology, including labeling, weighting, cross-validation, and feature sufficiency. While the system shows awareness of advanced techniques (triple-barrier, purged CV), the implementation contains significant flaws that undermine their effectiveness.

### 2.1 Triple-Barrier Labeling Inappropriateness

**Critique ID:** LABEL-001 | **Severity:** 🟡 MEDIUM

#### 2.1.1 Problem: 22.9% of Picks Are `TIME_EXIT`, But Label `0` (Expired) Has Asymmetric Weight of 0.5

The system employs triple-barrier labeling, a sophisticated technique popularized by Lopez de Prado (AFML), where each trade is labeled based on which of three barriers is hit first: an upper barrier (take profit), a lower barrier (stop loss), or a vertical barrier (time expiry). The labels are `+1` (TP hit), `-1` (SL hit), and `0` (expired/time exit).

The implementation of this labeling in `ml_ranker.py` is:

```python
def _compute_triple_barrier_label(pick: dict) -> tuple:
    result = str(pick.get('result', '') or pick.get('status', '') or '').upper()
    pnl = float(pick.get('pnl_pct', 0) or 0)
    if 'TP' in result or (pnl > 0 and 'WIN' in result) or result == 'WON':
        return 1, 1.0
    elif 'SL' in result or (pnl < 0 and ('LOSS' in result or 'STOP' in result)) or result == 'LOST':
        return -1, 1.2
    elif 'EXPIR' in result or pnl == 0:
        return 0, 0.5
    elif pnl > 0:
        return 1, 1.0
    else:
        return -1, 1.2
```

**The fundamental issue is that the label `0` (expired) is treated as a distinct class with a weight of 0.5, but the downstream model training converts the problem into binary classification.**

In `_build_features`, the code maps the ternary labels to binary:
```python
# +1 -> 1 (win), 0 -> 0 (uncertain/expired = non-win), -1 -> 0 (loss)
binary_labels = (labels_arr == 1).astype(int)
```

This means that both **losses** (`-1`) and **expired/time-exit trades** (`0`) are mapped to the same binary class `0`. However, they have **different sample weights** (losses have weight `1.2`, expired trades have weight `0.5`). This is a logical contradiction. The model is told that two samples in the same class are of different importance, but the model (a standard classifier) is trying to learn the boundary between class 0 and class 1. It cannot learn a boundary *within* class 0.

#### 2.1.2 Impact: Model Is Confused by `TIME_EXIT` Picks; Wastes Information

With 22.9% of picks being `TIME_EXIT`, a significant portion of the training data is being mislabeled or under-weighted in a way that confuses the model.

*   **Information Loss:** A trade that expires at `pnl_pct = 0` is very different from a trade that hits the stop loss at `pnl_pct = -5%`. By mapping both to class `0`, the model loses the nuanced signal that the expired trade was "neutral" rather than "bad."
*   **Weighting Inconsistency:** The weights `1.2` for losses and `0.5` for expired trades are applied within the same binary class `0`. In gradient boosting, sample weights scale the gradient of the loss function. Applying different weights to samples in the same class creates a "fuzzy" target that the tree splits will struggle to isolate.
*   **Wasted Signal on Near-Wins:** Consider a trade that expires with `pnl_pct = +4.9%`, just missing its `+5%` take profit. The current logic (`elif pnl > 0: return 1, 1.0`) would label this as a full win. This is an optimistic bias. The triple-barrier method is supposed to avoid exactly this by labeling based on which barrier was touched, but the fallback to `pnl > 0` overrides it.

#### 2.1.3 Fix: Use Ternary Classification (XGBoost `objective='multi:softprob'`) or Drop `TIME_EXIT` From Training

There are two viable paths to fix this.

**Option A: True Ternary Classification (Recommended if `TIME_EXIT` is >15%)**

If the `TIME_EXIT` rate is consistently high (~23%), these trades represent a genuine "neutral" outcome that the model should learn to predict. Instead of collapsing to binary, train the model to predict three classes: Win, Loss, Expired. The meta-labeling gate can then be adjusted to only take trades where `P(Win) > threshold` and `P(Loss) < some_other_threshold`.

```python
# --- RECOMMENDED FIX FOR ml_ranker.py ---
# In train(), change the objective:
if _HAS_XGBOOST:
    estimator = xgb.XGBClassifier(
        # ... existing params ...
        objective='multi:softprob',  # Ternary output
        num_class=3,               # Classes: 0=Loss, 1=Expired, 2=Win
        # Remove scale_pos_weight, not applicable for multi-class
    )

# In _build_features, keep ternary labels (-1, 0, +1) but map to 0, 1, 2 for XGBoost
ternary_labels = labels_arr + 1  # Maps -1->0, 0->1, +1->2

# In score_signal(), extract probabilities for all three classes
proba = self.model.predict_proba(_feat.reshape(1, -1))[0]
p_loss, p_expired, p_win = proba[0], proba[1], proba[2]

# Meta-labeling gate: require high win prob AND low loss prob
if p_win < META_LABEL_PROBABILITY_GATE or p_loss > 0.30:
    return p_win * 0.5 # Suppress
return p_win
```

**Option B: Remove `TIME_EXIT` from Training Data (Simpler, but Loses Data)**

If the primary goal is to predict "will this trade be a winner?", then trades that did not resolve to a clear win or loss are "censored" data. In survival analysis, censored data is handled with specific techniques. For a simpler classifier, the most robust approach is often to simply drop the `TIME_EXIT` samples from training. This makes the training set smaller but the target cleaner.

```python
# --- ALTERNATIVE FIX FOR ml_ranker.py, _build_features() ---
# Filter out expired/uncertain trades before training
mask = labels_arr != 0  # Keep only +1 (win) and -1 (loss)
X_filtered = X[mask]
y_filtered = labels_arr[mask]  # Still -1 and +1
weights_filtered = np.array(sample_weights)[mask]

# Now map to binary: +1 -> 1, -1 -> 0
binary_labels = (y_filtered == 1).astype(int)
# Use weights_filtered for training
```

Given that 22.9% is a substantial portion of the data, **Option A (Ternary Classification)** is the more statistically sound and information-preserving choice. It allows the model to learn that some signals are not clearly good or bad, but simply "noisy" or "stagnant."

### 2.2 Asymmetric Sample Weight Bias

**Critique ID:** WEIGHT-001 | **Severity:** 🟡 MEDIUM

#### 2.2.1 Problem: `loss=1.2`, `uncertain=0.5`, `win=1.0` Are Arbitrary and Not Validated

The system applies asymmetric sample weights based on the triple-barrier outcome:
*   **Win (`+1`):** weight = 1.0
*   **Expired (`0`):** weight = 0.5
*   **Loss (`-1`):** weight = 1.2

The stated rationale is: "asymmetric to penalize false positives more." The intent is to make the model more conservative by telling it that misclassifying a loss as a win is 1.2x worse than a standard error.

**The problem is that these weights are completely arbitrary and have not been validated against the system's actual utility function.**

In financial ML, sample weights should reflect the **economic cost** of misclassification, not just a heuristic penalty. The cost of a false positive (predicting a win, getting a loss) is not just a weighted error; it is the actual lost capital, transaction costs, and opportunity cost. The cost of a false negative (predicting a loss, missing a win) is the missed profit.

If the system's actual profit factor is 1.5 (average win is 1.5x the average loss), then the economic cost of a false negative is 1.5 units of profit, while the cost of a false positive is 1.0 unit of loss. In this case, the weights should arguably be inverted: wins should be weighted *more* heavily than losses, because they are more valuable.

#### 2.2.2 Impact: Model is Pessimistically Biased, May Filter Good Signals

By heavily penalizing losses (weight 1.2) and under-weighting wins (weight 1.0), the model is trained to be **pessimistically biased**. It will prefer to classify borderline signals as losses rather than wins to avoid the 1.2x penalty.

This has a direct impact on the meta-labeling gate. The gate is already set at a high threshold (`META_LABEL_PROBABILITY_GATE = 0.60`). If the model's internal probabilities are pushed down by the loss penalty, even fewer signals will clear the gate. The system may be systematically **filtering out good signals** that would have been profitable, simply because the model was trained to be overly fearful of losses.

Furthermore, the `uncertain=0.5` weight means that 22.9% of the data (if included) is effectively half-weighted. This is a massive discount on a large portion of the training set, telling the model to largely ignore these samples. This is not justified unless there is strong evidence that expired trades are pure noise.

#### 2.2.3 Fix: Replace with Cost-Sensitive Learning Using Actual P&L as Weights

Instead of arbitrary weights, the sample weights should be derived from the actual profit and loss of each trade. This is known as **cost-sensitive learning** and is directly tied to the portfolio's objective function (e.g., maximizing Sharpe ratio or total return).

**Recommended Fix: P&L-Driven Weights**

The weight of each sample should be proportional to the absolute magnitude of its outcome, with the sign indicating the direction of the error cost.

```python
# --- RECOMMENDED FIX FOR ml_ranker.py, _build_features() ---
# For each pick, compute the weight based on actual economic outcome
pnl = float(row.get("pnl_pct", 0) or 0)
transaction_cost = float(row.get("transaction_cost_pct", 0) or 0)
net_pnl = pnl - transaction_cost

# Weight by absolute net P&L: bigger outcomes (win or loss) are more informative
# Also apply a "regret" asymmetry based on the profit factor
profit_factor = db.get_overall_profit_factor() # e.g., 1.5

if label == 1:  # Win
    # Cost of false negative = missed profit = net_pnl
    weight = abs(net_pnl) * profit_factor  
elif label == -1: # Loss
    # Cost of false positive = realized loss = abs(net_pnl)
    weight = abs(net_pnl)
else: # Expired
    weight = abs(net_pnl) * 0.5 # Neutral, less informative

# Normalize weights so mean weight = 1.0
weights = np.array(weights)
weights = weights / weights.mean()
```

An even more advanced approach is to use **Focal Loss** (Lin et al., 2017), originally designed for object detection but applicable here. Focal Loss down-weights "easy" samples (e.g., trades with very high confidence that won easily) and focuses training on "hard" samples (e.g., trades that were borderline and lost, or trades that were predicted to lose but won). This would require modifying the XGBoost objective function, which is more complex but highly effective for imbalanced datasets.

### 2.3 Meta-Labeling Probability Gate Mis-calibration

**Critique ID:** META-001 | **Severity:** 🟡 MEDIUM

#### 2.3.1 Problem: 0.65 Gate Is a Fixed Constant; No Validation Against Actual Win Rate by Score Decile

The meta-labeling gate suppresses any signal with a predicted win probability below `META_LABEL_PROBABILITY_GATE = 0.60`. This is a hard, global threshold applied uniformly across all strategies, symbols, and market regimes.

**The core problem is that the threshold is a fixed constant with no empirical validation.** The system does not appear to regularly compute a calibration curve: a plot of predicted probability (binned into deciles) versus the actual observed win rate in that bin. If the model is poorly calibrated, a threshold of 0.60 may be meaningless.

For example, if the model's predictions are overconfident (a common issue with gradient boosting), a predicted probability of 0.60 might correspond to an actual win rate of only 0.45. In this case, the gate is not filtering out bad signals; it is filtering out signals based on a fantasy number.

The existing `model_calibration.py` (which the audit notes has a bug: "Confidence doesn't predict outcomes (Cohen's d = 0.011)") confirms this. A Cohen's d of 0.011 is effectively zero, meaning there is **no difference** in the mean `ml_score` between winning trades and losing trades. If the `ml_score` does not predict outcomes, then a gate on `ml_score` is worse than useless—it is a random filter that destroys alpha.

#### 2.3.2 Impact: Gate Filters Based on Un-calibrated Scores, Destroying Alpha

The impact is direct and severe. The system is using a broken filter to discard signals.

*   **Type I Error (False Negatives):** Good signals with a true win rate of 55% are being discarded because their overconfident model output was 0.58 (below the 0.60 gate).
*   **Type II Error (False Positives):** Bad signals with a true win rate of 40% are being accepted because their overconfident model output was 0.62 (above the gate).

Since the Cohen's d is 0.011, the filter is essentially a coin flip. It is not adding value; it is adding noise and variance to the system's returns.

#### 2.3.3 Fix: Implement Isotonic Regression Calibration and Regime-Conditional Thresholds

The fix requires a two-step process: calibration of probabilities, followed by dynamic threshold setting.

**Step 1: Isotonic Regression Calibration (Already Partially Implemented, but Broken)**

The code already has a calibrator:
```python
from sklearn.isotonic import IsotonicRegression
self.calibrator = IsotonicRegression(out_of_bounds='clip')
self.calibrator.fit(val_proba, y_val_binary)
```

However, this calibrator is trained on the **validation set** from the *initial training run*. It is never updated with new data. Furthermore, if the model is retrained, the calibrator is refit on the new validation set, but it is not validated on an independent **test set** or **out-of-time** dataset.

**The calibrator must be validated using a hold-out test set that is never seen during training or calibration.** Only if the calibrated probabilities on this hold-out set show a strong monotonic relationship with actual win rates should the calibrator be used.

**Step 2: Dynamic, Regime-Conditional Thresholds**

Instead of a global `0.60`, the threshold should be dynamic. In a high-volatility regime, the model's baseline accuracy may drop. The threshold should be adjusted accordingly. This can be done by computing a separate calibration curve and threshold for each detected market regime.

```python
# --- RECOMMENDED FIX FOR ml_ranker.py ---
# In score_signal():
win_prob = ... # Calibrated probability

# Load regime-specific threshold
regime = signal.get("market_regime", {}).get("regime", "unknown")
threshold = self._get_meta_label_threshold(regime)

if win_prob < threshold:
    return win_prob * 0.5
return win_prob

def _get_meta_label_threshold(self, regime: str) -> float:
    # These thresholds should be learned from historical data
    # by maximizing the Sharpe ratio of the sub-portfolio 
    # created by signals above the threshold in each regime.
    thresholds = {
        "trending": 0.55,
        "ranging": 0.65,
        "transitional": 0.75, # Be more conservative in uncertain regimes
        "unknown": 0.60
    }
    return thresholds.get(regime, 0.60)
```

**Step 3: Validate the Entire Pipeline**

The ultimate test is a **forward walk-forward analysis**. For each week of historical data:
1.  Train the model on all data up to the start of the week.
2.  Calibrate the model.
3.  Apply the meta-labeling gate.
4.  Record which signals pass the gate and their outcomes.
5.  Compute the Precision@K for K=10, 20, 50.

If the Precision@K is not significantly above the base rate (e.g., the overall win rate of all strategies), the meta-labeling gate is not working and should be disabled until the model's calibration is fixed.

### 2.4 Purged CV Embargo Inadequacy

**Critique ID:** CV-001 | **Severity:** 🟡 MEDIUM

#### 2.4.1 Problem: 2% Embargo on ~275 Samples = ~5-6 Samples; Not Enough for Serial Correlation Decay

The system uses purged K-Fold cross-validation with a 2% embargo, following Lopez de Prado (AFML, Chapter 7). The implementation is:

```python
def _purged_time_series_cv(n_samples, n_splits=5, embargo_pct=0.02):
    embargo_size = max(1, int(n_samples * embargo_pct))
    fold_size = n_samples // (n_splits + 1)
    for i in range(n_splits):
        test_start = (i + 1) * fold_size
        test_end = min(test_start + fold_size, n_samples)
        train_end = max(0, test_start - embargo_size)
        train_idx = list(range(0, train_end))
        test_idx = list(range(test_start, test_end))
        if len(train_idx) >= 10 and len(test_idx) >= 5:
            yield train_idx, test_idx
```

With `n_samples = 275` and `embargo_pct = 0.02`, the embargo size is `max(1, int(275 * 0.02)) = max(1, 5) = 5` samples.

**The problem is that 5 samples is likely insufficient to eliminate serial correlation.** In financial time series, the autocorrelation of returns can persist for dozens or even hundreds of bars. If the system is trading on hourly or 4-hour signals, adjacent trades can be highly correlated (e.g., multiple signals fired during the same trend). A 5-sample gap is unlikely to fully decorrelate the training set from the test set.

Furthermore, the implementation of the embargo is geometric rather than temporal. It removes a fixed number of *samples* between train and test. If the trading frequency is irregular (e.g., 10 signals one day, 0 the next), a 5-sample gap might represent a few hours or a few days. It does not guarantee a minimum *time* gap.

#### 2.4.2 Impact: Leakage at Fold Boundaries Inflates CV AUC

Because the embargo is too small to remove serial correlation, information from the training set "leaks" into the test set. If two adjacent samples are from the same trending market, the model learns the trend in the training set and is tested on the continuation of the same trend in the test set. This makes the problem artificially easier.

The result is an inflated Cross-Validation AUC. The system reports CV AUC scores that appear good (e.g., 0.70-0.80), but these scores do not translate to live performance because live performance requires predicting on truly unseen, decorrelated future data. This is a classic form of **temporal leakage**.

#### 2.4.3 Fix: Increase to 5% or Use Combinatorial Purged CV (Lopez de Prado, AFML Ch.7)

There are two recommended fixes.

**Fix A: Increase Embargo Size**

The simplest fix is to increase the embargo percentage. A 5% embargo on 275 samples would be ~14 samples, which is more likely to capture the decay of serial correlation.

```python
# In ml_ranker.py
# Increase embargo to 5% minimum, or better, compute it based on autocorrelation
# of the target variable.
def _compute_optimal_embargo(y, target_autocorr_decay=0.1):
    # Find lag where autocorrelation drops below target
    # and use that as the embargo size
    # ... (requires statsmodels) ...
    pass
```

**Fix B: Combinatorial Purged CV (Recommended)**

Lopez de Prado's more advanced method, Combinatorial Purged CV, is designed to provide a more robust estimate of out-of-sample performance. Instead of K folds, it generates all possible train/test splits with a embargo, trains a model on each, and evaluates it on the test set. This produces a distribution of Sharpe ratios (or AUCs), allowing you to compute the probability of backtest overfitting (PBO).

While computationally more expensive, it is the gold standard for validating financial ML models. For a small dataset of 275 samples, it is feasible.

```python
# Conceptual implementation of Combinatorial Purged CV
from itertools import combinations

def combinatorial_purged_cv(X, y, embargo_pct=0.05):
    n = len(X)
    embargo = max(1, int(n * embargo_pct))
    results = []
    
    # Generate all possible test sets of size ~n/5
    test_size = n // 5
    for test_indices in combinations(range(n), test_size):
        test_indices = sorted(list(test_indices))
        train_indices = [i for i in range(n) if i not in test_indices]
        
        # Purge embargo around test set
        min_test = min(test_indices)
        max_test = max(test_indices)
        train_indices = [i for i in train_indices if i < min_test - embargo or i > max_test + embargo]
        
        if len(train_indices) < 50:
            continue
            
        model = train_model(X[train_indices], y[train_indices])
        score = evaluate_model(model, X[test_indices], y[test_indices])
        results.append(score)
    
    return results # Distribution of scores
```

By using a larger embargo or, preferably, Combinatorial Purged CV, the system will get a much more honest estimate of its true out-of-sample performance, avoiding the trap of inflated AUCs that do not generalize.

### 2.5 Feature Starvation Risk

**Critique ID:** FEAT-003 | **Severity:** 🟡 MEDIUM

#### 2.5.1 Problem: 37 Features for ~189 Baby Strategies + 11 Live Systems = 1:5.5 Feature-to-Strategy Ratio

The system operates with a declared feature set of 37 engineered features. However, it runs a massive number of strategies: 189 "baby" strategies in various stages of testing, plus 11 live systems. The feature set is intended to be generic enough to describe the entry conditions of any strategy.

**The problem is that 37 generic features are likely insufficient to capture the unique edge (or lack thereof) of 200 different strategies.** A strategy based on Bollinger Band squeezes requires different information than a strategy based on funding rate arbitrage or a strategy based on on-chain whale movements. By forcing all strategies through the same 37-dimensional feature vector, the model is asked to perform a very difficult task: distinguish between 200 different signal generators using a single, limited descriptor.

This is a form of **feature starvation**. The model does not have enough information to disentangle why Strategy A works in a trending market while Strategy B works in a ranging market. The features are too coarse-grained.

#### 2.5.2 Impact: Model Cannot Disentangle Strategy-Specific Edges

The direct impact is poor discrimination. The model cannot learn that a high `volume_ratio` is good for a breakout strategy but irrelevant for a mean-reversion strategy. It sees a high `volume_ratio` and a win from a mean-reversion strategy, and this contradicts what it learned from the breakout strategy. This contradictory signal adds noise to the training process.

This explains the reported finding that `strategy_encoded` (a proxy for strategy identity) was a dominant feature with high importance. The model learned that the *identity* of the strategy is a better predictor of success than the market conditions. This is a form of leakage (since strategy identity is known at training time) and indicates that the generic features are not descriptive enough.

#### 2.5.3 Fix: Add Strategy-Specific Feature Embeddings or Per-Strategy ML Models

There are two architectural solutions.

**Option A: Strategy-Specific Feature Embeddings**

Instead of a single flat feature vector, the model should receive the generic market features PLUS a learned embedding of the strategy's identity. This is similar to how recommendation engines embed user and item IDs.

```python
# --- RECOMMENDED ARCHITECTURAL FIX ---
# Use a Wide & Deep model or a model with categorical embeddings
import tensorflow as tf # Or use CatBoost's native handling of categorical features

# Features:
# - Generic market features: 37 continuous variables
# - Strategy ID: categorical variable (200 categories)

# The model learns an embedding vector for each strategy.
# e.g., a 10-dimensional vector that captures "this strategy's typical behavior"
strategy_input = tf.keras.Input(shape=(1,), name='strategy_id')
strategy_embedding = tf.keras.layers.Embedding(input_dim=200, output_dim=10)(strategy_input)
strategy_embedding = tf.keras.layers.Flatten()(strategy_embedding)

market_input = tf.keras.Input(shape=(37,), name='market_features')

# Concatenate and pass through a deep network
concat = tf.keras.layers.concatenate([market_input, strategy_embedding])
x = tf.keras.layers.Dense(64, activation='relu')(concat)
# ... more layers ...
output = tf.keras.layers.Dense(1, activation='sigmoid')(x)
```

CatBoost natively handles categorical features (like strategy name) with Ordered Target Statistics, which would achieve a similar effect without requiring a deep learning framework.

**Option B: Per-Strategy or Per-Family ML Models**

Instead of one global model, train a separate ML model for each strategy *family* (e.g., one for momentum strategies, one for mean-reversion, one for macro/contrarian). Each model would be trained only on the data from its family, allowing it to learn the specific features that matter for that style of trading.

This requires more data per family, but the system has 189 baby strategies. If these can be grouped into 10-15 families, each family may have enough data for a dedicated model. A meta-learner could then combine the outputs of the family-specific models.

## 3. Enhancement Roadmap: Prioritized ML/Quant Improvements

This section outlines a strategic roadmap for enhancing the system's machine learning and quantitative infrastructure. Recommendations are categorized as **Quick Wins** (implementable within days) and **Strategic** (requiring weeks to months of development). Each recommendation is grounded in academic best practices and the specific deficiencies identified in this audit.

### 3.1 Quick Wins

Quick Wins are high-impact, low-effort improvements that can be implemented immediately to stabilize the existing pipeline and extract more value from the current architecture.

#### 3.1.1 Fix `ml_score` Persistence on Closed Picks (Enables Full Feedback Loop)

**Priority:** P0 | **Effort:** 1-2 days | **Impact:** CRITICAL

As detailed in Bug 1.2, the `ml_score` is currently lost when a pick transitions from open to closed. This breaks the most fundamental requirement of a learning system: the ability to evaluate its own predictions. Without this, calibration, drift detection, and strategy-specific performance analysis are impossible.

**Action Plan:**
1.  **Modify `database.py`:** Ensure the `close_pick` method (or the export logic) merges the `ml_score`, `confidence`, and `regime_at_entry` from the original open pick record into the `closed_picks.json` entry.
2.  **Update `get_ml_training_data()`:** Modify the database query to perform a `JOIN` between the `closed_picks` table and the original `open_picks` (or `signals`) table to retrieve the `ml_score` at entry time.
3.  **Enrich `update_prediction_outcomes`:** Change the matching key from `(symbol, strategy)` to a unique `pick_id` to ensure unambiguous backfilling of the prediction history for drift detection.

**Success Metric:** After this fix, a weekly report should be generated showing the actual win rate of trades segmented by `ml_score` decile (e.g., 0.50-0.60, 0.60-0.70, etc.). This will immediately reveal whether the ML model has any discriminative power.

#### 3.1.2 Implement Feature Name Contract and Hash Check (Prevents Silent Misalignment)

**Priority:** P0 | **Effort:** 1 day | **Impact:** CRITICAL

As detailed in Bug 1.1, the system relies on implicit positional alignment between a hardcoded `FEATURES` list and a dynamically constructed `feat` array. This is a recipe for silent, catastrophic failure.

**Action Plan:**
1.  **Refactor `_signal_to_features`:** Change the return type from `np.ndarray` to `OrderedDict[str, float]`. The dictionary keys must be exactly the `FEATURES` list.
2.  **Add Runtime Contract Check:** At the end of `_signal_to_features`, add a check: `assert list(feat_dict.keys()) == self.FEATURES`. This turns any future misalignment into a hard, immediate crash with a clear error message.
3.  **Implement Feature Hashing:** In `train()`, compute a SHA-256 hash of `self.FEATURES`. Store it in the model artifact. In `_load_model()`, recompute the hash and refuse to load the model if it does not match.

**Success Metric:** Any future code change that modifies the feature set without updating the `FEATURES` list will trigger an immediate, unmissable error during the next CI/CD run or local test.

#### 3.1.3 Replace Boruta with LASSO/Elastic Net for Stability

**Priority:** P1 | **Effort:** 2-3 days | **Impact:** HIGH

As detailed in Bug 1.3, the Boruta feature selection process is unstable due to the small sample size and the stochastic nature of the underlying Random Forest. This causes the champion/challenger model promotion logic to compare models trained on different feature sets, which is statistically invalid.

**Action Plan:**
1.  **Implement LASSO Selection:** Replace the `BorutaPy` call in `select_features` with `LogisticRegressionCV(penalty='l1', solver='saga')`. Use the non-zero coefficients as the selected feature set.
2.  **Cross-Validate the Regularization Parameter:** Use `LogisticRegressionCV` to automatically find the optimal `C` parameter via internal cross-validation. This is more robust than Boruta's arbitrary `max_iter=50`.
3.  **Stabilize with Bootstrap:** To further increase stability, run the LASSO on 20 bootstrap samples of the data. Select only features that have non-zero coefficients in more than 70% of the runs.

**Success Metric:** Train the model 5 times on the same dataset (with different random seeds). The Jaccard index (intersection over union) of the selected feature sets between runs should be >0.80. With Boruta, this is likely <0.50.

#### 3.1.4 Use P&L-Driven Sample Weights Instead of Arbitrary 1.2/0.5/1.0

**Priority:** P1 | **Effort:** 1 day | **Impact:** HIGH

As detailed in Critique 2.2, the current sample weights (`loss=1.2`, `uncertain=0.5`, `win=1.0`) are arbitrary and likely bias the model toward pessimism. The weights should reflect the actual economic utility of each trade.

**Action Plan:**
1.  **Compute Net P&L Weights:** In `_build_features`, compute the sample weight for each pick as `weight = abs(net_pnl_pct)`.
2.  **Apply Regime Scaling:** Scale the weights by the inverse of the strategy's recent volatility to prevent a single large outlier trade from dominating the gradient.
3.  **Normalize:** Ensure the mean weight across the training set is 1.0 to prevent interaction issues with the `scale_pos_weight` parameter in XGBoost.

**Success Metric:** After retraining with P&L weights, the model's predictions on the validation set should show a higher correlation with actual `net_pnl_pct` than with the binary win/loss label. This indicates the model is learning to predict magnitude, not just direction.

### 3.2 Strategic Improvements

Strategic improvements require more significant architectural changes or data collection efforts but are necessary for the system to achieve long-term, stable alpha.

#### 3.2.1 Feature Engineering: Add Microstructure, Options Flow, Cross-Asset Correlation

**Priority:** P1 | **Effort:** 2-4 weeks | **Impact:** VERY HIGH

The current 37-feature set is heavily skewed toward basic technical indicators and generic market data. It lacks the high-information features used by sophisticated quant funds. The following feature categories should be added:

1.  **Market Microstructure (Crypto):**
    *   **Order Book Imbalance (OBI) Slope:** The current OBI is a snapshot. The *rate of change* of the OBI (the slope of the OBI time series over the last 5 minutes) is a stronger predictor of imminent price moves (Easley et al., 2012; EFMA 2025).
    *   **Trade Sign Classification (Lee-Ready):** Classify each trade as buyer-initiated or seller-initiated based on its price relative to the mid-quote. Aggregate this into a signed volume (Volume-Synchronized Probability of Informed Trading - VPIN).
    *   **Bid-Ask Bounce/Spread:** The average effective spread and the frequency of price oscillations between bid and ask.

2.  **Cross-Asset Correlation and Lead-Lag:**
    *   **BTC Beta:** The rolling 24-hour beta of the signal's asset to BTC. A signal on an altcoin when its BTC beta is >0.90 is essentially a leveraged BTC trade and should be sized accordingly.
    *   **SPY/DXY Correlation:** For equity and forex signals, the correlation to the S&P 500 and the US Dollar Index.
    *   **Cross-Sectional Momentum (Liu et al., 2022 JFE):** Rank the asset's 7-day return within its sector (e.g., DeFi coins, Layer 1s). The current system has some cross-sectional features, but they are basic. A full cross-sectional model should be considered.

3.  **Options Flow (Equity/Crypto where available):**
    *   **Put/Call Skew:** The implied volatility skew. Extreme skew can predict reversals.
    *   **Unusual Options Volume:** A spike in options volume relative to open interest can signal informed trading.

4.  **Macro Regime Indicators:**
    *   **Yield Curve Slope (10Y-2Y):** A flattening or inverted yield curve is a strong risk-off signal for equities.
    *   **DXY Momentum:** A rising dollar is typically bearish for commodities and emerging markets.
    *   **FRED Net Liquidity (Arthur Hayes Index):** The sum of the Fed's balance sheet and the Treasury General Account. This has been a strong predictor of crypto bull markets.

**Implementation Strategy:** Add these features behind a feature flag. Use the `compute_ml_features_at_entry` function in `scanner.py` to calculate them at signal time and store them in `ml_features_at_entry`.

#### 3.2.2 Model Architecture: Stay with Gradient Boosting; Add TabNet or FT-Transformer for Heterogeneous Features

**Priority:** P2 | **Effort:** 3-4 weeks | **Impact:** HIGH

The system currently uses XGBoost/LightGBM, which is an excellent choice for tabular financial data. There is **no compelling reason to switch to Transformers or Temporal Convolutional Networks (TCNs)** for this specific problem. Transformers excel at sequence modeling (e.g., language, long time series), but the current feature set is a flat vector of engineered features per signal, not a long sequence. TCNs are good for local temporal patterns but are overkill for a single-signal classification task.

**Recommended Path: Upgrade within the Gradient Boosting family, but add a Deep Learning meta-learner for feature interactions.**

1.  **Primary Model: CatBoost or LightGBM with Native Categorical Handling:**
    The system already uses CatBoost as a secondary model. CatBoost should be promoted to the **primary** model. Its handling of categorical features (like `strategy` name) via Ordered Target Statistics is far superior to one-hot encoding or hash encoding. It also handles feature interactions more effectively than XGBoost.

2.  **Secondary Model: TabNet or Feature Tokenizer (FT) Transformer:**
    If the feature set expands to include both continuous and categorical features with complex interactions, a model like **TabNet** (Arik & Pfister, 2019) or an **FT-Transformer** (Gorishniy et al., 2021) can be used as a secondary model in the stacking ensemble. These models use attention mechanisms specifically designed for tabular data, allowing them to learn which features to focus on for each individual prediction. This is a more appropriate use of "Transformers" than using a vanilla BERT-style model.

3.  **Avoid Deep Learning for Now:**
    Given the small sample size (~275 picks), deep learning models will almost certainly overfit. The rule of thumb is that you need at least 10x more samples than model parameters. A simple 2-layer neural network with 100 neurons per layer has ~10,000 parameters. You would need ~100,000 samples to train it reliably. Stick with tree-based models until the dataset grows to >5,000 samples.

#### 3.2.3 Risk Management: Replace Kelly with CPPI + Drawdown-Based Deleveraging

**Priority:** P1 | **Effort:** 2 weeks | **Impact:** CRITICAL

The current position sizing uses the Kelly Criterion with fractional Kelly (quarter, half, three-quarter). While mathematically sound in a theoretical, i.i.d. environment with known probabilities, the Kelly Criterion is **dangerous in practice** for trading systems. It assumes that the probability of win (`p`) and the win/loss ratio (`b`) are known constants. In reality, they are noisy estimates derived from small-sample historical data.

**The primary danger of Kelly sizing is that it leads to excessive leverage and catastrophic drawdowns when the edge estimate is wrong (which it often is).**

**Recommended Fix: CPPI (Constant Proportion Portfolio Insurance) + Drawdown Circuit Breakers**

1.  **CPPI Framework:**
    Instead of sizing based on expected returns, CPPI sizes based on a **floor**—a minimum acceptable portfolio value (e.g., 90% of the initial capital). The "cushion" is the difference between the current portfolio value and the floor. The exposure to risky assets is a multiple of this cushion.
    ```
    Cushion = Portfolio_Value - Floor
    Risky_Allocation = Multiplier * Cushion
    ```
    This automatically deleverages as the portfolio approaches the floor, preventing total ruin.

2.  **Drawdown-Based Deleveraging:**
    Implement a tiered response to portfolio drawdowns:
    *   **10% Drawdown:** Reduce position sizes by 50% (half-Kelly becomes quarter-Kelly).
    *   **20% Drawdown:** Reduce position sizes by 75%. Only take the highest-confidence signals (e.g., top 5%).
    *   **30% Drawdown:** **Halt all new entries.** Enter a pure "recovery mode" where the system only manages existing positions (e.g., moving stops to breakeven).

3.  **Time-Based Stops (Max Hold Time):**
    The system already has a `max_hold` time in `check_open_picks`. This should be made dynamic based on volatility. In high-volatility regimes, the max hold time should be *shorter* to prevent being caught in reversals.

#### 3.2.4 Ensemble Weighting: Bayesian Model Averaging for the 11 Systems

**Priority:** P2 | **Effort:** 2-3 weeks | **Impact:** HIGH

The system has 11 different strategy "systems" (e.g., `CRYPTO_STRATEGIES`, `QUANT_STRATEGIES`, `SURVIVOR_STRATEGIES`, etc.). The current approach is to run all of them, collect their signals, and let the ML model sort them out. This is inefficient. The ML model is being asked to compare a momentum signal from a crypto strategy with a mean-reversion signal from a forex strategy using the same 37 features.

**Recommended Fix: Bayesian Model Averaging (BMA) for System-Level Weighting**

Instead of a flat ensemble, treat each of the 11 systems as a "model" in a Bayesian framework. Compute the posterior probability that each system has a positive edge, given its recent performance.

```python
# Conceptual implementation
import numpy as np
from scipy.stats import norm

def compute_system_weights(system_returns: dict[str, list[float]]) -> dict[str, float]:
    """
    system_returns: {'crypto': [0.01, -0.02, 0.03, ...], 'quant': [...]}
    Returns: weights that sum to 1.0
    """
    posteriors = {}
    for system, returns in system_returns.items():
        if len(returns) < 10:
            posteriors[system] = 0.0 # Insufficient data
            continue
        
        mean_ret = np.mean(returns)
        std_ret = np.std(returns, ddof=1)
        n = len(returns)
        
        # Compute the probability that the true mean return is > 0
        # Using a Bayesian t-test with an uninformative prior
        t_stat = mean_ret / (std_ret / np.sqrt(n))
        # Approximate posterior probability of positive edge
        p_positive = 1 - norm.cdf(-t_stat) # Simplified; use proper Bayesian t-test for production
        
        posteriors[system] = p_positive
    
    # Normalize to sum to 1.0
    total = sum(posteriors.values())
    if total == 0:
        return {s: 1.0/len(system_returns) for s in system_returns}
    
    return {s: p / total for s, p in posteriors.items()}

# Usage:
# 1. Compute recent returns for each system over the last 30 days.
# 2. Compute weights.
# 3. When a signal arrives, its initial 'confidence' is multiplied by its system's weight.
#    e.g., a signal from 'quant' with weight 0.05 gets a 95% confidence reduction.
```

This creates a natural "kill switch" for underperforming systems. If a system's recent returns are negative, its posterior probability drops, and its signals are automatically down-weighted or ignored entirely, without needing a manual `GENERATOR_HARD_KILL` list.

#### 3.2.5 Regime Detection: Use HMM with Supervised State Labels; Fix `regime_at_entry` Persistence

**Priority:** P1 | **Effort:** 1-2 weeks | **Impact:** HIGH

As noted in the bug list, `regime_at_entry` is 0% populated. The code in `open_new_picks` attempts to set it:
```python
"regime_at_entry": ((context or {}).get("hmm_regime", {}).get("aggregate", {}).get("market_regime") or regime_str or "UNKNOWN").upper()
```

The problem is that `context.get("hmm_regime")` is populated from `hmm_regime.json`, which may not exist or may not be updated. The fallback `regime_str` comes from `signal.get("market_regime", {})`, which is set by `annotate_signal_with_regime`. If this annotation fails or is missing from the signal dict, `regime_at_entry` becomes `"UNKNOWN"`.

**Fix 1: Make Regime Detection Mandatory and Robust**
1.  **Hard Fail on Missing Regime:** The `run_strategies` function should not allow a signal to pass to the scoring stage if `market_regime` is not set. It should be a mandatory field.
2.  **Multiple Regime Sources:** The regime should be computed from multiple independent sources and require consensus:
    *   **HMM (Hidden Markov Model):** A statistical model on volatility and returns.
    *   **Regime Sentinel:** The existing on-chain cycle classifier.
    *   **ADX:** A simple technical measure of trend strength.
    *   **VIX/Fear & Greed:** A sentiment-based measure.
    If 3 out of 4 sources agree on "trending," the signal is labeled as such. If there is no consensus, the regime is "transitional."

**Fix 2: Store Regime at Entry Time**
The `regime_at_entry` must be a snapshot of the regime *at the exact moment the signal is generated*. It must never be updated after the fact. The current `open_new_picks` logic does this correctly, but the source data (`context`) is unreliable. Fix the source, and the persistence will follow.

#### 3.2.6 Calibration: Use Beta Calibration for Probabilistic Outputs from Tree Ensembles

**Priority:** P2 | **Effort:** 1 week | **Impact:** MEDIUM

The current calibration uses Isotonic Regression. While better than no calibration, Isotonic Regression can be unstable with small datasets and can produce non-monotonic results. Tree-based models like XGBoost and LightGBM tend to produce predictions that are pushed toward the extremes (0 and 1), a problem known as **overconfidence**.

**Recommended Fix: Beta Calibration (Kull et al., 2019)**

Beta Calibration is specifically designed for probabilistic classifiers. It fits a Beta distribution to the model's outputs, which is a more natural choice for probabilities than the piecewise constant function of Isotonic Regression. It is also more robust to small sample sizes.

```python
# Using the `betacal` package or a custom implementation
from scipy.optimize import minimize
from scipy.special import expit, logit

def fit_beta_calibration(probas, y_true):
    """
    Fits parameters (a, b, c) such that:
    p_calibrated = 1 / (1 + exp(-c) * (p / (1-p))^(-a) * ... ) 
    A simplified version using a 2-parameter mapping on logit space is often sufficient.
    """
    # ... implementation of maximum likelihood estimation for Beta calibration ...
    pass
```

For a simpler but still effective fix, use **Platt Scaling** (logistic regression on the uncalibrated probabilities). It is less flexible than Isotonic Regression but much more stable with small validation sets.

```python
from sklearn.linear_model import LogisticRegression
# Train a logistic regression where X = model.predict_proba(X_val)[:, 1] and y = y_val
platt_scaler = LogisticRegression(C=1e10) # Very weak regularization
platt_scaler.fit(val_proba.reshape(-1, 1), y_val_binary)
# Calibrated probability = platt_scaler.predict_proba(new_proba.reshape(-1, 1))[:, 1]
```

#### 3.2.7 Meta-Labeling: Implement Proper Secondary Model per Lopez de Prado AFML Ch.3

**Priority:** P1 | **Effort:** 2 weeks | **Impact:** HIGH

The current system attempts meta-labeling but does it incorrectly. The meta-labeling gate (`META_LABEL_PROBABILITY_GATE`) is a single threshold applied to the primary model's output. True meta-labeling, as described by Lopez de Prado (AFML, Chapter 3), involves a **secondary model** that learns to predict the success of the *primary model's* positions.

**The Correct Meta-Labeling Architecture:**

1.  **Primary Model (The Strategies):** The 11 live systems generate signals. These are the "primary model." They have their own entry and exit rules.
2.  **Label Generation:** For every trade taken by the primary model, compute the outcome (+1 for TP hit, -1 for SL hit, 0 for Expired). This is the label for the secondary model.
3.  **Feature Generation for Secondary Model:** The features for the secondary model are *not* the same as the primary model's features. They should be features that describe the *context* of the primary model's decision, such as:
    *   The primary model's recent win rate.
    *   The volatility at the time of the signal.
    *   The correlation between the asset and the broader market.
    *   The time of day (to catch intra-day seasonality).
    *   The funding rate (to catch crowded positioning).
4.  **Secondary Model Training:** Train a classifier (e.g., XGBoost) to predict whether the primary model's trade will be a winner. The features are the context, and the label is the outcome.
5.  **The Gate:** The secondary model's predicted probability is the "meta-label." Only take trades where the meta-label is > threshold.

**The key difference from the current implementation:** The current system trains a single model on the features and applies its output as the gate. In true meta-labeling, the primary model (the strategies) is *fixed*, and the secondary model learns when to *trust* it. This decouples the strategy logic from the filtering logic and is far more robust.

## 4. Risk Management Recommendations: Specific Changes to Sizing, Stops, Circuit Breakers

This section focuses on the practical risk controls that protect capital. The current system has basic safeguards, but they are insufficient for the observed negative expectancy crises and high volatility of the crypto-heavy portfolio.

### 4.1 Kelly Criterion Critique

**Critique ID:** RISK-001 | **Severity:** 🟡 MEDIUM

#### 4.1.1 Problem: Quarter-Kelly Still Too Aggressive with Noisy Edge Estimates

The system uses fractional Kelly Criterion (`quarter`, `half`, `three-quarter`) for position sizing. The Kelly fraction `f` is calculated as:
```
f = (p * b - (1 - p)) / b
```
Where `p` is the win rate and `b` is the average win / average loss ratio.

**The problem is that both `p` and `b` are estimated from historical data with high variance.** If a strategy has a true win rate of 55% but the sample estimate is 65% due to a lucky streak, the Kelly formula will recommend a dramatically larger position size. Because the Kelly formula is linear in `p` but the resulting growth is exponential, overestimating the edge by just 10% can lead to a position size that is **2-3x too large**.

Quarter-Kelly is often recommended as a "conservative" approach, but it is only conservative relative to Full Kelly. If the edge estimate is wrong, even Quarter-Kelly can lead to ruin. The system has experienced "negative expectancy crises," which suggests that the edge estimates are indeed unreliable.

#### 4.1.2 Fix: Use Half-Kelly with 90% Confidence Interval Lower Bound on Edge

Instead of using the point estimate of `p` and `b`, the system should use the **lower bound of a confidence interval** (e.g., the 10th percentile of the posterior distribution) to compute the Kelly fraction. This is a Bayesian approach that explicitly accounts for estimation uncertainty.

```python
import numpy as np
from scipy.stats import beta

def conservative_kelly(wins, losses, avg_win, avg_loss, confidence=0.10):
    """
    Compute Kelly fraction using the lower bound of the edge estimate.
    """
    total = wins + losses
    if total == 0:
        return 0.0
    
    # Bayesian posterior for win rate (Beta distribution)
    # Prior: Beta(1, 1) = Uniform
    posterior = beta(wins + 1, losses + 1)
    p_lower = posterior.ppf(confidence) # e.g., 10th percentile
    
    # Conservative win/loss ratio: use the observed ratio but penalize small samples
    b = avg_win / max(avg_loss, 1e-6)
    
    # Kelly formula with conservative p
    kelly = (p_lower * b - (1 - p_lower)) / b
    return max(0.0, kelly) # Never go negative (no betting if edge is uncertain)

# Usage:
# kelly_frac = conservative_kelly(wins=30, losses=20, avg_win=0.05, avg_loss=0.03, confidence=0.10)
# position_size = kelly_frac * 0.5 # Then apply half-Kelly on the conservative estimate
```

This ensures that the system only takes large positions when it is **very confident** in the edge. If the edge is uncertain (e.g., a strategy with 10 wins and 10 losses), the conservative Kelly fraction will be close to zero, effectively disabling the strategy until more data is collected.

### 4.2 Drawdown-Based Deleveraging

**Critique ID:** RISK-002 | **Severity:** 🔴 CRITICAL

#### 4.2.1 Problem: No Dynamic Sizing Reduction During Losing Streaks

The current position sizing (`get_position_size` in `position_sizing.py`) computes a size based on the signal, account equity, and strategy stats. It does **not** consider the portfolio's current drawdown. If the portfolio is down 20%, the system continues to size new positions as if it were at all-time highs.

This is a form of **volatility targeting**, but in reverse. Sophisticated funds (e.g., Bridgewater, AQR) practice **volatility targeting**: they reduce exposure when market volatility increases. The system should practice **drawdown targeting**: it should reduce exposure when portfolio volatility (as measured by drawdown) increases.

#### 4.2.2 Fix: Implement Tiered Circuit Breakers (10% DD = 50% size, 20% DD = 25% size, 30% DD = halt)

Implement a dynamic scaling factor that multiplies the Kelly-derived position size based on the current portfolio drawdown from the last equity peak.

```python
# --- RECOMMENDED FIX FOR position_sizing.py ---

def get_drawdown_scaling_factor(current_equity: float, peak_equity: float) -> float:
    """
    Returns a multiplier for position size based on drawdown.
    """
    if peak_equity <= 0:
        return 0.0
    
    drawdown = (peak_equity - current_equity) / peak_equity
    
    if drawdown >= 0.30:
        return 0.0  # Halt all new entries
    elif drawdown >= 0.20:
        return 0.25 # 75% size reduction
    elif drawdown >= 0.10:
        return 0.50 # 50% size reduction
    else:
        return 1.0  # Full size

# In get_position_size():
# After computing kelly_sizing:
dd_factor = get_drawdown_scaling_factor(account_equity, get_peak_equity())
final_position_size = kelly_sizing["position_size_usd"] * dd_factor
```

This is a simple but highly effective form of risk control. It automatically implements the trading adage: "Cut your losses." When the system is losing, it trades smaller. When it is winning, it trades at full size.

### 4.3 Time-Based Stops

**Critique ID:** RISK-003 | **Severity:** 🟡 MEDIUM

#### 4.3.1 Problem: `max_hold` Is Static; Should Be Volatility-Conditional

The current `max_hold` time is static per category (e.g., 10 days for stocks). This is suboptimal. In a high-volatility regime, a trade that hasn't hit TP or SL after 3 days is more likely to reverse than in a low-volatility regime. A static hold time does not adapt to market conditions.

#### 4.3.2 Fix: `max_hold = base_max_hold * (1 - volatility_percentile)`

Make the `max_hold` time inversely proportional to the recent volatility of the asset. If the asset's volatility is in the 90th percentile of its 30-day range, the hold time should be shortened.

```python
# In scanner.py, check_open_picks()
# Compute a dynamic max hold based on recent volatility
recent_vol = df['Close'].pct_change().tail(5).std()
historical_vol = df['Close'].pct_change().tail(30).std()
vol_percentile = recent_vol / max(historical_vol, 1e-8)

# Base max hold from config
base_max_hold = CATEGORY_RISK.get(category, (-0.08, 0.15, 10))[2]

# Scale down: if vol is 2x normal, halve the hold time
dynamic_max_hold = base_max_hold / max(1.0, vol_percentile)

if hold_days >= dynamic_max_hold and exit_reason is None:
    exit_reason = "TIME_EXIT_VOLATILITY"
```

## 5. Overfitting Assessment: Are the Edge Claims Real or Selection Bias?

This section provides a statistical assessment of whether the system's claimed edge is genuine or an artifact of testing hundreds of strategies and selecting the best-performing ones. This is one of the most insidious and common problems in quantitative trading.

### 5.1 Multiple Testing Problem

**Assessment ID:** STAT-001 | **Severity:** 🔴 CRITICAL

#### 5.1.1 Problem: 189 Baby Strategies + 11 Live Systems = 200 Strategies Tested

The system has developed and tested a vast number of strategies: 189 "baby" strategies plus 11 live systems, for a total of **200 strategies**. The 11 live systems are presumably the ones that showed the best performance during their "baby" phase.

**This is a classic multiple testing problem.** If you test 200 strategies, and each strategy has a true Sharpe ratio of 0.0 (i.e., no edge, just random noise), the probability that *at least one* of them will show a statistically significant Sharpe ratio by chance is extremely high.

#### 5.1.2 Bonferroni Correction: Required p-value for Significance at α=0.05 is 0.00025

The Bonferroni correction is a conservative method for controlling the family-wise error rate (FWER). It states that if you are testing `N` hypotheses, the significance level for each individual test should be `α / N`.

With `N = 200` and a desired overall significance level of `α = 0.05`:

```
α_corrected = 0.05 / 200 = 0.00025
```

This means that for any single strategy to be considered statistically significant, its p-value must be less than **0.00025**. This corresponds to a z-score of approximately **3.48** (or a t-statistic of similar magnitude).

**For a Sharpe ratio to be significant at this level, how many years of data are needed?**

The t-statistic for a Sharpe ratio is approximately `SR * sqrt(years)`. To achieve a t-statistic of 3.48 with a Sharpe ratio of 1.0, you would need `3.48^2 = 12.1` years of data. With a Sharpe ratio of 1.5, you would need `3.48^2 / 1.5^2 = 5.4` years.

The system almost certainly does not have 5-12 years of out-of-sample data for its 189 baby strategies. Therefore, it is **mathematically impossible** for the Bonferroni-corrected significance test to be passed.

#### 5.1.3 FDR Analysis (Benjamini-Hochberg): If 50 of 200 Strategies Show "Significance" at p<0.05, ~10 Are False Discoveries

The False Discovery Rate (FDR) is a less conservative but more realistic measure. It controls the expected proportion of false positives among the rejected hypotheses.

Let's assume the system has tested 200 strategies and found that 50 of them show a p-value < 0.05.
*   **Expected False Positives:** If all 200 strategies had no true edge, we would expect `200 * 0.05 = 10` of them to show p < 0.05 purely by chance.
*   **Observed "Significant" Strategies:** 50
*   **Estimated True Positives:** `50 - 10 = 40`
*   **False Discovery Rate (FDR):** `10 / 50 = 20%`

This means that even under optimistic assumptions, **20% of the strategies deemed "significant" are likely false discoveries**. If the true number of significant strategies is smaller (e.g., 20), then the FDR rises to `10 / 20 = 50%`.

### 5.2 Edge Claim Assessment

**Assessment ID:** STAT-002 | **Severity:** 🔴 CRITICAL

#### 5.2.1 Question: Is the "Edge" Just the Top-Performing Subset of 200+ Tested Strategies?

Given the multiple testing analysis above, the most parsimonious explanation for the system's "edge" is that the 11 live systems are simply the **best-performing subset** of a large pool of random strategies. This is known as **survivorship bias**.

To determine if the edge is real, the system must answer the following question:

**"Can the 11 live systems predict out-of-sample returns on data that was not used during their selection process?"**

If the selection process involved backtesting on all available historical data, then there is no true out-of-sample data left to test on. The "edge" is likely curve-fitted.

#### 5.2.2 Required Evidence: Out-of-Sample Walk-Forward Analysis on Untouched Data

To prove that the edge is real, the system must produce the following evidence:

1.  **Walk-Forward Analysis (WFA):** The strategies must be tested on a **hold-out period** that was never seen during development, optimization, or selection. For example, if the system was developed using data from 2020-2024, it must be tested on Q1 2025 data *without any parameter adjustments*.
2.  **Paper Trading Record:** The live systems must have a track record of at least **6-12 months** of paper trading (or small-size live trading) that matches the backtested performance. If the live performance is significantly worse than the backtest, the edge is not real.
3.  **Pre-Registration:** The hypothesis for each strategy should have been pre-registered. For example: "Strategy X, based on momentum in funding rates, is expected to have a Sharpe ratio > 0.5 on out-of-sample crypto data." If the strategy was developed by trying 100 variations and picking the best one, it is not a valid test.

#### 5.2.3 Current System Likely Has FDR > 50%; Most "Edges" Are Statistical Noise

Based on the number of strategies tested (200+) and the likely small sample sizes for each, it is highly probable that the **False Discovery Rate of the live systems is > 50%**. This means that more than half of the 11 live systems do not have a true edge and are expected to lose money in the future.

**Recommendation:**
1.  **Immediate Halt of New Strategy Development:** Stop adding new strategies until the existing ones are properly validated.
2.  **Mandate 6-Month Paper Trading:** All current live systems must undergo a 6-month paper trading period on strictly out-of-sample data. Their performance must be tracked against a benchmark (e.g., buy-and-hold BTC).
3.  **Apply Bonferroni Correction retroactively:** Re-evaluate the statistical significance of the 11 live systems using the Bonferroni-corrected threshold (`p < 0.00025`). If none of them pass this test, the system has no statistically proven edge.
4.  **Focus on Feature Engineering, Not Strategy Generation:** Instead of trying to find 200 strategies and hoping one works, focus on building a robust feature set and a single, well-validated meta-model (the meta-labeling approach) that can filter signals from a small number of well-understood, theoretically grounded strategies.

## 6. Conclusion and Immediate Action Items

This audit reveals a system with a sophisticated architectural vision but significant implementation flaws that create a brittle, unreliable, and likely overfitted pipeline. The good news is that the core concepts (triple-barrier labeling, purged CV, meta-labeling, ensemble methods) are correct. The bad news is that the data flow is broken, the model validation is inadequate, and the "edge" claims are statistically unsubstantiated.

### 6.1 Top 5 Fixes to Implement This Week

To prevent catastrophic failure and begin the path to a robust system, the following five fixes must be implemented immediately:

1.  **Fix `ml_score` Persistence on Closed Picks (Bug 1.2):** Modify the database export and `get_ml_training_data` to preserve the `ml_score` at entry time. This is the single most important fix to enable any form of model validation or learning.
2.  **Implement Feature Name Contract (Bug 1.1):** Refactor `_signal_to_features` to return an `OrderedDict` and add a runtime assertion that the keys match the `FEATURES` list. Add SHA-256 hashing to the model artifact to prevent train-serve misalignment.
3.  **Apply Bonferroni Correction to Strategy Selection (Overfitting 5.2):** Halt all new strategy development. Compute the Bonferroni-corrected p-value for the 11 live systems. If none pass at `p < 0.00025`, the system does not have a proven edge and should switch to paper trading only.
4.  **Implement Drawdown-Based Circuit Breakers (Risk 4.2):** Add the tiered drawdown scaling factor to `position_sizing.py` (10% DD = 50% size, 20% DD = 25% size, 30% DD = halt). This will prevent the next "negative expectancy crisis" from wiping out the portfolio.
5.  **Replace Arbitrary Sample Weights with P&L-Driven Weights (Critique 2.2):** In `_build_features`, compute sample weights proportional to the absolute `net_pnl_pct` of each trade. This aligns the model's objective function with the portfolio's actual economic goal.

### 6.2 Medium-Term Roadmap (1-3 Months)

After stabilizing the system with the quick wins, the following strategic improvements should be pursued:

1.  **Replace Boruta with LASSO/Elastic Net:** Stabilize the feature selection process and make the champion/challenger model promotion statistically valid.
2.  **Implement True Meta-Labeling:** Separate the primary model (strategies) from the secondary model (the filter). Train the secondary model to predict the success of the primary model's trades.
3.  **Add High-Value Features:** Implement OBI slope, cross-asset beta, and macro liquidity features to escape the current feature starvation.
4.  **Upgrade Drift Detection:** Replace the 45% accuracy threshold with a Page-Hinkley or ADWIN detector monitoring Brier score on the live prediction stream.
5.  **Replace Kelly with CPPI + Conservative Bayesian Estimates:** Move to a drawdown-aware position sizing framework that prioritizes capital preservation over theoretical growth optimization.

The system is at a critical juncture. It can either continue down the path of adding more strategies and more features to a broken foundation, or it can pause, fix the foundation, and build a truly robust, evidence-based quantitative engine. The choice made in the next two weeks will determine whether this project becomes a reliable trading system or remains a sophisticated backtesting exercise.