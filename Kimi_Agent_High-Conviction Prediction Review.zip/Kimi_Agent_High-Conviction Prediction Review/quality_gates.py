"""
Quality Gates for Audit Dashboard Picks

This module implements the filtering logic to ensure only high-quality,
tradeable picks appear on findtorontoevents.ca/audit

Usage:
    from audit_trail.quality_gates import passes_active_gate, passes_smart_gate

    if passes_active_gate(pick):
        active_picks.append(pick)

Optional strict data-quality mode (off by default): set environment variable
``AUDIT_PICK_SANITY_GATE=1`` to reject picks that fail ``audit_trail.pick_sanity``
after normal trade-geometry checks. Prediction-market rows are exempt (same as
geometry skip list).

    if passes_smart_gate(pick):
        smart_picks.append(pick)
"""

import json
import logging
import os
import re
import sys
from typing import Dict, Any, List, Optional, Set, Tuple
from datetime import datetime, timezone

# Mutation filter — enforce symbol-lock and direction-filter constraints
# for CANDIDATE strategies derived from banned parents
try:
    from alpha_engine.strategy_mutations import (
        check_mutation_filter,
        get_mutation_for_parent,
        ALL_MUTATIONS,
        SYMBOL_LOCKED_VARIANTS,
        DIRECTION_FILTERED_VARIANTS,
    )

    _MUTATIONS_AVAILABLE = True
except ImportError:
    _MUTATIONS_AVAILABLE = False
    ALL_MUTATIONS = {}
    SYMBOL_LOCKED_VARIANTS = {}
    DIRECTION_FILTERED_VARIANTS = {}

try:
    from audit_trail.hf_policy_thresholds import (
        decay_hard_gate_triggers,
        normalize_wr_percent,
    )
except ImportError:

    def decay_hard_gate_triggers(bt_wr, fwd_wr, n_closed, gap_pp=15.0, min_closed=20):
        return False

    def normalize_wr_percent(value):
        return None


try:
    from audit_trail.forward_degradation_tracker import _is_rehab_variant_strategy
except ImportError:

    def _is_rehab_variant_strategy(strategy_name: str) -> bool:
        return False

try:
    from audit_trail.pick_sanity import passes_pick_sanity as _PICK_SANITY_PASS
except ImportError:
    _PICK_SANITY_PASS = None

try:
    from alpha_engine.matrix_symbol_gates import matrix_symbol_gate_blocks
except ImportError:

    def matrix_symbol_gate_blocks(pick):  # type: ignore
        return False, ""


try:
    from alpha_engine.sandbox_mutation_experiments import (
        apply_sandbox_experiment_relabels,
    )
except ImportError:

    def apply_sandbox_experiment_relabels(pick):  # type: ignore
        pass

# Trade geometry validation for ALL asset classes (fixes non-crypto bypass bug)
try:
    from audit_trail.trade_geometry import has_valid_trade_geometry
    _TRADE_GEOMETRY_AVAILABLE = True
except ImportError:
    _TRADE_GEOMETRY_AVAILABLE = False

try:
    from audit_trail.score_calibration import apply_score_calibration
except ImportError:
    apply_score_calibration = None  # type: ignore

try:
    from audit_trail.strategy_governance import apply_governance_score_adjustment
except ImportError:
    apply_governance_score_adjustment = None  # type: ignore


logger = logging.getLogger(__name__)
_TECH_ALIGN_RE = re.compile(
    r"(?P<aligned>\d+)\s*/\s*(?P<total>\d+)\s*(?P<bias>BUY|SELL)", re.I
)
# ── SUPER STRATEGY: Multi-symbol robustness tiers (cached at module load) ──
# A strategy that profits across many symbols is more trustworthy than one
# that only works on a single symbol. This is the 'super strategy' concept:
#   ALL_SYMBOL (10+ profitable symbols) = highest trust
#   MULTI_SYMBOL (5-9) = high trust
#   FEW_SYMBOL (3-4) = moderate trust
#   SINGLE_SYMBOL = lowest trust (curve-fit risk)
_SYMBOL_STRENGTH_TIERS: Dict[str, Any] = {}


def _load_symbol_strength_tiers() -> Dict[str, Any]:
    """Load symbol_strength_tiers.json once at module level. Cached."""
    global _SYMBOL_STRENGTH_TIERS
    if _SYMBOL_STRENGTH_TIERS:
        return _SYMBOL_STRENGTH_TIERS
    _tiers_path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "alpha_engine",
        "data",
        "ab_test_portfolios",
        "symbol_strength_tiers.json",
    )
    try:
        with open(_tiers_path, "r", encoding="utf-8") as f:
            _SYMBOL_STRENGTH_TIERS = json.load(f)
        logger.info(
            "Loaded symbol_strength_tiers.json: %d strategies",
            len(_SYMBOL_STRENGTH_TIERS.get("details", {})),
        )
    except (FileNotFoundError, json.JSONDecodeError, OSError) as exc:
        logger.warning("Could not load symbol_strength_tiers.json: %s", exc)
        _SYMBOL_STRENGTH_TIERS = {}
    return _SYMBOL_STRENGTH_TIERS


# ── Q12 STREAK MOMENTUM: module-level cache of per-strategy win/loss streaks ──
_STREAK_CACHE: Dict[str, int] = {}  # strategy -> signed streak (+N wins, -N losses)


def _load_streak_cache() -> Dict[str, int]:
    """Load closed_picks.json, compute trailing win/loss streak per strategy."""
    cache: Dict[str, int] = {}
    _path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "..",
        "alpha_engine",
        "data",
        "closed_picks.json",
    )
    try:
        with open(_path, "r", encoding="utf-8") as f:
            picks = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return cache
    from collections import defaultdict

    grouped: Dict[str, list] = defaultdict(list)
    for p in picks:
        strat = p.get("strategy") or ""
        ts = p.get("closed_at") or p.get("exit_time") or p.get("entry_time") or ""
        if strat and ts:
            grouped[strat].append((ts, p.get("pnl_pct", 0)))
    for strat, entries in grouped.items():
        entries.sort(key=lambda x: x[0], reverse=True)  # newest first
        streak = 0
        for _, pnl in entries:
            won = (pnl or 0) > 0
            if streak == 0:
                streak = 1 if won else -1
            elif won and streak > 0:
                streak += 1
            elif not won and streak < 0:
                streak -= 1
            else:
                break
        cache[strat] = streak
    return cache


_STREAK_CACHE = _load_streak_cache()


# Quality thresholds
ACTIVE_PICKS_MIN_SCORE = 0  # REVERTED: let ALL picks through, sort by score. Hiding picks starves the dashboard.
SMART_PICKS_MIN_SCORE = 60  # RAISED 50->60 (2026-04-21): Hedge fund level - top 40% only
# 5+ agent consensus (Kimi/Codex/claude-dash-fix/antigrav-scoring-review/me):
# At threshold=70, ZERO active picks qualify (max live score=60).
# At threshold=60, 1 pick qualifies; at 50, 7 qualify.
# Penalty stacking (Sunday -6, LONG_OVERCONF -25, direction_conflict -12
# applied to 65pct of picks) is destroying genuine signals.
# My earlier raise to 70 was based on closed-pick H1 vs H2 chrono-split,
# but LIVE book has different dynamics — score IS predictive, but
# current calibration floors most picks before they reach 70. Lowering to
# 60 until underlying scoring recalibration lands. Codex closed-pick
# analysis: score 60-69 = 62.7pct WR PF 12.90 (strong edge).
# v1 rationale (superseded): Chrono-split on 2662 closed crypto showed forward-decay
# floor=60 H1=81%WR -> H2=50%WR. Raised to 70, but scoring recalibration gaps
# prevented live picks from reaching 70. Lowering back until recalibration lands.
SMART_PICKS_MIN_SCORE_EQUITY = (
    50  # Lowered to match EQUITY's elite score distribution (median 36, 0% ≥ 70) and allow more candidates through
)
# vs old floor=30 recent-third: 40%WR PF 1.06 (stale calibration).
# Chrono-stable: H1 67%WR PF 2.69 / H2 64%WR PF 2.91.
# 2026-04-21: FOREX score floor RAISED 40→55 for hedge fund performance.
# The 40 threshold allowed too many low-quality picks (25% WR).
# Raise to 55 to focus on proven strategies with forward WR ≥45%
# - FwdWR≥50 is the correct forex gate (PF 1.62 on n=466), already added in PR #191
# - Score≥55 filters to top-tier forex strategies only
# - Proven strategies (forex_rsi2_mean_reversion, myfxbook_retail_contrarian) score 30-45
#   but must now pass additional quality gates beyond score
# - The FwdWR≥50 gate (added in PR #191) provides the real quality filtering for forex
SMART_PICKS_MIN_SCORE_FOREX = 55
SMART_PICKS_MIN_SCORE_COMMODITY = 60  # RAISED 40->60 (2026-04-21): Hedge fund commodity standards
# Antigravity P2 diagnosis. Floor=60 was unreachable: commodity strategies
# can't accumulate score booster enrichment (score_booster has crypto-only
# guards in MTF + ensemble gates), so achievable score range is ~30-55.
# Floor=60 = silent zero picks. Lowering to 40 (matching ETF/BOND/FOREX)
# is safe because downstream filters fortified: BLOCKED_STRATEGIES,
# BLOCKED_ASSET_STRATEGY_PAIRS, _is_valid_resolved_pick (commit 19b8eda365),
# and hc_filter per-class WR/score floors at 40 (commit 8e97a8500d).
SMART_PICKS_MIN_SCORE_BOND = (
    60  # RAISED 40->60 (2026-04-21): Hedge fund bond standards
)
SMART_PICKS_MIN_SCORE_FUTURES = 65  # RAISED 40->65 (2026-04-21): Hedge fund futures elite
# Same reason as COMMODITY above. n=17 closed futures (was 5 in original
# comment) but per-strategy WR shows futures_momentum is the winner getting
# drowned by killed strategies (now blocked in commit 19b8eda365). With the
# winner filter open + strategy_filter="all" + downstream defenses,
# floor=40 lets futures_momentum candidates survive the smart picks gate.
SMART_PICKS_MIN_SCORE_ETF = (
    60  # RAISED 40->60 (2026-04-21): Hedge fund ETF standards
)
SMART_PICKS_MIN_CONFIDENCE = 0.60  # Sweet spot: 0.60-0.70 = 61% WR per decile test
# ML score gate is currently DISABLED — ml_score is not reliably populated upstream,
# so enforcing a floor rejects large fractions of otherwise-valid picks.
# Historical target was 0.60 (IC=+0.33 on decile test; <0.50 was the 22% WR kill zone).
# Re-enable only after validating ml_score fill rate on live picks.
# Canonical value is the single assignment further below (SMART_PICKS_MIN_ML_SCORE = 0.0).
# Prior duplicate assignment removed 2026-04-19 per code review (Finding 2).

# ── PREFERRED STRATEGY-SYMBOL PAIRS (HF-P0 ┬º2.4, 2026-04-05 claude-noncrypto-drilldown) ──
# Whitelist of empirically vetted (asset_class, strategy, symbol, timeframe) combos from
# cross_asset_edge_finder.py scan (Sharpe>=1.8, WR>=60%, PF>=1.8, n>=13 trades, live yfinance data).
# Matching picks receive PREFERRED_PAIR_BONUS (+10) in _apply_score_penalties.
# Refresh cadence: regenerate cross_asset_edge_finder_results.json monthly OR after regime shift.
# Fail-safe: if file missing or malformed, returns empty dict — bonus silently not applied.
PREFERRED_PAIR_BONUS = 10
_PREFERRED_PAIRS_CACHE: Optional[Set[Tuple[str, str, str]]] = None


def _load_preferred_pairs() -> Set[Tuple[str, str, str]]:
    """Lazy-load cross-asset edge-finder recommended combos as (asset_class, strategy_fragment, symbol_root) set.

    Format in JSON: 'ASSET|STRATEGY|SYMBOL|TIMEFRAME' keys.
    We match fuzzy on symbol_root (GC=F -> GC, EURUSD=X -> EURUSD).
    Strategy matched as substring since strategy names vary across the pipeline.
    """
    global _PREFERRED_PAIRS_CACHE
    if _PREFERRED_PAIRS_CACHE is not None:
        return _PREFERRED_PAIRS_CACHE
    import json as _json
    from pathlib import Path as _Path

    result: Set[Tuple[str, str, str]] = set()
    try:
        _path = _Path(__file__).parent.parent / "cross_asset_edge_finder_results.json"
        if not _path.exists():
            _PREFERRED_PAIRS_CACHE = result
            return result
        with open(_path, "r", encoding="utf-8") as _f:
            _data = _json.load(_f)
        _rec = _data.get("recommended", {}) or {}
        for _key in _rec.keys():
            _parts = _key.split("|")
            if len(_parts) < 3:
                continue
            _asset = _parts[0].strip().upper()
            _strat = _parts[1].strip().upper()
            _sym = (
                _parts[2]
                .strip()
                .upper()
                .replace("=F", "")
                .replace("=X", "")
                .replace("^", "")
            )
            result.add((_asset, _strat, _sym))
    except (OSError, ValueError, KeyError):
        pass  # Fail-safe: empty whitelist
    _PREFERRED_PAIRS_CACHE = result
    return result


def _matches_preferred_pair(pick: Dict[str, Any]) -> bool:
    """Check if pick matches any whitelisted preferred pair (fuzzy match)."""
    pairs = _load_preferred_pairs()
    if not pairs:
        return False
    _ac = str(pick.get("asset_class", "") or "").upper()
    # Asset aliases: ETF_LEVERAGED -> ETF, INDEX -> FUTURES (per cursor-audit-quant convention)
    if _ac == "ETF_LEVERAGED":
        _ac = "ETF"
    elif _ac == "INDEX":
        _ac = "FUTURES"
    _strat = str(pick.get("strategy", "") or "").upper()
    _sym = (
        str(pick.get("symbol", "") or "")
        .upper()
        .replace("=F", "")
        .replace("=X", "")
        .replace("^", "")
    )
    # Also strip USDT/USD suffix for crypto-equivalent matching (BTCUSDT <-> BTC)
    _sym_stripped = _sym
    for suffix in ("USDT", "USDC", "BUSD", "USD"):
        if _sym_stripped.endswith(suffix) and len(_sym_stripped) > len(suffix):
            _sym_stripped = _sym_stripped[: -len(suffix)]
            break
    for _p_ac, _p_strat_frag, _p_sym in pairs:
        if _p_ac != _ac:
            continue
        if _p_sym not in (_sym, _sym_stripped):
            continue
        # Strategy substring match in either direction (pipeline names vary)
        _strat_key = _strat.replace("_", "").replace("-", "")
        _p_key = _p_strat_frag.replace("_", "").replace("-", "")
        if _p_key in _strat_key or _strat_key in _p_key:
            return True
        # Also allow fragment-level match (e.g., "SUPERTREND" in both)
        for _frag in _p_strat_frag.split("_"):
            if len(_frag) >= 5 and _frag in _strat_key:
                return True
    return False


# ── CROSS-ASSET CONFLUENCE BONUS (HF-┬ºextra, 2026-04-05) ──
# Deferred follow-on from commit 30832eba08 (score floors) and 823d253a1e (preferred pairs).
# When the same underlying asset has aligned directional signals across 2+ DIFFERENT
# asset classes (e.g., BTCUSDT LONG in CRYPTO + BITO LONG in ETF + BTC1! LONG in FUTURES),
# that confluence is a strong institutional signal more robust than a single pipeline.
# Each matching pick receives CROSS_ASSET_CONFLUENCE_BONUS (+8) in _apply_score_penalties.
# Smaller than +10 preferred_pair bonus because confluence counting is noisier.
# Fail-safe: missing asset_class or normalization failure => no match, no bonus.
# Idempotent: _cross_asset_confluence field is set once per pick and checked before bonus.
CROSS_ASSET_CONFLUENCE_BONUS = 8

# ETF ÔåÆ underlying asset root mapping (so ETF picks can align with crypto/commodity/equity)
_ETF_UNDERLYING_MAP = {
    "BITO": "BTC",
    "BITI": "BTC",
    "BTF": "BTC",
    "GBTC": "BTC",
    "IBIT": "BTC",
    "FBTC": "BTC",
    "ETHE": "ETH",
    "ETHA": "ETH",
    "FETH": "ETH",
    "ETH": "ETH",
    "GLD": "GC",
    "IAU": "GC",
    "GLDM": "GC",
    "SLV": "SI",
    "SIVR": "SI",
    "USO": "CL",
    "UCO": "CL",
    "SCO": "CL",
    "UNG": "NG",
    "BOIL": "NG",
    "KOLD": "NG",
    "SPY": "ES",
    "VOO": "ES",
    "IVV": "ES",
    "QQQ": "NQ",
    "QQQM": "NQ",
    "DIA": "YM",
    "IWM": "RTY",
}


def _normalize_symbol_root(symbol: str, asset_class: str) -> Optional[str]:
    """Normalize a symbol to its underlying asset root for cross-class matching.

    Returns None if normalization fails or asset_class is unrecognized for cross-class linking.
    Equities are returned as-is (they generally don't link to other asset classes).
    """
    if not symbol:
        return None
    sym = str(symbol).upper().strip()
    ac = str(asset_class or "").upper().strip()
    if ac == "ETF_LEVERAGED":
        ac = "ETF"
    elif ac == "INDEX":
        ac = "FUTURES"
    try:
        if ac == "CRYPTO":
            # BTCUSDT -> BTC, ETHUSDC -> ETH
            for suffix in ("USDT", "USDC", "BUSD", "USD"):
                if sym.endswith(suffix) and len(sym) > len(suffix):
                    return sym[: -len(suffix)]
            return sym
        if ac == "FUTURES":
            # GC=F -> GC, BTC1! -> BTC, ES1! -> ES
            root = sym.replace("=F", "")
            # Strip trailing "!" month codes like 1!, 2!, !, etc.
            root = re.sub(r"\d*!$", "", root)
            return root or None
        if ac == "FOREX":
            # EURUSD=X -> EURUSD
            return sym.replace("=X", "")
        if ac == "COMMODITY":
            return sym.replace("=F", "")
        if ac == "ETF":
            return _ETF_UNDERLYING_MAP.get(sym, sym)
        if ac == "BOND":
            return sym.replace("=X", "").replace("=F", "")
        if ac == "EQUITY":
            # Equities don't generally link cross-class; keep as-is (will only match same class)
            return sym
        return sym or None
    except (AttributeError, TypeError):
        return None


def _normalize_direction(direction: str) -> Optional[str]:
    """Collapse direction variants to LONG/SHORT."""
    if not direction:
        return None
    d = str(direction).upper().strip()
    if d in ("LONG", "BUY", "BULLISH"):
        return "LONG"
    if d in ("SHORT", "SELL", "BEARISH"):
        return "SHORT"
    return None


def _compute_cross_asset_confluence(all_picks: List[Dict[str, Any]]) -> Dict[str, int]:
    """Compute cross-asset confluence counts across all picks.

    Groups picks by (normalized_root, direction) and counts the number of DISTINCT
    asset_class values present in each group. Returns a map of pick_id -> confluence_count
    where confluence_count is the number of distinct asset classes aligning on that
    root+direction (>=2 means cross-asset confluence exists).

    Side-effect: stamps each matching pick with pick["_cross_asset_confluence"] = count
    (idempotent: only set once, skipped if already present).

    Fail-safe: picks with missing symbol/direction/asset_class are silently skipped.
    """
    confluence_map: Dict[str, int] = {}
    if not all_picks:
        return confluence_map
    # Build groups: (root, direction) -> set of asset_classes and list of pick refs
    groups: Dict[Tuple[str, str], Dict[str, Any]] = {}
    for pick in all_picks:
        try:
            ac_raw = str(pick.get("asset_class", "") or "").upper().strip()
            if not ac_raw:
                continue
            ac_norm = (
                "ETF"
                if ac_raw == "ETF_LEVERAGED"
                else ("FUTURES" if ac_raw == "INDEX" else ac_raw)
            )
            root = _normalize_symbol_root(pick.get("symbol", ""), ac_raw)
            direction = _normalize_direction(pick.get("direction", ""))
            if not root or not direction:
                continue
            key = (root, direction)
            entry = groups.setdefault(key, {"asset_classes": set(), "picks": []})
            entry["asset_classes"].add(ac_norm)
            entry["picks"].append(pick)
        except (AttributeError, TypeError, KeyError):
            continue  # Fail-safe: skip malformed picks
    # Assign counts
    for key, entry in groups.items():
        count = len(entry["asset_classes"])
        if count < 2:
            continue
        for pick in entry["picks"]:
            pid = str(pick.get("id", "") or "").strip()
            # Idempotency: only set if not already present
            if "_cross_asset_confluence" not in pick:
                pick["_cross_asset_confluence"] = count
            if pid:
                confluence_map[pid] = count
    return confluence_map


SMART_PICKS_MAX_CONFIDENCE = 0.95  # Cap overconfident picks
ACTIVE_PICKS_MIN_RR = 1.0
SMART_PICKS_MIN_RR = 1.5
SMART_PICKS_MAX_RR = 3.5  # R:R ceiling — widened: docstring golden combo is R:R 2.0-3.0, old 1.75 was too narrow
SMART_PICKS_MIN_ML_SCORE = 0.0  # Disabled - ML scores not currently populated
# 2026-04-14 edge-filter audit (all-picks, no cherry-picking):
# Trust≥3 outperforms Trust≥5 for crypto (PF 1.98 on n=689 vs PF 1.96 on n=348)
# and equity (PF 2.62 on n=119 vs PF 2.09 on n=201). Lowering from 5ÔåÆ3 widens
# the net while retaining edge. PF CI lower bound > 1.5 for both at Trust≥3.
# For forex, trust filter hurts — FwdWR≥50 is the correct forex gate.
SMART_PICKS_MIN_TRUST_SCORE = 3  # LOWERED 5ÔåÆ3 (2026-04-14): wider net, PF still >1.9
# Active picks (non-crypto): reject when 0 < trust_score < MIN (same floor as smart picks).
# Product note (2026-04-15): passes_active_gate previously used a hard-coded "< 4", which
# rejected trust_score==3 while SMART_PICKS_MIN_TRUST_SCORE was already 3. Using this
# constant aligns active gate with smart picks (2026-04-14 edge audit: Trust>=3 keeps PF edge).
# Forex still uses FwdWR in passes_smart_gate, not trust alone.
ACTIVE_NON_CRYPTO_MIN_TRUST_SCORE = 3  # LOWERED 5ÔåÆ3 to match smart picks

# 2026-04-14 edge-filter convergence (Claude + Cursor + Mercury):
# CRYPTO SHORT picks had PF 1.54 vs LONG 1.91 in the last-7d validation window
# (dashboard ledger, ghost-filtered, n=2,060 baseline PF 1.69). Combined with
# LONG + Score>=50 + Trust>=3 the filter pushes to PF 5.48 on n=438 (Wilson
# WR_LB 64.9%). The LONG-only constraint on CRYPTO is the single net-new
# hard-filter addition vs the existing Smart Picks gate (MIN_SCORE=60,
# MIN_TRUST_SCORE=5). Non-crypto assets are unaffected — they already have
# per-asset thresholds calibrated separately. Keep the flag so we can flip
# it off instantly if live performance diverges from backtest.
#
# Caveat: trust_score is re-computed at dashboard generation time via
# enrich_picks_with_trust_score(recent_closed) — historical trust_score
# values reflect later strategy performance (partial lookahead in backtest).
# For LIVE picks the filter is forward-clean because trust_score is read from
# the strategy_performance snapshot available AT pick creation time.
SMART_PICKS_CRYPTO_LONG_ONLY = True

# ── PSI (Population Stability Index) drift gate (task J / handoff P1) ──
# PSI measures feature distribution drift between training and production.
# Industry convention: PSI < 0.10 stable, 0.10-0.25 moderate, > 0.25 = material
# drift — models/rules keyed on that feature become unreliable. When any feature
# in alpha_engine/data/feature_health_report.json exceeds this threshold, the
# pick pipeline is in a drifted regime. Currently SHADOW-mode: we log and tag
# but do not actually reject, because we have no per-strategy ÔåÆ per-feature
# ownership map yet (global drift would kill the book). Remove shadow after
# 48h of forward observation + decision to hard-enforce, per handoff guidance.
PSI_BLOCK_THRESHOLD = 0.25
_PSI_REPORT_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "alpha_engine", "data", "feature_health_report.json",
)
_PSI_CACHE: Dict[str, Any] = {"mtime": 0.0, "max_psi": 0.0, "drifted": []}


def _get_max_psi() -> Tuple[float, List[str]]:
    """Return (max_psi, drifted_feature_names) from the cached feature health
    report. Cheap: reads the JSON only when its mtime changes. Returns (0.0, [])
    on any error so the gate never breaks admission.
    """
    try:
        st = os.stat(_PSI_REPORT_PATH)
    except OSError:
        return 0.0, []
    if st.st_mtime == _PSI_CACHE["mtime"]:
        return _PSI_CACHE["max_psi"], _PSI_CACHE["drifted"]
    try:
        with open(_PSI_REPORT_PATH, "r", encoding="utf-8") as f:
            report = json.load(f)
        psi_scores = report.get("psi_scores", {}) or {}
        if not isinstance(psi_scores, dict) or not psi_scores:
            _PSI_CACHE.update(mtime=st.st_mtime, max_psi=0.0, drifted=[])
            return 0.0, []
        max_psi = 0.0
        drifted: List[str] = []
        for fname, val in psi_scores.items():
            try:
                v = float(val)
            except (TypeError, ValueError):
                continue
            if v > max_psi:
                max_psi = v
            if v > PSI_BLOCK_THRESHOLD:
                drifted.append(str(fname))
        _PSI_CACHE.update(mtime=st.st_mtime, max_psi=max_psi, drifted=drifted)
        return max_psi, drifted
    except Exception as e:
        logger.debug("PSI cache load failed: %s", e)
        _PSI_CACHE.update(mtime=st.st_mtime, max_psi=0.0, drifted=[])
        return 0.0, []
BLOCKED_ACTIVE_TRUST_LABELS = {"AVOID", "BANNED"}
# UNTRUSTED added: client-side already blocked BANNED+UNTRUSTED; server-side must match.
# 7 UNTRUSTED picks from kimi_riseoftheclaw were leaking through with score=120 (2026-04-04).
BLOCKED_ACTIVE_TRUST_TIERS = {"BANNED", "AVOID", "UNTRUSTED"}
AUDITED_PM_MIN_HISTORY_WR = 0.65
AUDITED_PM_MIN_HISTORY_TRADES = 20
AUDITED_PM_MIN_SOURCE_COUNT = 2
AUDITED_PM_SCORE_BONUS = 10
SMART_CONCENTRATION_MODERATE_PENALTY = 8
SMART_CONCENTRATION_HIGH_PENALTY = 15

# Age limits (hours)
CRYPTO_MAX_AGE_HOURS = 168  # RELAXED: 7 days (was 72h)
NON_CRYPTO_MAX_AGE_HOURS = 240  # 10 days for forex/equity

# Source tiers that are allowed (exclude EXPERIMENTAL)
ALLOWED_SOURCE_TIERS = {"TOP_TIER", "PROVEN", "WATCH"}

# Permanently killed strategies (from TODO analysis)
PERMANENTLY_KILLED_STRATEGIES = {
    # Copy-trader sentiment (not real copy trading)
    "binance_smart_money",
    # Proven losers
    "hl_funding_fade",
    "cta_tsmom_blend",
    "yahoo_analyst_consensus",
    "winner_pattern_precursor",
    "inverse_winner_pattern_precursor",
    # Rapid Fire now_picks.json banned strategies (2026-04-02 leak fix: 183/500 picks were from these)
    "macd_crossover",  # 25-31% WR LONG/SHORT, 139 leaked picks
    "rsi_overbought",  # 29% WR SHORT, -17.1% PnL, 44 leaked picks
    # 0% WR strategies ( bleeding capital, identified 2026-03-26)
    "stoch-rsi-crypto",  # 0% WR, -$4,000
    "keltner_compression_expansion_doge",  # 2.2% WR, -$57
    "keltner_compression_expansion_doge_v1",  # 0% WR baseline
    "macd-momentum",  # 0% WR, -$28,340
    # "MeanReversionBB",  # REHABBED 2026-04-05 claude-bus-setup: 77.8% WR +25.4% PnL n=18
    #   on closed picks, PF=4.17, bootstrap 95% CI [+0.88, +2.65]% avgPnL, perm p=0.002.
    #   Only LINK-USD loses (33% WR, -2.3%). See TESTING_PROTOCOL ┬ºStage 1.
    #   Block added to BLOCKED_STRATEGY_SYMBOL_PAIRS.
    "battleground_vwap_1h_mut",  # 0% WR, -$24,000
    "vwap_deviation_reversion_doge",  # 0% WR
    "st_multi_day_momentum",  # 0% rolling WR
    "hh-hl-scout",  # 0% rolling WR
    # "claude_ml_moderate_mut",  # REHABBED 2026-04-05 claude-bus-setup: 52% WR +12.2% PnL n=25.
    #   Passes TESTING_PROTOCOL Stage 1: 2 qualifying symbols (SEI 100% WR n=5, JUP 60% WR n=5,
    #   both PF>=1.2). Loser symbols (IMX, TIA) added to BLOCKED_STRATEGY_SYMBOL_PAIRS.
    # crypto_soc family - extensive 0% WR bleeders
    "crypto_soc_delta_divergence_a03_v1",
    "crypto_soc_dynamic_risk_heat_a02_v1",
    "crypto_soc_dynamic_risk_heat_a03_v1",
    "crypto_soc_dynamic_risk_heat_a06_v1",
    "crypto_soc_dynamic_risk_heat_a07_v1",
    "crypto_soc_dynamic_risk_heat_a08_v1",
    "crypto_soc_dynamic_risk_heat_a09_v1",
    "crypto_soc_dynamic_risk_heat_a10_v1",
    "crypto_soc_mtf_orb_pivots_a02_v1",
    "crypto_soc_mtf_orb_pivots_a03_v1",
    "crypto_soc_mtf_orb_pivots_a04_v1",
    "crypto_soc_mtf_orb_pivots_a06_v1",
    "crypto_soc_mtf_orb_pivots_a07_v1",
    "crypto_soc_mtf_orb_pivots_a08_v1",
    "crypto_soc_mtf_orb_pivots_a09_v1",
    "crypto_soc_mtf_orb_pivots_a10_v1",
    "crypto_soc_proxy_decoupling_a03_v1",
    "crypto_soc_proxy_decoupling_a06_v1",
    "crypto_soc_regime_filters_a01_v1",
    "crypto_soc_regime_filters_a02_v1",
    "crypto_soc_regime_filters_a03_v1",
    "crypto_soc_regime_filters_a06_v1",
    "crypto_soc_regime_filters_a07_v1",
    "crypto_soc_regime_filters_a08_v1",
    "crypto_soc_regime_filters_a10_v1",
    "crypto_soc_vol_expansion_index_a08_v1",
    # Additional 0% WR strategies from kill list analysis
    "kimi_lgbm_features",  # 0% WR, -$43,420
    "stocktwits:QuietZonePlayers",  # 0% WR, -$36,000
    # "ttm_squeeze",                              # REMOVED 2026-04-04: unfairly tested (3/5 grade-gated,
    #                                              # only 2 real trades). John Carter's BB-inside-KC squeeze
    #                                              # has documented 60-75% WR on equities. Needs 50+ trades
    #                                              # across equities/forex/crypto before kill decision.
    "irb_hoffman",  # 0% WR, -$35,500
    "corr_kama_adaptive",  # 0% WR, -$32,000
    "Meta Learner",  # 0% WR, -$32,000
    "multi_timeframe_ema_stack",  # 0% WR, -$29,040
    "GPX_Gen10_2a4b0b",  # 0% WR, -$24,000
    "lower_wick_absorption",  # 13% WR, -$24,000
    # Anti-predictive ML timeframes
    # (block all 15m models, keep 1h/4h/1d)
    # Portfolio optimization kills (2026-03-29 analysis)
    # Data: quan_engine_position 0% WR, 13/13 SL exits, TAOUSDT only
    "quan_engine_scalp",  # 25% WR, 1793 trades, -352.88% PnL — worst strategy by total loss
    "quan_engine_position",  # 0% WR, -$995, 100% SL exits
    # Data: maplestax 12% WR, -4.98% avg PnL, score=1
    "maplestax_vwap_cbc_flip",  # 12% WR, avg score=1, -4.98% avg PnL
    # Data: flash-crash-reversal 0% WR on 6 active, -3.65% avg PnL
    "flash-crash-reversal",  # 0% WR active, -3.65% avg PnL
    # 2026-04-05: REMOVED from killed — consensus variants producing +2.2% to +4.6% winners on EQUITY class
    # (NFLX, ARM, GOOG, LIN, UNH, LLY, IBM, GOOGL, GS, PFE). Historical crypto WR was poor but EQUITY
    # application is working. Move to mutation/rehabilitation track per mutate-before-kill policy.
    # "goldmine_1x_consensus",  # was 24% crypto WR, now +3-4% EQUITY winners
    # "goldmine_2x_consensus",  # was 29% crypto WR, now +2.5% EQUITY winners
    # "goldmine_3x_consensus",  # was 12% crypto WR, now +2.2% EQUITY winners
    # 2026-04-02: Closed pick analysis — worst strategy+direction combos
    "st_rsi_momentum_confluence",  # 10% WR LONG (10W/95L, -296.5% PnL!) — WORST in entire system
    "crypto_roc_acceleration_trend_v1",  # 20% WR LONG (1W/4L)
    "crypto_drawdown_convexity_recovery_v1",  # 25% WR SHORT (2W/6L)
    "futures_ema_stack_momentum",  # 0/4=0% WR, 7 active zombie picks — killed 2026-04-02
    # 2026-04-04: MUTATION CANDIDATES — NOT killed, moved to inverse/symbol-lock pipeline
    # Per user policy: oppose killing strategies, prefer inverse/DNA mutation/symbol-lock/TP-SL tweak
    # "claude_gainer_1h",         # 14.3% WR LONG ÔåÆ inverse_claude_gainer_1h = 85.7% WR (VALIDATED)
    # "enhanced_ml_A_xgboost",   # 30.8% WR LONG ÔåÆ symbol-lock SEI/ALGO/JTO = 67%+ WR; drop TRX(0%)
    # "widened_tp_momentum_carry",# 22.2% WR ÔåÆ try tighter TP/SL or inverse
    # "Extreme Fear Contrarian Buy",# 20% WR ÔåÆ distinct from st_fear_greed_contrarian(87.7%!), try inverse
    # "crypto_adx_pullback_trendresume_v1", # 14.3% WR ÔåÆ try inverse or different symbols
    # 2026-04-04: ml_crypto_predictor LONG killed per copilot-quant-audit (responsible for -15238% cum PnL)
    # ONLY LONG direction killed — SHORT variants work (100% WR combos on FETUSDT, SUIUSDT already in _100WR_COMBOS)
    # Per mutate-before-kill: the SHORT signal has edge, LONG does not. Use ml_crypto_predictor_short_only mutation.
    "ml_crypto_predictor",  # LONG 0% WR, 41 trades, contributes -15238% — SHORT variants retained
    # 2026-04-11 leaderboard cull (peer e81e7ee5a6 verified on dashboard_data.json):
    # Conservative criteria: fwd_trades>=30, fwd_wr<=35, fwd_pf<=0.7, fwd_total_pnl<=-20
    "Value + Quality",           # n=51 WR 7.8% PF 0.15 PnL -251.27 (leaderboard cull)
    "volume_spike_breakout",     # n=189 WR 33.9% PF 0.49 PnL -158.35
    "Consecutive Beats",         # n=59 WR 20.3% PF 0.43 PnL -136.86
    "Earnings Drift",            # n=31 WR 12.9% PF 0.25 PnL -102.54
    "st_bb_squeeze_expansion",   # n=104 WR 31.7% PF 0.33 PnL -43.27
    "ML Ranker",                 # n=46 WR 30.4% PF 0.57 PnL -39.27
    # 2026-04-11 user-flagged non-crypto drain fix:
    "Dividend Aristocrats",      # n=8 WR 0.0% PnL -49.6 — EQUITY drain
    "futures_mean_reversion",    # n=2 catastrophic -88.8% single-pick tail risk
    # 2026-04-12: ETF/FUTURES drain strategies identified by per-asset-class audit
    "extreme_oversold_bounce",   # ETF: n=6 0% WR -15.5% PnL; FUTURES: n=2 0% WR — zero wins across all asset classes
    "vix_reversal",              # ETF: n=6 WR 33% -1.7% PnL; FUTURES: n=4 WR 0% -0.4% PnL; overall drain
    # 2026-04-21 HF-grade audit: Strategies with WR<35% on 15+ non-flat trades (statistically significant)
    # Each is confirmed negative-edge by dashboard_payload.json closed-pick analysis.
    "atr_regime_rsi",            # 17.2% WR, 29 trades, -10.4% PnL — anti-predictive
    "st_atr_vol_breakout",       # 22.2% WR, 27 trades, -21.5% PnL
    "st_obv_support_divergence", # 23.8% WR, 84 trades, -78.5% PnL — massive sample confirms
    "carry-trade-momentum",      # 26.7% WR, 15 trades, -2.2% PnL
    "copy_hl_lb_None",           # 32.0% WR, 278 trades, -806.4% PnL — 2nd worst strategy by total loss
    "copy_hl_lb_none",           # lowercase variant of above
}

# FIX: Case-insensitive kill check. Picks arrive as lowercase but kill list has mixed case.
# Codebuff audit found 33 active picks leaking through (24 from enhanced_ml_A_xgboost alone).
_KILLED_STRATEGIES_LOWER = {s.lower() for s in PERMANENTLY_KILLED_STRATEGIES}

# Direction-specific penalties: strategies that lose in one direction but win in another
# Data: rsi_overbought SHORT = 29% WR (4W/10L) but overall 76% WR
# The strategy works for LONG but NOT for SHORT — penalize SHORT picks from it
DIRECTION_SPECIFIC_LOSERS = {
    ("rsi_overbought", "SHORT"): -15,  # 29% WR, -17.1% PnL on SHORTs
    ("macd_crossover", "LONG"): -15,  # 31% WR on LONGs
    ("macd_crossover", "SHORT"): -10,  # 25% WR on SHORTs
    ("luxalgo_confluence", "LONG"): -10,  # 35% WR on LONGs
    ("crypto_mtf_ema_slope_alignment_v1", "SHORT"): -12,  # 12% WR on SHORTs
}

# Energy stocks consistently lose — block from equity portfolios
EQUITY_BLOCKED_SYMBOLS = {"XLE", "CVX", "XOM"}  # 0W/4L combined, -18.8% PnL

# Asset-class-level blocks — temporarily disable entire classes with systemic issues
# FUTURES: score penalty (not an active-list hard ban) per kilo-audit-agent + bus (2026-04-04):
#   - Closed book showed 0% WR / heavy loss on Connors/hyperopt lane (sample n small)
#   - Separate: symbol format mismatches (/ES vs ES=F) — keep penalty until paths verified
#   - Active visibility still uses passes_active_gate (e.g. GC=F entry sanity was blocking gold)
# ETF: same -60 penalty plus **hard ban** in passes_active_gate (PLAN_FIX_LOWPICKSCOUNT Phase 1:
#   thin closed book, systemic drain — no new ETF actives until forward validation justifies).
BLOCKED_ASSET_CLASSES: set = set()  # Was {"FUTURES"} — removed 2026-04-16; -60 penalty created data starvation catch-22

# Non-crypto raw-score floor bypass: audited *backtest* history is not enough; require
# a minimum **forward** lane sample so low dashboard scores cannot ride history alone.
NC_RAW_SCORE_BYPASS_MIN_FORWARD_TRADES = 10
NC_RAW_SCORE_BYPASS_MIN_FORWARD_WR = 0.55

# Large-sample active-feed floors by asset class. These are stricter than
# ranking penalties but looser than Smart Picks: once a cohort has enough
# forward history to be statistically meaningful, obviously weak strategies
# should not remain visible in the main active book.
ACTIVE_CRYPTO_MIN_FORWARD_TRADES = 50
ACTIVE_CRYPTO_MIN_FORWARD_WR = 0.40
ACTIVE_NON_CRYPTO_MIN_FORWARD_TRADES = 20
ACTIVE_NON_CRYPTO_MIN_FORWARD_WR = 0.45


def active_non_crypto_forward_wr_floor(asset_class: str) -> float:
    """Minimum forward win-rate (0–1) for the large-sample active gate (#288).

    The single global ``ACTIVE_NON_CRYPTO_MIN_FORWARD_WR`` (0.45) was calibrated
    on mixed non-crypto cohorts. In production it zeroed the live **EQUITY** book:
    many legitimate scanners sit at ~41–44% forward WR with n≥20 while still
    contributing positive ``recent_closed`` expectancy. ``FOREX`` / ``COMMODITY``
    keep the stricter 0.45 default; ``BOND`` uses a lower bar because the forward
    book is tiny and we still need visibility to build history.

    See ``docs/ACTIVE_PICKS_ASSET_CLASS_DIAGNOSIS_2026_04_22.md``.
    """
    ac = (asset_class or "").upper().strip()
    _floors: dict[str, float] = {
        "EQUITY": 0.40,
        "ETF": 0.40,
        "BOND": 0.35,
        "COMMODITY": ACTIVE_NON_CRYPTO_MIN_FORWARD_WR,
        "FOREX": ACTIVE_NON_CRYPTO_MIN_FORWARD_WR,
        "FUTURES": ACTIVE_NON_CRYPTO_MIN_FORWARD_WR,
    }
    return _floors.get(ac, ACTIVE_NON_CRYPTO_MIN_FORWARD_WR)


# Asset-class trust bonuses. The 2026-04-04 attribution (EQUITY 67.2% WR) was
# reversed by the 2026-04-11 per-asset-class edge report (peer claude-opus-4.6-hyro,
# updates/2026-04-11-per-asset-class-edge-report.md): EQUITY n=572 cum -395%, with
# 61% of that drain from ONE strategy (Value + Quality). The +8 bonus was actively
# amplifying losses on a bleeding asset class. Neutralized to 0 — we still WANT
# to keep running equity picks and build forward history (per user directive:
# don't fully block, keep building history), but without the score tailwind.
#
# FOREX also neutralized after 2026-04-12 forensic investigation (peer cursor,
# updates/2026-04-11-forex-data-integrity-spot-check.md): the +4 bonus was
# originally justified by PF 2.09 +211% on 570 trades, BUT forensic spot-check
# found the reported FOREX edge was 94% driven by 4 anomalous rows from
# `kimi_signal_tracking` with confidence=9.9999 (broken data) and +40-95%
# single-pick "gains" that are physically impossible for unleveraged spot FX.
# Root cause: bulk outcome-resolver double-stamp bug on 2026-04-10 22:42Z that
# wrote a second WON row for 3 picks already resolved as LOST. After dedup,
# clean FOREX is n=567 PnL +12% PF 1.06 — marginal, not edge. The +4 bonus
# was baked into a data artifact. Neutralized to 0 until forward data justifies.
#
# Small-n classes (BOND n=8, ETF n=4) also zeroed until n ≥ 50 gives real signal.
ASSET_CLASS_BONUSES = {
    "EQUITY": 0,  # was +8; reversed 2026-04-11 per hyro edge report (-395% cum)
    "BOND": 0,  # was +5; n=8 too small to justify bonus
    "ETF": 0,  # was +5; n=4 too small
    "FOREX": 0,  # was +4; reversed 2026-04-12 per cursor forex integrity report
                 # (bulk-resolver bug inflated 3 rows by +203%; clean PF 1.06)
    "CRYPTO": 0,  # 49.8% WR baseline
    "COMMODITY": 0,  # was -3; neutral — let forward history decide
    # FUTURES handled by BLOCKED_ASSET_CLASSES (-60)
}

# Broken/delisted symbols generating phantom trades — HARD BLOCK (2026-04-03 data mining)
# NOTE: This set is referenced by both the penalty scorer AND the pick filter.
# There is NO separate BLOCKED_SYMBOLS below — all symbol blocks go HERE.
BLOCKED_SYMBOLS = {
    "MATICUSDT",  # 424 trades, 0% WR, -63.60% total PnL — delisted, phantom TIME_EXIT trades
    "UUSDT",  # 14 trades, 0% WR — broken symbol
    "XMR",  # 23 trades, 0% WR, -115% PnL — most destructive symbol (codebuff confirmed)
    "XMRUSDT",  # alias for XMR — same 0% WR, -115% PnL data
    "ENAUSDT",  # 8 trades, 12.5% WR, -15.6% PnL
    "IMXUSDT",  # 7 trades, 0% WR, -12.6% PnL
    "KASUSDT",  # 12% WR, 25 trades — P1 kill
    # Data quality / redenomination blocks (merged from second definition)
    "KATUSDT",  # Token redenomination: entry 0.0108 -> live 0.1408 (13x jump)
    "TRXUSDT",  # -10,064% PnL (103% of ALL negative crypto PnL). Blacklisted 2026-04-02.
    # 2026-04-11 EQUITY drain symbols — identified by pattern-mining on 1,371
    # non-crypto closed picks in dashboard_data.json. Our mean-reversion strategies
    # are shorting uptrending enterprise-software/tech mega-caps at the wrong times.
    # See updates/2026-04-11-non-crypto-pattern-mining.md (Finding 3).
    # Combined drain across these 6 symbols: ~-315% PnL across 82 closed picks.
    "ADBE",  # n=18, 5.6% WR, -85.5% PnL (Software) — single largest equity drain
    "CRM",   # n=10, 0.0% WR, -66.7% PnL (Software) — zero wins
    "ACN",   # n=11, 0.0% WR, -56.7% PnL (Consulting) — zero wins
    "MSFT",  # n=16, 18.8% WR, -48.0% PnL (Software)
    "PLTR",  # n=12, 16.7% WR, -33.3% PnL (Software)
    "TSLA",  # n=15, 26.7% WR, -24.4% PnL (Auto/tech)
    # T1-C bottom-symbol blocklist (2026-04-15) - structural anti-edge regardless of strategy
    # Evidence: 3,500-pick closed ledger, n >= 20, WR < 35%
    "JTOUSDT",    # n=33, 18.2% WR, PF 0.38, -34.1% PnL
    "XLMUSDT",    # n=26, 19.2% WR, PF 0.81, -1.7% PnL
    "ICPUSDT",    # n=53, 22.6% WR, PF 0.65, -6.7% PnL
    "RENDERUSDT", # n=45, 31.1% WR, PF 0.40, -33.8% PnL
    "NVDA",        # n=21, 33.3% WR, PF 0.77, -6.3% PnL (equity)
    # 2026-04-18 Codex equity-drain attribution — verified independently against
    # current dashboard_data.json (693 closed equity rows). These 3 complete the
    # 6-symbol toxic cluster identified by ChatGPT Codex; the other 3 (ADBE,
    # CRM, ACN) are already blocked above. Excluding all 6 lifts equity PF
    # 0.834 → 1.071 with total PnL flipping to +90.65%.
    # See: updates/2026-04-18-non-crypto-synthesis-and-action-plan.md (P4.3)
    "NKE",   # n=8,  0.0% WR, -66.78% PnL (Consumer/Apparel)
    "PG",    # n=8,  0.0% WR, -44.97% PnL (Consumer Staples)
    "HD",    # n=10, 10.0% WR, PF 0.005, -35.00% PnL (Retail)
}

# ─────────────────────────────────────────────────────────────────────
# Corrupted outcome rows (bulk-resolver double-stamp bug 2026-04-10 22:42Z)
# ─────────────────────────────────────────────────────────────────────
# On 2026-04-10 22:42Z a bulk outcome resolver wrote a second WON row for
# 3 kimi_signal_tracking FOREX picks already resolved as LOST. The fake
# rows have id=MISSING, confidence=9.9999 (should be [0,1]), empty strategy
# field, and PnL physically impossible for unleveraged spot FX.
# They inflate reported FOREX aggregate from clean PF 1.06 to fake PF 2.04.
#
# Root cause: missing uniqueness constraint on outcome ledger + suspected
# unit-conversion bug in resolver. See the resolver investigation notes:
#   make_pick_id() at audit_trail/universal_pick_resolver.py:372-376 does NOT
#   include entry_price in its composite key, allowing retry loops to
#   re-resolve the same physical pick as a new row.
#
# Forensic reports:
#   updates/2026-04-11-forex-data-integrity-spot-check.md   (peer cursor)
#   updates/2026-04-11-non-crypto-pattern-mining.md         (findings)
#
# Client-side mirror: audit_dashboard/template.html::_CORRUPTED_OUTCOME_ROWS
# (PR #87 merged 2026-04-12).
#
# Tuple key: (symbol, timestamp, entry_price, direction, source_system, pnl_pct)
# The underlying rows are NOT deleted from dashboard_data.json — reversible quarantine only.
CORRUPTED_OUTCOME_ROWS = frozenset({
    ("USDCAD=X", "2026-03-24 16:54:37", 1.37709, "BUY", "kimi_signal_tracking", 40.45),
    ("EURUSD=X", "2026-03-13 19:07:51", 1.14338, "BUY", "kimi_signal_tracking", 66.76),
    ("AUDUSD=X", "2026-03-13 16:16:18", 0.70028, "BUY", "kimi_signal_tracking", 95.58),
})


def is_corrupted_outcome_row(pick: dict) -> bool:
    """Return True if pick matches a known-corrupted outcome row.

    Used by display/aggregation layers to drop picks that should have been
    deduplicated at outcome resolution time. Matches on the composite
    (symbol, timestamp, entry_price, direction, source_system, pnl_pct) key.

    Callers: audit_trail/outcome_aggregator.py, any stat computation path.
    """
    try:
        key = (
            pick.get("symbol"),
            pick.get("timestamp"),
            float(pick.get("entry_price")) if pick.get("entry_price") is not None else None,
            pick.get("direction"),
            pick.get("source_system"),
            float(pick.get("pnl_pct")) if pick.get("pnl_pct") is not None else None,
        )
        return key in CORRUPTED_OUTCOME_ROWS
    except (TypeError, ValueError):
        return False

# ── Dashboard Visibility Filters: Hard-rejects that suppress picks ──

# BLOCKED_SOURCE_SYSTEMS: Statistically proven losers (10+ trades, negative PnL, PF < 1.0)
# These systems are HARD-BLOCKED - their picks are completely hidden from all views.
# Sync with template.html's BLOCKED_SYSTEMS.
#
# Before ADDING new entries: read docs/STRATEGY_INVESTIGATION_BEFORE_KILL.md — prefer
# DNA mutation, inverse, regime grid, and cross-asset checks (TESTING_PROTOCOL ┬º7). Losers
# often rehab or invert to winners; hard block only after documented investigation.
BLOCKED_SOURCE_SYSTEMS = {
    "mercury2_fast",  # 14 trades, 25% WR, -639% PnL, PF 0.02
    # 2026-04-05: RE-BLOCKED per user data verification (re-audit 2026-04-05):
    # stocks_competition: 33.5% WR, -304.2% cum PnL on n=281 closed - BLEEDING
    # fast_stocks_competition: 14.3% WR, -41.0% cum on n=21
    # Prior 2026-04-04 unblock was based on crypto-filtered stats that missed the
    # actual equity-side losses. Full-population data shows clear negative edge.
    "stocks_competition",
    "fast_stocks_competition",
    "kimi_signal_tracking",  # 22 trades, 18.2% WR, -126% PnL, PF 0.20
    "ml_bg_system_a",  # 19 trades, 10.5% WR, -50% PnL, PF 0.14
    "ml_bg_system_b",  # 19 trades, 5.6% WR, -55% PnL, PF 0.02
    "ml_crypto_pred_v12",  # 117 trades, 36.8% WR, -32% PnL, PF 0.55
    "crypto_winners",  # 48 trades, 39.6% WR, PF 0.30
    "ml_bg_system_c",  # 5 trades, 0% WR
    "ml_bg_ensemble",  # 8 trades, 0% WR, -33% PnL
    # "signal_validation",  # UNBANNED 2026-04-13/14: stale ban comment was "10 trades, 0% WR, -18.4% PnL".
    # Canonical data now shows n=139 (universal_resolved_picks.json) / n=140 (dashboard cross-check),
    # WR 57.6%/57.1%, PF 2.16/2.11, Wilson 95% CI [49.2%, 65.5%], +108-110% cum PnL on universal.
    # Internal consistency: line 2863 _SOURCE_SYSTEM_SCORES already scored this strategy +10 with
    # comment "56.6% WR, +0.86% avg PnL" — same file contradicted itself. Verified independently by
    # Cursor + Claude on the same file (see docs/CURSOR_CLAUDE_AGREEMENT_2026-04-14.md).
    # The ban reflected an ancient state (n=10) before the strategy accumulated 130+ additional
    # profitable trades. FOREX-specific variant remains blocked via BLOCKED_ASSET_SOURCE_PAIRS
    # (line ~970) — conservative carve-out kept since forex subset may behave differently.
    # RE-BLOCK TRIGGER: if WR drops below 40% on n >= 50 forward-test trades, add this back.
    "ml_bg_system_f",  # 7 trades, 0% WR, -37.8% PnL
    "rocket_scanner",  # 2026-04-05: 5 active picks, 0% WR, -0.81% avg — kimi + noncrypto-drilldown live audit
    # 2026-04-04: MUTATION CANDIDATES — NOT blocked, moved to inverse pipeline
    # "claude_gainer",        # 14.3% WR ÔåÆ inverse_claude_gainer = 85.7% WR (VALIDATED)
    # "aggregated_picks",     # 16.7% WR ÔåÆ needs confluence filter + symbol-lock mutation
}

# ── BLOCKED_STRATEGIES: Per-strategy blocks that are asset-class aware ──
# Unlike BLOCKED_SOURCE_SYSTEMS (which blocks an entire source), these block
# specific strategy names that have been proven losers via investigation.
# Format: set of (strategy_name_fragment, asset_class_or_None)
# If asset_class is None, blocked across all asset classes.
# Per TESTING_PROTOCOL ┬º7: investigation doc required before adding entries.
BLOCKED_STRATEGIES = {
    # Equity losers from stocks_competition investigation (2026-04-14):
    # docs/strategy_audits/stocks_competition_2026-04-14.md
    ("Value + Quality", "EQUITY"),      # 6.2% WR, PF 0.14, n=48 — worst equity strategy
    ("Consecutive Beats", "EQUITY"),    # 25.6% WR, PF 0.54, n=39
    ("Earnings Drift", "EQUITY"),       # 15.8% WR, PF 0.30, n=19 (inverse confirmed PF 2.07)
    ("Dividend Aristocrats", "EQUITY"), # 0% WR, n=8
    # Crypto losers confirmed by 3-day audit + Claude convergence:
    ("enhanced_ml_A_xgboost", None),    # 28% WR, PF 0.42, 189 picks, 0% winning days
    # ETF: all strategies losing — block at asset class level instead
    ("extreme_oversold_bounce", "ETF"), # 0% WR, n=5
    ("vix_reversal", "ETF"),            # 33% WR, PF 0.02, n=6
    # 2026-04-14 edge-discovery sweep (see updates/2026-04-14-edge-discovery-and-plan.md)
    # Strategies below were scanned from the ~3,500-pick closed ledger (n >= 30).
    # Most: WR < 35% and/or PF < 0.65. Exception: Short-Term Reversal has PF 1.07 but
    # WR 34.2% (blocked on WR / weak edge, not PF).
    ("ig_contrarian_sentiment", None),  # 30.3% WR, PF 0.01, n=33 — effectively zero
    ("ML Ranker", None),                # 31.1% WR, PF 0.58, n=45 — inverted ML signal
    ("Short-Term Reversal", None),      # 34.2% WR, PF 1.07, n=38 -- WR < 35% gate
    ("st_bb_squeeze_expansion", None),  # 38.7% WR, PF 0.83, n=31 — net negative
    ("vix_reversal", None),             # 26.7% WR, PF 0.13 on n=30 (ALL classes; ETF-specific above)
    # 2026-04-18 FUTURES toxic strategies dragging the futures card to WR=5.9%.
    # Verified locally against current dashboard_data.json (26 futures rows).
    # `futures_momentum` is the ONE winner (4W/3L/1F = +4.94% on n=8) and is
    # being drowned out by these losers. Strategy-level blocks let it surface.
    # See: updates/2026-04-18-non-crypto-synthesis-and-action-plan.md
    ("connors_rsi2", "FUTURES"),               # 0/2/3 = 0% WR n=5 (futures variant)
    ("hyperopt_connors_rsi2", "FUTURES"),      # 0/1/0 = 0% WR n=1 (variant)
    ("mean_reversion_bollinger", "FUTURES"),   # 0/2/0 = 0% WR n=2
    ("extreme_oversold_bounce", "FUTURES"),    # 0/1/1 = 0% WR n=2 (already killed elsewhere)
    ("vix_reversal", "FUTURES"),               # 0/2/2 = 0% WR n=4 (already killed)
    ("futures_mean_reversion", "FUTURES"),     # 0/1/0 (already killed; -0.88% bleed)
    ("ema_stack_momentum", "FUTURES"),         # 1/1/0 marginal but listed as killed by Antigravity
    # liquidity_sweep_reversal n=1 only F=1 — keep watching, not enough data to kill
    # 2026-04-17 deepscan-4 loser anatomy (subagent investigation):
    # Owns the 4 worst absolute losses in the 3,500-pick book (-46.8% FF, -23.8% MMT,
    # -20.8% MMT, -12.3% VANRY). All entries conf=0.90 paired with R:R 0.05-0.46 =
    # structurally negative-EV math. 53 picks, 43.4% WR, PF 0.52, total -88.3% PnL.
    # Removing this single strategy lifts crypto book WR by ~2pp and saves ~88 PnL pts.
    ("claude_gainer_1h", None),                # 53 picks, 43.4% WR, PF 0.52 (deepscan-4)
    # 2026-04-17 11-strategy WR-drop subagent investigation:
    # See updates/2026-04-17-eleven-strategies-decay-investigation.md
    # volume_spike_breakout: 10.8% WR PF 0.136 n=37 full-history (per
    # strategy_performance.json); 0% WR last 30d on n=4. Zero active. Already
    # blocked on FOREX above; this extends to all asset classes.
    ("volume_spike_breakout", None),           # 10.8% WR PF 0.136 (eleven-strategies)
    # crypto_bayesian_regime_transition_momentum_v1: 32% WR n=47 BTCUSDT only.
    # Both LONG and SHORT broken. Binomial-significant. Zero active. Estimated
    # +30 PnL pts saved over next 30 days.
    ("crypto_bayesian_regime_transition_momentum_v1", "CRYPTO"),
    # 2026-04-21 HF-grade audit: per-system-per-asset-class blocks
    # kimi_riseoftheclaw on CRYPTO: 8.3% WR (1W/11L), -59.8% PnL — works on EQUITY (54.6% WR) but toxic on crypto
    ("kimi_signal_tracking", "CRYPTO"),  # 0% WR on crypto (0W/3L), -10.9% PnL
    # goldmine_stocks on EQUITY: 0% WR (0W/5L), -22.3% PnL — dead strategy
    ("goldmine_stocks", "EQUITY"),       # 0% WR n=5, -22.3% PnL — zero wins ever
    # fast_stocks_competition on EQUITY: 0% WR (0W/6L), -22.0% PnL
    ("fast_stocks_competition", "EQUITY"), # 0% WR n=6 — zero wins ever
}


def _blocked_name_matches(haystack_upper: str, needle_upper: str) -> bool:
    """True if needle appears as a whole phrase (token boundaries), not as a substring of a larger token.

    Avoids false positives like matching ``ML Ranker`` inside ``XML Ranker``.
    """
    if needle_upper not in haystack_upper:
        return False
    if needle_upper == haystack_upper:
        return True
    esc = re.escape(needle_upper)
    return (
        re.search(rf"(^|[^A-Z0-9]){esc}((?:[^A-Z0-9]|$))", haystack_upper) is not None
    )


def is_strategy_blocked(strategy: str, asset_class: str) -> bool:
    """Check if a strategy is blocked for a given asset class."""
    if not strategy:
        return False
    strat_upper = strategy.upper()
    ac_upper = (asset_class or "").upper()
    for blocked_strat, blocked_ac in BLOCKED_STRATEGIES:
        if _blocked_name_matches(strat_upper, blocked_strat.upper()):
            if blocked_ac is None or blocked_ac.upper() == ac_upper:
                return True
    return False


# Rapid_fire score floor (raised from 10 to match quality floor)
RAPID_FIRE_MIN_SCORE = 50

# Entry price bounds (prevent broken entry-price outliers)
MAX_ENTRY_PRICE = 1_000_000.0

# Age-based staleness bounds: only reject if PnL is also low (winners can run)
# Sync with template.html's renderPicks filtering
# Hard cap for /audit active visibility: stale + flat PnL rows hidden (not booster age limits).
# 2026-04-05: 48h was starving the book (~110/149 actives failed passes_active_gate); 72h keeps
# Layer-0 hygiene while restoring breadth. Promotion / Smart Picks still use tighter gates.
CRYPTO_HARD_MAX_AGE_HOURS = 72
NON_CRYPTO_HARD_MAX_AGE_HOURS_VISIBLE = 336  # 14 days
STALENESS_PNL_LIMIT = 1.0

# Non-crypto Active display: require a minimum *raw* dashboard score (before penalties).
# Elite_score must not override this floor (see tests + _extract_final_score contract).
ACTIVE_DISPLAY_NON_CRYPTO_MIN_RAW_SCORE = 55
# TESTING_PROTOCOL ┬º2.5 uses score>=40 for toxic-pool stats and >=60 for promotion — this is
# **audit default visibility only** for CRYPTO (rank-sort still applies). Floor 40 hid ~74%
# of post-boost actives while non-crypto kept stricter NC raw>=55 + trust rules.
ACTIVE_DISPLAY_CRYPTO_MIN_RAW_SCORE = 30

# Low confidence strategies (0.4x multiplier)
LOW_CONFIDENCE_STRATEGIES = {
    "futures_bb_mean_reversion",
    "futures_ema_stack_momentum",
    "claude_gainer_ml",
    "claude_gainer_ml_perf",
}

# Inverse strategies with proven edge (78%+ WR)
PROVEN_INVERSE_STRATEGIES = {
    "st_multi_day_momentum",
    "claude_gainer_1h",
    "luxalgo_confluence",
    "crypto_rsi_whaleconfirmed_v1",
    "atr_regime_rsi",
    "winner_pattern_precursor_inverse",
    # 2026-04-01: Degraded strategy inverses (0% WR originals)
    "inverse_quan_engine_scalp",
    "inverse_binance_smart_money",
    "inverse_cci_reversal_scout",
    "inverse_macd_momentum",
    "inverse_gainer_compression_relaxed",
    "inverse_mean_reversion_bb",
}

# SHORT strategy exemptions - these have proven profitable SHORT performance
# Based on analysis: 13 strategies with WR >= 50% and positive avg PnL
# See: analyze_short_strategies.py
PROFITABLE_SHORT_STRATEGIES = {
    "tsmom_strategy",  # 2026-04-05: KITE SHORT won on ALL 5 TV books (+2.24 to +8.6%).
    "tsmom_volscaled",  # Leveraged-inverse-alt SHORTs during weak-alt regime. Live-validated.
    "funding_momentum",  # 60.4% WR, +0.12% avg PnL, 106 trades
    # REMOVED: rolling 7d WR collapsed vs baseline on audit — no SHORT exemption
    "crypto_kalman_trend_residual_reversion_v1",  # 80% WR, +2.20% avg PnL, 5 trades
    "crypto_keltner_compression_expansion_v1",  # 75% WR, +0.66% avg PnL, 8 trades
    "vwap_deviation_reversion_xrp_v1",  # 66.7% WR, +0.73% avg PnL, 6 trades
    "crypto_soc_orderflow_absorption_a01_v1",  # 60% WR, +0.36% avg PnL, 10 trades
    "crypto_soc_delta_divergence_a01_v1",  # 66.7% WR, +0.52% avg PnL, 6 trades
    "crypto_soc_delta_divergence_a04_v1",  # 57.1% WR, +0.36% avg PnL, 7 trades
    "crypto_soc_proxy_decoupling_a04_v1",  # 60% WR, +0.50% avg PnL, 5 trades
    "crypto_soc_delta_divergence_a07_v1",  # 60% WR, +0.37% avg PnL, 5 trades
    "crypto_soc_orderflow_absorption_a10_v1",  # 57.1% WR, +0.21% avg PnL, 7 trades
    "crypto_soc_delta_divergence_a10_v1",  # 60% WR, +0.26% avg PnL, 5 trades
    "crypto_soc_orderflow_absorption_a05_v1",  # 60% WR, +0.05% avg PnL, 5 trades
}

# Rolling 7d vs prior window: audit performance_alerts REDUCE strategies — extra sort penalty.
# Keys are canonical strategy names; lookup uses .lower(). See also performance_alerts suppression.
ROLLING_7D_DEGRADATION_STRATEGY_PENALTIES = {
    "quan_engine_scalp": -28,
    "crypto_bayesian_regime_transition_momentum_v1": -28,
    "ml_crypto_predictor": -28,
    "crypto_adx_pullback_trendresume_v1": -28,
    "enhanced_ml_a_xgboost": -32,
    "extreme fear contrarian buy": -28,
    "quan_engine_swing": -25,  # 0% rolling 7d WR vs 38% baseline (n=12 recent, n=78 prior) - 2026-04-14 audit
}
_ROLLING_7D_DEGRADE_LOWER = {
    k.lower(): v for k, v in ROLLING_7D_DEGRADATION_STRATEGY_PENALTIES.items()
}

# Per-symbol strategy blocks: specific (strategy, symbol) pairs with proven 0% WR
# Data: quan_engine_scalp on MATICUSDT = 0 wins / 239 losses = -35.85% PnL
BLOCKED_STRATEGY_SYMBOL_PAIRS = {
    ("quan_engine_scalp", "MATICUSDT"),  # 0/239 WR, -35.85% PnL
    ("quan_engine_scalp", "ADAUSDT"),  # 0/7 WR, -4.19% PnL
    ("quan_engine_scalp", "ICPUSDT"),  # 4/37 WR (10.8%), -16.40% PnL
    ("quan_engine_scalp", "SOLUSDT"),  # 3/20 WR (15%), -8.02% PnL
    # 2026-04-05 claude-bus-setup (bus task 3): enhanced_ml_A_xgboost per-symbol
    # audit on 104 closed picks. Strategy overall 32.7%WR PF=0.73. Winners kept
    # (SEI 100%, CHZ 86%, JTO 57%, ETC 100% — mutate-before-kill policy).
    # These specific symbol-pairs have proven 0-33% WR + negative PnL: hard-block.
    (
        "enhanced_ml_A_xgboost",
        "TRXUSDT",
    ),  # 0/38 WR, -76% PnL (worst) — already -20 penalty, now hard-block
    ("enhanced_ml_A_xgboost", "FILUSDT"),  # 2/9 WR (22%), -8% PnL
    ("enhanced_ml_A_xgboost", "TIAUSDT"),  # 0/3 WR, -6% PnL
    ("enhanced_ml_A_xgboost", "FETUSDT"),  # 0/2 WR, -4% PnL
    ("enhanced_ml_A_xgboost", "SOLUSDT"),  # 0/2 WR, -4% PnL
    ("enhanced_ml_A_xgboost", "WLDUSDT"),  # 1/3 WR (33%), -1% PnL
    # 2026-04-05 claude-bus-setup: REHAB BLOCKS (un-killed strategies, bad symbol pairs)
    # MeanReversionBB re-activated (77.8% WR overall, PF=4.17). Single blocker:
    ("MeanReversionBB", "LINK-USD"),  # 1/3 WR (33%), -2.3% PnL — only loser
    # claude_ml_moderate_mut re-activated (52% WR overall, 2 qualifying symbols).
    # Losers:
    ("claude_ml_moderate_mut", "IMXUSDT"),  # 1/7 WR (12%), -10.1% PnL — worst
    ("claude_ml_moderate_mut", "TIAUSDT"),  # 0/3 WR, -4.2% PnL
}

# Symbols with known data quality issues (token redenomination, bad price feeds)
# MERGED into BLOCKED_SYMBOLS above (line ~251) — do NOT redefine here.
# "KATUSDT" and "TRXUSDT" are now in the main BLOCKED_SYMBOLS set.

# PnL sanity bounds — if computed PnL is outside these bounds and entry/live math
# disagrees, the pick has a data quality issue and should be flagged.
PNL_SANITY_MAX = 200.0  # No single pick should show >200% PnL
PNL_SANITY_MIN = -50.0  # No active pick should be beyond -50% without SL firing

# Asset-aware blocks for systems/strategies that are dragging down low-WR
# non-crypto books. Keep this narrow so verified PM/pro-trader sources still flow.
BLOCKED_ASSET_SOURCE_PAIRS = {
    ("FOREX", "signal_validation"),
    # ("EQUITY", "stocks_competition"),  # UNBLOCKED 2026-04-04: stocks WR 48.3%, block was overkill
}

BLOCKED_ASSET_STRATEGY_PAIRS = {
    ("FOREX", "MomentumEMA"),
    ("FOREX", "volume_spike_breakout"),
    ("FOREX", "myfxbook_retail_contrarian"),
    ("EQUITY", "ML Ranker"),
    # 2026-04: goldmine consensus on CRYPTO = 18-19% WR, -29 to -87% PnL.
    # Equity application retained (commented out of kill list 2026-04-05).
    ("CRYPTO", "goldmine_1x_consensus"),
    ("CRYPTO", "goldmine_2x_consensus"),
    ("CRYPTO", "goldmine_3x_consensus"),
    # 2026-04-18 Codex equity attribution — re-verified locally against
    # 693-row equity closed ledger. Both goldmine variants already blocked on
    # CRYPTO; equity equivalents are similarly destructive:
    #   goldmine_2x_consensus  EQUITY  n=20  WR=20.0%  PF=0.174  total=-110.13%
    #   goldmine_1x_consensus  EQUITY  n=23  WR=26.1%  PF=0.597  total= -26.74%
    # See: updates/2026-04-18-non-crypto-synthesis-and-action-plan.md (P4.2)
    ("EQUITY", "goldmine_1x_consensus"),
    ("EQUITY", "goldmine_2x_consensus"),
    # 2026-04-18 top-loser audit additions — found in worst-30 review against
    # current dashboard ledger. The 3x/4x variants extend the same goldmine
    # consensus pattern that's already blocked on 1x/2x; per-trade losses on
    # AMD show the same characteristic SL hits.
    #   AMD goldmine_3x_consensus -17.51% / goldmine_2x_consensus -13.22% / -10.74%
    #   CRM goldmine_4x_consensus -9.47% / goldmine_3x_consensus -9.44%
    ("EQUITY", "goldmine_3x_consensus"),
    ("EQUITY", "goldmine_4x_consensus"),
    # ml_enhanced_APEUSDT_1d_D_ensemble_stack: 3 closed picks in current
    # ledger, all SHORT, all hit SL at 0.1039 (broken or stale SL price),
    # losing -22.60%, -21.88%, -19.22% = -63.69% total. Symbol-specific
    # block until the strategy is re-tuned.
    ("CRYPTO", "ml_enhanced_APEUSDT_1d_D_ensemble_stack"),
    # 2026-04-22: RCA — quan_engine_scalp = largest closed volume, ~23% WR, PF 0.27;
    # pair blocks above still allow other symbols. Full class block stops new emissions.
    ("CRYPTO", "quan_engine_scalp"),
    # penny_deep_oversold (multi_asset_institutional source): IONQ -14.63%,
    # RIOT -11.80% in worst-30 review. Penny stock mean reversion is a
    # documented loser pattern (no edge — see updates/non_crypto policy).
    ("EQUITY", "penny_deep_oversold"),
}


# Direction-aware blocks — kills (asset_class, strategy, direction) triples.
# Used by historical-blocked filter to exclude rows from aggregations and by
# active-pick gating to reject new emissions. Adds the missing third axis on
# top of BLOCKED_ASSET_STRATEGY_PAIRS for cases where a strategy has edge in
# one direction only.
#
# 2026-04-17 deep-dive (subagent A) on ml_crypto_predictor SHORTs:
#   - Total: 297 SHORTs, 38.4% WR, PF 0.62, -568.3% PnL
#   - APEUSDT alone: 28 SHORTs, 0% WR, -459.5% PnL (all hit identical SL
#     at 0.1039 — broken/stale SL logic, NOT real losses)
#   - 2026-04-16 single-day catastrophe: 69 SHORTs, 0% WR, -558.5% PnL,
#     all closed at 22:52:26Z (synchronized — exchange/liquidation issue)
#   - LONG variants remain healthy: 89 picks, 86.5% WR, +270.4% PnL
#     (do NOT extend block to LONG)
#   - FETUSDT bonus claim ("100% WR" at line 2748) outdated:
#     current data shows 53.4% WR, +4.3% PnL (still slightly profitable)
BLOCKED_DIRECTION_TRIPLES = {
    ("CRYPTO", "ml_crypto_predictor", "SHORT"),
    # 2026-04-17 11-strategy WR-drop subagent (MUTATE recommendations).
    # See updates/2026-04-17-eleven-strategies-decay-investigation.md
    # quan_engine_swing LONG: 0% WR last 7d; sister to quan_engine_scalp which
    # has same LONG-bias bleed (-83% PnL — see deepscan-1 + mutation MD).
    # SHORT variant of quan_engine_swing remains profitable; keep direction-only.
    ("CRYPTO", "quan_engine_swing", "LONG"),
    # crypto_keltner_compression_expansion_v1 LONG = 17% WR -2.7% avg;
    # SHORT = 55% WR +0.7%. Asymmetric edge — block LONG only.
    ("CRYPTO", "crypto_keltner_compression_expansion_v1", "LONG"),
    # keltner_compression_expansion_eth_v1 LONG = 27% WR -3.6%; SHORT 1/1 OK.
    # Same Keltner family pattern as above.
    ("CRYPTO", "keltner_compression_expansion_eth_v1", "LONG"),
}

# Single-axis kill list extension — 2026-04-17 forex bleed forensics.
# These strategies have a -20 score penalty (`STRATEGY_NEGATIVE_BIAS_SCORES`)
# but were NOT in PERMANENTLY_KILLED so historical aggregations still
# included them. Adding here so _is_historical_blocked_pick excludes them
# AND so they're hard-killed for new picks (not just demoted).
EXTRA_KILLED_FOREX_STRATEGIES = {
    "community_london_breakout_v2_forex",  # 0.0% WR on n=16, -7.9% PnL
                                           # London ORB academic edge is 40-60% WR;
                                           # this implementation has zero edge
}
PERMANENTLY_KILLED_STRATEGIES |= EXTRA_KILLED_FOREX_STRATEGIES
# Refresh case-insensitive lookup
_KILLED_STRATEGIES_LOWER = {s.lower() for s in PERMANENTLY_KILLED_STRATEGIES}


def _forward_lane_wr_ratio(pick: Dict[str, Any]) -> float:
    """Best win-rate among forward/out-of-sample fields only (0-1). Ignores history_wr."""
    return max(
        _ratio(pick.get("strat_fwd_wr")),
        _ratio(pick.get("strategy_fwd_wr")),
        _ratio(pick.get("forward_wr")),
    )


def _forward_lane_trades(pick: Dict[str, Any]) -> int:
    """Largest forward/out-of-sample trade count. Ignores history_trades."""
    return max(
        _int(pick.get("strat_fwd_trades")),
        _int(pick.get("strategy_fwd_trades")),
        _int(pick.get("forward_trades")),
    )


def _non_crypto_active_raw_score_bypass(pick: Dict[str, Any]) -> bool:
    """Strong audited history can justify surfacing a low raw dashboard score.

    Requires both (1) concentrated backtest history and (2) a minimum forward
    lane with non-random WR so picks cannot bypass the floor on BT alone.
    """
    n = _int(pick.get("history_trades", 0))
    if n < 30:
        return False
    hist_ok = _ratio(pick.get("history_wr_bayes", 0)) >= 0.88 or (
        _ratio(pick.get("history_wr", 0)) >= 0.88 and n >= 40
    )
    if not hist_ok:
        return False
    fwd_n = _forward_lane_trades(pick)
    fwd_wr = _forward_lane_wr_ratio(pick)
    if fwd_n < NC_RAW_SCORE_BYPASS_MIN_FORWARD_TRADES:
        return False
    if fwd_wr < NC_RAW_SCORE_BYPASS_MIN_FORWARD_WR:
        return False
    return True


def _float(value: Any) -> float:
    """Safely convert to float."""
    if value is None:
        return 0.0
    try:
        return float(value)
    except (ValueError, TypeError):
        return 0.0


def _ratio(value: Any) -> float:
    """Normalize win-rate style fields to a 0-1 ratio."""
    val = _float(value)
    if val > 1:
        return val / 100.0
    return val


def _int(value: Any) -> int:
    """Safely convert to int."""
    return int(round(_float(value)))


def _as_list(value: Any) -> list[str]:
    """Normalize CSV/list-like fields into a list of strings."""
    if isinstance(value, str):
        return [item.strip() for item in value.split(",") if item.strip()]
    if isinstance(value, (list, tuple, set)):
        return [str(item).strip() for item in value if str(item).strip()]
    return []


# ── Exit-reason normalization (issue #186) ────────────────────────────────
# Some closed picks carry binary outcome labels (WON/LOST/WIN/LOSS) instead of
# canonical exit reasons (TP_HIT/SL_HIT/TIME_EXIT). The labels leak from
# copy-trader scrapers via dashboard_generator.py:5139's outcome fallback chain.
# Forensic analysis (issue #186 + the late 2026-04-14 audit): 92% of forex
# LOST picks have |pnl_pct| < 0.5% but forex SL median is 0.5%, and 60% exit
# within 0.1% of entry price — meaning these are unresolved mark-to-market
# force-closes, NOT stop-loss events. Treating them as SL_HIT corrupts
# stop-discipline metrics.
#
# This helper canonicalizes exit_reason into one of:
#   TP_HIT, SL_HIT, TIME_EXIT, EXPIRED, FORCE_CLOSED, UNKNOWN
#
# Wired into ``audit_trail/dashboard_generator.py`` for deduped ``resolved_closed``
# (see ``_apply_issue186_exit_normalization``). Set ``AUDIT_SKIP_EXIT_NORMALIZATION=1``
# to disable. Raw scrape label is preserved on each pick as ``exit_reason_raw``.
# Upstream scrapers should still prefer correct exit_reason at ingest time.

# Canonical exit reason families
_TP_FAMILY = {"TP_HIT", "TP", "WON", "WIN", "TAKE_PROFIT"}
_SL_FAMILY = {"SL_HIT", "SL", "LOST", "LOSS", "STOP_LOSS"}
_TIME_FAMILY = {"TIME_EXIT", "TIME_EXPIRY", "TIME", "MAX_HOLD_EXCEEDED"}
_EXPIRED_FAMILY = {"EXPIRED", "EXPIRED_RESOLVED"}


def _canonical_exit_reason(raw: str) -> str:
    """Map a raw exit_reason string to one of the canonical families.

    Legacy 'TP'/'SL'/'WON'/'LOST' (which include the unsafe binary outcome
    labels from copy-trader scrapers) are mapped to 'TP_HIT'/'SL_HIT' as a
    last resort if no price-distance refinement is available. Use
    `normalize_exit_reason(pick)` instead when you have access to the full
    pick dict — that function refines binary labels using exit_price vs
    take_profit / stop_loss distance.
    """
    if not raw:
        return "UNKNOWN"
    upper = raw.upper().strip()
    # Direct family match
    if upper in _TP_FAMILY:
        return "TP_HIT"
    if upper in _SL_FAMILY:
        return "SL_HIT"
    if upper in _TIME_FAMILY:
        return "TIME_EXIT"
    if upper in _EXPIRED_FAMILY:
        return "EXPIRED"
    # Substring matches for parameterized labels like "TAKE_PROFIT 4.2% (ATR ...)"
    if "TAKE_PROFIT" in upper or "TP_HIT" in upper or "TP HIT" in upper:
        return "TP_HIT"
    if "STOP_LOSS" in upper or "SL_HIT" in upper or "SL HIT" in upper:
        return "SL_HIT"
    if "TIME" in upper or "MAX_HOLD" in upper or "MAX HOLD" in upper:
        return "TIME_EXIT"
    if "EXPIRED" in upper:
        return "EXPIRED"
    if "ATR" in upper or "TRAILING" in upper or "hit at $" in upper.lower():
        # ATR/trailing stops — usually SL-style but could be TP. Mark as TP_HIT
        # only if the original contained 'tp' or 'profit'; otherwise treat as
        # SL_HIT-equivalent for discipline purposes.
        return "TP_HIT" if ("TP" in upper or "PROFIT" in upper) else "SL_HIT"
    return "UNKNOWN"


def normalize_exit_reason(pick: Dict[str, Any]) -> str:
    """Canonicalize a closed pick's exit_reason using both the raw label and
    price-distance refinement.

    Returns one of: TP_HIT, SL_HIT, TIME_EXIT, EXPIRED, FORCE_CLOSED, UNKNOWN.

    Refinement logic for binary outcome labels (WON/LOST/WIN/LOSS):
      - If exit_price is within 0.5% of take_profit ÔåÆ TP_HIT
      - If exit_price is within 0.5% of stop_loss ÔåÆ SL_HIT
      - Otherwise ÔåÆ FORCE_CLOSED (e.g., copy-trader leader exit, scanner pruning,
        mark-to-market reconciliation — these are NOT stop-loss events even
        though they typically have small negative pnl)

    For canonical labels (TP_HIT/SL_HIT/TIME_EXIT/EXPIRED), passes through
    without refinement.

    Per issue #186: 92% of forex LOST picks have |pnl| < 0.5% (well below the
    forex SL median), 60% exit within 0.1% of entry price. Treating them as
    SL_HIT corrupts stop-discipline metrics. FORCE_CLOSED is the honest label.
    """
    raw = (pick.get("exit_reason") or pick.get("close_reason") or "").upper().strip()
    if not raw:
        # No exit_reason at all — see if it's a stale active or actually closed
        if pick.get("pnl_pct") is None:
            return "UNKNOWN"
        # Has pnl but no exit_reason — try outcome field as last resort
        outcome = (pick.get("outcome") or pick.get("status") or "").upper().strip()
        if outcome in {"WON", "LOST", "WIN", "LOSS"}:
            raw = outcome
        else:
            return "UNKNOWN"

    canonical = _canonical_exit_reason(raw)

    # If the raw label was already a clean TP_HIT/SL_HIT/TIME_EXIT/EXPIRED with
    # a distinctive prefix (not from the binary WON/LOST family), trust it.
    if raw in {"TP_HIT", "SL_HIT", "TIME_EXIT", "EXPIRED"}:
        return canonical

    # Otherwise, this might be from the binary WON/LOST family — refine using
    # price-distance to TP/SL.
    if raw in {"WON", "LOST", "WIN", "LOSS"}:
        try:
            entry = float(pick.get("entry_price") or 0)
            exit_price = float(pick.get("exit_price") or 0)
            tp = float(pick.get("take_profit") or 0)
            sl = float(pick.get("stop_loss") or 0)
        except (TypeError, ValueError):
            return canonical  # fall back to family map

        if entry > 0 and exit_price > 0:
            # Distance to TP and SL as percent of TP/SL respectively
            tp_dist = abs(exit_price - tp) / tp if tp > 0 else 1.0
            sl_dist = abs(exit_price - sl) / sl if sl > 0 else 1.0
            EPS = 0.005  # within 0.5% counts as a hit
            if tp_dist < EPS and tp_dist < sl_dist:
                return "TP_HIT"
            if sl_dist < EPS and sl_dist < tp_dist:
                return "SL_HIT"
            # Neither — this is a force-close, not a real TP/SL event
            return "FORCE_CLOSED"

    return canonical


def _effective_forward_wr_ratio(pick: Dict[str, Any]) -> float:
    """Return the strongest available forward win rate as a 0-1 ratio."""
    return max(
        _ratio(pick.get("strat_fwd_wr")),
        _ratio(pick.get("strategy_fwd_wr")),
        _ratio(pick.get("forward_wr")),
        _ratio(pick.get("history_wr")),
        _ratio(pick.get("history_wr_bayes")),
    )


def _effective_forward_trades(pick: Dict[str, Any]) -> int:
    """Return the strongest available forward trade sample size."""
    return max(
        _int(pick.get("strat_fwd_trades")),
        _int(pick.get("strategy_fwd_trades")),
        _int(pick.get("forward_trades")),
        _int(pick.get("history_trades")),
    )


def _is_futures_contract_pick(pick: Dict[str, Any]) -> bool:
    """Return True for futures contracts, including commodity/index futures aliases."""
    asset_class = str(pick.get("asset_class", "") or "").upper()
    symbol = str(pick.get("symbol", "") or "").upper().strip()
    category = str(pick.get("category", "") or "").lower().strip()
    return symbol.endswith("=F") or asset_class == "FUTURES" or category == "futures"


def _is_consensus_pick(pick: Dict[str, Any]) -> bool:
    """Return True for consensus/super-signal style picks."""
    source = str(pick.get("source_system", "") or "").lower()
    strategy = str(pick.get("strategy", "") or "").lower()
    return (
        "consensus" in strategy
        or strategy.startswith("super signal")
        or source == "super_signals"
    )


def _trade_bias(pick: Dict[str, Any]) -> str:
    """Return BUY/SELL based on the pick direction."""
    direction = str(pick.get("direction", pick.get("signal_type", "")) or "").upper()
    if direction in ("LONG", "BUY"):
        return "BUY"
    if direction in ("SHORT", "SELL"):
        return "SELL"
    return ""


def _technical_alignment_bucket(pick: Dict[str, Any]) -> str:
    """
    Return a direction-aware technical-alignment bucket.

    Values:
      full_support, strong_support, weak_support, no_support,
      strong_opposition, weak_opposition, unknown
    """
    expected_bias = _trade_bias(pick)
    if not expected_bias:
        return "unknown"

    tech_align = str(pick.get("technical_alignment_str", "") or "").upper().strip()
    match = _TECH_ALIGN_RE.search(tech_align)
    if match:
        aligned = _int(match.group("aligned"))
        reported_total = max(_int(match.group("total")), aligned)
        reported_bias = match.group("bias").upper()
        if reported_bias != expected_bias:
            if aligned >= 2:
                return "strong_opposition"
            if aligned == 1:
                return "weak_opposition"
            return "unknown"
        if aligned >= 3:
            return "full_support"
        if aligned >= 2:
            return "strong_support"
        if aligned == 1:
            return "weak_support"
        if reported_total > 0:
            return "no_support"
        return "unknown"

    buy_tfs = _int(pick.get("technical_buy_tfs", 0))
    sell_tfs = _int(pick.get("technical_sell_tfs", 0))
    supporting = buy_tfs if expected_bias == "BUY" else sell_tfs
    opposing = sell_tfs if expected_bias == "BUY" else buy_tfs
    total = max(supporting + opposing, supporting, opposing)

    if opposing >= 2:
        return "strong_opposition"
    if opposing == 1 and total >= 2 and supporting == 0:
        return "weak_opposition"
    if supporting >= 3:
        return "full_support"
    if supporting >= 2:
        return "strong_support"
    if supporting == 1:
        return "weak_support"
    if total > 0:
        return "no_support"
    return "unknown"


def _wf_verdict(pick: Dict[str, Any]) -> str:
    """Return normalized walk-forward verdict."""
    return str(pick.get("wf_verdict", "") or "").upper().strip()


def _has_direction_conflict(pick: Dict[str, Any]) -> bool:
    """Return True when the symbol has live opposite-direction picks."""
    return bool(pick.get("_direction_conflict") or pick.get("has_conflict"))


def _audit_pick_sanity_gate_enabled() -> bool:
    """Strict data-quality gate for active picks (off by default).

    Set ``AUDIT_PICK_SANITY_GATE=1`` (or ``true``/``yes``/``on``) to reject rows
    that fail ``audit_trail.pick_sanity`` (R:R bounds, score ranges, geometry
    when TP/SL present). Prediction-market rows use the same exemptions as
    trade-geometry checks.
    """
    v = str(os.environ.get("AUDIT_PICK_SANITY_GATE", "") or "").strip().lower()
    return v in ("1", "true", "yes", "on")


def _pick_sanity_gate_exempt(pick: Dict[str, Any]) -> bool:
    """Sources where pick_sanity is skipped (non-standard economics)."""
    source = str(pick.get("source_system", "") or "").lower()
    strategy = str(pick.get("strategy", "") or "").lower()
    if source in {
        "prediction_market_consensus",
        "pm_kalshi_signals",
        "pm_whale_signals",
        "polymarket_signals",
    } or strategy.startswith("copy_pm_"):
        return True
    return False


def _has_valid_trade_geometry(pick: Dict[str, Any]) -> bool:
    """Return True when entry/TP/SL form a valid directional trade.
    
    FIXED 2026-04-10: Now applies validation to ALL asset classes (CRYPTO, FOREX,
    EQUITY, COMMODITY, FUTURES) - previously non-CRYPTO assets skipped validation.
    """
    # Use unified trade_geometry module if available (applies to ALL asset classes)
    if _TRADE_GEOMETRY_AVAILABLE:
        return has_valid_trade_geometry(pick)
    
    # Fallback to inline validation (CRYPTO only) if module not available
    if _pick_sanity_gate_exempt(pick):
        return True

    entry = _float(pick.get("entry_price", 0))
    tp = _float(pick.get("take_profit", 0))
    sl = _float(pick.get("stop_loss", 0))
    # Only reject if entry price is missing — TP/SL may not be populated yet
    if entry <= 0:
        return False
    # If TP and SL are both present, check directional consistency
    if tp > 0 and sl > 0:
        direction = str(
            pick.get("direction", pick.get("signal_type", "LONG")) or ""
        ).upper()
        if direction in ("LONG", "BUY"):
            return tp > entry > sl
        if direction in ("SHORT", "SELL"):
            return tp < entry < sl
        return False
    # If TP/SL missing, allow through — many valid picks lack TP/SL at emission time
    return True


def _trade_rr(pick: Dict[str, Any]) -> float:
    """Return normalized risk/reward for the pick."""
    rr = _float(pick.get("rr_ratio", 0))
    if rr > 0:
        return rr

    entry = _float(pick.get("entry_price", 0))
    tp = _float(pick.get("take_profit", 0))
    sl = _float(pick.get("stop_loss", 0))
    if entry <= 0 or tp <= 0 or sl <= 0 or entry == sl:
        return 0.0

    direction = str(
        pick.get("direction", pick.get("signal_type", "LONG")) or ""
    ).upper()
    if direction in ("LONG", "BUY"):
        return (tp - entry) / (entry - sl) if tp > entry > sl else 0.0
    if direction in ("SHORT", "SELL"):
        return (entry - tp) / (sl - entry) if tp < entry < sl else 0.0
    return 0.0


def _equity_forward_proven_mitigates_conf_deadzone(pick: Dict[str, Any]) -> bool:
    """EQUITY rows with validated forward history: conf 0.60–0.69 is a weak proxy.

    Otherwise `conf_danger_zone` and `long_deadzone_combo` stack (-22) on picks that
    already show strong strategy-level forward WR (e.g. multi_asset_copytrader META).
    Requires large-n, above-floor WR — same spirit as HC Gate 5.
    """
    if str(pick.get("asset_class", "") or "").upper() != "EQUITY":
        return False
    if not pick.get("forward_validated"):
        return False
    n = _effective_forward_trades(pick)
    wr = _effective_forward_wr_ratio(pick)
    return n >= 50 and wr >= 0.45


def _extract_final_score(pick: Dict[str, Any]) -> tuple[float, bool]:
    """Return (score_value, has_explicit_score_field).

    has_explicit_score_field=False means the pick has no meaningful score yet
    and _apply_score_penalties will apply the baseline of 50.
    Treat score=0 as 'unscored' — upstream scanners emit 0 as a sentinel for
    'not yet scored', not as a legitimate quality signal of zero.
    """
    # Prefer the final post-penalty score, then fall back through scoring fields
    for key in ("score", "elite_score", "smart_score", "ml_score"):
        raw = pick.get(key)
        if raw not in (None, ""):
            val = _float(raw)
            if val > 0:  # treat 0 as unscored (scanners emit 0 as sentinel)
                return val, True
    # Confidence (0-1 scale) ÔåÆ map to 0-100 scale
    conf = pick.get("confidence")
    if conf not in (None, ""):
        val = _float(conf)
        if 0 < val <= 1:
            return val * 100, True
        elif val > 1:
            return val, True
    return 0.0, False


def _calculate_age_hours(timestamp_str: Optional[str]) -> float:
    """Calculate age in hours from timestamp string."""
    if not timestamp_str:
        return 0.0

    try:
        # Try ISO format
        if "T" in timestamp_str:
            dt = datetime.fromisoformat(timestamp_str.replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
        else:
            # Try common formats
            for fmt in ["%Y-%m-%d %H:%M:%S", "%Y-%m-%d"]:
                try:
                    dt = datetime.strptime(timestamp_str, fmt)
                    dt = dt.replace(tzinfo=timezone.utc)
                    break
                except ValueError:
                    continue
            else:
                return 0.0

        now = datetime.now(timezone.utc)
        age = now - dt
        return age.total_seconds() / 3600
    except Exception as e:
        logger.warning(f"Failed to parse timestamp {timestamp_str}: {e}")
        return 0.0


def _get_strategy_tier(strategy: str) -> str:
    """Get tier for a strategy."""
    if strategy in PROVEN_INVERSE_STRATEGIES:
        return "TOP_TIER"
    if strategy in LOW_CONFIDENCE_STRATEGIES:
        return "UNDERPERFORMING"
    if strategy.lower() in _KILLED_STRATEGIES_LOWER:
        return "TOXIC"
    return "WATCH"  # Default


def _is_15m_model(strategy: str) -> bool:
    """Check if strategy uses anti-predictive 15m timeframe."""
    return "_15m_" in strategy or strategy.endswith("_15m")


def _concentration_risk(pick: Dict[str, Any]) -> str:
    """Return the normalized concentration-risk label."""
    return str(
        pick.get("strategy_concentration_risk")
        or pick.get("strat_concentration_level")
        or pick.get("strat_concentration_risk")
        or ""
    ).upper()


def _concentration_penalty(pick: Dict[str, Any]) -> float:
    """Return an extra penalty for concentrated strategy track records."""
    penalty = max(
        _float(pick.get("strat_concentration_penalty")),
        _float(pick.get("strategy_concentration_penalty")),
    )
    risk = _concentration_risk(pick)
    if risk == "HIGH":
        penalty = max(penalty, SMART_CONCENTRATION_HIGH_PENALTY)
    elif risk == "MODERATE":
        penalty = max(penalty, SMART_CONCENTRATION_MODERATE_PENALTY)

    top_symbol_pnl = max(
        _float(pick.get("strat_top_symbol_pnl_pct")),
        _float(pick.get("strategy_top_symbol_pnl_pct")),
    )
    if top_symbol_pnl >= 150:
        penalty = max(penalty, SMART_CONCENTRATION_HIGH_PENALTY)
    elif top_symbol_pnl >= 100:
        penalty = max(penalty, SMART_CONCENTRATION_MODERATE_PENALTY)

    return penalty


def _trust_tier(pick: Dict[str, Any]) -> str:
    """Return normalized trust tier."""
    return str(pick.get("trust_tier", "") or "").upper()


def _has_source_provenance(pick: Dict[str, Any]) -> bool:
    """Return True when a pick has an explicit, non-placeholder source."""
    source = (
        str(pick.get("source_system", pick.get("source", "")) or "").strip().lower()
    )
    return bool(source and source not in {"unknown", "none", "null", "nan"})


def _has_strong_audited_pm_history(pick: Dict[str, Any]) -> bool:
    """
    Allow audited PM consensus rows to survive a strict score floor if the
    attached history is both strong and multi-source.
    """
    source = str(pick.get("source_system", "") or "").lower()
    strategy = str(pick.get("strategy", "") or "").lower()
    if (
        source != "prediction_market_consensus"
        and strategy != "prediction_market_consensus"
    ):
        return False

    history_wr = max(
        _ratio(pick.get("history_wr_bayes")),
        _ratio(pick.get("profile_crypto_wr_bayes")),
        _ratio(pick.get("history_wr")),
        _ratio(pick.get("profile_crypto_wr")),
    )
    history_trades = max(
        _int(pick.get("history_trades")),
        _int(pick.get("profile_crypto_trades")),
    )
    pm_source_systems = _as_list(pick.get("pm_source_systems"))
    source_count = max(
        _int(pick.get("source_count")),
        _int(pick.get("agreement_count")),
        len(pm_source_systems),
    )

    return (
        history_wr >= AUDITED_PM_MIN_HISTORY_WR
        and history_trades >= AUDITED_PM_MIN_HISTORY_TRADES
        and source_count >= AUDITED_PM_MIN_SOURCE_COUNT
    )


def _active_floor_score(pick: Dict[str, Any]) -> float:
    """Return score used for the active-feed quality floor."""
    score, _ = _extract_final_score(pick)
    if _has_strong_audited_pm_history(pick):
        score += AUDITED_PM_SCORE_BONUS
    return score


def _smart_floor_score(pick: Dict[str, Any]) -> float:
    """Return score used for the Smart Picks quality floor."""
    return _active_floor_score(pick) - _concentration_penalty(pick)


def is_profitable_short_strategy(pick: Dict[str, Any]) -> bool:
    """
    Check if a SHORT pick is from a proven profitable short strategy.
    These strategies are exempt from blanket SHORT penalties.
    """
    direction = pick.get("direction", "LONG").upper()
    if direction != "SHORT":
        return False

    strategy = pick.get("strategy", "")
    return strategy in PROFITABLE_SHORT_STRATEGIES


def _apply_score_penalties(pick: Dict[str, Any]) -> None:
    """
    Apply score penalties/bonuses to a pick based on quality signals.

    Philosophy: ALL picks reach the dashboard. Quality signals adjust the
    score so weaker picks sort lower rather than being hidden entirely.
    Penalties are stored in pick["_penalties"] for transparency.
    """
    # Idempotency guard: passes_active_gate and passes_smart_gate both call this
    # function. The second call would re-apply all penalties to the already-penalized
    # score, causing picks to be double-penalized into the floor (e.g. 50->36->7).
    if pick.get("_penalties") is not None:
        return  # Already scored — skip second application

    penalties = []
    score, has_score = _extract_final_score(pick)
    if not has_score:
        score = 50.0  # Default baseline for unscored picks

    strategy = pick.get("strategy", "")

    # Rehab child strategies (parent_* + rsi2/confluence/mtf/regime/...) — mutate-before-kill path
    if _is_rehab_variant_strategy(strategy):
        score += 8
        penalties.append("rehab_variant_confluence:+8")

    # BLOCKED SYMBOLS — phantom/delisted symbols that generate 0% WR trades
    _symbol = str(pick.get("symbol", "") or "").upper()
    if _symbol in BLOCKED_SYMBOLS:
        score -= 50
        penalties.append(f"blocked_symbol({_symbol}):-50")

    # BLOCKED ASSET CLASSES — temporarily disable entire classes with systemic issues
    _asset_class = str(pick.get("asset_class", "CRYPTO") or "CRYPTO").upper()
    if _asset_class in BLOCKED_ASSET_CLASSES:
        score -= 60
        # Breadcrumb label must match the actual delta (2026-04-19 code review, Finding 1).
        penalties.append(f"blocked_asset_class({_asset_class}):-60")

    # Futures probation: pipeline support exists, but the live cohort is still thin,
    # mostly forward-test-only, and recent realized outcomes are poor. Keep these rows
    # visible but force them below premium ranks until they earn real sample support.
    if _is_futures_contract_pick(pick):
        _forward_test_only = bool(pick.get("forward_test_only"))
        _forward_validated = bool(pick.get("forward_validated"))
        _edge_trades = _effective_forward_trades(pick)
        _edge_wr = _effective_forward_wr_ratio(pick)
        if _forward_test_only and not _forward_validated:
            if _edge_trades <= 0:
                score -= 20
                penalties.append("futures_forward_test_only_no_sample:-20")
            elif _edge_trades < 5 or _edge_wr < 0.45:
                score -= 12
                penalties.append(
                    f"futures_forward_test_only_thin_sample(wr={_edge_wr:.0%},n={_edge_trades}):-12"
                )

    # Non-crypto probation: keep weak-evidence classes visible but de-prioritized.
    # This mirrors the futures probation stance from edge-review docs:
    # - FOREX often shows weak score discrimination unless validated sample exists.
    # - COMMODITY / ETF / BOND are usually thin-sample lanes.
    _forward_test_only = bool(pick.get("forward_test_only"))
    _forward_validated = bool(pick.get("forward_validated"))
    _edge_trades = _effective_forward_trades(pick)
    _edge_wr = _effective_forward_wr_ratio(pick)
    if _asset_class in {"FOREX", "COMMODITY", "ETF", "BOND"} and _forward_test_only and not _forward_validated:
        if _edge_trades <= 0:
            score -= 16
            penalties.append(f"{_asset_class.lower()}_forward_test_only_no_sample:-16")
        elif _edge_trades < 5 or _edge_wr < 0.50:
            score -= 10
            penalties.append(
                f"{_asset_class.lower()}_forward_test_only_thin_sample(wr={_edge_wr:.0%},n={_edge_trades}):-10"
            )

    # Forex-specific confidence calibration guard:
    # high confidence with weak sample should not rank as premium by default.
    if _asset_class == "FOREX":
        _fx_conf = _float(pick.get("confidence", 0))
        if _fx_conf >= 0.75 and (_edge_trades < 10 or _edge_wr < 0.52):
            score -= 8
            penalties.append(
                f"forex_confidence_uncalibrated(conf={_fx_conf:.2f},wr={_edge_wr:.0%},n={_edge_trades}):-8"
            )

    # CONFIDENCE TRAP — DATA 2026-04-03 (1952 closed picks):
    #   conf >= 0.65 AND elite_score < 40 = 581 trades at 9% WR
    #   These are high-confidence picks from low-quality strategies — deadly combo
    #   RECALIBRATED 2026-04-05: Reduced from -25 to -18 for 0.90-0.95 bucket
    _elite = _float(pick.get("elite_score", 0))
    _conf_raw = _float(pick.get("confidence", 0))
    if _conf_raw >= 0.65 and 0 < _elite < 40:
        # Tiered penalty based on confidence level
        if _conf_raw >= 0.90:
            score -= 18  # Reduced from -25: worst bucket is 0.90-0.95 (36% WR)
            penalties.append(
                f"confidence_trap(conf={_conf_raw:.2f},elite={_elite:.0f}):-18"
            )
        else:
            score -= 15
            penalties.append(
                f"confidence_trap(conf={_conf_raw:.2f},elite={_elite:.0f}):-15"
            )

    # Killed strategies get heavy penalty but still show (so user sees them flagged)
    if strategy.lower() in _KILLED_STRATEGIES_LOWER:
        score -= 40
        penalties.append("killed_strategy:-40")

    # 2026-04-05: TOXIC COMBO blocks from antigrav-independent-review findings.
    # These strategy+direction combos have confirmed 0-17% WR with negative avg PnL:
    # - tsmom_volscaled+SHORT: 0% WR, -1.43% avg
    # - rocket_scanner+SHORT: 0% WR, -0.77% avg
    # - enhanced_ml_A_xgboost+LONG: 17% WR, -0.48% avg
    _strat_low = strategy.lower()
    _dir_up = (pick.get("direction") or pick.get("signal_type") or "").upper()
    _toxic = False
    if "tsmom_volscaled" in _strat_low and _dir_up in ("SHORT", "SELL"):
        _toxic = True
    elif "rocket_scanner" in _strat_low and _dir_up in ("SHORT", "SELL"):
        _toxic = True
    elif "enhanced_ml_a_xgboost" in _strat_low and _dir_up in ("LONG", "BUY"):
        _toxic = True
    if _toxic:
        score -= 25
        penalties.append(f"toxic_combo({_strat_low[:20]}/{_dir_up}):-25")

    # 2026-04-05: MASTERED PAIR boosts - strategy+symbol combos with 100% WR.
    # Per antigrav-independent-review: claude_gainer_st has mastered ARB/DOT/SOL/BNB/SUI/DOGE/ADA.
    # Also quan_engine+ETCUSDT, kimi+AVAXUSDT.
    _sym_up = str(pick.get("symbol", "") or "").upper()
    _mastered_pairs = {
        ("claude_gainer_st", "ARBUSDT"),
        ("claude_gainer_st", "DOTUSDT"),
        ("claude_gainer_st", "SOLUSDT"),
        ("claude_gainer_st", "BNBUSDT"),
        ("claude_gainer_st", "SUIUSDT"),
        ("claude_gainer_st", "DOGEUSDT"),
        ("claude_gainer_st", "ADAUSDT"),
        ("quan_engine", "ETCUSDT"),
        ("kimi_riseoftheclaw", "AVAXUSDT"),
    }
    for _ms, _msym in _mastered_pairs:
        if _ms in _strat_low and _sym_up.startswith(_msym):
            score += 10
            penalties.append(f"mastered_pair({_ms[:12]}+{_msym[:8]}):+10")
            break

    # 2026-04-05: SHARP TOOLS EDGE MAP - st_fear_greed_contrarian CROWN JEWEL.
    # Validated on 525 closed picks, overall 61.9% WR. Per-symbol LONG verified:
    # LTC 96% (n=25), BNB 93% (n=28), TRX 85% (n=13), XRP 82% (n=34), DOT 77% (n=35), LINK 75% (n=12).
    # Boost is LARGER than mastered_pair because WR>75% on all 6 pairs.
    _sharp_fear_greed = {
        "LTCUSDT",
        "BNBUSDT",
        "TRXUSDT",
        "XRPUSDT",
        "DOTUSDT",
        "LINKUSDT",
    }
    if (
        "fear_greed" in _strat_low
        and _dir_up in ("LONG", "BUY")
        and any(_sym_up.startswith(s) for s in _sharp_fear_greed)
    ):
        score += 12
        penalties.append(f"sharp_fear_greed+{_sym_up[:8]}:+12")

    # 2026-04-05: QUALITY FILTER BOOSTS (user-verified asset-class edges).
    # CRYPTO filter: trust>=3.5 AND strat_fwd_wr>=50% -> 60.3% WR (+16.8pp, n=2881)
    # EQUITY filter: strat_fwd_wr>=60% AND strat_fwd_pf>=1.5 -> 65% WR (+31.3pp, n=531)
    _ac_quality = str(pick.get("asset_class", "") or "").upper()
    _trust_val = _float(pick.get("trust_score") or 0)
    _sfwd_wr = _float(pick.get("strat_fwd_wr") or 0)
    if _sfwd_wr > 1.5:
        _sfwd_wr = _sfwd_wr / 100.0
    _sfwd_pf = _float(pick.get("strat_fwd_pf") or 0)
    if _ac_quality == "CRYPTO" and _trust_val >= 3.5 and _sfwd_wr >= 0.50:
        score += 7
        penalties.append(f"crypto_quality_filter(tr>=3.5,wr>=50):+7")
    elif _ac_quality == "EQUITY" and _sfwd_wr >= 0.60 and _sfwd_pf >= 1.5:
        score += 10
        penalties.append(f"equity_quality_filter(wr>=60,pf>=1.5):+10")

    # 2026-04-05: Asset-class-specific rr_ratio gating (from factor deep-dive).
    # CRYPTO: rr_ratio>=2.0 -> 68.4% WR n=177 vs 43% baseline (massive edge cliff).
    # EQUITY: rr_ratio INVERTS - tight 1.6-1.9 is optimal, >2.0 drops WR to 24%.
    _rr = _float(pick.get("rr_ratio") or 0)
    if _ac_quality == "CRYPTO" and _rr >= 2.0:
        score += 8
        penalties.append(f"crypto_rr_sweetspot(rr={_rr:.1f}):+8")
    elif _ac_quality == "EQUITY" and 1.6 <= _rr <= 1.9:
        score += 6
        penalties.append(f"equity_rr_sweetspot(rr={_rr:.1f}):+6")
    elif _ac_quality == "EQUITY" and _rr > 2.0:
        score -= 5
        penalties.append(f"equity_rr_inverted(rr={_rr:.1f}):-5")

    # 2026-04-05: EQUITY tp_dist_pct>8% HARD BLOCK - 18% WR, -3.4% avg PnL n=89.
    # Greedy TPs are disaster on equities (factor deep-dive P3).
    _tp_dist = _float(pick.get("tp_dist_pct") or 0)
    if _tp_dist > 1.5:  # could be stored as 8.0 or 0.08
        _tp_dist = _tp_dist / 100.0
    if _ac_quality == "EQUITY" and _tp_dist > 0.08:
        score -= 20
        penalties.append(f"equity_greedy_tp(tp_dist={_tp_dist * 100:.1f}pct):-20")

    # 2026-04-05: CRYPTO wf_p_value<0.01 - strongest statistical filter.
    # 63.2% WR n=552 vs 36% at p>0.224 (from factor deep-dive P4).
    _wf_p = _float(pick.get("wf_p_value") or 0)
    if _ac_quality == "CRYPTO" and 0 < _wf_p < 0.01:
        score += 8
        penalties.append(f"crypto_wf_significant(p={_wf_p:.4f}):+8")

    # 15m anti-predictive models
    if _is_15m_model(strategy) and not is_profitable_short_strategy(pick):
        score -= 30
        penalties.append("15m_model:-30")

    # Missing entry price / TP/SL — less actionable
    entry = _float(pick.get("entry_price", 0))
    tp = _float(pick.get("take_profit", 0))
    sl = _float(pick.get("stop_loss", 0))
    if entry <= 0:
        score -= 10
        penalties.append("no_entry:-10")
    if tp <= 0 or sl <= 0:
        score -= 10
        penalties.append("no_tp_sl:-10")
    if not _has_valid_trade_geometry(pick):
        score -= 35
        penalties.append("invalid_trade_geometry:-35")

    # R:R scoring — DATA CORRECTED 2026-04-01:
    # Closed-pick analysis (1868 picks) shows R:R is INVERTED:
    #   R:R < 1.0 = 66.7% WR, R:R 1.0-1.5 = 70.8% WR (BEST),
    #   R:R 1.5-2.0 = 45.6%, R:R 2.0-3.0 = 42.4%
    # Tight TP/SL wins more often. Wider R:R means TP is too far.
    rr = _trade_rr(pick)
    if 0 < rr <= 1.5:
        # Tight R:R is the proven winner zone
        score += 10
        penalties.append(f"tight_rr_winner({rr:.1f}):+10")
    elif 1.5 < rr <= 2.0:
        # Neutral zone
        score += 0
        penalties.append(f"mid_rr({rr:.1f}):+0")
    elif 2.0 < rr <= 3.0:
        # Wide R:R underperforms — slight penalty
        score -= 5
        penalties.append(f"wide_rr({rr:.1f}):-5")
    elif rr > 3.0:
        # Very wide R:R — TP too ambitious
        score -= 10
        penalties.append(f"overwide_rr({rr:.1f}):-10")

    # Confidence — RECALIBRATED 2026-04-05 on 3500 closed picks (bus task 2):
    #   <0.60 = 42.7% WR (n=911), 0.60-0.64 = 37.9% WR (DANGER, n=663),
    #   0.65-0.69 = 45.8% WR (n=411), 0.70-0.74 = 49.5% WR (n=276),
    #   0.75-0.79 = 58.8% WR (SWEET SPOT, n=974, +337% totalPnL),
    #   0.80-0.84 = 61.1% WR (PEAK, n=54, +1.70% avgPnL),
    #   0.85-0.89 = 50.0% WR (n=36), 0.90-0.94 = 36.1% WR (DANGER, -2.60% avgPnL),
    #   0.95-1.00 = 43.6% WR (n=78, -1.25% avgPnL).
    # Previous 2026-04-03 claim (87.4% sweet spot, 22.2% overconf) was from n=1000
    # older sample — revised down but pattern holds: 0.75-0.84 is best, 0.90+ worst.
    conf = _float(pick.get("confidence", 0))
    if conf >= 0.95:
        # 43.6% WR but -1.25% avgPnL = still losing money
        score -= 12
        penalties.append(f"conf_extreme_overconfident({conf:.2f}):-12")
    elif 0.90 <= conf < 0.95:
        # 36.1% WR, -2.60% avgPnL = WORST avg PnL bucket
        score -= 18
        penalties.append(f"conf_overconfident({conf:.2f}):-18")
    elif 0.85 <= conf < 0.90:
        # 50% WR neutral
        score += 2
        penalties.append(f"conf_high_neutral({conf:.2f}):+2")
    elif 0.80 <= conf < 0.85:
        # 61.1% WR, +1.70% avgPnL = PEAK (small n=54, moderate bonus)
        score += 10
        penalties.append(f"conf_peak({conf:.2f}):+10")
    elif 0.75 <= conf < 0.80:
        # 58.8% WR, +0.35% avgPnL = SWEET SPOT (large n=974)
        score += 12
        penalties.append(f"conf_sweet_spot({conf:.2f}):+12")
    elif 0.70 <= conf < 0.75:
        # 49.5% WR = break-even
        score += 3
        penalties.append(f"conf_good({conf:.2f}):+3")
    elif 0.65 <= conf < 0.70:
        # 45.8% WR
        score -= 3
        penalties.append(f"conf_below_avg({conf:.2f}):-3")
    elif 0.60 <= conf < 0.65:
        # 37.9% WR, ~flat avgPnL = DANGER ZONE — unless EQUITY + proven forward book
        if _equity_forward_proven_mitigates_conf_deadzone(pick):
            score -= 3
            penalties.append(
                f"conf_below_avg_equity_forward_proven({conf:.2f}):-3"
            )
        else:
            score -= 10
            penalties.append(f"conf_danger_zone({conf:.2f}):-10")
    elif conf < 0.60:
        # 42.7% WR, ~flat avgPnL
        score -= 3
        penalties.append(f"conf_low({conf:.2f}):-3")

    edge_wr = _effective_forward_wr_ratio(pick)
    edge_trades = _effective_forward_trades(pick)
    if conf > SMART_PICKS_MAX_CONFIDENCE:
        if edge_trades == 0 and not _is_verified_pm_or_copy_pick(pick):
            score -= 30
            penalties.append(f"overconfident_no_history({conf:.2f}):-30")
        elif edge_trades >= 10 and edge_wr >= 0.60:
            penalties.append(f"overconfident_but_proven({conf:.2f}):+0")
        else:
            score -= 12
            penalties.append(f"overconfident_unproven({conf:.2f}):-12")

    # Technical alignment must be evaluated against trade direction.
    # DATA UPDATE 2026-04-03: Dashboard analysis shows tech_alignment penalty
    # averages -17.3 pts but picks receiving it still win 59.8% of the time.
    # Penalties were too harsh — reduced to avoid over-penalizing winning picks.
    tech_bucket = _technical_alignment_bucket(pick)
    if tech_bucket == "full_support":
        score += 10
        penalties.append("tech_full_support:+10")
    elif tech_bucket == "strong_support":
        score += 6
        penalties.append("tech_strong_support:+6")
    elif tech_bucket == "weak_support":
        score -= 3
        penalties.append("tech_weak_support:-3")
    elif tech_bucket == "no_support":
        score -= 8
        penalties.append("tech_no_support:-8")
    elif tech_bucket == "weak_opposition":
        score -= 8
        penalties.append("tech_weak_opposition:-8")
    elif tech_bucket == "strong_opposition":
        score -= 12
        penalties.append("tech_strong_opposition:-12")

    wf_verdict = _wf_verdict(pick)
    # 2026-04-05: Rebalanced from 3500-pick forensic. wf_verdict is STRONGEST
    # discrete signal (Spearman -0.132 on p_value, r=+0.173 on forward_wr).
    # Data: ELITE=94% WR (n=16), STRONG=77% WR (n=64), VIABLE=56% WR (n=1132),
    # FAILING=39% WR (n=1736). Previous lumped ELITE+STRONG at +8 underweighted ELITE.
    if wf_verdict == "ELITE":
        score += 18  # 94% WR - preserve the 48pp edge over baseline
        penalties.append("wf_elite:+18")
    elif wf_verdict == "STRONG":
        score += 12  # 77% WR - 31pp edge
        penalties.append("wf_strong:+12")
    elif wf_verdict == "VIABLE":
        score += 4  # 56% WR - 10pp edge
        penalties.append("wf_viable:+4")
    elif wf_verdict in {"DECAYING", "WEAK", "WARNING"}:
        score -= 10
        penalties.append(f"wf_{wf_verdict.lower()}:-10")
    elif wf_verdict in {"FAILING", "REJECTED", "BROKEN"}:
        score -= 20
        penalties.append(f"wf_{wf_verdict.lower()}:-20")

    if _has_direction_conflict(pick):
        score -= 12
        penalties.append("direction_conflict:-12")

    # Only trust the kill flag when other live evidence also looks bad.
    if pick.get("_killed_strategy") and wf_verdict in {"FAILING", "REJECTED", "BROKEN"}:
        score -= 10
        penalties.append("corroborated_killed_strategy:-10")

    # Health at entry: panic = 24% WR (889 trades), caution = 60% WR
    # v101: -8 was too soft — panic picks lose 76% of the time
    health = str(pick.get("health_at_entry", "") or "").lower()
    if health == "panic":
        score -= 30
        penalties.append("health_panic:-30")
    elif health == "caution":
        score += 5
        penalties.append("health_caution:+5")

    # Volume ratio: 1.5-2.0x is the only profitable bucket; spikes >2x are bad
    vol_ratio = _float(pick.get("volume_ratio", 0))
    if 1.5 <= vol_ratio <= 2.0:
        score += 5
        penalties.append(f"vol_sweetspot({vol_ratio:.1f}):+5")
    elif vol_ratio > 3.0:
        score -= 5
        penalties.append(f"vol_spike({vol_ratio:.1f}):-5")

    # Age penalty — DATA CORRECTED 2026-04-01:
    # Portfolio A lesson: stale picks LOSE. ADAUSDT SHORT from 12h+ old data hit SL.
    # Fresh picks (<6h) are dramatically better than stale ones.
    # Aggressive age penalty for crypto — prices move fast.
    created = (
        pick.get("created_at") or pick.get("timestamp") or pick.get("generated_at")
    )
    if created:
        age_hours = _calculate_age_hours(created)
        asset_class = str(pick.get("asset_class", "CRYPTO")).upper()
        if asset_class in {"FOREX", "EQUITY", "COMMODITY", "FUTURES"}:
            max_age = NON_CRYPTO_MAX_AGE_HOURS
            if age_hours > max_age:
                score -= 25
                penalties.append(f"stale({age_hours:.0f}h):-25")
            elif age_hours > max_age * 0.75:
                score -= 10
                penalties.append(f"aging({age_hours:.0f}h):-10")
        else:
            # Crypto: much more aggressive age penalty
            if age_hours > 48:
                score -= 35
                penalties.append(f"crypto_very_stale({age_hours:.0f}h):-35")
            elif age_hours > 24:
                score -= 25
                penalties.append(f"crypto_stale({age_hours:.0f}h):-25")
            elif age_hours > 12:
                score -= 15
                penalties.append(f"crypto_aging({age_hours:.0f}h):-15")
            elif age_hours > 6:
                score -= 8
                penalties.append(f"crypto_warming({age_hours:.0f}h):-8")
            elif age_hours < 2:
                score += 5
                penalties.append(f"crypto_fresh({age_hours:.0f}h):+5")

    # ASSET CLASS TRUST BONUS — DATA 2026-04-04 (attribution_tracker on 1200 closed picks):
    # EQUITY 67.2% WR, FOREX 55.7%, CRYPTO 49.8% — route picks toward proven classes.
    # Corrects under-allocation: 43 active CRYPTO vs 2 EQUITY despite EQUITY PF 2.17.
    _ac_bonus = ASSET_CLASS_BONUSES.get(_asset_class, 0)
    if _ac_bonus != 0:
        score += _ac_bonus
        penalties.append(f"asset_class({_asset_class}):{_ac_bonus:+d}")

    # Copy-trader staleness penalty (2026-04-04 antigrav-dash-integrity P1 request):
    # copy_trader_intel/highscore/clones ingestion dead 7 days (last_signal=2026-03-28).
    # Penalize picks where last_signal_at exceeds 72h threshold.
    _last_signal = pick.get("last_signal_at") or pick.get("last_signal")
    _source_sys = str(pick.get("source_system", pick.get("source", "")) or "").lower()
    if _last_signal and ("copy_trader" in _source_sys or "copytrader" in _source_sys):
        _signal_age_hrs = _calculate_age_hours(_last_signal)
        if _signal_age_hrs > 168:  # 7 days
            score -= 35
            penalties.append(f"copytrader_dead_signal({_signal_age_hrs:.0f}h):-35")
        elif _signal_age_hrs > 72:  # 3 days
            score -= 20
            penalties.append(f"copytrader_stale_signal({_signal_age_hrs:.0f}h):-20")

    # Trust penalties
    trust_label = str(pick.get("trust_label", "") or "").upper()
    if trust_label == "AVOID":
        score -= 20
        penalties.append("trust_AVOID:-20")
    elif trust_label == "LOW":
        score -= 10
        penalties.append("trust_LOW:-10")

    trust_tier = _trust_tier(pick)
    if trust_tier == "BANNED":
        score -= 25
        penalties.append("tier_BANNED:-25")
    elif trust_tier == "AVOID":
        score -= 15
        penalties.append("tier_AVOID:-15")

    # Blocked asset/strategy pairs get penalty
    asset_class = str(pick.get("asset_class", "CRYPTO")).upper()
    source = pick.get("source_system", pick.get("source", ""))
    if (asset_class, str(source)) in BLOCKED_ASSET_SOURCE_PAIRS:
        score -= 20
        penalties.append("blocked_source:-20")
    if (asset_class, str(strategy)) in BLOCKED_ASSET_STRATEGY_PAIRS:
        score -= 20
        penalties.append("blocked_strategy:-20")

    # Concentration penalty
    # 2026-04-05: Exempt per-symbol ensemble stacks from the generic
    # concentration penalty. Strategies like ml_enhanced_APEUSDT_1d_B_ensemble_stack
    # are DESIGNED to be single-symbol by architecture — penalizing them
    # for concentration is triple-counting (they already carry their own
    # strategy_concentration_multiplier=0.25 in source score breakdown).
    _strat_lower = str(strategy or "").lower()
    _is_per_symbol_stack = "_ensemble_stack" in _strat_lower and (
        "ml_enhanced_" in _strat_lower or "per_symbol_" in _strat_lower
    )
    conc_penalty = 0 if _is_per_symbol_stack else _concentration_penalty(pick)
    if conc_penalty > 0:
        score -= conc_penalty
        penalties.append(f"concentration:-{conc_penalty:.0f}")
    elif _is_per_symbol_stack:
        penalties.append("per_symbol_stack_exempt(+0)")

    # ── FORWARD-TEST VIABILITY BONUS (2026-04-10 audit) ──
    # Only 5/23 strategies viable in forward testing - boost the proven ones
    strategy_lower = str(strategy).lower()
    for viable_strat, viable_bonus in _VIABLE_STRATEGIES_FORWARD.items():
        if viable_strat in strategy_lower:
            score += viable_bonus
            penalties.append(f"forward_viable({viable_strat}):+{viable_bonus}")
            break
    
    # Demote non-viable strategies
    for demoted_strat in _DEMOTED_STRATEGIES_FORWARD:
        if demoted_strat in strategy_lower:
            score -= 25
            penalties.append(f"forward_demoted({demoted_strat}):-25")
            break

    # ── DATA-DRIVEN SCORING (from closed-pick correlation analysis) ──

    # 1. SOURCE SYSTEM PERFORMANCE (strongest predictor: source determines WR)
    source = str(pick.get("source_system", pick.get("source", "")) or "").lower()
    source_bonus = _SOURCE_SYSTEM_SCORES.get(source, 0)
    if source_bonus > 0:
        score += source_bonus
        penalties.append(f"proven_source({source}):+{source_bonus}")
    elif source_bonus < 0:
        score += source_bonus
        penalties.append(f"weak_source({source}):{source_bonus}")

    # 2. STRATEGY PERFORMANCE (second strongest predictor)
    strategy_l = str(strategy or "").lower()
    strat_bonus = _STRATEGY_SCORES.get(strategy_l, 0)
    if not strat_bonus:
        # Partial match for strategy families
        for pattern, bonus in _STRATEGY_FAMILY_SCORES.items():
            if pattern in strategy_l:
                strat_bonus = bonus
                break
    if strat_bonus > 0:
        score += strat_bonus
        penalties.append(f"proven_strat:+{strat_bonus}")
    elif strat_bonus < 0:
        score += strat_bonus
        penalties.append(f"weak_strat:{strat_bonus}")

    if strategy_l not in _KILLED_STRATEGIES_LOWER:
        _roll_d = _ROLLING_7D_DEGRADE_LOWER.get(strategy_l)
        if _roll_d:
            score += _roll_d
            penalties.append(f"rolling_7d_degrade({_roll_d:+d})")

    # 3. TRUST SCORE — DATA CORRECTED 2026-04-03 (1000 closed dashboard picks):
    #   Trust 1-3 = 38.0% WR, Trust 4-5 = 57.6% WR, Trust 6-7 = 76.9% WR
    #   Trust is the strongest single predictor (39pp spread). Low trust = penalty.
    trust_score = _float(pick.get("trust_score", 0))
    if trust_score >= 6:
        trust_bonus = min(15, int(trust_score * 2.0))
        score += trust_bonus
        penalties.append(f"trust_high({trust_score:.0f}):+{trust_bonus}")
    elif trust_score >= 4:
        trust_bonus = min(10, int(trust_score * 1.5))
        score += trust_bonus
        penalties.append(f"trust_mid({trust_score:.0f}):+{trust_bonus}")
    elif trust_score > 0:
        # REDUCED -15 → -10: trust_label "LOW" already applies -10 for the
        # same picks, creating a -35 total stack (trust_LOW + trust_low + long_low_trust_combo)
        # that kills any pick starting under score ~85.  -10 keeps the signal
        # meaningful (-30 max stack) without being devastating.
        score -= 10
        penalties.append(f"trust_low({trust_score:.0f}):-10")

    # LONG + CONFIDENCE COMBO PENALTIES — DATA 2026-04-03 + codebuff analysis:
    #   LONG + conf 0.80-0.89 = 50% WR (fine, no penalty)
    #   LONG + conf 0.90+ = 19.5% WR (TOXIC — worse than coin flip)
    #   LONG + conf 0.60-0.69 = 31.3% WR on 182 picks (dead zone for LONGs)
    #   LONG + trust 0-3 = 36.2% WR on 506 picks (biggest volume loser)
    direction = str(pick.get("direction", "") or "").upper()
    if direction in ("LONG", "BUY") and conf >= 0.90:
        score -= 25
        penalties.append(f"long_overconf_combo({conf:.2f}):-25")
    elif direction in ("LONG", "BUY") and 0.60 <= conf < 0.70:
        if _equity_forward_proven_mitigates_conf_deadzone(pick):
            penalties.append(
                f"long_deadzone_exempt_equity_forward_proven(conf={conf:.2f}):+0"
            )
        else:
            score -= 12
            penalties.append(f"long_deadzone_combo({conf:.2f}):-12")

    # LONG + LOW TRUST combo — 36.2% WR on 506 picks
    if direction in ("LONG", "BUY") and 0 < trust_score <= 3:
        score -= 10
        penalties.append(f"long_low_trust_combo(trust={trust_score:.0f}):-10")

    # 5. SYMBOL+DIRECTION EDGE — DATA 2026-04-03 (1000 closed picks):
    #    Certain symbols have strong directional bias (e.g., LTCUSDT LONG 92% WR,
    #    XMR LONG 0% WR). Apply bonuses/penalties based on proven track record.
    symbol = str(pick.get("symbol", "") or "").upper()
    sym_dir_key = (symbol, direction)
    sym_dir_bonus = SYMBOL_DIRECTION_BONUSES.get(sym_dir_key, 0)
    if sym_dir_bonus != 0:
        score += sym_dir_bonus
        penalties.append(f"sym_dir({symbol}_{direction}):{sym_dir_bonus:+d}")

    # 6. STRATEGY+SYMBOL COMBO EDGE — DATA 2026-04-03:
    #    Some strategies work brilliantly on specific symbols but fail on others.
    strat_sym_key = (strategy, symbol)
    strat_sym_bonus = STRATEGY_SYMBOL_BONUSES.get(strat_sym_key, 0)
    if strat_sym_bonus != 0:
        score += strat_sym_bonus
        penalties.append(f"strat_sym({strategy[:20]}_{symbol}):{strat_sym_bonus:+d}")

    # 6b. PROVEN SYMBOL BOOSTS (T1-D, 2026-04-15)
    #    Top symbols with WR >= 50% and n >= 20. Nudges picks over gate thresholds.
    #    Cap: score cannot exceed 100 after boost.
    #    Skip when a SYMBOL_DIRECTION_BONUS already applies (direction-specific edge
    #    overrides generic proven boost; avoids double-boosting or partial penalty undo).
    _proven_boost = PROVEN_SYMBOL_BOOSTS.get(symbol, 0)
    if _proven_boost != 0 and sym_dir_bonus == 0:
        score = min(100, score + _proven_boost)
        penalties.append(f"proven_symbol({symbol}):{_proven_boost:+d}")

    # 7. REGIME DRIFT DETECTION — DATA 2026-04-04 (regime analysis):
    #    ml_enhanced_stack: BTC 14% WR vs ALT 51% WR (37pp gap) ÔåÆ block BTC
    #    ml_enhanced_lightgbm: LONG 49% vs SHORT 68% (19pp gap) ÔåÆ prefer SHORT
    #    ml_enhanced_lightgbm LONG: 71% ÔåÆ 42% decline (regime ended)
    strat_lower = str(strategy or "").lower()
    if "ml_enhanced_stack" in strat_lower and symbol == "BTCUSDT":
        score -= 25
        penalties.append("ml_stack_btc_regime_broken:-25")
    if "ml_enhanced_lightgbm" in strat_lower and direction in ("LONG", "BUY"):
        score -= 15
        penalties.append("ml_lightgbm_long_degraded:-15")
    if "ml_enhanced_lightgbm" in strat_lower and direction in ("SHORT", "SELL"):
        score += 10
        penalties.append("ml_lightgbm_short_edge:+10")

    # 7a. CONSENSUS PERCENTAGE — DATA 2026-04-03 (2109 closed picks):
    #   consensus_pct < 0.67 = 12.2% WR (589 picks) — death zone
    #   consensus_pct = 1.0 = 32.2% WR — better but still below average
    #   The specific strategy COMBINATION matters more than raw agreement count.
    _consensus_pct = _float(pick.get("consensus_pct", 0))
    if 0 < _consensus_pct < 0.67:
        score -= 10
        penalties.append(f"consensus_death_zone({_consensus_pct:.2f}):-10")

    # 7b. METHOD A GRADE — DATA 2026-04-03 (2109 closed picks):
    #   INVERTED relationship: Grade F = 76.5% WR, Grade D = 45.1%, Grade B = 14.3%
    #   This is because method_a penalizes contrarian strategies which actually win.
    #   Don't use method_a_grade for scoring since it's anti-predictive in this system.
    #   Instead, use method_a_score >= 80 as a positive signal (42.8% WR vs 20.4%)
    _method_a = _float(pick.get("method_a_score", 0))
    if _method_a >= 80:
        score += 8
        penalties.append(f"method_a_strong({_method_a:.0f}):+8")

    # 7c. TOXIC STRATEGY COMBINATIONS — DATA 2026-04-03 (2109 closed picks):
    #   Specific 3-strategy combos have extreme WR. The composition of strategies_agreed
    #   matters more than the count.
    _strats_agreed = str(pick.get("strategies_agreed", "") or "")
    if "proven_propfirm" in _strats_agreed and "proven_triple_ema" in _strats_agreed:
        # This combo = 1.7% WR on 481 picks — toxic
        score -= 15
        penalties.append("toxic_strat_combo(propfirm+triple_ema):-15")
    elif (
        "corr_hma_trend" in _strats_agreed and "fear_greed_contrarian" in _strats_agreed
    ):
        # This combo = 70.6% WR on 34 picks — golden
        score += 10
        penalties.append("golden_strat_combo(hma+fgc):+10")

    # 4. MULTI-SOURCE CONSENSUS
    # Cross-run analysis shows raw agreement count is noisy by itself. Consensus
    # only deserves meaningful credit when the underlying strategy actually has
    # decent forward edge.
    agreement = _float(pick.get("agreement_count", 0))
    source_systems = pick.get("source_systems", [])
    if isinstance(source_systems, str):
        source_systems = [s.strip() for s in source_systems.split(",") if s.strip()]
    n_sources = max(len(source_systems), int(agreement))
    proven_edge = edge_trades >= 10 and edge_wr >= 0.55
    decent_edge = edge_trades >= 5 and edge_wr >= 0.50
    weak_edge = edge_trades >= 10 and 0 < edge_wr < 0.35
    if n_sources >= 5:
        if weak_edge:
            score -= 10
            penalties.append(
                f"crowded_consensus_weak_edge({n_sources}|{edge_wr:.0%}):-10"
            )
        elif proven_edge:
            score += 6
            penalties.append(f"crowded_consensus_proven({n_sources}):+6")
        else:
            score += 2
            penalties.append(f"crowded_consensus_unproven({n_sources}):+2")
    elif n_sources >= 3:
        if weak_edge:
            score -= 6
            penalties.append(f"multi_consensus_weak_edge({n_sources}|{edge_wr:.0%}):-6")
        elif decent_edge:
            score += 5
            penalties.append(f"multi_consensus_proven({n_sources}):+5")
        else:
            # v101: 2-4 strategy consensus WITHOUT proven edge is the WORST WR bucket (14.6%)
            # Data shows U-shaped curve: 0 strats (46.2% WR) and 5+ strats (44.7%) beat 3-4 strats (14.6%)
            score -= 5
            penalties.append(f"consensus_dead_zone({n_sources}):-5")
    elif n_sources == 2:
        if weak_edge:
            score -= 3
            penalties.append(f"dual_source_weak_edge({edge_wr:.0%}):-3")
        elif decent_edge:
            score += 3
            penalties.append("dual_source_proven:+3")
        else:
            score += 1
            penalties.append("dual_source_unproven:+1")

    # 4b. NULL-ML + SINGLE-SOURCE PENALTY (2026-04-05 claude-bus-setup, P0-A fix)
    # Mirrors smart_picks_engine._compute_ml_composite fallback penalty at the
    # dashboard-aggregation path. Picks arriving from upstream aggregators
    # (alpha_engine, super_signals, ml_crypto_pred) bypass smart_picks_engine and
    # the ml_null penalty never fires. Result: 104/106 picks score=120 with
    # null ml_composite_score (observed on 2026-04-05 01:17Z payload).
    # Fix: apply score cap when BOTH ml_score is None AND single-source.
    # Multi-source picks are exempt — confluence IS their edge signal.
    #
    # 2026-04-14: goldmine_stocks — consensus/avg_score ARE the ML signal; applying
    # null_ml_solo_source when ml_composite_score is not yet merged duplicates a
    # timing bug. Exempt (consensus row is not "missing ML").
    _skip_null_ml_penalty = str(pick.get("source_system") or "").lower() == "goldmine_stocks"
    if not _skip_null_ml_penalty:
        _ml = pick.get("ml_score")
        _ml_comp = pick.get("ml_composite_score")
        if (_ml is None or _float(_ml) <= 0) and (
            _ml_comp is None or _float(_ml_comp) <= 0
        ):
            if n_sources < 2:
                score -= 20
                penalties.append(f"null_ml_solo_source({n_sources}):-20")
            elif n_sources < 3:
                # Dual-source with null ml gets a smaller demotion
                score -= 8
                penalties.append(f"null_ml_dual_source:-8")
            # n_sources >= 3 with null ml: confluence carries, no extra penalty

    # 5. TECHNICAL BIAS ALIGNMENT (58.8% WR aligned vs 43.1% misaligned)
    direction = str(pick.get("direction", pick.get("signal_type", "")) or "").upper()
    tech_verdict = str(pick.get("technical_verdict", "") or "").upper()
    htf_bias = str(pick.get("htf_bias", "") or "").upper()
    bias = htf_bias or tech_verdict
    if bias and direction:
        bullish_bias = bias in ("BULL", "BULLISH", "BUY", "STRONG BUY", "STRONG_BUY")
        bearish_bias = bias in ("BEAR", "BEARISH", "SELL", "STRONG SELL", "STRONG_SELL")
        if (direction in ("LONG", "BUY") and bullish_bias) or (
            direction in ("SHORT", "SELL") and bearish_bias
        ):
            score += 8
            penalties.append("htf_aligned:+8")
        elif (direction in ("LONG", "BUY") and bearish_bias) or (
            direction in ("SHORT", "SELL") and bullish_bias
        ):
            score -= 8
            penalties.append("htf_misaligned:-8")

    # 6. OVERFITTING PENALTY (forward_wr r=-0.49 with PnL — high backtest WR = worse live)
    fwd_wr = edge_wr
    fwd_trades = edge_trades
    if fwd_wr > 0.75 and fwd_trades < 20:
        score -= 10
        penalties.append(f"overfit_risk(wr={fwd_wr:.0%},n={fwd_trades:.0f}):-10")
    elif fwd_wr > 0 and fwd_trades >= 20 and fwd_wr >= 0.50:
        # Genuine track record with enough trades — small bonus
        score += 5
        penalties.append(f"proven_track(wr={fwd_wr:.0%},n={fwd_trades:.0f}):+5")

    # 6a. HF THRESHOLD A — BT vs forward decay (user-approved 2026-04-04)
    # Requires bt_win_rate on pick (dashboard join from strategy leaderboard /
    # survivor BT). Skips when missing — no penalty for unknown BT.
    _bt_win = pick.get("bt_win_rate")
    if decay_hard_gate_triggers(_bt_win, edge_wr, edge_trades):
        pick["_hf_threshold_a"] = True
        score -= 45
        _bt_disp = normalize_wr_percent(_bt_win)
        _fwd_disp = normalize_wr_percent(edge_wr)
        _bt_s = ("%.1f" % _bt_disp) if _bt_disp is not None else "?"
        _fwd_s = ("%.1f" % _fwd_disp) if _fwd_disp is not None else "?"
        penalties.append(
            "hf_decay_gate_A(bt=%s%%,fwd=%s%%,n=%d):-45" % (_bt_s, _fwd_s, edge_trades)
        )

    # 7. DIRECTION BIAS — DATA CORRECTED 2026-04-01:
    # Closed analysis: SHORT 50.3% WR (+0.19% avg) vs LONG 43.6% (+0.06% avg)
    # SHORT+highConf+tightRR = 80.0% WR (best combo). Remove SHORT penalty.
    if direction in ("SHORT", "SELL"):
        # SHORT outperforms LONG by 8pp (56.7% vs 48.7%) across ALL trust/conf buckets
        score += 5
        penalties.append("short_base_bonus:+5")
        # Extra boost if tight R:R + high confidence (golden combo: 80% WR)
        if rr <= 1.5 and rr > 0 and conf >= 0.70:
            score += 8
            penalties.append("short_golden_combo:+8")

    # 8. TRADE MODE — SCALP ELIMINATED (24.8% WR across 855 trades = biggest WR drag)
    # Data: SWING +0.013% avg (only profitable mode), SCALP -0.171%, POSITION 0% WR
    mode = str(pick.get("mode", pick.get("trade_mode", "")) or "").upper()
    if mode == "SCALP":
        score -= 40  # Effectively kills SCALP (was -25, now -40 to guarantee bottom)
        penalties.append("scalp_killed:-40")
    elif mode == "POSITION":
        score -= 30  # 0% WR on 13 trades
        penalties.append("position_killed:-30")
    elif mode == "SWING":
        score += 5
        penalties.append("swing_mode:+5")

    # 9. STRATEGY FORWARD WR (strongest Q1->Q4 spread: 19.1% -> 56.2%)
    # KiloCode analysis: strategy_fwd_wr has the largest WR spread of any metric
    strat_fwd_wr = max(
        _ratio(pick.get("strat_fwd_wr")),
        _ratio(pick.get("strategy_fwd_wr")),
        _ratio(pick.get("forward_wr")),
    )
    strat_fwd_trades = max(
        _float(pick.get("strat_fwd_trades", 0)),
        _float(pick.get("strategy_fwd_trades", 0)),
        _float(pick.get("forward_trades", 0)),
    )
    if strat_fwd_wr >= 0.60 and strat_fwd_trades >= 10:
        score += 12
        penalties.append(
            f"strat_wr_proven({strat_fwd_wr:.0%}/{strat_fwd_trades:.0f}t):+12"
        )
    elif strat_fwd_wr >= 0.50 and strat_fwd_trades >= 5:
        score += 6
        penalties.append(
            f"strat_wr_decent({strat_fwd_wr:.0%}/{strat_fwd_trades:.0f}t):+6"
        )
    elif strat_fwd_wr > 0 and strat_fwd_wr < 0.35 and strat_fwd_trades >= 10:
        score -= 10
        penalties.append(
            f"strat_wr_poor({strat_fwd_wr:.0%}/{strat_fwd_trades:.0f}t):-10"
        )

    # 10. Multi-timeframe support breadth, made direction-aware.
    tech_buy_tfs = _int(pick.get("technical_buy_tfs", 0))
    tech_sell_tfs = _int(pick.get("technical_sell_tfs", 0))
    supporting_tfs = tech_buy_tfs if direction in ("LONG", "BUY") else tech_sell_tfs
    if supporting_tfs >= 3:
        score += 8
        penalties.append(f"multi_tf_support({supporting_tfs}tf):+8")
    elif supporting_tfs == 2:
        score += 4
        penalties.append("multi_tf_support(2tf):+4")
    elif supporting_tfs == 0 and tech_bucket in {"no_support", "strong_opposition"}:
        score -= 6
        penalties.append("multi_tf_support_missing:-6")

    # Legacy bonuses
    if _has_strong_audited_pm_history(pick):
        score += AUDITED_PM_SCORE_BONUS
        penalties.append(f"audited_pm:+{AUDITED_PM_SCORE_BONUS}")

    verified_bonus = _verified_pm_or_copy_bonus(pick)
    if verified_bonus:
        score += verified_bonus
        penalties.append(f"verified_source:+{verified_bonus}")

    if strategy in PROVEN_INVERSE_STRATEGIES:
        score += 10
        penalties.append("proven_inverse:+10")

    # Backtest-validated strategy bonus (970-run case study 2026-04-04)
    _bt_bonus = 0
    for _bt_key, _bt_val in BACKTEST_VALIDATED_STRATEGIES.items():
        if _bt_key in strategy_l:
            _bt_bonus = _bt_val
            break
    if _bt_bonus > 0:
        score += _bt_bonus
        penalties.append(f"backtest_validated({strategy_l[:25]}):+{_bt_bonus}")

    # Symbol-Aware Track Record (SAG) - MANDATORY FOR TRUST (2026-03-29 upgrade)
    sym_track_wr = pick.get("sym_track_wr")
    sym_track_total = _int(pick.get("sym_track_total", 0))
    if sym_track_wr is not None and sym_track_total >= 3:
        if sym_track_wr < 45:
            score -= 35  # Heavy penalty for proven losers on this symbol
            penalties.append(f"bad_sym_track({sym_track_wr}%):-35")
        elif sym_track_wr >= 45 and sym_track_wr < 55:
            score -= 10
            penalties.append(f"mediocre_sym_track({sym_track_wr}%):-10")
        elif sym_track_wr >= 65:
            score += 15
            penalties.append(
                f"proven_sym_track({sym_track_wr}%/n={sym_track_total}):+15"
            )

    # Mercury 2 quality flag penalty
    m2_flags = pick.get("quality_flags", [])
    if isinstance(m2_flags, list) and m2_flags:
        flag_penalty = min(len(m2_flags) * 5, 15)  # -5 per flag, max -15
        score -= flag_penalty
        penalties.append(f"m2_quality_flags:-{flag_penalty}")

    # Meta-labeler filter (Lopez de Prado): P(profitable) score from ML model
    # Picks with meta_label_score < 0.60 are predicted unprofitable by the secondary model
    meta_score = _float(pick.get("meta_label_score", 0))
    if meta_score > 0:
        if meta_score >= 0.75:
            score += 10  # High confidence from meta-labeler
            penalties.append(f"meta_label_high({meta_score:.2f}):+10")
        elif meta_score >= 0.60:
            score += 5
            penalties.append(f"meta_label_ok({meta_score:.2f}):+5")
        elif meta_score < 0.40:
            score -= 15  # Meta-labeler says this pick is likely unprofitable
            penalties.append(f"meta_label_reject({meta_score:.2f}):-15")

    # Track record bonus (98% NULL but +97% WR spread when populated)
    track_record = _float(
        pick.get("track_record", pick.get("sb_strategy_track_record", 0))
    )
    if track_record > 0:
        if track_record >= 80:
            score += 12
            penalties.append(f"track_record_elite({track_record:.0f}):+12")
        elif track_record >= 60:
            score += 8
            penalties.append(f"track_record_good({track_record:.0f}):+8")
        elif track_record < 30:
            score -= 10
            penalties.append(f"track_record_poor({track_record:.0f}):-10")

    # ── QUANT PLAN SCORING ENHANCEMENTS (Mar 31, 2026) ──
    # Based on 1886 closed pick DNA, inverse analysis, and statistical validation.
    # All picks stay visible — better picks get higher scores.

    # Q1. INVERSE STRATEGY DETECTION: strategies with <30% WR on LONGs
    # Data: quan_engine LONG 29% WR (387 trades), ml_crypto_predictor LONG 0% WR (41)
    # If a strategy is a known bad LONG predictor, heavily penalize LONG picks from it
    _INVERSE_LONG_PENALTIES = {
        "ml_crypto_predictor": -20,  # 0% WR on LONGs (41 trades)
        "quan_engine": -15,  # 29% WR on LONGs (387 trades)
        "atr_regime_rsi": -12,  # 23% WR on LONGs (26 trades)
        "ensemble": -10,  # 24% WR on LONGs (45 trades)
        "enhanced_ml_a_xgboost": -10,  # 29% WR on LONGs (24 trades)
        "macd_crossover": -10,  # 25% WR on LONGs (8 trades)
    }
    if direction in ("LONG", "BUY"):
        for inv_strat, inv_penalty in _INVERSE_LONG_PENALTIES.items():
            if inv_strat in strategy_l:
                score += inv_penalty
                penalties.append(f"inverse_long_trap({inv_strat}):{inv_penalty}")
                break

    # Q2. KELLY-INSPIRED CONFIDENCE BONUS: picks with optimal params get boosted
    # Data: confidence 70-80% = 64% WR (only profitable band)
    # Data: R:R 1.2-1.5 = 67% WR (best bracket)
    # Combined: if both in optimal range, big boost
    _conf = _float(pick.get("confidence", 0))
    if _conf > 1:
        _conf = _conf / 100  # normalize
    _rr = _float(pick.get("rr", pick.get("rr_ratio", pick.get("risk_reward", 0))))
    if 0.70 <= _conf <= 0.80 and 1.2 <= _rr <= 1.5:
        score += 15  # Golden combo: optimal confidence + optimal R:R
        penalties.append("kelly_golden_combo:+15")
    elif 0.70 <= _conf <= 0.80:
        score += 8  # Confidence in sweet spot
        penalties.append("conf_sweet_spot:+8")
    elif 1.2 <= _rr <= 1.5:
        score += 5  # R:R in sweet spot
        penalties.append("rr_sweet_spot:+5")

    # Q3. TRADE COUNT RELIABILITY BONUS (more data = more trustworthy)
    # Kelly fraction scales with trade count — reflect this in score
    _fwd_trades = max(
        _float(pick.get("strat_fwd_trades", 0)),
        _float(pick.get("strategy_fwd_trades", 0)),
        _float(pick.get("forward_trades", 0)),
    )
    if _fwd_trades >= 200:
        score += 10  # Half-Kelly territory — high trust
        penalties.append(f"trade_count_elite({_fwd_trades:.0f}):+10")
    elif _fwd_trades >= 100:
        score += 7
        penalties.append(f"trade_count_strong({_fwd_trades:.0f}):+7")
    elif _fwd_trades >= 50:
        score += 4
        penalties.append(f"trade_count_decent({_fwd_trades:.0f}):+4")
    elif _fwd_trades < 10 and _fwd_trades > 0:
        score -= 5  # Too few trades to trust
        penalties.append(f"trade_count_thin({_fwd_trades:.0f}):-5")

    # Q4. 100% WR PROVEN COMBO SUPER-BOOST
    # 15 combos with 100% WR across 141 picks — give massive boost when matched
    _100WR_COMBOS = {
        ("ml_crypto_predictor", "FETUSDT", "SHORT"): 25,
        # st_rsi_momentum_confluence combos REMOVED — strategy killed per PEER_INTEL 2026-04-02 (10% WR, -296% PnL)
        ("st_fear_greed_contrarian", "XRPUSDT", "LONG"): 15,
        ("ml_crypto_predictor", "SUIUSDT", "SHORT"): 20,
        ("st_fear_greed_contrarian", "TRXUSDT", "LONG"): 12,
        ("st_fear_greed_contrarian", "DOGEUSDT", "LONG"): 12,
    }
    _sym = str(pick.get("symbol", "") or "").upper()
    for (combo_strat, combo_sym, combo_dir), combo_boost in _100WR_COMBOS.items():
        if combo_strat in strategy_l and combo_sym == _sym and combo_dir == direction:
            score += combo_boost
            penalties.append(
                f"100pct_wr_combo({combo_strat[:20]}+{combo_sym}+{combo_dir}):+{combo_boost}"
            )
            break

    # Q5. REGIME-AWARE DIRECTION PREMIUM (from 1886 pick analysis)
    # SHORT = 68% WR overall, LONG = 36% in extreme fear
    # Scale the premium by how extreme the fear is (use FGI if available)
    _fgi = _float(pick.get("fear_greed", pick.get("fgi", 0)))
    _is_contrarian_strat = "contrarian" in strategy_l or "fear_greed" in strategy_l
    if _fgi > 0 and _fgi < 25:
        _fear_intensity = (25 - _fgi) / 25  # 1.0 at FGI=0, 0.0 at FGI=25
        if direction in ("SHORT", "SELL") and not _is_contrarian_strat:
            _regime_boost = int(12 * _fear_intensity)
            score += _regime_boost
            penalties.append(f"fear_short_premium(fgi={_fgi:.0f}):+{_regime_boost}")
        elif direction in ("LONG", "BUY") and _is_contrarian_strat:
            # Contrarian LONGs in extreme fear = 88.2% WR (best validated edge)
            _contrarian_boost = int(15 * _fear_intensity)
            score += _contrarian_boost
            penalties.append(
                f"fear_contrarian_long(fgi={_fgi:.0f}):+{_contrarian_boost}"
            )
        elif direction in ("LONG", "BUY"):
            _regime_penalty = int(-8 * _fear_intensity)
            score += _regime_penalty
            penalties.append(f"fear_long_penalty(fgi={_fgi:.0f}):{_regime_penalty}")

    # Q5b. SHORT BIAS GATE — bear regime + extreme fear = 1.5x SHORT weight
    # Task from copilot-quant-audit (P1): when BTC<200MA AND FGI<30, weight SHORT picks
    # Rationale: both filters confirm bear regime; SHORT has +8pp edge system-wide, compounds in bear.
    _btc_regime = str(
        pick.get("btc_regime", pick.get("regime_at_entry", "")) or ""
    ).upper()
    _btc_below_200ma = (
        "BEAR" in _btc_regime
        or "DOWN" in _btc_regime
        or _btc_regime == "BEARISH"
        or pick.get("btc_below_200ma") is True
    )
    if _fgi > 0 and _fgi < 30 and _btc_below_200ma and direction in ("SHORT", "SELL"):
        # 1.5x weight realized as +12 score bonus (roughly 50% amplification
        # of the typical SHORT-leg signal score ~24)
        score += 12
        penalties.append(f"short_bias_gate(fgi={_fgi:.0f},btc_bear):+12")

    # Q6. MOMENTUM GAINER PATTERN BONUS (paradigm shift discovery 2026-04-01)
    # Peer analysis of 18 top crypto gainers revealed pumps are preceded by:
    #   RSI ~56 (neutral, NOT oversold), price near upper BB (67%), ATR < 3% (61%),
    #   ADX > 20 (89%), gradual volume increase (not spike).
    # This is the OPPOSITE of mean-reversion signals. Reward momentum/breakout
    # strategies that catch neutral-RSI setups with decent confidence.
    _MOMENTUM_KEYWORDS = ("momentum", "gainer", "breakout", "trend")
    _rsi = _float(pick.get("rsi", pick.get("rsi_14", 0)))
    _strat_lower = strategy.lower()
    if (
        40 <= _rsi <= 60
        and conf >= 0.60
        and direction in ("LONG", "BUY")
        and any(kw in _strat_lower for kw in _MOMENTUM_KEYWORDS)
    ):
        score += 8
        penalties.append(f"gainer_paradigm_bonus(rsi={_rsi:.1f}):+8")

    # Q7. TIME-OF-DAY EDGE (from 2,000 closed pick statistical analysis)
    # Night session 01-05 UTC: 61.1% WR vs 41.2% rest of day
    # Dead zones: 07-08 UTC (26% WR), 17-21 UTC (30% WR)
    # Autocorrelation lag-1 = +0.273 — wins cluster, time-of-day is a real edge.
    _ts_raw = (
        pick.get("created_at") or pick.get("timestamp") or pick.get("generated_at")
    )
    _pick_dt = None
    if _ts_raw:
        try:
            _pick_dt = datetime.fromisoformat(str(_ts_raw).replace("Z", "+00:00"))
        except (ValueError, TypeError):
            _pick_dt = None
    if _pick_dt is not None:
        _utc_hour = _pick_dt.hour
        if 1 <= _utc_hour <= 5:
            score += 6
            penalties.append(f"night_session_edge(h={_utc_hour}):+6")
        elif _utc_hour == 23 or _utc_hour == 0:
            score += 3
            penalties.append(f"late_night_edge(h={_utc_hour}):+3")
        elif 7 <= _utc_hour <= 8:
            score -= 8
            penalties.append(f"dead_zone_morning(h={_utc_hour}):-8")
        elif 16 <= _utc_hour <= 17:
            # DATA 2026-04-03: 16:00=9.1% WR (77 trades), 17:00=16.1% WR (93 trades)
            score -= 15
            penalties.append(f"dead_zone_us_close(h={_utc_hour}):-15")
        elif 18 <= _utc_hour <= 21:
            score -= 6
            penalties.append(f"dead_zone_evening(h={_utc_hour}):-6")

        # Q7b. ASSET-CLASS SPECIFIC SAFETY WINDOWS (Audit 2026-04-05)
        # EQUITY: US Market Open (13-15 UTC) is the institutional edge for stocks.
        # FOREX: London/NY overlap (08-16 UTC) is the high-liquidity alpha peak.
        _ac_val = str(pick.get("asset_class", pick.get("mode", ""))).upper()
        if "EQUITY" in _ac_val or "STOCK" in _ac_val:
            if 13 <= _utc_hour <= 15:
                score += 12
                penalties.append(f"equity_us_open_bonus(h={_utc_hour}):+12")
        elif "FOREX" in _ac_val or "FX" in _ac_val:
            if 8 <= _utc_hour <= 16:
                score += 8
                penalties.append(f"forex_liquidity_bonus(h={_utc_hour}):+8")

        # Penalize "Morning Noise" (06-12 UTC) - Identified as -$125 PnL drain
        if 6 <= _utc_hour <= 12 and not ("EQUITY" in _ac_val or "STOCK" in _ac_val):
            score -= 5
            penalties.append(f"morning_noise_penalty(h={_utc_hour}):-5")

        # Q8. DAY-OF-WEEK EDGE — UPDATED 2026-04-03 (1952 closed picks):
        # Tuesday: 50.5% WR (best, only profitable day)
        # Sunday: 14.2% WR over 281 trades (worst, massively significant)
        _dow = _pick_dt.weekday()  # 0=Monday ... 6=Sunday
        if _dow == 1:  # Tuesday (best day)
            score += 5
            penalties.append("tuesday_edge:50.5%WR:+5")
        elif _dow == 3:  # Thursday
            score += 4
            penalties.append("thursday_edge:61.9%WR:+4")
        elif _dow == 6:  # Sunday — 14.2% WR on 281 trades (2026-04-03 data)
            score -= 12
            penalties.append("sunday_penalty:32.8%WR:-6")
        elif (
            _dow == 4
        ):  # Friday — 41.3% WR on 387 trades (attribution_tracker 2026-04-04)
            # 18.1pp spread vs Wed (59.5% WR). Per attribution_report recommendation.
            # Data source: alpha_engine/data/attribution_report.json (1200 closed picks)
            score -= 9
            penalties.append("friday_penalty:41.3%WR:-9")
        elif _dow == 0:  # Monday
            score -= 3
            penalties.append("monday_penalty:40.8%WR:-3")

    # Q9. MULTI-SYMBOL ROBUSTNESS BONUS — the "super strategy" concept
    # A strategy that profits across 10+ symbols (ALL_SYMBOL tier) is far more
    # trustworthy than one profitable on a single symbol (likely curve-fit).
    # Data: st_fear_greed_contrarian = 69.4% WR across 17/19 symbols (ALL_SYMBOL).
    # SINGLE_SYMBOL strategies with low robustness are unreliable — penalize them.
    _tiers_data = _load_symbol_strength_tiers()
    _tier_details = _tiers_data.get("details", {})
    # Normalize strategy name for lookup (try exact, then lowercase)
    _tier_info = _tier_details.get(strategy) or _tier_details.get(strategy_l) or {}
    _sym_tier = str(_tier_info.get("tier", "")).upper()
    _sym_robustness = _float(_tier_info.get("robustness", 0))
    if _sym_tier == "ALL_SYMBOL":
        score += 12
        penalties.append(f"super_strategy_all_symbol({_sym_robustness:.2f}):+12")
    elif _sym_tier == "MULTI_SYMBOL":
        score += 8
        penalties.append(f"super_strategy_multi_symbol({_sym_robustness:.2f}):+8")
    elif _sym_tier == "FEW_SYMBOL":
        score += 4
        penalties.append(f"super_strategy_few_symbol({_sym_robustness:.2f}):+4")
    elif _sym_tier == "SINGLE_SYMBOL" and _sym_robustness < 0.3:
        score -= 5
        penalties.append(f"single_symbol_fragile({_sym_robustness:.2f}):-5")

    # Q10. MOVE EXHAUSTION PENALTY — Mercury AI item #7
    # Rationale: Entering LONG after a >3% up move = chasing; the asset has already
    # priced in momentum and reversal risk is elevated.  Similarly, entering SHORT
    # after a >3% down move = chasing the dump.  Subtract 10 points to discourage
    # regime-blind entries that ignore recent price displacement.
    _price_chg_24h = _float(pick.get("price_change_24h"))
    if pick.get("price_change_24h") is not None:
        if _price_chg_24h > 3.0 and direction in ("LONG", "BUY"):
            score -= 10
            penalties.append(f"move_exhaustion_long(24h={_price_chg_24h:+.1f}%):-10")
        elif _price_chg_24h < -3.0 and direction in ("SHORT", "SELL"):
            score -= 10
            penalties.append(f"move_exhaustion_short(24h={_price_chg_24h:+.1f}%):-10")

    # Q11. VOLATILITY SPIKE PENALTY — Mercury AI item #7
    # Rationale: When short-term (20d) volatility exceeds 2x the longer-term (60d)
    # baseline, the regime is unstable — wider candles, more stop-loss hunting, and
    # higher probability of SL hits.  Subtract 8 points to reflect the elevated
    # regime risk until volatility normalises.
    _vol_20d = _float(pick.get("volatility_20d"))
    _vol_60d = _float(pick.get("volatility_60d"))
    if (
        pick.get("volatility_20d") is not None
        and pick.get("volatility_60d") is not None
        and _vol_60d > 0
    ):
        if _vol_20d > 2.0 * _vol_60d:
            score -= 8
            penalties.append(
                f"volatility_spike(20d={_vol_20d:.4f}>2x60d={_vol_60d:.4f}):-8"
            )

    # Q12. MERCURY 2 UNIFIED SCORE — FROZEN (p=0.76, pure noise)
    # 46 trades, 39.1% WR, CI includes zero — no statistical significance.
    # All scoring boosts set to 0 until Mercury2 proves edge on fresh data.
    # Original: +6 for score>0.70, -6 for score<0.40, -4 for regime mismatch.
    pass  # Mercury 2 frozen — no scoring impact

    # Q13. STREAK MOMENTUM FILTER — autocorrelation lag-1 = +0.273
    # Rationale: Wins cluster (2,000-pick analysis). After 2 consecutive wins
    # for a strategy, next-pick WR rises ~10pp. Reward hot streaks, penalise cold.
    _streak = _STREAK_CACHE.get(strategy, 0)
    if _streak >= 3:
        score += 12
        penalties.append("streak_momentum:3+_consec_wins:+12")
    elif _streak >= 2:
        score += 8
        penalties.append("streak_momentum:2_consec_wins:+8")
    elif _streak <= -3:
        score -= 8
        penalties.append("cold_streak:3+_consec_losses:-8")

    # Q14. DIRECTION-SPECIFIC LOSER PENALTY
    # Some strategies win in one direction but lose in the other.
    # Data: rsi_overbought is 76% WR overall but only 29% on SHORTs.
    _strat_l = str(pick.get("strategy", pick.get("source", "")) or "").lower()
    _dir_up = str(pick.get("direction", "") or "").upper()
    for (ds_strat, ds_dir), ds_penalty in DIRECTION_SPECIFIC_LOSERS.items():
        if ds_strat.lower() in _strat_l and ds_dir == _dir_up:
            score += ds_penalty
            penalties.append(f"dir_specific_loser({ds_strat}+{ds_dir}):{ds_penalty}")
            break

    # Q15. VOL-OF-VOL FILTER (+0.27 Sharpe) — re-applied after rebase loss
    _atr_current = _float(pick.get("atr_14") or pick.get("atr") or 0)
    _atr_90p75 = _float(pick.get("atr_90d_p75") or 0)
    _fgi_q15 = _float(pick.get("fear_greed") or pick.get("fgi") or 50)
    if _atr_current > 0 and _atr_90p75 > 0 and _fgi_q15 >= 15:
        if _atr_current > _atr_90p75:
            score -= 10
            penalties.append(
                f"vol_of_vol(atr={_atr_current:.4f}>p75={_atr_90p75:.4f}):-10"
            )

    # Q16. EMBEDDED CARRY FILTER (+0.55 Sharpe) — re-applied after rebase loss
    _funding = _float(pick.get("funding_rate") or 0)
    if _funding != 0 and 15 <= _fgi_q15 <= 85:
        if direction in ("LONG", "BUY") and _funding > 0.0025:
            score -= 12
            penalties.append(f"carry_filter_long(funding={_funding:.4f}):-12")
        elif direction in ("SHORT", "SELL") and _funding < -0.0025:
            score -= 12
            penalties.append(f"carry_filter_short(funding={_funding:.4f}):-12")
        elif direction in ("LONG", "BUY") and _funding < -0.0008:
            score += 5
            penalties.append(f"carry_tailwind_long(funding={_funding:.4f}):+5")

    # HARD CAP: verified kill+failing picks cannot reach smart gate threshold.
    # When _killed_strategy=True (set by dashboard_generator from core_whitelist.json)
    # AND walk-forward confirms the strategy is FAILING/REJECTED/BROKEN, the source/
    # strategy static bonuses (+18, +15) must not override the live failure evidence.
    # Cap at 59 so the pick stays in active display (floor=40) but never hits smart
    # picks (Smart min=60). This prevents the 120-cap exploit seen on enhanced_ml_A_xgboost.
    # Data: 16 picks scored 120 from kills+failing strategies in stale payload (2026-04-05).
    if pick.get("_killed_strategy") and wf_verdict in {"FAILING", "REJECTED", "BROKEN"}:
        if score > 59.0:
            penalties.append(
                f"killed_failing_cap(was_{score:.0f}->59):-{score - 59:.0f}"
            )
            score = 59.0

    # ── REALIZED OUTPERFORMANCE RECLAIM (2026-04-05) ──
    # A pick that is ACTUALLY making money deserves to be ranked by its
    # market evidence, not by pre-trade penalties that have been disproven
    # by live P&L. Example caught by user: APEUSDT SHORT at score=0 but
    # +6.02% PnL after 40h — triple-counted concentration + stale penalties
    # zeroed out the score despite the pick being correct.
    #
    # Gates:
    #   - age_hours >= 1.0 prevents new-pick luck inflation
    #   - pnl_pct >= 2.0 prevents noise
    # Scales +2% -> +10, +5% -> +20, +10% -> +30 (capped)
    # Symmetric penalty for realized underperformance at pnl <= -3.0%
    _age_h = _float(pick.get("age_hours") or 0)
    _pnl_pct = _float(pick.get("pnl_pct") or pick.get("unrealized_pnl_pct") or 0)
    if _age_h >= 1.0 and _pnl_pct >= 2.0:
        _reclaim = min(30, int(10 + (_pnl_pct - 2.0) * 2))
        score += _reclaim
        penalties.append(
            f"realized_outperformance(+{_pnl_pct:.1f}%/{_age_h:.0f}h):+{_reclaim}"
        )
    elif _age_h >= 1.0 and _pnl_pct <= -3.0:
        _drain = min(20, int(2 + abs(_pnl_pct + 3.0) * 1.5))
        score -= _drain
        penalties.append(f"realized_underperformance({_pnl_pct:.1f}%):-{_drain}")

    # ── PREFERRED PAIR BONUS (HF-P0 ┬º2.4) ──
    # Whitelisted combos from cross_asset_edge_finder_results.json (Sharpe>=1.8).
    # Rewards empirically vetted (asset_class, strategy, symbol) combos without unbanning
    # whole strategies. +10 matches existing conf_peak/sweet_spot magnitude.
    if _matches_preferred_pair(pick):
        score += PREFERRED_PAIR_BONUS
        penalties.append(f"preferred_pair_edge:+{PREFERRED_PAIR_BONUS}")

    # ── CROSS-ASSET CONFLUENCE BONUS (HF-┬ºextra) ──
    # When the same underlying asset has aligned directional signals from 2+ different
    # asset classes (e.g., BTCUSDT LONG + BITO LONG + BTC1! LONG), apply +8 bonus.
    # _cross_asset_confluence is stamped by _compute_cross_asset_confluence() upstream.
    # Idempotency guard: only apply bonus once per pick, tracked via _cross_asset_bonus_applied.
    _confluence_n = pick.get("_cross_asset_confluence")
    if (
        _confluence_n
        and int(_confluence_n) >= 2
        and not pick.get("_cross_asset_bonus_applied")
    ):
        score += CROSS_ASSET_CONFLUENCE_BONUS
        pick["_cross_asset_bonus_applied"] = True
        penalties.append(
            f"cross_asset_confluence(n={int(_confluence_n)}):+{CROSS_ASSET_CONFLUENCE_BONUS}"
        )

    # Strategy-governance adjustment (kill/deprioritize/probation/overweight).
    if apply_governance_score_adjustment is not None:
        _pf = _float(
            pick.get("strategy_fwd_pf", pick.get("strat_fwd_pf", pick.get("profit_factor", 1.0)))
        )
        _trades = int(
            _float(
                pick.get(
                    "strategy_fwd_trades",
                    pick.get("strat_fwd_trades", pick.get("forward_trades", 0)),
                )
            )
        )
        _new_score, _gov_reason = apply_governance_score_adjustment(
            strategy=strategy,
            score=score,
            trades=_trades,
            profit_factor=_pf if _pf > 0 else 1.0,
        )
        if _new_score != score:
            penalties.append(f"governance({_gov_reason}):{_new_score - score:+.0f}")
            score = _new_score

    # Calibration guardrails (net-loser cap, WR divergence caps, direction-aware trim).
    if apply_score_calibration is not None:
        _cal = apply_score_calibration(pick, score)
        if _cal.adjusted_score != score:
            penalties.append(
                f"calibration({_cal.score_cap_reason or 'adjust'}):{_cal.adjusted_score - score:+.0f}"
            )
            score = _cal.adjusted_score
        pick["score_cap_reason"] = _cal.score_cap_reason
        pick["wr_divergence_flag"] = bool(_cal.wr_divergence_flag)
        pick["calibration_conflict"] = bool(_cal.calibration_conflict)

    # Clamp to 0-120 (scores above 100 = SUPER_PICK — rare, high-conviction)
    score = max(0.0, min(120.0, score))

    # ── SUPER_PICK QUALIFICATION GATE (2026-04-05) ──
    # Previously the 100+ threshold was advisory only. Ml_crypto_pred flood of 14 picks
    # at score=120 with trust=5 and conf=0.78 exposed the gap. Now enforcing a real cap:
    # only picks meeting ALL super criteria can hold scores above 100; others capped at 100.
    # Super requirements: trust>=6, proven strategy track record, conf in sweet spot (0.65-0.84).
    if score > 100:
        _trust_val = _float(pick.get("trust_score") or pick.get("trust") or 0)
        _strat_lower = (strategy or "").lower()
        _qualifies = (
            _trust_val >= 6.0
            and conf >= 0.65
            and conf < 0.85
            and strat_fwd_wr >= 0.55
            and strat_fwd_trades >= 15
        )
        if not _qualifies:
            _old = score
            score = 100.0
            _reasons = []
            if _trust_val < 6.0:
                _reasons.append(f"trust={_trust_val:.0f}<6")
            if conf < 0.65 or conf >= 0.85:
                _reasons.append(f"conf={conf:.2f}_outside_sweet_spot")
            if strat_fwd_wr < 0.55 or strat_fwd_trades < 15:
                _reasons.append(
                    f"unproven_wr={strat_fwd_wr:.0%}_n={strat_fwd_trades:.0f}"
                )
            penalties.append(
                f"super_cap(was_{_old:.0f}->100,{'/'.join(_reasons)}):-{_old - 100:.0f}"
            )

    # ── SUPER_PICK DESIGNATION ──
    # Scores above 100 are extremely rare — every signal must align.
    # These are "once in a blue moon" trades with the highest historical probability.
    # Requirements: score > 100 AND proven strategy AND tight R:R AND high confidence
    is_super = False
    if score > 100:
        is_super = True
        pick["super_pick"] = True
        pick["super_pick_score"] = round(score, 1)
        penalties.append(f"SUPER_PICK(score={score:.0f})")
    elif score >= 85:
        # Near-super: all signals aligned but just below threshold
        # Check if it hits the golden combo: SHORT + highConf + tightRR = 80% WR
        if (
            direction in ("SHORT", "SELL")
            and conf >= 0.70
            and 0 < rr <= 1.5
            and strat_fwd_wr >= 0.55
            and strat_fwd_trades >= 10
        ):
            is_super = True
            score = min(score + 10, 120.0)
            pick["super_pick"] = True
            pick["super_pick_score"] = round(score, 1)
            penalties.append("SUPER_PICK(golden_combo_boost)")

    # ── SAFETY TAG ──
    # Based on historical WR of this strategy+symbol+direction combo.
    # "SAFE" = strategy has >65% WR on this symbol in this direction on 5+ trades.
    # Displayed as a tooltip badge on the dashboard.
    _safety = "UNKNOWN"
    _safety_reason = ""
    _sym_track_wr_val = _float(sym_track_wr) if sym_track_wr is not None else 0
    _sym_track_n = sym_track_total

    if _sym_track_n >= 10 and _sym_track_wr_val >= 70:
        _safety = "SAFE"
        _safety_reason = (
            f"Strategy WR {_sym_track_wr_val:.0f}% on {_sym} over {_sym_track_n} trades"
        )
    elif _sym_track_n >= 5 and _sym_track_wr_val >= 65:
        _safety = "SAFE"
        _safety_reason = (
            f"Strategy WR {_sym_track_wr_val:.0f}% on {_sym} over {_sym_track_n} trades"
        )
    elif strat_fwd_wr >= 0.65 and strat_fwd_trades >= 15:
        _safety = "SAFE"
        _safety_reason = (
            f"Strategy overall WR {strat_fwd_wr:.0%} over {strat_fwd_trades:.0f} trades"
        )
    elif strat_fwd_wr >= 0.55 and strat_fwd_trades >= 20:
        _safety = "LIKELY"
        _safety_reason = (
            f"Strategy WR {strat_fwd_wr:.0%} over {strat_fwd_trades:.0f} trades"
        )
    elif _sym_track_n >= 5 and _sym_track_wr_val < 40:
        _safety = "RISKY"
        _safety_reason = (
            f"Strategy WR {_sym_track_wr_val:.0f}% on {_sym} — poor history"
        )
    elif strat_fwd_wr > 0 and strat_fwd_wr < 0.35 and strat_fwd_trades >= 10:
        _safety = "RISKY"
        _safety_reason = f"Strategy WR {strat_fwd_wr:.0%} overall — low confidence"

    pick["safety"] = _safety
    pick["safety_reason"] = _safety_reason
    if _safety == "SAFE":
        penalties.append(f"safety_SAFE:{_safety_reason[:40]}")
    elif _safety == "RISKY":
        penalties.append(f"safety_RISKY:{_safety_reason[:40]}")

    # Write back
    pick["score"] = round(score, 1)
    pick["_penalties"] = penalties


# ── DATA-DRIVEN LOOKUP TABLES (from closed-pick analysis of 2,256 trades) ──

# ── FORWARD-TEST VIABLE STRATEGIES (2026-04-10 audit) ──
# Only 5 of 23 strategies passed forward testing with correlation > 0.45
# These strategies should receive scoring bonuses (defined early for reference)
# Populated dynamically from forward_test_results.json in production
_VIABLE_STRATEGIES_FORWARD = {
    "funding_rate_arbitrage": 20,      # Grade A, 0.92 correlation
    "pairs_trading_cointegration": 18, # Grade A-, 0.85 correlation
    "betting_against_beta": 18,        # Grade A-, 0.78 correlation
    "flash_crash_reversal": 15,        # Grade B+, 0.45 correlation
    "quality_minus_junk": 15,          # Grade B+, 0.82 correlation
}

# Non-viable strategies that should be demoted (correlation < 0.4)
_DEMOTED_STRATEGIES_FORWARD = {
    # Add strategies with poor forward correlation here
    # These will receive -25 score penalty in _apply_score_penalties
}

# Source systems ranked by historical WR and avg PnL
_SOURCE_SYSTEM_SCORES = {
    # Proven winners (>50% WR, positive PnL, 10+ trades)
    "revival_all": 20,  # 97.8% WR, +2.33% avg PnL
    "ml_crypto_pred": 5,  # DOWNGRADED 18->5 (2026-04-05): live audit 20% green, ejaguiar1 backtest
    # 31.3% WR on LONG. Historical 76.2% WR is stale/overfit.
    # Rolling 7d degradation -28 also applies = effectively negative.
    "kimi_signal_tracking": 12,  # 50.9% WR, +1.67% avg PnL
    "signal_validation": 10,  # 56.6% WR, +0.86% avg PnL
    "ml_crypto_pred_v12": -5,  # DOWNGRADED 5->-5: BLOCKED_SOURCE_SYSTEMS already bans it.
    # Multi-source / consensus
    "prediction_market_consensus": 14,  # UPGRADED 10->14 per claude-paper-tv (2/2 correct today, direct probability > derived)
    "polymarket_signals": 14,  # NEW: claude-paper-tv d252a77925 (2026-04-05)
    "pm_whale_signals": 10,  # NEW: per claude-paper-tv (PM whale intelligence)
    "cross_aggregation": 8,
    # 2026-04-05: Closed-pick analysis on 3017 trades reveals source skew
    "claude_gainer_st": 15,  # UPGRADED 10->15: W:L 2.05x, XRP 73% WR (35/48), drives 3 TV winners today
    "stocks_competition": 15,  # ELITE EQUITY (79.2% WR, PF 3.76, audit 2026-04-05)
    "multi_asset_copytrader": 5,  # ELITE FOREX (55.7% WR, PF 2.17, audit 2026-04-05)
    "goldmine_stocks": 12,  # +1.17% avg PnL, 67% WR on closed (per sector analysis)
    "alpha_engine": -8,  # INCREASED PENALTY -5->-8: 36.4% WR LONG (claude-paper-tv live validation),
    # ejaguiar1 backtest -161K cum. Only SHORT side has edge (66.7% WR n=9).
    # NEW SOURCES from today's TV winners (2026-04-05 lessons learned)
    "tsmom_strategy": 8,  # NEW: KITE SHORT won on ALL 5 books (+2.24 to +8.6%). tsmom_volscaled
    # produced leveraged-inverse-alt SHORTs that captured regime-driven decay.
    "battleground": 8,  # NEW: drove BTC+BNB LONGs (XRPUSDT LONG 80% WR per dashboard, BTC +3.59%)
    "contrarian_consensus": 8,  # NEW: BNBUSDT SHORT +3.96% (biggest single active winner, score was 0!)
    # Underperformers / Drains (penalty)
    "claude_gainer": -50,  # THE CLAUDE TRAP (13.3% WR, -$162 PnL drain)
    "quan_engine": -15,  # 26.1% WR, -0.15% avg PnL, 962 picks. ejaguiar1 backtest confirms: 25% WR -45,611%
    "quan_engine_scalp": -15,  # Same system, dominant volume, drags everything down
    "rocket_scanner": -30,  # 0% WR on 5 live picks. BLOCKED_SOURCE_SYSTEMS already bans it.
    # 2026-04: Over-penalized source — luxalgo_confluence (64.4% WR) gets 0 source bonus
        "luxalgo_filters": 10,  # Powers luxalgo_confluence (64.4% WR, 90 trades, +120.8% PnL)
    # ── 2026-04-15: Missing source_system entries added (edge audit P1 fix) ──
    # Proven winners
    "dna_rapid_fire_mutations": 15,  # 80.0% WR, +1.76% avg PnL, n=10
    "signal_engine_mutations": 12,  # 63.6% WR, +0.96% avg PnL, n=11
    "super_signals": 8,  # 55.7% WR, +0.72% avg PnL, n=122
    "aggregated_picks": 6,  # 50.0% WR, +0.71% avg PnL, n=10
    # Slight positive / large volume
    "kimi_riseoftheclaw": 4,  # 44.7% WR, +0.30% avg PnL, n=273 (huge volume, marginal edge)
    "baby_strats_forward": 2,  # 44.4% WR, +0.01% avg PnL, n=162 (huge volume, flat)
    "dna_winner_picks": 2,  # 41.7% WR, +0.14% avg PnL, n=24
    # Proven losers
    "rapid_fire": -5,  # 40.0% WR, -0.59% avg PnL, n=35
    "non_crypto_consensus": -5,  # 38.9% WR, flat PnL, n=18
    "alpha_engine_fast": -10,  # 39.5% WR, -0.14% avg PnL, n=81
    "cta_replicator": -10,  # 34.0% WR, -0.04% avg PnL, n=50
    "multi_asset_institutional": -15,  # 33.3% WR, -2.23% avg PnL, n=18
    "multi_asset_scanner": -25,  # 16.9% WR, -0.14% avg PnL, n=71
}

# Individual strategies with proven track records
_STRATEGY_SCORES = {
    "enhanced_ml_a_xgboost": -10,  # DOWNGRADED 15->-10 (2026-04-05): 30.2% WR closed, PF 0.65,
    # ejaguiar1 backtest -77K cum on ema9_pullback variant, live 20% green.
    # Rolling 7d degradation -32 also applies. Historical 70.5% WR is stale.
    "st_fear_greed_contrarian": 20,  # UPGRADED 12->20: CROWN JEWEL. 7 of 13 SHARP TOOLS, ejaguiar1 backtest
    # confirms across LTCUSDT(96%WR), BNBUSDT(93%), XRPUSDT(82%), DOTUSDT(77%).
    # Today's TV: drove AVAX+ADA+UNI wins. 524 closed trades, 62% WR.
    # BUG: currently scored at 5 due to score_booster regression (P0 open).
    "copy_hl_whale_24.5m": 12,  # 68.8% WR, +1.44% avg PnL, n=32
    "keltner_compression_expansion": 12,  # UPGRADED 10->12: ejaguiar1 backtest +1,196% cum (149 trades, 64% WR).
    # ETH variant 71% WR +571%. sol variant 58% WR +599%.
    "drawdown_recovery_rsi": 12,  # NEW: drove BTC+XRP+ETH LONG winners today. Dashboard 80% WR on XRP.
    # drawdown_recovery_rsi_eth 61% WR 137 trades +378% in ejaguiar1.
    "justin_breakout_volume_v2": 18,  # NEW: ejaguiar1 KING — 3,550 trades, 74% WR, +8,278% cumulative.
    # TRXUSDT SHORT 79% WR +6,221%. Multi-symbol consistent edge.
    "multi_period_rsi_confluence": 12,  # NEW: ejaguiar1 72% WR 173 trades +401% on BTCUSDT LONG.
    "tsmom_volscaled": 10,  # NEW: KITE SHORT winner on all 5 TV books today (+2-8% each).
    # Leveraged-inverse-alt SHORTs during weak-alt regime.
    "vwap_deviation_reversion": 10,  # NEW: ejaguiar1 62% WR +777% (volfilter variant).
    "st_rsi_vol_bounce": 10,  # NEW: UNIUSDT LONG 92% WR (n=13) per SHARP_TOOLS.
    "irb_hoffman": 8,  # NEW: ejaguiar1 45% WR but +6.04% avg PnL, +664% cum (high avg win).
    "autocorrelation_exploiter": 8,  # NEW: ejaguiar1 100% WR n=30, +12.19% avg. Small sample caveat.
    "momentumema": 8,  # 63.2% WR, +1.06% avg PnL
    "rsi2_bb_squeeze": 8,  # 52.4% WR, +0.010% (only profitable scalp)
    "meanreversionbb": 6,  # 54.4% WR, +0.80% avg PnL
    # 2026-04: Over-penalized winners identified by score-vs-PnL anomaly analysis
    "luxalgo_confluence": 15,  # 64.4% WR, 90 trades, +120.8% cumPnL, avgScore was 37.8
    "strong consensus": 10,  # 56.3% WR, 103 trades, +61.5% cumPnL
    "bollinger mr": 10,  # 53.8% WR, 80 trades, +59.7% cumPnL (source: stocks_competition)
    "stocks_rsi2_pullback": 8,  # 90.0% WR, 10 trades, +12.9% cumPnL
    "donchian-stock-breakout": 8,  # 80.0% WR, 5 trades, +33.3% cumPnL (small n)
        "macd_rsi_confluence": 6,  # 58.3% WR, 12 trades, +8.2% cumPnL
    # ── 2026-04-15: Missing strategy entries added (edge audit P1 fix) ──
    # Proven winners (WR >= 50% + positive PnL)
    "st_obv_support_divergence": 15,  # 70.8% WR, +1.22% avg PnL, n=72
    "markov_zone_transition": 15,  # 76.9% WR, +0.21% avg PnL, n=13
    "rs-breakout-scout": 14,  # 69.2% WR, +1.99% avg PnL, n=13
    "quality-minus-junk": 12,  # 63.6% WR, +0.68% avg PnL, n=22
    "vwap-reversion-scout": 12,  # 60.0% WR, +1.07% avg PnL, n=10
    "fx_smart_carry_trade_momentum": 12,  # 60.0% WR, +0.24% avg PnL, n=10
    "signal_engine_momentum_mut": 12,  # 63.6% WR, +0.96% avg PnL, n=11
    "crypto_mtf_ema_slope_alignment_v1": 12,  # 61.5% WR, +0.36% avg PnL, n=13
    "proven_vwap_mean_reversion": 10,  # 100% WR, +0.32% avg PnL, n=4 (exceptional WR)
    "rapid_momentum_filter_mut": 10,  # 75.0% WR, +1.58% avg PnL, n=8
    "strong consensus (alpha_engine, ml_crypto_pred)": 8,  # 56.3% WR, +0.60% avg PnL, n=103
    "rsi-divergence-scout": 8,  # 53.3% WR, +1.76% avg PnL, n=15
    "forex-rsi-ema-scout": 7,  # 57.1% WR, +0.32% avg PnL, n=14
    "post-earnings-rev-scout": 7,  # 58.3% WR, +0.46% avg PnL, n=12
    "meme-velocity": 6,  # 60.0% WR, +0.59% avg PnL, n=5
    "claude_ml_moderate_mut": 5,  # 50.0% WR, +0.39% avg PnL, n=14
    "forex_rsi2_mean_reversion": 4,  # 48.9% WR, +0.08% avg PnL, n=407 (huge n, marginal edge)
    "breakout momentum": 4,  # 47.9% WR, +0.17% avg PnL, n=71
    "classic momentum": 4,  # 46.7% WR, +0.91% avg PnL, n=30
    "meta learner": 4,  # 46.7% WR, +0.83% avg PnL, n=15 (lowercase variant; 'Meta Learner' in killed)
    # Proven losers (WR < 40% + negative PnL)
    "non_crypto_consensus": -5,  # 38.9% WR, flat PnL, n=18
    "ema_stack_momentum": -15,  # 21.4% WR, n=14
    "carry-trade-momentum": -15,  # 26.7% WR, -0.14% avg PnL, n=15
    "dxy-reversal-scout": -15,  # 20.0% WR, -0.19% avg PnL, n=10
    "goldmine_1x_consensus": -15,  # 19.0% WR, -1.38% avg PnL, n=21 (crypto-blocked separately)
    "goldmine_3x_consensus": -15,  # 28.6% WR, -0.86% avg PnL, n=14
    "claude_gainer_1h": -20,  # 47.6% WR but -3.00% avg PnL, n=21 (huge tail losses)
    "community_london_breakout_v2_forex": -20,  # 0.0% WR, -0.50% avg PnL, n=16
    "betting-against-beta": -20,  # 23.1% WR, -1.08% avg PnL, n=13
    "call-surge-scout": -20,  # 16.7% WR, -2.09% avg PnL, n=12
    "quan_engine_swing": -25,  # 0.0% WR, -2.33% avg PnL, n=10
    "goldmine_2x_consensus": -25,  # 18.8% WR, -5.47% avg PnL, n=16
    "goldmine_4x_consensus": -25,  # 0.0% WR, -5.06% avg PnL, n=5
}

# Backtest-validated strategy bonuses (from 970-run backtest case study 2026-04-04)
# These strategies survived rigorous backtesting across multiple symbols/timeframes.
# Bonus is additive on top of any _STRATEGY_SCORES or _STRATEGY_FAMILY_SCORES match.
BACKTEST_VALIDATED_STRATEGIES = {
    "supertrend_vwma_confluence": 15,  # Sharpe 3.55, PF 2.00, 133 trades
    "short_only_contrarian": 12,  # Sharpe 3.36, PF 5.74
    "triple_confirmation": 12,  # Sharpe 2.87, PF 2.01, 82 trades
    "keltner_rsi2_squeeze": 10,  # Sharpe 2.62, PF 5.27
    "simplified_kimi_rsi2": 10,  # PF 2.17, simplified > complex
    "supertrend_optimized": 10,  # PF 4.99 (optimized params)
    "vwma_momentum_trend": 8,  # Sharpe 2.22, PF 2.18 (matches function name in proven_edge_strategies.py)
    "vwma_momentum": 8,  # Alias for legacy naming
}

# Strategy family patterns (partial match)
_STRATEGY_FAMILY_SCORES = {
    "enhanced_ml_": 10,  # ML enhanced family generally strong
    "copy_hl_whale": 8,  # Copy trader whale family
    "revival_": 8,  # Revival systems strong
    "quan_engine_scalp": -12,  # Scalp strategies underperform
}

# Symbol+Direction bonuses/penalties (data: 1000 closed dashboard picks, 2026-04-03)
# Updated 2026-04-04: KAS flip (+10), BTC/SOL/DOGE LONG degraded from recent 200 picks
SYMBOL_DIRECTION_BONUSES: Dict[tuple, int] = {
    ("LTCUSDT", "LONG"): 14,  # 92% WR, 13 trades
    ("AVAXUSDT", "LONG"): 12,  # 89% WR, 18 trades
    ("SEIUSDT", "LONG"): 11,  # 83% WR, 12 trades
    (
        "KASUSDT",
        "LONG",
    ): 10,  # FLIPPED: was -19 (12% WR overall) -> recent 13 trades 85% WR
    ("APTUSDT", "LONG"): 8,  # 76% WR, 29 trades
    ("BNBUSDT", "LONG"): 7,  # 73% WR, 22 trades
    ("XRPUSDT", "LONG"): 7,  # 72% WR, 18 trades
    ("UNIUSDT", "LONG"): 7,  # 71% WR, 28 trades
    ("HYPEUSDT", "LONG"): 6,  # 71% WR, 17 trades
    ("BTCUSDT", "SHORT"): 5,  # 55% WR, 62 trades
    ("XMR", "LONG"): -20,  # 0% WR, 23 trades
    ("TRXUSDT", "LONG"): -20,  # 8% WR, 25 trades
    ("ICPUSDT", "LONG"): -16,  # 17% WR, 23 trades
    ("SOLUSDT", "LONG"): -15,  # NEW: recent 1/10=10% WR -- severe degradation
    ("ONDOUSDT", "LONG"): -13,  # 24% WR, 21 trades
    ("BTCUSDT", "LONG"): -12,  # DEGRADED: recent 2/11=18% WR (was -5 at 38% overall)
    ("DOGEUSDT", "LONG"): -10,  # FLIPPED: was +13 (91% overall) -> recent 1/7=14% WR
}

# Strategy+Symbol combos with extreme edge (5+ trades)
STRATEGY_SYMBOL_BONUSES: Dict[tuple, int] = {
    ("st_fear_greed_contrarian", "AVAXUSDT"): 10,
    ("st_fear_greed_contrarian", "LTCUSDT"): 10,
    ("st_fear_greed_contrarian", "NEARUSDT"): 8,
    ("st_fear_greed_contrarian", "LINKUSDT"): 8,
    ("st_fear_greed_contrarian", "DOTUSDT"): 8,
    (
        "st_fear_greed_contrarian",
        "UNIUSDT",
    ): -15,  # STRENGTHENED: 0/4 WR, all SL/expired losses
    ("st_fear_greed_contrarian", "SOLUSDT"): -5,
    ("claude_gainer_1h", "XMR"): -25,
    ("enhanced_ml_A_xgboost", "TRXUSDT"): -20,
    ("quan_engine_scalp", "BTCUSDT"): -15,
    ("quan_engine_scalp", "KASUSDT"): -15,
    ("quan_engine_scalp", "ONDOUSDT"): -15,
    ("quan_engine_scalp", "ICPUSDT"): -15,
}

# T1-D proven-symbol score boosts (2026-04-15)
# Top 10 symbols with n >= 20 and WR >= 50% from closed ledger.
# Nudges picks on proven combos over Gate 1/2 thresholds without changing any floor.
# When a SYMBOL_DIRECTION_BONUS applies for the same symbol+direction, proven boost is skipped.
PROVEN_SYMBOL_BOOSTS: Dict[str, int] = {
    "BNBUSDT": +5,    # 83.9% WR, PF 12.70, n=31
    "CVX": +4,        # 72.4% WR, PF 2.25, n=29
    "XRPUSDT": +4,    # 69.4% WR, PF 4.43, n=36
    "OPUSDT": +3,     # 63.3% WR, PF 2.37, n=30
    "NEARUSDT": +3,   # 62.5% WR, PF 2.74, n=24
    "XOM": +3,        # 60.5% WR, PF 1.53, n=43
    "WLDUSDT": +3,    # 60.0% WR, PF 2.06, n=20
    "UNIUSDT": +2,    # 57.6% WR, PF 1.54, n=33
    "ARBUSDT": +2,    # 54.1% WR, PF 1.92, n=37
    "SOLUSDT": +2,    # 50.8% WR, PF 1.84, n=130
}


def passes_active_gate(pick: Dict[str, Any]) -> bool:
    """
    Active Picks display gate (dashboard visibility).

    Crypto: permissive — quality is mostly score-based; only structural /
    catastrophic / stale-with-flat-PnL rows are hard-rejected.

    Non-crypto: stricter — blocked asset├ùstrategy/source pairs, trust_score < 4,
    and raw dashboard score < 55 unless audited history bypass applies.
    """
    # Auto-generate ID if missing
    pick_id = str(pick.get("id", "") or "").strip()
    if not pick_id or pick_id.lower() in ("", "none", "null", "nan"):
        sym = pick.get("symbol", "UNK")
        strat = pick.get("strategy", "unk")
        ts = pick.get("created_at", pick.get("timestamp", ""))[:16]
        pick["id"] = f"{sym}_{strat}_{ts}".replace(" ", "_")

    # Must have a symbol
    symbol = str(pick.get("symbol", "") or "").strip()
    if not symbol:
        logger.debug("Pick rejected: no symbol")
        return False

    # Must not be closed/resolved
    status = str(pick.get("status", "")).upper().strip()
    if status and status not in {"OPEN", "ACTIVE", "PENDING", "LIVE", ""}:
        logger.debug(f"Pick rejected: closed status={status}")
        return False

    # Hard-block BANNED/AVOID trust tiers — catastrophic trust picks must never display
    _pick_trust_tier = str(pick.get("trust_tier", "") or "").upper()
    if _pick_trust_tier in BLOCKED_ACTIVE_TRUST_TIERS:
        logger.debug(f"Pick rejected: trust_tier={_pick_trust_tier} blocked ({symbol})")
        return False

    # GC=F Bad Data Protection (audit session 2026-04-05; revised post-diagnostic)
    # Total Active Futures Audit confirmed Gold (GC=F) entry ~4702.
    if symbol.upper() == "GC=F":
        entry = _float(pick.get("entry_price", 0))
        if entry > 0 and (entry < 800 or entry > 12000):
            logger.debug(f"Pick rejected: insane gold entry {entry}")
            return False

    # Block symbols with known data quality issues (redenomination, bad feeds)
    if symbol.upper() in BLOCKED_SYMBOLS:
        logger.debug(f"Pick rejected: blocked symbol {symbol} (data quality issue)")
        return False

    # ── Blocker 2 defense-in-depth (2026-04-22): hard-reject EXEMPT_FROM_SAFETY_GATES ──
    # Per reports/HC_GATE_BLOCKER_2_PLACEHOLDER_STATS_DIAGNOSIS_2026_04_22.md,
    # clone_hl_copy_* picks carry clone_safety_mode="EXEMPT_FROM_SAFETY_GATES"
    # AND placeholder stats (score ≈ forward_trades ≈ forward_wr, all derived from
    # the source whale's historical WR not the clone's own closed trades).
    # Safety gates exist for a reason — no strategy should ever bypass them.
    # This is restrictive-only (can't cause false negatives) and fully reversible.
    _safety_mode = str(pick.get("clone_safety_mode", "") or "").upper()
    if _safety_mode == "EXEMPT_FROM_SAFETY_GATES":
        logger.debug(
            "Pick rejected: clone_safety_mode=EXEMPT_FROM_SAFETY_GATES (%s %s)",
            symbol, pick.get("strategy", ""),
        )
        return False

    # Block specific losing strategies per asset class (2026-04-14)
    # Per TESTING_PROTOCOL ┬º7 and docs/strategy_audits/stocks_competition_2026-04-14.md
    _strategy = str(pick.get("strategy", "") or "").strip()
    _asset_class = str(pick.get("asset_class", "") or "").upper().strip()
    if is_strategy_blocked(_strategy, _asset_class):
        logger.debug(
            "Pick rejected: strategy=%s blocked for asset_class=%s (%s)",
            _strategy, _asset_class, symbol
        )
        return False

    # ── elite_grade D/F hard block (Action 1, 2026-04-12) ──
    # Data from filter analysis on 3,500 closed picks:
    #   Grade D: n=789 WR 30.9% PF 0.62 total PnL -419%
    #   Grade F: n=82  WR 32.9% PF 0.35 total PnL -90%
    # Combined: 871 picks (25%) losing -509% PnL. Blocking these lifts the
    # remaining pool PF from 1.24 to ~2.0+. Verified via Playwright on live
    # site + confirmed by cursor peer coordination in CHATWITHIT.MD.
    _pick_grade = str(pick.get("elite_grade", "") or "").upper()
    if _pick_grade in ("D", "F"):
        logger.debug(
            "Pick rejected: elite_grade=%s hard-blocked (%s %s)",
            _pick_grade, symbol, pick.get("strategy", ""),
        )
        return False

    # ── Phase 1 confidence gate REVERTED 2026-04-22 (see PR #323 diagnosis) ──
    # The "confidence < 0.80 reject" gate added by PR #253 was removed because
    # the data it cited proved confidence is ANTI-predictive, not monotone:
    #   conf 0.00–0.55: WR 42.8% (BEST)     ← the gate was rejecting these
    #   conf 0.65–0.75: WR 26.2% (WORST)    ← the gate was KEEPING these
    #   conf 0.75–0.85: mean PnL −2.20%
    #   conf 0.85+:     WR 36.6%
    # Rejecting everything <0.80 was selecting for losing picks. Root cause of
    # the 2026-04-22 "only 5 active picks on /audit" incident: 15/90 false
    # rejects here + 21/90 false rejects at score<=0 (see Fix 2 below).
    # Unanimous 4-model consensus (gpt-oss-120b, kimi-k2.5, deepseek-v3.2,
    # glm-4.6) recommended full revert over shadow-mode or narrowing.
    #
    # The dead-zone gate below (reject ONLY 0.65–0.75 band) is retained — it
    # targets the actually-worst band and stays in shadow mode by default.
    _ac_upper = str(pick.get("asset_class", "") or "").upper()

    # ── Phase 1 confidence dead-zone gate (PR #291 deep investigation, 2026-04-21) ──
    # The 0.65–0.75 confidence band is a non-monotonic dead zone on crypto.
    # Cross-section (n=1695 closed crypto picks):
    #   conf 0.00–0.55: n=138  WR 42.8%
    #   conf 0.55–0.65: n=301  WR 41.9%
    #   conf 0.65–0.75: n=820  WR 26.2%   ← worst band, largest sample
    #   conf 0.75–0.85: n=365  WR 34.2%   mean PnL −2.20%
    #   conf 0.85–1.01: n=71   WR 36.6%
    # Within HC-pass crypto (n=121, post Kimi calibration): same pattern —
    # conf 0.55–0.65 → 67.3% WR, conf 0.65–0.75 → 20.0% WR.
    # The band absorbs picks from systems with mediocre score+trust but no real
    # alpha; rejecting it drops ~17% of HC volume in exchange for higher mean WR.
    #
    # Env-tunable:
    #   PHASE1_CONF_DEADZONE_ENABLED  (1/0/shadow, default 1 for CRYPTO)
    #   PHASE1_CONF_DEADZONE_LOW      (float, default 0.65)
    #   PHASE1_CONF_DEADZONE_HIGH     (float, default 0.75)
    #
    # Related: updates/2026-04-21-deep-strategy-investigation-by-asset-class.md (§7).
    _dz_mode = os.environ.get("PHASE1_CONF_DEADZONE_ENABLED", "shadow").lower()
    if _dz_mode != "0" and _ac_upper == "CRYPTO":
        try:
            _dz_lo = float(os.environ.get("PHASE1_CONF_DEADZONE_LOW", "0.65"))
            _dz_hi = float(os.environ.get("PHASE1_CONF_DEADZONE_HIGH", "0.75"))
        except ValueError:
            _dz_lo, _dz_hi = 0.65, 0.75
        _raw_dz_conf = pick.get("confidence")
        if _raw_dz_conf is not None:
            try:
                _dz_conf = float(_raw_dz_conf)
            except (TypeError, ValueError):
                _dz_conf = None
            if _dz_conf is not None and _dz_lo <= _dz_conf < _dz_hi:
                if _dz_mode == "shadow":
                    pick["_phase1_dz_shadow_reject"] = (
                        f"confidence={_dz_conf:.3f} in dead zone [{_dz_lo}, {_dz_hi})"
                    )
                else:
                    logger.debug(
                        "Pick rejected: confidence=%.3f in dead zone [%.2f, %.2f) (%s %s)",
                        _dz_conf, _dz_lo, _dz_hi, symbol, pick.get("strategy", ""),
                    )
                    return False

    # ── Phase 1 time-of-day gate (2026-04-17 deep-dive + 2026-04-21 PR #291 expansion) ──
    # Two death windows on crypto:
    #
    #   Window A: 08:00–11:00 UTC (original 2026-04-17 finding, n=697 −164% cum)
    #   Window B: 16:00–21:00 UTC (PR #291 deep investigation, n=460 over 6 hours):
    #     16:00 UTC n=60  WR 20.0% mean −0.76%
    #     17:00 UTC n=55  WR 18.2% mean −0.77%
    #     18:00 UTC n=81  WR 25.9% mean −0.48%
    #     19:00 UTC n=83  WR 19.3% mean −0.87%
    #     20:00 UTC n=117 WR 17.1% mean −1.03%   ← worst single hour in dataset
    #     21:00 UTC n=64  WR 20.3% mean −0.71%
    #
    # By contrast, 22:00–23:00 UTC is the BEST window (WR 63–72%, mean +0.81–1.08%).
    # Filter excludes 10 hours total (45% of trading day); leaves 22-07 UTC + 12-15 UTC
    # which is where ~60% of the productive volume lives.
    #
    # Env-tunable:
    #   PHASE1_TOD_GATE_HOURS   (CSV of UTC hours to block, default "8,9,10,11,16,17,18,19,20,21")
    #   PHASE1_TOD_GATE_ENABLED (1/0/shadow, default 1 for CRYPTO)
    #
    # Related: PR #291 deep-investigation, feedback_quick_guess_horizons.md,
    # project_clean_data_symbol_wr.md (22 UTC best, 08-09 + 16-21 worst).
    _tod_mode = os.environ.get("PHASE1_TOD_GATE_ENABLED", "shadow").lower()
    if _tod_mode != "0" and _ac_upper == "CRYPTO":
        _hours_env = os.environ.get(
            "PHASE1_TOD_GATE_HOURS", "8,9,10,11,16,17,18,19,20,21"
        )
        try:
            _blocked_hours = {int(h.strip()) for h in _hours_env.split(",") if h.strip()}
        except ValueError:
            _blocked_hours = {8, 9, 10, 11, 16, 17, 18, 19, 20, 21}
        # Use the pick's intended entry moment; fall back to the row timestamp
        _entry_ts = (
            pick.get("entry_time")
            or pick.get("opened_at")
            or pick.get("timestamp")
            or pick.get("created_at")
        )
        _entry_hour = None
        if _entry_ts:
            try:
                _entry_dt = datetime.fromisoformat(
                    str(_entry_ts).replace("Z", "+00:00")
                )
                if _entry_dt.tzinfo is not None:
                    _entry_dt = _entry_dt.astimezone(timezone.utc)
                _entry_hour = _entry_dt.hour
            except Exception:
                _entry_hour = None
        if _entry_hour is None:
            # Use current UTC hour as best guess — prevents stale picks from slipping
            # past the window check when the source omits a timestamp.
            _entry_hour = datetime.now(timezone.utc).hour
        if _entry_hour in _blocked_hours:
            if _tod_mode == "shadow":
                pick["_phase1_tod_shadow_reject"] = (
                    f"entry_hour={_entry_hour:02d}:00Z in blocked window "
                    f"{sorted(_blocked_hours)}"
                )
            else:
                logger.debug(
                    "Pick rejected: entry_hour=%02d:00Z in Phase1 block window %s (%s %s)",
                    _entry_hour, sorted(_blocked_hours), symbol,
                    pick.get("strategy", ""),
                )
                return False

    # ── PSI drift gate (task J / handoff P1) ──
    # Bind on alpha_engine/feature_health.py PSI output. When ANY feature has
    # drifted beyond PSI_BLOCK_THRESHOLD (0.25), downstream ML scores and
    # rule-based features keyed on that distribution become unreliable. Env-
    # gated for staged rollout (matches signal_ts_strict / bear_day_strict):
    #   PSI_GATE_STRICT=shadow (default) — log + tag pick, do NOT reject
    #   PSI_GATE_STRICT=1               — hard reject while drift is active
    #   PSI_GATE_STRICT=0               — disable entirely
    # SHADOW — remove after 48h forward observation
    try:
        _psi_mode = os.environ.get("PSI_GATE_STRICT", "shadow").lower()
        if _psi_mode != "0":
            _max_psi, _drifted_feats = _get_max_psi()
            if _max_psi > PSI_BLOCK_THRESHOLD:
                if _psi_mode == "1":
                    logger.info(
                        "PICK_REJECTED psi_gate_strict symbol=%s strategy=%s "
                        "max_psi=%.3f drifted=%s",
                        symbol, pick.get("strategy", ""), _max_psi,
                        ",".join(_drifted_feats[:5]),
                    )
                    return False
                # shadow mode: tag without rejecting
                pick["_psi_shadow_reject"] = (
                    f"max_psi={_max_psi:.3f} > {PSI_BLOCK_THRESHOLD} "
                    f"(drifted: {','.join(_drifted_feats[:3])})"
                )
    except Exception:
        pass  # never break admission on this gate

    # Block specific strategy+symbol pairs with proven 0% WR
    strategy = str(pick.get("strategy", "") or "")
    # Raw dashboard score before penalties (elite_score must not satisfy min-score tests)
    raw_active_score = _float(pick.get("score", 0))
    if (strategy, symbol.upper()) in BLOCKED_STRATEGY_SYMBOL_PAIRS:
        logger.debug(
            f"Pick rejected: blocked strategy+symbol pair ({strategy}, {symbol})"
        )
        return False

    # ── Matrix CSV gates (system ├ù symbol block / optional allow-only) ──
    _mx_block, _mx_reason = matrix_symbol_gate_blocks(pick)
    if _mx_block:
        logger.debug("Pick rejected: matrix symbol gate (%s)", _mx_reason)
        return False

    # ── SANDBOX experiments: relabel passing picks (strategy + trust_tier) ──
    apply_sandbox_experiment_relabels(pick)
    strategy = str(pick.get("strategy", "") or "")

    # ── Mutation filter: enforce symbol-lock / direction-filter for CANDIDATE mutations ──
    if _MUTATIONS_AVAILABLE and strategy in ALL_MUTATIONS:
        direction = str(pick.get("direction", "") or "").upper()
        allowed, mutation_reason = check_mutation_filter(strategy, symbol, direction)
        if not allowed:
            logger.debug(f"Pick rejected by mutation filter: {mutation_reason}")
            return False

    # ── Mutation re-attribution: if a BANNED parent strategy has a viable mutation,
    #    re-attribute the pick to the mutation variant instead of hard-blocking ──
    if _MUTATIONS_AVAILABLE and strategy.lower() in _KILLED_STRATEGIES_LOWER:
        direction = str(pick.get("direction", "") or "").upper()
        variant_id = get_mutation_for_parent(strategy, symbol, direction)
        if variant_id:
            logger.info(
                f"Pick re-attributed from banned {strategy} to mutation {variant_id} "
                f"(symbol={symbol}, direction={direction})"
            )
            pick["strategy"] = variant_id
            pick["_original_strategy"] = strategy
            pick["_mutation_applied"] = True
            strategy = variant_id  # update local var for downstream checks

    # PnL sanity check — flag picks with impossible PnL values
    _pnl = _float(pick.get("pnl_pct", 0))
    if _pnl < PNL_SANITY_MIN or _pnl > PNL_SANITY_MAX:
        logger.warning(
            f"Pick {symbol} has insane PnL={_pnl}% — likely data quality issue"
        )
        # Don't hard-reject but flag and penalize heavily
        pick["_pnl_anomaly"] = True
        current_score = _float(pick.get("score", 50))
        pick["score"] = max(0, current_score - 50)

    # R:R sanity check — reject mathematically impossible or exploitative R:R
    # Gated by AUDIT_PICK_SANITY_GATE (matching pick_sanity gate behavior)
    if _audit_pick_sanity_gate_enabled():
        entry_price = _float(pick.get("entry_price", 0))
        tp_price = _float(pick.get("take_profit", 0))
        sl_price = _float(pick.get("stop_loss", 0))
        if entry_price > 0 and tp_price > 0 and sl_price > 0:
            risk = abs(entry_price - sl_price)
            reward = abs(tp_price - entry_price)
            if risk > 0:
                rr = reward / risk
                if rr > 20 or rr < 0.1:
                    logger.debug(
                        "Pick rejected: insane R:R=%.2f (entry=%.4f tp=%.4f sl=%.4f) %s",
                        rr, entry_price, tp_price, sl_price, symbol,
                    )
                    return False

    # Trade geometry check — gated by AUDIT_PICK_SANITY_GATE
    if _audit_pick_sanity_gate_enabled():
        if not _has_valid_trade_geometry(pick):
            logger.debug("Pick rejected: invalid crypto trade geometry")
            return False

    if (
        _audit_pick_sanity_gate_enabled()
        and _PICK_SANITY_PASS is not None
        and not _pick_sanity_gate_exempt(pick)
        and not _PICK_SANITY_PASS(pick)
    ):
        logger.debug("Pick rejected: pick_sanity (AUDIT_PICK_SANITY_GATE)")
        return False

    # Apply score penalties (quality signals adjust score, not visibility)
    _apply_score_penalties(pick)

    # Strict-mode copy-trade verification hard reject (opt-in). When
    # COPYTRADE_VERIFICATION_STRICT=1 and verify_copy_pick returned FAIL inside
    # _apply_score_penalties, the pick is flagged and must be dropped.
    if pick.get("_copytrade_verification_rejected"):
        logger.debug("Pick rejected: copytrade verification FAIL (strict mode)")
        return False

    asset_class = str(pick.get("asset_class", "CRYPTO")).upper()
    source_sys = str(pick.get("source_system", pick.get("source", "")) or "")

    # ETF: hard ban REMOVED 2026-04-19. Was a "Phase 1 rehab" emergency measure that
    # became permanent by neglect. ETF n=4 is thin, but the hard ban created a data
    # starvation catch-22 - no picks can flow to build the forward history needed to
    # justify unblocking. ETF also removed from BLOCKED_ASSET_CLASSES (was -60).
    # Quality filtering now relies on normal score penalties + soft gates instead.

    # Hard-block toxic asset├ùstrategy / asset├ùsource combinations (penalties alone are not enough)
    if (asset_class, strategy) in BLOCKED_ASSET_STRATEGY_PAIRS:
        logger.debug("Pick rejected: blocked asset class + strategy")
        return False
    if (asset_class, source_sys) in BLOCKED_ASSET_SOURCE_PAIRS:
        logger.debug("Pick rejected: blocked asset class + source system")
        return False

    # Non-crypto: require moderate trust + minimum raw score (audited history can bypass)
    # Scanner-generated picks (multi_asset, stocks_competition, multi_asset_copytrader, etc.)
    # arrive without pre-computed scores — only apply the raw-score floor when the pick
    # has an EXPLICIT score field (raw_active_score > 0). Unscored picks are scored by
    # _apply_score_penalties and their quality is evaluated post-scoring.
    _NC_SCORE_EXEMPT_SOURCES = {
        "multi_asset",
        "multi_asset_institutional",
        "stocks_competition",
        "fast_stocks_competition",
        "stocks_forex_comp",
        "goldmine_stocks",
        # 2026-04-05: copy-trader sources arrive with raw_active_score 20-44 after
        # _apply_score_penalties and were hitting the >=55 non-crypto floor, dropping
        # 68/69 active copytrader picks from dashboard. They're scored via their own
        # pipeline (per claude-copytrader-merge investigation, docs/COPYTRADER_MERGE_BUG_20260405.md).
        "multi_asset_copytrader",
        "cta_replicator",
    }
    if asset_class in ("FOREX", "EQUITY", "COMMODITY", "FUTURES", "ETF", "BOND"):
        trust_score = _float(pick.get("trust_score", 0))
        if trust_score > 0 and trust_score < ACTIVE_NON_CRYPTO_MIN_TRUST_SCORE:
            logger.debug(
                "Pick rejected: non-crypto trust_score < %s",
                ACTIVE_NON_CRYPTO_MIN_TRUST_SCORE,
            )
            return False
        if source_sys not in _NC_SCORE_EXEMPT_SOURCES:
            # Only apply floor for picks that have an explicit pre-penalty score.
            # raw_active_score == 0 means unscored (no score field) — not bad score.
            if (
                raw_active_score > 0
                and raw_active_score < ACTIVE_DISPLAY_NON_CRYPTO_MIN_RAW_SCORE
                and not _non_crypto_active_raw_score_bypass(pick)
            ):
                logger.debug(
                    "Pick rejected: non-crypto raw score below active-display floor"
                )
                return False

    # ── Non-Crypto Quality Gate ──
    # Non-crypto gets softer gates — let picks through but penalize via score.
    # The previous hard-reject at score<70 for unproven pairs was too aggressive.
    if asset_class in ("FOREX", "EQUITY", "COMMODITY"):
        sym_track_wr = pick.get("sym_track_wr")
        sym_track_total = _int(pick.get("sym_track_total", 0))
        # Only hard-reject: proven catastrophic failure (WR < 20% on 10+ trades)
        if sym_track_total >= 10 and (sym_track_wr or 0) < 20:
            logger.debug(
                f"Non-crypto reject: catastrophic symbol track ({sym_track_wr}%)"
            )
            return False

    # ── Crypto Active Display Gate ──
    # Philosophy: ALL crypto picks reach the dashboard. Quality is expressed
    # through score (sort order), not visibility. The previous 7-filter
    # hard-gate rejected 96% of picks (364 ÔåÆ 14), starving the dashboard.
    # Only hard-reject picks with proven catastrophic symbol-level failure.
    if asset_class == "CRYPTO":
        sym_track_wr = _float(pick.get("sym_track_wr", 0))
        sym_track_total = _int(pick.get("sym_track_total", 0))
        # Only hard-reject: proven 0% WR on this specific strategy+symbol with enough data
        if sym_track_total >= 10 and sym_track_wr < 20:
            return False

    # Large-sample forward-WR floor: once a cohort has enough forward evidence,
    # sub-edge win rates should not stay in the active feed just because the
    # pick is fresh or the score pipeline is noisy.
    edge_wr = _effective_forward_wr_ratio(pick)
    edge_trades = _effective_forward_trades(pick)
    if asset_class == "CRYPTO":
        if (
            edge_trades >= ACTIVE_CRYPTO_MIN_FORWARD_TRADES
            and 0 < edge_wr < ACTIVE_CRYPTO_MIN_FORWARD_WR
        ):
            logger.debug(
                "Pick rejected: crypto forward WR %.1f%% on %d trades below %.1f%% floor",
                edge_wr * 100.0,
                edge_trades,
                ACTIVE_CRYPTO_MIN_FORWARD_WR * 100.0,
            )
            return False
    elif asset_class in ("FOREX", "EQUITY", "COMMODITY", "FUTURES", "ETF", "BOND"):
        _nc_wr_floor = active_non_crypto_forward_wr_floor(asset_class)
        if (
            edge_trades >= ACTIVE_NON_CRYPTO_MIN_FORWARD_TRADES
            and 0 < edge_wr < _nc_wr_floor
        ):
            logger.debug(
                "Pick rejected: non-crypto forward WR %.1f%% on %d trades below %.1f%% floor (%s)",
                edge_wr * 100.0,
                edge_trades,
                _nc_wr_floor * 100.0,
                asset_class,
            )
            return False

    # ── v101.1 Dashboard Visibility Sync: Hard-rejects from template.html ──

    # 1. Blocked source systems (proven losers)
    source_lower = str(pick.get("source_system", "") or "").lower().strip()
    if source_lower in BLOCKED_SOURCE_SYSTEMS:
        logger.debug(f"Pick rejected: blocked source system {source_lower}")
        return False

    # 2. Rapid_fire noise filter (score < 10)
    if source_lower == "rapid_fire":
        # Check initial score BEFORE penalties (it will get capped later)
        score_val, _ = _extract_final_score(pick)
        if score_val < RAPID_FIRE_MIN_SCORE:
            logger.debug("Pick rejected: rapid_fire noise (score < 10)")
            return False

    # 3. Entry price range (broken entries)
    entry_price = _float(pick.get("entry_price", 0))
    if entry_price <= 0:
        logger.debug("Pick rejected: missing entry price")
        return False
    if entry_price > MAX_ENTRY_PRICE:
        logger.debug(f"Pick rejected: insane entry price={entry_price}")
        return False

    # 4. Age-based staleness (if not winning)
    # Picks older than crypto/non-crypto hard max age with |PnL| < 1% are hidden
    created_ts = (
        pick.get("created_at") or pick.get("timestamp") or pick.get("generated_at")
    )
    if created_ts:
        age_hours = _calculate_age_hours(created_ts)
        pnl = _float(pick.get("pnl_pct") or pick.get("unrealized_pnl_pct", 0))

        is_nc = asset_class in {
            "FOREX",
            "EQUITY",
            "COMMODITY",
            "FUTURES",
            "BOND",
            "ETF",
        }
        max_age_h = (
            NON_CRYPTO_HARD_MAX_AGE_HOURS_VISIBLE
            if is_nc
            else CRYPTO_HARD_MAX_AGE_HOURS
        )

        if age_hours > max_age_h and abs(pnl) < STALENESS_PNL_LIMIT:
            logger.debug(
                f"Pick rejected: stale pick (age={age_hours:.1f}h, pnl={pnl:.2f}%)"
            )
            return False

    # Score floor gate: score < 40 = 33.9% WR on 372 picks (TESTING_PROTOCOL ┬º13)
    # Score <= 0 is NOT "unscored" — it is a failed/bad score and must be rejected.
    # Only exempt sources (synthetic strategy names that collide with kill list)
    # bypass the floor; all others must have a positive score above the floor.
    _SCORE_FLOOR_EXEMPT_SOURCES = {
        "goldmine_stocks",
        "stocks_competition",
        "fast_stocks_competition",
        "stocks_forex_comp",
        "multi_asset_copytrader",
        "cta_replicator",
    }
    source_sys_fl = str(pick.get("source_system", "") or "").lower()
    if source_sys_fl in _SCORE_FLOOR_EXEMPT_SOURCES:
        return True  # exempt from universal 40 floor (synthetic strategy names collide with kill list)
    _raw_floor = ACTIVE_DISPLAY_CRYPTO_MIN_RAW_SCORE if asset_class == "CRYPTO" else 40

    # Fix 2 (PR #323, 2026-04-22): Exempt pre-score active candidates from the
    # score<=0 hard reject. Restores the contract codified by
    # test_pre_score_active_candidate_keeps_valid_zero_score_pick_alive in
    # tests/test_dashboard_generator.py. Prediction-market-consensus picks
    # enter the active book before elite/score_booster have run and must not
    # be collapsed prematurely. Trust-tier BANNED/AVOID remain hard-blocked.
    # (Inlined to avoid circular import from audit_trail.dashboard_generator.)
    _pre_score_blocked = {"BANNED", "AVOID"}
    _pre_score_trust_tier = str(pick.get("trust_tier", "") or "").strip().upper()
    _pre_score_trust_label = str(pick.get("trust_label", "") or "").strip().upper()
    _pre_score_strategy = str(pick.get("strategy", "") or "").strip().lower()
    _is_pre_score_candidate = (
        _pre_score_trust_tier not in _pre_score_blocked
        and _pre_score_trust_label not in _pre_score_blocked
        and bool(_pre_score_strategy)
        and _pre_score_strategy not in {"none", "null", "unknown"}
    )
    if raw_active_score <= 0 and _is_pre_score_candidate:
        return True  # pre-score PM candidate — quality expressed via sort order, not visibility
    if raw_active_score <= 0:
        logger.debug(
            f"Pick rejected: score={raw_active_score:.1f} is null/zero/negative ({symbol})"
        )
        return False
    if raw_active_score < _raw_floor:
        logger.debug(
            f"Pick rejected: score={raw_active_score:.1f} below raw display floor {_raw_floor} ({symbol})"
        )
        return False

    return True


def passes_smart_gate(pick: Dict[str, Any]) -> bool:
    """
    Smart Picks gate — selects high-conviction picks using the golden
    criteria derived from 2,256+ closed pick analysis.

    Golden combo (68.2% WR, +4.67% avg PnL):
      PROVEN trust + agreement 1-2 + score 40-69

    Additional qualifiers from cross-AI analysis:
      - No SCALP mode (24.8% WR drag)
      - No panic health (24% WR)
      - Strategy fwd WR >= 35% if known
      - Prefer SWING mode, HTF alignment, R:R 2.0-3.0
    """
    if not passes_active_gate(pick):
        return False

    # HF Threshold A: exclude from Smart Picks when forward WR lags BT by >15pp (n>=20)
    if pick.get("_hf_threshold_a"):
        logger.debug("Smart gate: HF threshold A (BT/FWD decay)")
        return False

    if not _has_source_provenance(pick):
        logger.debug("Smart gate: missing source provenance")
        return False

    score = _float(pick.get("score", 0))

    # Concentrated track records: keep in Active, exclude from Smart unless verified PM/copy
    if not _is_verified_pm_or_copy_pick(pick):
        if _concentration_penalty(pick) >= 10:
            logger.debug(
                "Smart gate: concentration penalty too high for non-verified pick"
            )
            return False
        if _concentration_risk(pick) == "HIGH":
            logger.debug("Smart gate: HIGH concentration risk for non-verified pick")
            return False

    # Primary: score threshold (all quality signals already baked in)
    # EQUITY uses a lower threshold — score 30-50 = 66.7% WR PF 2.61 (different distribution from crypto)
    # FOREX uses a HIGHER threshold — MC sweep (n=367) shows 16% WR baseline, p=0.999 (catastrophic)
    _ac = str(pick.get("asset_class", "CRYPTO")).upper()

    # 2026-04-14 edge convergence: LONG-only constraint for CRYPTO Smart Picks.
    # SHORT crypto PF 1.54 underperformed LONG crypto PF 1.91 baseline in 7d
    # window; LONG+Score>=50+Trust>=3 composite reached PF 5.48. See
    # SMART_PICKS_CRYPTO_LONG_ONLY docstring above for full rationale.
    if SMART_PICKS_CRYPTO_LONG_ONLY and _ac == "CRYPTO":
        _direction = str(pick.get("direction") or pick.get("signal_type") or "").upper()
        if _direction not in ("LONG", "BUY"):
            logger.debug(
                "Smart gate: CRYPTO SHORT rejected (SMART_PICKS_CRYPTO_LONG_ONLY)"
            )
            return False
    # Per-asset-class floors derived from chrono-split closed-pick analysis 2026-04-05
    # (claude-noncrypto-drilldown cross-asset score-floor tuning lane)
    if _ac == "EQUITY":
        _min_score = SMART_PICKS_MIN_SCORE_EQUITY
    elif _ac == "FOREX":
        _min_score = SMART_PICKS_MIN_SCORE_FOREX
        # 2026-04-14: Forex edge comes from FwdWR≥50, not Score+Trust
        # (Score≥50+Trust≥3 HURTS forex: PF 0.46 on n=49 vs baseline PF 2.02)
        # FwdWR≥50 gives PF 1.62 on n=466, beats random. Apply as additional gate.
        _fwd_wr = _effective_forward_wr_ratio(pick) * 100.0
        if _fwd_wr > 0 and _fwd_wr < 50:
            return False
    elif _ac == "COMMODITY" or _ac == "COMMODITIES":
        _min_score = SMART_PICKS_MIN_SCORE_COMMODITY
    elif _ac == "BOND" or _ac == "BONDS":
        _min_score = SMART_PICKS_MIN_SCORE_BOND
    elif _ac == "FUTURES":
        _min_score = SMART_PICKS_MIN_SCORE_FUTURES
    elif _ac == "ETF" or _ac == "ETFS":
        _min_score = SMART_PICKS_MIN_SCORE_ETF
    else:
        _min_score = SMART_PICKS_MIN_SCORE  # CRYPTO and unknown default

    # Forward-validated strategy bypass: if the strategy has strong forward
    # evidence, waive the min score gate.  Tightened from original 10/55% and
    # 20/50% thresholds - those let in strategies with too few trades to be
    # statistically meaningful.  30+ trades at 55% WR or 50+ at 50% WR are
    # robust enough to trust despite low composite scores.
    _bypass_edge_wr = _effective_forward_wr_ratio(pick)
    _bypass_edge_trades = _effective_forward_trades(pick)
    _forward_bypass = (
        (_bypass_edge_trades >= 50 and _bypass_edge_wr >= 0.50)
        or (_bypass_edge_trades >= 30 and _bypass_edge_wr >= 0.55)
    )
    if score < _min_score and not _forward_bypass:
        return False

    # Golden criteria disqualifiers — picks that empirically lose
    mode = str(pick.get("mode", pick.get("trade_mode", "")) or "").upper()
    health = str(pick.get("health_at_entry", "") or "").lower()

    # SCALP mode: 24.8% WR — exclude from Smart Picks entirely
    if mode == "SCALP":
        return False

    # Panic health: 24% WR — not Smart Pick material
    if health == "panic":
        return False

    rr = _trade_rr(pick)
    if rr < SMART_PICKS_MIN_RR:
        return False

    # R:R ceiling — data shows R:R >= 2.0 has lower hit rate (TP too far)
    rr = _float(pick.get("rr", pick.get("rr_ratio", pick.get("risk_reward", 0))))
    if rr > SMART_PICKS_MAX_RR and rr > 0:
        logger.debug(f"Smart gate: R:R {rr} exceeds ceiling {SMART_PICKS_MAX_RR}")
        return False

    conf = _float(pick.get("confidence", 0))
    edge_wr = _effective_forward_wr_ratio(pick)
    edge_trades = _effective_forward_trades(pick)
    _raw_trust_score = pick.get("trust_score")
    trust_score = _float(_raw_trust_score) if _raw_trust_score is not None else None
    trust_label = str(pick.get("trust_label", "") or "").upper()
    trust_tier = _trust_tier(pick)
    wf_verdict = _wf_verdict(pick)
    tech_bucket = _technical_alignment_bucket(pick)
    sym_track_wr = _float(pick.get("sym_track_wr", 0))
    sym_track_total = _int(pick.get("sym_track_total", 0))

    if conf < SMART_PICKS_MIN_CONFIDENCE:
        return False
    # NEW: ML score filter (decile test shows ml_score < 0.50 = 22% WR Kill Zone)
    ml_score = pick.get("ml_score")
    if ml_score is not None and ml_score < SMART_PICKS_MIN_ML_SCORE:
        logger.debug(
            f"Pick rejected: ml_score {ml_score:.2f} < {SMART_PICKS_MIN_ML_SCORE} (Kill Zone)"
        )
        return False
    if conf > SMART_PICKS_MAX_CONFIDENCE and not (
        edge_trades >= 10 and edge_wr >= 0.60
    ):
        return False
    # Only block on numeric trust_score if the field is explicitly set.
    # trust_score=None means "unrated by registry" — not the same as bad.
    # tier/label checks below still protect against explicitly bad picks.
    if trust_score is not None and trust_score < SMART_PICKS_MIN_TRUST_SCORE:
        return False
    if (
        trust_label in BLOCKED_ACTIVE_TRUST_LABELS
        or trust_tier in BLOCKED_ACTIVE_TRUST_TIERS
    ):
        return False
    if _has_direction_conflict(pick):
        return False
    if sym_track_total >= 3 and sym_track_wr < 45:
        return False
    # Hard-block only REJECTED/BROKEN; FAILING is a soft penalty (score already penalizes it)
    if wf_verdict in {"REJECTED", "BROKEN"}:
        return False
    if tech_bucket in {"strong_opposition", "weak_opposition"}:
        return False
    if tech_bucket in {"no_support", "weak_support"}:
        proven_contrarian = trust_score >= 7 and (
            wf_verdict in {"VIABLE", "STRONG", "ELITE"}
            or (edge_trades >= 20 and edge_wr >= 0.55)
        )
        if not proven_contrarian:
            return False

    # Forward-test viability check: only accept picks from viable strategies
    strategy_lc = str(pick.get("strategy", "")).lower()
    is_viable = any(vs in strategy_lc for vs in _VIABLE_STRATEGIES_FORWARD.keys())
    is_demoted = any(ds in strategy_lc for ds in _DEMOTED_STRATEGIES_FORWARD.keys())
    
    # For non-crypto assets, be stricter - require forward validation
    if _ac not in ("CRYPTO", "") and not is_viable and edge_trades < 10:
        logger.debug("Smart gate: non-crypto strategy lacks forward validation")
        return False
    
    # Strategy with known poor forward WR: not Smart Pick material
    strat_fwd_wr = max(
        _ratio(pick.get("strat_fwd_wr")),
        _ratio(pick.get("strategy_fwd_wr")),
        _ratio(pick.get("forward_wr")),
    )
    strat_fwd_trades = max(
        _float(pick.get("strat_fwd_trades", 0)),
        _float(pick.get("strategy_fwd_trades", 0)),
        _float(pick.get("forward_trades", 0)),
    )
    if strat_fwd_wr > 0 and strat_fwd_wr < 0.35 and strat_fwd_trades >= 10:
        return False

    # Consensus rows need real edge, not just many agreeing sources.
    if _is_consensus_pick(pick) and edge_trades >= 10 and edge_wr < 0.45:
        return False

    # Trust/high-conviction rework:
    # require minimum realized evidence for non-verified sources and block
    # drifted picks currently underperforming in live window.
    if not _is_verified_pm_or_copy_pick(pick):
        if edge_trades < 5:
            return False
        if edge_wr < 0.45:
            return False

    _age_h = _float(pick.get("age_hours") or 0)
    _live_pnl = _float(pick.get("pnl_pct") or pick.get("unrealized_pnl_pct") or 0)
    if _age_h >= 1.0 and _live_pnl <= -2.0:
        return False

    pick["high_conviction_gate_passed"] = bool(
        edge_trades >= 10
        and edge_wr >= 0.55
        and score >= (_min_score + 8)
        and not _has_direction_conflict(pick)
        and wf_verdict in {"VIABLE", "STRONG", "ELITE"}
    )

    return True


def _is_verified_pm_or_copy_pick(pick: Dict[str, Any]) -> bool:
    """Return True for audited PM / pro-trader style sources we want to surface."""
    return _verified_pm_or_copy_bonus(pick) > 0


def _verified_pm_or_copy_bonus(pick: Dict[str, Any]) -> int:
    """Ranking bonus for verified PM / auditable pro-trader sources."""
    source = str(pick.get("source_system", "") or "").lower()
    strategy = str(pick.get("strategy", "") or "").lower()

    if source == "prediction_market_consensus":
        return 16
    # 2026-04-05 what-if: Polymarket direct signals were 2/2 correct (BTC LONG + ETH SHORT)
    # while pm_whale BTC SHORT consensus FAILED (BTC drifted +0.30% today). Direct
    # Polymarket probability > whale-derived aggregates. Reweighting.
    if source == "polymarket_signals" and strategy.startswith("copy_pm_"):
        return 16  # was 14 - direct PM with copy strategy = highest non-consensus
    if source == "polymarket_signals":
        return 14  # was 10 - direct PM probability validated on 2026-04-05
    if source == "pm_kalshi_signals":
        return 12
    if source == "pm_whale_signals" and strategy.startswith("copy_pm_"):
        return 12  # was 15 - reduced relative to direct Polymarket
    if source == "pm_whale_signals":
        return 10  # was 12 - whale aggregates can miss actual resolution
    if strategy.startswith("copy_pm_"):
        return 12
    if source == "multi_asset_copytrader" and strategy in {
        "forex_rsi2_mean_reversion",
        "stocks_rsi2_pullback",
        "cftc_cot_commercial_signal",
    }:
        return 10
    return 0


def calculate_smart_score(pick: Dict[str, Any]) -> float:
    """
    Calculate a 0-100 Smart Score for ranking Smart Picks.

    Weights derived from golden criteria analysis (2,256+ closed picks,
    cross-validated by Claude, ChatGPT-Codex, KiloCode, Copilot):

    Component weights (total = 100):
      Base score (penalty-adjusted)    30 pts  — already encodes 13 factors
      R:R quality                      15 pts  — 2.0-3.0 = 71.6% WR (strongest)
      Strategy track record            15 pts  — largest Q1-Q4 WR spread
      Trust tier                       12 pts  — Spearman r=0.21
      Confidence sweet spot            10 pts  — 0.7-0.8 = 61.8% WR
      Technical alignment              10 pts  — 2/3+ = 76-86% WR
      Multi-source consensus            8 pts  — 5 strats = 44.7% WR
    """
    if not _has_valid_trade_geometry(pick):
        return 0.0

    score = 0.0
    edge_wr = _effective_forward_wr_ratio(pick)
    edge_trades = _effective_forward_trades(pick)
    proven_edge = edge_trades >= 10 and edge_wr >= 0.60
    decent_edge = edge_trades >= 5 and edge_wr >= 0.50
    weak_edge = edge_trades >= 10 and 0 < edge_wr < 0.35

    # 1. Base score (0-30 pts) — already encodes source system, strategy,
    #    trust, consensus, HTF, mode, health, overfit, etc.
    # 2026-04-19: Recalibrated per Phase B of AUDIT_PREDICTION_SYSTEM_ENHANCEMENT_PLAN.
    # Raw-score Spearman vs PnL only +0.08; linear pass-through propagates miscalibration.
    # Piecewise capped mapping discounts low/mid raw scores, caps top scores at 30.
    raw = _float(pick.get("score", 0))
    if raw <= 0:
        base = 0.0
    elif raw <= 40:        # bottom decile territory
        base = raw * 0.10
    elif raw <= 70:        # middle deciles
        base = raw * 0.20
    else:                  # top deciles
        base = min(raw * 0.30, 30.0)

    # Copy-trader cap: 0.8x when non-BTC-major (mirrors alpha_engine/elite_scorer cap philosophy)
    strategy_lower = str(pick.get("strategy", "")).lower()
    is_copy = pick.get("_is_copy_pick") is True or strategy_lower.startswith("copy_hl")
    symbol = str(pick.get("symbol", "")).upper()
    is_btc_major = symbol in {"BTC", "ETH", "SOL", "BTCUSDT", "ETHUSDT", "SOLUSDT", "BTC-USD", "ETH-USD", "SOL-USD"}
    if is_copy and not is_btc_major:
        base *= 0.8
    score += base

    # 2. R:R quality (0-15 pts) — strongest single technical signal
    entry = _float(pick.get("entry_price", 0))
    tp = _float(pick.get("take_profit", 0))
    sl = _float(pick.get("stop_loss", 0))
    rr = _trade_rr(pick)
    if 2.0 <= rr <= 3.0:
        score += 15  # Sweet spot: 71.6% WR
    elif 1.5 <= rr < 2.0:
        score += 10
    elif 1.0 <= rr < 1.5:
        score += 6
    elif rr > 3.0:
        score += 8  # Good but not as reliable as 2-3x
    elif rr > 0:
        score += 2

    # 3. Strategy forward WR (0-15 pts) — largest Q1-Q4 spread
    strat_fwd_wr = edge_wr
    strat_fwd_trades = edge_trades
    if strat_fwd_wr >= 0.60 and strat_fwd_trades >= 10:
        score += 15
    elif strat_fwd_wr >= 0.50 and strat_fwd_trades >= 5:
        score += 10
    elif strat_fwd_wr >= 0.40 and strat_fwd_trades >= 5:
        score += 5
    elif strat_fwd_wr > 0 and strat_fwd_wr < 0.35:
        pass  # No bonus for poor track records

    # 4. Trust tier (0-15 pts) — strongest scalar correlate
    # 2026-04-05: Closed-pick analysis on 3017 trades shows PROVEN tier
    # is 2.00x over-represented in winners vs losers (31.6% vs 15.8%).
    # RELIABLE is 0.76x under-represented in winners (34.7% vs 45.9%)
    # so it gets no extra boost. Bumping PROVEN strong-edge bonus from
    # +12 to +15 to reflect the 2x winner over-representation.
    trust_score_val = _float(pick.get("trust_score", 0))
    trust_label = str(pick.get("trust_label", "") or "").upper()
    trust_tier_val = _trust_tier(pick)
    if trust_tier_val == "PROVEN" or trust_label == "PROVEN":
        score += 5 if weak_edge else 15
    elif trust_score_val >= 7:
        score += 10
    elif trust_score_val >= 5:
        score += 6
    elif trust_tier_val in ("BANNED", "AVOID"):
        pass  # No bonus

    # 2026-04-05: SWING x RELIABLE biggest fixable bleed - 36.4% WR on n=1043.
    # Apply -8 penalty specifically to SWING timeframe picks from RELIABLE tier.
    _tf_upper = str(pick.get("trade_timeframe", "") or "").upper()
    if _tf_upper == "SWING" and (
        trust_tier_val == "RELIABLE" or trust_label == "RELIABLE"
    ):
        score -= 8
        # No append to penalties list here (not in that function scope)

    # 2026-04-05: Cursor factor-ranking confirms RELIABLE tier is TOXIC across
    # all timeframes: 36.1% WR on n=1377 CRYPTO closed (-7.3pp vs baseline).
    # Apply -5 general penalty on CRYPTO RELIABLE picks not already caught by SWING combo.
    _asset_cls = str(pick.get("asset_class", "") or "").upper()
    if (
        _asset_cls == "CRYPTO"
        and _tf_upper != "SWING"
        and (trust_tier_val == "RELIABLE" or trust_label == "RELIABLE")
    ):
        score -= 5

    # 2026-04-05: grade=A on CRYPTO = 70.2% WR on n=84 (+26.8pp) per Cursor data.
    # Strong signal, rare occurrence. Boost to capture edge.
    _pick_grade = str(pick.get("grade", "") or "").upper()
    if _pick_grade == "A" and _asset_cls in ("CRYPTO", "EQUITY"):
        score += 8

    # POSITION timeframe on CRYPTO = 31.5% WR (-12pp lift). Anti-signal.
    if _asset_cls == "CRYPTO" and _tf_upper == "POSITION":
        score -= 5

    # 5. Confidence sweet spot (0-10 pts) — 0.7-0.8 = 61.8% WR
    conf = _float(pick.get("confidence", 0))
    if 0.70 <= conf <= 0.80:
        score += 10  # Empirical sweet spot
    elif 0.55 <= conf < 0.70:
        score += 5
    elif 0.80 < conf <= 0.90:
        score += 6
    elif conf > SMART_PICKS_MAX_CONFIDENCE and not proven_edge:
        score -= 6
    # 0.6-0.7 is NOT penalized here (already done in base score)

    # 6. Technical alignment (0-10 pts) — 2/3+ alignment = 76-86% WR
    tech_bucket = _technical_alignment_bucket(pick)
    if tech_bucket == "full_support":
        score += 10
    elif tech_bucket == "strong_support":
        score += 8
    elif tech_bucket == "weak_support":
        score += 2
    elif tech_bucket == "no_support":
        score -= 6
    elif tech_bucket == "weak_opposition":
        score -= 8
    elif tech_bucket == "strong_opposition":
        score -= 12

    # 7. Multi-source consensus (0-8 pts)
    # Consensus only deserves a meaningful bonus when the track record supports it.
    agreement = _float(pick.get("agreement_count", 0))
    source_systems = pick.get("source_systems", [])
    if isinstance(source_systems, str):
        source_systems = [s.strip() for s in source_systems.split(",") if s.strip()]
    n_sources = max(len(source_systems), int(agreement))
    if n_sources >= 5:
        if proven_edge:
            score += 4
        elif decent_edge:
            score += 2
        elif weak_edge:
            score -= 4
        else:
            score += 1
    elif n_sources >= 3:
        if proven_edge or decent_edge:
            score += 4
        elif weak_edge:
            score -= 3
        else:
            score += 2
    elif n_sources == 2:
        if proven_edge or decent_edge:
            score += 3
        elif weak_edge:
            score -= 1
        else:
            score += 1

    # Bonuses for verified/proven sources
    verified_alpha_bonus = _verified_pm_or_copy_bonus(pick)
    if verified_alpha_bonus:
        score += min(verified_alpha_bonus * 0.5, 8)

    strategy = pick.get("strategy", "")
    if strategy in PROVEN_INVERSE_STRATEGIES:
        score += 5

    concentration_penalty = _concentration_penalty(pick)
    if concentration_penalty:
        score -= concentration_penalty

    wf_verdict = _wf_verdict(pick)
    if wf_verdict in {"ELITE", "STRONG"}:
        score += 6
    elif wf_verdict == "VIABLE":
        score += 3
    elif wf_verdict in {"DECAYING", "WEAK", "WARNING"}:
        score -= 5
    elif wf_verdict in {"FAILING", "REJECTED", "BROKEN"}:
        score -= 12

    if _has_direction_conflict(pick):
        score -= 10

    return round(max(0.0, min(score, 100)), 1)


def classify_pick_quality(pick: Dict[str, Any]) -> str:
    """
    DEPRECATED — use classify_pick_quality_v2.

    Uses a single global score threshold (SMART_PICKS_MIN_SCORE=50), which
    diverges from passes_smart_gate's per-asset floors + crypto LONG-only +
    forex forward-WR + RR + SCALP/panic exclusions. Kept for backward compat.
    """
    if not passes_active_gate(pick):
        return "REJECTED"
    score = _float(pick.get("score", 0))
    if score >= SMART_PICKS_MIN_SCORE:
        return "SMART"
    return "ACTIVE"


def classify_pick_quality_v2(pick: Dict[str, Any]) -> str:
    """
    Single source of truth for SMART/ACTIVE/REJECTED classification.

    Delegates to passes_active_gate + passes_smart_gate so analytics labels
    match production behavior. For post-hoc analytics on closed picks, clones
    status='ACTIVE' so the classifier evaluates at-issue quality regardless
    of current resolved state.

    Returns: 'SMART' | 'ACTIVE' | 'REJECTED'
    """
    if not isinstance(pick, dict):
        return "REJECTED"
    clone = dict(pick)
    clone["status"] = "ACTIVE"
    if not passes_active_gate(clone):
        return "REJECTED"
    if passes_smart_gate(clone):
        return "SMART"
    return "ACTIVE"


def get_pick_rationale(pick: Dict[str, Any]) -> Dict[str, Any]:
    """
    Generate human-readable rationale for why a pick passed/failed gates.
    """
    rationale = {
        "quality_tier": classify_pick_quality(pick),
        "smart_score": calculate_smart_score(pick),
        "checks": {},
        "passed_all": True,
    }

    # Active gate checks
    checks = {
        "has_valid_status": str(pick.get("status", "")).upper()
        in {"", "OPEN", "ACTIVE", "PENDING", "LIVE"},
        "has_entry_price": _float(pick.get("entry_price", 0)) > 0,
        "has_tp_sl": _float(pick.get("take_profit", 0)) > 0
        and _float(pick.get("stop_loss", 0)) > 0,
        "valid_trade_geometry": _has_valid_trade_geometry(pick),
        "not_killed": pick.get("strategy", "").lower() not in _KILLED_STRATEGIES_LOWER,
        "not_15m": not _is_15m_model(pick.get("strategy", "")),
        "fresh_enough": True,  # Would need timestamp check
        "allowed_tier": _get_strategy_tier(pick.get("strategy", ""))
        in ALLOWED_SOURCE_TIERS,
    }

    # Smart gate checks (if applicable)
    if all(checks.values()):
        score = _smart_floor_score(pick)
        conf = _float(pick.get("confidence", 0))
        ml = _float(pick.get("ml_score", 0))

        smart_checks = {
            "high_score": score >= SMART_PICKS_MIN_SCORE,
            "confidence_sweet_spot": SMART_PICKS_MIN_CONFIDENCE
            <= conf
            <= SMART_PICKS_MAX_CONFIDENCE,
            "ml_validated": ml >= SMART_PICKS_MIN_ML_SCORE,
            "trustworthy": (
                pick.get("trust_score") in (None, "")
                or _float(pick.get("trust_score")) >= SMART_PICKS_MIN_TRUST_SCORE
            )
            and str(pick.get("trust_label", "") or "").upper() not in {"LOW", "AVOID"}
            and _trust_tier(pick) not in BLOCKED_ACTIVE_TRUST_TIERS,
            "good_rr": True,  # Would need calculation
        }
        checks.update(smart_checks)
        rationale["passed_all_smart"] = all(smart_checks.values())

    rationale["checks"] = checks
    rationale["passed_all"] = all(checks.values())

    return rationale
