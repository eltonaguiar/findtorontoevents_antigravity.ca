    except Exception:
        _BLOCKED_SETS_CACHE['symbols'] = set()
        _BLOCKED_SETS_CACHE['is_strategy_blocked'] = lambda s, ac: False
        _BLOCKED_SETS_CACHE['asset_strategy_pairs'] = set()
    # Direction-aware triples (ml_crypto_predictor SHORT etc.) — separate
    # try/except since it was added in commit 0548fb746d follow-on; avoid
    # breaking older deployments that don't yet ship BLOCKED_DIRECTION_TRIPLES.
    try:
        from audit_trail.quality_gates import BLOCKED_DIRECTION_TRIPLES
        _BLOCKED_SETS_CACHE['direction_triples'] = BLOCKED_DIRECTION_TRIPLES
    except Exception:
        _BLOCKED_SETS_CACHE['direction_triples'] = set()
    # PERMANENTLY_KILLED_STRATEGIES — kept separate from BLOCKED_STRATEGIES.
    # Active-pick gating already drops new picks from these (via
    # _KILLED_STRATEGIES_LOWER), but the historical filter wasn't consulting
    # this set, so old closed picks from yahoo_analyst_consensus,
    # cta_tsmom_blend, hl_funding_fade, etc. were still polluting aggregations.
    # OpenClaw-MiMo 2026-04-17 investigation flagged this as a P0.
    try:
        from audit_trail.quality_gates import PERMANENTLY_KILLED_STRATEGIES
        _BLOCKED_SETS_CACHE['permanently_killed'] = {s.lower() for s in PERMANENTLY_KILLED_STRATEGIES}
    except Exception:
        _BLOCKED_SETS_CACHE['permanently_killed'] = set()
    return _BLOCKED_SETS_CACHE


def _is_historical_blocked_pick(pick: dict) -> bool:
    """True if this closed pick is on a strategy/symbol we've since blocked.

    Picks resolved BEFORE we identified a strategy or symbol as toxic stay in
    the closed ledger forever and continue to drag down headline metrics.
    Example surfaced 2026-04-18 audit: 7 historical TRXUSDT closes from
    `ml_enhanced_TRXUSDT_1d_B_light` contributed -554% to alpha_engine
    aggregate, even though TRXUSDT has been hard-blocked since 2026-04-02
    (nothing new can land on it). Excluding these from aggregations
    preserves the row in `recent_closed` but stops the bleed in WR/PF/PnL.

    Also addresses ml_crypto_pred (138/141 picks on `enhanced_ml_A_xgboost`,
    already in BLOCKED_STRATEGIES) and similar cleanup cases.
    """
    blocked = _get_blocked_sets()
    sym = str(pick.get("symbol") or "").upper()
    if sym in blocked['symbols']:
        return True
    strategy = pick.get("strategy") or ""
    asset_class = (
        str(pick.get("asset_class") or pick.get("category") or "").upper()
    )
    if blocked['is_strategy_blocked'](strategy, asset_class):
        return True
    # Also check the (asset_class, strategy) tuple set used by active-pick
    # gating. Same intent, different shape — see _get_blocked_sets() docstring.
    if (asset_class, str(strategy)) in blocked['asset_strategy_pairs']:
        return True
    # Direction-aware triples (ml_crypto_predictor SHORT etc.) — use this
    # when a strategy has edge in only one direction.
    direction = str(pick.get("direction", "") or "").upper()
    if direction and (asset_class, str(strategy), direction) in blocked['direction_triples']:
        return True
    # Permanently killed strategies — case-insensitive match. Active-pick
    # gating already drops these but the historical filter needs this
    # explicitly (OpenClaw-MiMo 2026-04-17). Includes yahoo_analyst_consensus
    # (0% WR n=55), cta_tsmom_blend (16.7% WR forex), binance_smart_money,
    # hl_funding_fade, winner_pattern_precursor, and many others.
    if str(strategy).lower() in blocked['permanently_killed']:
        return True
    return False


def _is_auto_expired_pick(pick: dict) -> bool:
    """Check if a closed pick is an auto-expired stale pick with no real outcome.

    Auto-expired picks have pnl_pct=0 and an exit_reason/status indicating
    staleness rather than a genuine TP/SL hit. Counting them inflates trade
    counts and deflates system-wide win rates.
    """
    pnl = float(pick.get("pnl_pct", 0) or 0)
    if pnl != 0:
        return False  # Has real PnL — not a no-outcome expiry

    # Check exit_reason field
    exit_reason = str(pick.get("exit_reason", "") or "").lower()
    for pattern in _AUTO_EXPIRED_PATTERNS:
        if pattern in exit_reason:
            return True

    # Check status field
    status = str(pick.get("status", "") or "").lower()
    if status in ("expired", "time_exit", "max_hold", "timed_out"):
        return True

    return False


def _is_valid_resolved_pick(pick: dict) -> bool:
    """Return True only for picks that should count in performance metrics.

    The dashboard displays many kinds of "closed" rows from different source
    systems. Some are legitimate realized outcomes; others are stale/snapshot
    rows that should not feed win rate, profit factor, or total PnL.
    """
    if not isinstance(pick, dict):
        return False
    if (
        pick.get("paper_trade")
        or pick.get("expired_no_pnl")
        or pick.get("_auto_expired")
    ):
        return False

    pnl_raw = pick.get("pnl_pct")
    if pnl_raw is None:
        return False

    # Reject rows where the recorded pnl_pct is incompatible with
    # (entry_price, exit_price, direction). These come from JPY-pair feeders
    # that confuse pips with percent — a single row can swing aggregate PF
    # by 100×. See _pnl_pct_looks_corrupt() above for thresholds.
    if _pnl_pct_looks_corrupt(pick):
        return False

    # Reject non-crypto rows whose entry/exit prices imply impossible moves
    # (>50% on forex/equity). Catches a separate failure mode where the
    # entry or exit price itself was stamped wrong (one AUDUSD=X row had
    # exit=76430 vs entry=0.715, contributing -106,700% to forex aggregate).
    # See _price_move_corrupt_for_non_crypto() above.
    if _price_move_corrupt_for_non_crypto(pick):
        return False

    # Reject ANY row (including crypto) where entry vs exit prices differ
    # by more than 100x. Catches symbol/price stamping bugs that even
    # affect crypto. Example: ZKUSDT entry=9.41 vs exit=0.01542 (612x
    # ratio) producing fake -99.84% wipeout that polluted super_signals.
    if _price_magnitude_corrupt(pick):
        return False

    # Reject historical rows from strategies/symbols we've since blocked.
    # These rows can't be re-traded but stay in the ledger and drag down
    # current performance metrics. Example: 7 historical TRXUSDT trades
    # contribute -554% to alpha_engine aggregate even though TRXUSDT has
    # been hard-blocked since 2026-04-02. See _is_historical_blocked_pick().
    if _is_historical_blocked_pick(pick):
        return False

    exit_reason = str(pick.get("exit_reason", "") or "").upper().strip()
    if exit_reason in _NON_PERFORMANCE_EXIT_REASONS:
        return False
    if exit_reason.startswith("STALE") or exit_reason == "INVALID_ENTRY":
        return False

    terminal_status = str(pick.get("status", "") or "").upper().strip()
    if terminal_status in _NON_PERFORMANCE_STATUSES:
        return False

    if exit_reason in ("", "UNKNOWN"):
        close_markers = (
            pick.get("closed_at")
            or pick.get("exit_timestamp")
            or pick.get("exit_time_est")
            or pick.get("exit_date")
        )
        if not close_markers and terminal_status not in {
            "WON",
            "LOST",
            "EXPIRED",
            "CLOSED",
        }:
            return False

    return True


def _filter_valid_resolved_picks(picks):
    """Filter a pick list down to realized, metric-safe resolved trades."""
    return [pick for pick in picks if _is_valid_resolved_pick(pick)]


def _compound_equal_weight_capped_sequence(
    picks: list[dict], max_pnl_pct: float = 500.0
) -> float:
    """Equal-notional geometric compound of capped per-trade PnL% (chronological).

    Each trade's ``pnl_pct`` is treated as a percent return on one unit of capital,
    capped at +/- ``max_pnl_pct`` to match headline summation, then multiplied in
    timestamp order (tie-break by symbol).
    """
    if not picks:
        return 0.0

    def _sort_key(p: dict) -> tuple[str, str]:
        return (str(p.get("timestamp") or ""), str(p.get("symbol") or ""))

    prod = 1.0
    for p in sorted(picks, key=_sort_key):
        raw = float(p.get("pnl_pct", 0) or 0)
        capped = max(-max_pnl_pct, min(max_pnl_pct, raw))
        prod *= 1.0 + capped / 100.0
    return round((prod - 1.0) * 100.0, 2)


def _outcome_bucket_from_pnl(
    pnl: float, threshold: float = _MIN_REALIZED_PNL_PCT
) -> str:
    """Classify a realized trade as win/loss/flat using a small noise threshold."""
    if pnl > threshold:
        return "win"
    if pnl < -threshold:
        return "loss"
    return "flat"


def _calculate_win_rate_pct(wins: int, losses: int, flat: int = 0) -> float:
    """Standardized WR formula: wins / (wins + losses + flat)."""
    total = wins + losses + flat
    return round(wins / total * 100, 1) if total > 0 else 0.0


def _calculate_expectancy_pct(
    total_pnl: float, wins: int, losses: int, flat: int = 0
) -> float:
    """Average PnL per resolved trade, including flat outcomes in the denominator."""
    total = wins + losses + flat
    return round(total_pnl / total, 2) if total > 0 else 0.0


def _looks_resolved_source_pick(raw: dict) -> bool:
    """Detect closed/resolved rows embedded inside an "active" source file."""
    if not isinstance(raw, dict):
        return False
    if _is_closed_status(raw.get("status", "")):
        return True

    explicit_close_time = (
        raw.get("resolved_at")
        or raw.get("_resolved_at")
        or raw.get("resolvedAt")
        or raw.get("resolved_at_est")
        or raw.get("closed_at")
        or raw.get("closedAt")
        or raw.get("closed_at_est")
        or raw.get("exit_time")
        or raw.get("exitTime")
        or raw.get("exit_time_est")
        or raw.get("exit_timestamp")
        or raw.get("exitDate")
        or raw.get("exit_date")
        or raw.get("close_time")
        or raw.get("closeTime")
        or raw.get("closeDate")
    )
    if explicit_close_time:
        return True

    outcome_marker = (
        str(
            raw.get(
                "exit_reason",
                raw.get(
                    "close_reason", raw.get("resolved_reason", raw.get("outcome", ""))
                ),
            )
            or ""
        )
        .upper()
        .strip()
    )
    if outcome_marker and outcome_marker not in {
        "OPEN",
        "ACTIVE",
        "PENDING",
        "LIVE",
        "READY",
        "UNRESOLVED",
        "UNKNOWN",
        "NONE",
        "NULL",
    }:
        return True

    exit_price = _float(
        raw.get(
            "exit_price",
            raw.get(
                "close_price",
                raw.get("_resolved_price", 0),
            ),
        )
    )
    if exit_price > 0:
        return True
    pnl_raw = raw.get(
        "pnl_pct",
        raw.get(
            "actual_pnl_pct",
            raw.get(
                "outcome_pnl_pct",
                raw.get(
                    "plPercent",
                    raw.get(
                        "_resolved_pnl_pct",
                        raw.get("pnl_dollar", raw.get("unrealized_pnl_pct", None)),
                    ),
                ),
            ),
        ),
    )
    try:
        if (
            pnl_raw not in (None, "")
            and abs(float(pnl_raw)) >= _MIN_REALIZED_PNL_PCT
            and outcome_marker
            and outcome_marker
            not in {
                "OPEN",
                "ACTIVE",
                "PENDING",
                "LIVE",
                "READY",
                "UNRESOLVED",
                "UNKNOWN",
                "NONE",
                "NULL",
            }
        ):
            return True
    except (TypeError, ValueError):
        pass
    return False


def _pick_identity_key(pick: dict):
    """Stable logical identity used to match active picks to resolved outcomes."""
    raw_id = pick.get(
        "id", pick.get("pick_id", pick.get("signal_id", pick.get("prediction_id", "")))
    )
    if raw_id not in (None, ""):
        return ("id", pick.get("source_system", ""), str(raw_id))
    ts = str(pick.get("timestamp", "") or "").strip()
    ts_key = ts[:19] if ts else ""
    entry = _float(pick.get("entry_price", 0) or 0)
    return (
        "fallback",
        pick.get("source_system", ""),
        _normalize_symbol(pick.get("symbol", "")),
        str(pick.get("direction", "")).upper(),
        str(pick.get("strategy", "") or ""),
        round(entry, 8) if entry else 0.0,
        ts_key,
    )


def _closed_conflict_key(pick: dict):
    """Broader key used to drop stale shadow rows when a real resolved twin exists."""
    raw_id = pick.get(
        "id", pick.get("pick_id", pick.get("signal_id", pick.get("prediction_id", "")))
    )
    if raw_id not in (None, ""):
        return ("id", pick.get("source_system", ""), str(raw_id))
    entry = _float(pick.get("entry_price", 0) or 0)
    return (
        "fallback",
        pick.get("source_system", ""),
        _normalize_symbol(pick.get("symbol", "")),
        str(pick.get("direction", "")).upper(),
        str(pick.get("strategy", "") or ""),
        round(entry, 8) if entry else 0.0,
    )


def _prefer_metric_safe_closed_picks(picks: list[dict]) -> tuple[list[dict], int]:
    """When the same logical pick appears twice, keep the metric-safe resolved version."""
    grouped = defaultdict(list)
    for pick in picks:
        grouped[_closed_conflict_key(pick)].append(pick)

    kept = []
    dropped = 0
    for group in grouped.values():
        valid = [p for p in group if _is_valid_resolved_pick(p)]
        if valid:
            kept.extend(valid)
            dropped += len(group) - len(valid)
        else:
            kept.extend(group)
    return kept, dropped


def _is_closed_status(raw_status: str) -> bool:
    """Check if a status string represents a closed/resolved pick."""
    return str(raw_status).lower().strip() in _CLOSED_STATUSES


def _logical_dashboard_source_system(
    source_system: str, raw: dict, asset_class: str
) -> str:
    """Map bridge-managed rows back to the logical dashboard system.

    The multi-asset bridge mirrors non-crypto picks into both alpha-engine and the
    dedicated multi-asset files. We need one stable logical system name so actives and
    realized closes line up on /audit. Preserve the explicit multi-asset subsystem
    (`multi_asset_copytrader`, `multi_asset_scanner`, etc.) instead of collapsing those
    rows into a generic `multi_asset` bucket.
    """
    if source_system != "alpha_engine" or not isinstance(raw, dict):
        if source_system == "multi_asset":
            raw_source = str(raw.get("source_system", "") or "").strip()
            if asset_class.upper() != "CRYPTO" and raw_source.startswith(
                "multi_asset_"
            ):
                return raw_source
        return source_system

    raw_source = str(raw.get("source_system", "") or "").strip()
    if not raw_source:
        return source_system

    if asset_class.upper() == "CRYPTO":
        return source_system

    if raw_source.startswith("multi_asset_"):
        return raw_source
    if raw_source.startswith("cta_"):
        return "multi_asset"

    return source_system


def _is_prediction_market_pick(
    source_system: str,
    dashboard_source_system: str,
    raw: dict,
    strategy: str,
) -> bool:
    candidates = {
        str(source_system or "").strip().lower(),
        str(dashboard_source_system or "").strip().lower(),
        str(raw.get("source_system", "") or "").strip().lower(),
        str(raw.get("source_subsystem", "") or "").strip().lower(),
    }
    if candidates & {
        "pm_whale_signals",
        "pm_momentum_signals",
        "pm_kalshi_signals",
        "prediction_market_consensus",
        "pm_high_conviction",
        "polymarket_whale_tracker",
        "polymarket_momentum",
        "kalshi_signal_agent",
        "polymarket_signals",
        "polymarket",
    }:
        return True

    strat = (
        str(strategy or raw.get("strategy") or raw.get("strategy_name") or "")
        .strip()
        .lower()
    )
    return (
        strat.startswith("copy_pm_")
        or strat.startswith("pm_whale_")
        or strat.startswith("pm_momentum")
        or "polymarket" in strat
        or "kalshi" in strat
    )


def _derive_prediction_market_trade_levels(
    entry_price: float,
    direction: str,
    confidence: float,
    source_count: int = 1,
) -> tuple[float, float]:
    """Convert a PM signal-only row into a concrete spot trade frame."""
    if entry_price <= 0:
        return (0.0, 0.0)

    conf = max(0.55, min(0.95, _float(confidence or 0.70)))
    source_bonus = max(0, min(int(source_count or 1) - 1, 3))
    tp_pct = min(0.04, max(0.015, 0.014 + (conf - 0.55) * 0.04 + source_bonus * 0.0025))
    sl_pct = max(0.009, tp_pct / 1.67)

    if str(direction).upper() == "SHORT":
        return (
            round(entry_price * (1 - tp_pct), 8),
            round(entry_price * (1 + sl_pct), 8),
        )
    return (
        round(entry_price * (1 + tp_pct), 8),
        round(entry_price * (1 - sl_pct), 8),
    )


def _snapshot_prediction_market_entry(pick: dict, current_price: float) -> bool:
    """Backfill entry/TP/SL for PM rows that arrive as signal-only objects."""
    if current_price <= 0:
        return False
    if _float(pick.get("entry_price", 0)) > 0:
        return False

    direction = str(pick.get("direction", "LONG") or "LONG").upper()
    if direction not in {"LONG", "SHORT"}:
        direction = "LONG"

    source_count = 1
    consensus_data = pick.get("consensus_data")
    if isinstance(consensus_data, dict):
        source_count = (
            consensus_data.get("source_category_count")
            or consensus_data.get("num_sources")
            or source_count
        )

    entry_price = round(float(current_price), 8)
    pick["entry_price"] = entry_price
    if _float(pick.get("take_profit", 0)) <= 0 or _float(pick.get("stop_loss", 0)) <= 0:
        take_profit, stop_loss = _derive_prediction_market_trade_levels(
            entry_price,
            direction,
            _float(pick.get("confidence", 0.70)),
            int(source_count or 1),
        )
        pick["take_profit"] = take_profit
        pick["stop_loss"] = stop_loss
    return True


# Verified Alpha sources - prediction markets + auditable copy trading
_VERIFIED_ALPHA_PM_SOURCES = {
    "pm_whale_signals",
    "pm_kalshi_signals",
    "prediction_market_consensus",
    "polymarket_signals",
    "pm_high_conviction",
    "pm_momentum_signals",
}
_VERIFIED_ALPHA_COPY_SOURCES = {
    "copy_trader_intel",
    "copy_trader_highscore",
    "copy_trader_consensus",
    "copy_trader_clones",
    "highscore_pick",
    "alpha_engine",
    "smart_picks",
}
_VERIFIED_ALPHA_CURATED_COPY_STRATEGIES = {
    "forex_rsi2_mean_reversion",
    "stocks_rsi2_pullback",
    "cftc_cot_commercial_signal",
    "cot_positioning",
    "cta_commodity_momentum_term",
    "cta_cross_asset_tsmom",
    "cta_golden_cross_200",
}
# Strategy prefixes that indicate verified copy trading with audit trail
_VERIFIED_ALPHA_COPY_PREFIXES = (
    "copy_pm_",
    "clone_hl_",
    "copy_hl_",
    "hs_",
    "consensus_",
)
_TRACK_RECORD_CLOSED_SOURCES = {
    "copy_trader_intel",
    "multi_asset_copytrader",
    "multi_asset",
    "multi_asset_institutional",
    "cta_replicator",
    "pm_whale_signals",
    "pm_kalshi_signals",
    "polymarket_signals",
    "prediction_market_consensus",
}
# Non-crypto asset classes that should always have reserved closed-pick slots.
# Without reservation, high-frequency crypto picks crowd them out of the 1000 cap.
_NON_CRYPTO_ASSET_CLASSES = {"EQUITY", "ETF", "FOREX", "FUTURES", "COMMODITY", "BOND"}


def _track_stats_key(strategy: str, symbol: str) -> str:
    """Return canonical key for per-(strategy, symbol) track stats lookup."""
    return f"{strategy}::{symbol}"


def _source_symbol_track_key(source_system: str, symbol: str) -> str:
    """Key for per-(source_system, symbol) stats (super-signal `via` is a system id)."""
    sys_key = (source_system or "").strip().lower()
    sym = _normalize_symbol(symbol)
    return f"{sys_key}::{sym}"


def _super_signal_via_feeder_candidates(via_token: str) -> list[str]:
    """Expand `via` segment to possible source_system values on closed rows.

    Super signals label strategies as ``super signal (tier) via <X>`` where ``X``
    comes from ``source_system`` of the winning feeder pick, not from that
    pick's ``strategy`` field (see ``cross_aggregation/super_signal.py``).
    Closed-trade rows keep real algo names in ``strategy`` and the feeder in
    ``source_system``, so we must match the ledger by system+symbol too.
    """
    v0 = (via_token or "").strip()
    if not v0:
        return []
    v = v0.lower()
    out: list[str] = []
    seen: set[str] = set()

    def add(x: str) -> None:
        x = (x or "").strip()
        if not x or x.lower() in seen:
            return
        seen.add(x.lower())
        out.append(x)

    add(v0)
    # Common dashboard / file variants for the same feeder
    alias_extra: dict[str, tuple[str, ...]] = {
        "kimi": ("kimi_live_signals", "kimi_live"),
        "kimi_live": ("kimi", "kimi_live_signals"),
        "kimi_live_signals": ("kimi", "kimi_live"),
        "alpha_engine": ("alpha_engine_fast",),
        "alpha_engine_fast": ("alpha_engine",),
    }
    for extra in alias_extra.get(v, ()):
        add(extra)
    return out


def _build_source_symbol_track_stats(closed_picks: list) -> dict:
    """Like _build_strategy_symbol_track_stats but keyed by source_system+symbol."""
    stats: dict[str, dict] = {}
    for pick in closed_picks:
        sys_name = (pick.get("source_system") or "").strip()
        sym = _normalize_symbol(pick.get("symbol", ""))
        if not sys_name or not sym:
            continue
        key = _source_symbol_track_key(sys_name, sym)
        if key not in stats:
            stats[key] = {
                "sym_track_total": 0,
                "sym_track_wins": 0,
                "sym_track_losses": 0,
                "sym_track_wr": None,
                "sym_track_pnl": 0.0,
            }
        entry = stats[key]
        entry["sym_track_total"] += 1
        pnl = float(pick.get("pnl_pct", 0) or 0)
        entry["sym_track_pnl"] = round(entry["sym_track_pnl"] + pnl, 4)
        status = (pick.get("status") or pick.get("outcome") or "").upper()
        exit_reason = (pick.get("exit_reason") or "").upper()
        if exit_reason == "TP_HIT":
            entry["sym_track_wins"] += 1
        elif exit_reason == "SL_HIT":
            entry["sym_track_losses"] += 1
        elif status in ("WON", "WIN", "TP_HIT", "CLOSED_TP"):
            entry["sym_track_wins"] += 1
        elif status in ("LOST", "LOSS", "SL_HIT", "CLOSED_SL"):
            entry["sym_track_losses"] += 1
        elif exit_reason == "TIME_EXIT" or status == "CLOSED":
            if pnl > 0.01:
                entry["sym_track_wins"] += 1
            elif pnl < -0.01:
                entry["sym_track_losses"] += 1
    for entry in stats.values():
        resolved = entry["sym_track_wins"] + entry["sym_track_losses"]
        entry["sym_track_wr"] = (
            round(entry["sym_track_wins"] / resolved * 100, 1) if resolved > 0 else None
        )
    return stats


def _build_strategy_symbol_track_stats(closed_picks: list) -> dict:
    """Build per-(strategy, symbol) win statistics from closed picks.

    Returns a dict keyed by ``_track_stats_key(strat, sym)`` where each value
    has keys: sym_track_total, sym_track_wins, sym_track_losses, sym_track_wr,
    sym_track_pnl.
    """
    stats: dict[str, dict] = {}
    for pick in closed_picks:
        strat = pick.get("strategy", "")
        sym = _normalize_symbol(pick.get("symbol", ""))
        if not strat or not sym:
            continue
        key = _track_stats_key(strat, sym)
        if key not in stats:
            stats[key] = {
                "sym_track_total": 0,
                "sym_track_wins": 0,
                "sym_track_losses": 0,
                "sym_track_wr": None,
                "sym_track_pnl": 0.0,
            }
        entry = stats[key]
        entry["sym_track_total"] += 1
        pnl = float(pick.get("pnl_pct", 0) or 0)
        entry["sym_track_pnl"] = round(entry["sym_track_pnl"] + pnl, 4)
        status = (pick.get("status") or pick.get("outcome") or "").upper()
        exit_reason = (pick.get("exit_reason") or "").upper()
        # Universal resolver rows often use status=CLOSED + exit_reason=TP_HIT/SL_HIT/TIME_EXIT
        if exit_reason == "TP_HIT":
            entry["sym_track_wins"] += 1
        elif exit_reason == "SL_HIT":
            entry["sym_track_losses"] += 1
        elif status in ("WON", "WIN", "TP_HIT", "CLOSED_TP"):
            entry["sym_track_wins"] += 1
        elif status in ("LOST", "LOSS", "SL_HIT", "CLOSED_SL"):
            entry["sym_track_losses"] += 1
        elif exit_reason == "TIME_EXIT" or status == "CLOSED":
            if pnl > 0.01:
                entry["sym_track_wins"] += 1
            elif pnl < -0.01:
                entry["sym_track_losses"] += 1
    # Compute WR for each entry
    for entry in stats.values():
        resolved = entry["sym_track_wins"] + entry["sym_track_losses"]
        entry["sym_track_wr"] = (
            round(entry["sym_track_wins"] / resolved * 100, 1) if resolved > 0 else None
        )
    return stats


def compute_asset_class_health(ac_breakdown: dict) -> dict:
    """Min-N aware health labels per asset class for dashboard UI.

    Uses resolved win/loss counts from ``ac_breakdown`` (same basis as WR/PF).
    """
    min_stable_n = 50
    min_display_n = 10
    out: dict[str, dict] = {}
    for ac_raw, b in (ac_breakdown or {}).items():
        ac = str(ac_raw).upper()
        wins = int(b.get("wins") or 0)
        losses = int(b.get("losses") or 0)
        n = wins + losses
        wr = float(b.get("win_rate") or 0)
        pnl = float(b.get("pnl") or 0)
        pf_raw = b.get("profit_factor")
        try:
            pf = float(pf_raw) if pf_raw is not None else None
        except (TypeError, ValueError):
            pf = None
        if n < min_display_n:
            status = "insufficient_data"
        elif n < min_stable_n:
            status = "thin_sample"
        elif wr < 38.0 or pnl < -80.0 or (pf is not None and pf < 0.82):
            status = "stressed"
        elif wr >= 45.0 and (pf is None or pf >= 1.0) and pnl >= 0:
            status = "stable"
        else:
            status = "watch"
        out[ac] = {
            "status": status,
            "resolved_n": n,
            "win_rate": wr,
            "total_pnl_pct": round(pnl, 2),
            "profit_factor": pf,
            "min_stable_n": min_stable_n,
        }
    return out


def _compute_closed_pnl_concentration_by_source(
    resolved_closed: list, max_pnl_cap: float = 500.0
):
    """Share of capped *winning* PnL by source_system (pipeline concentration)."""
    by_sys: dict[str, float] = {}
    for p in resolved_closed:
        sys = (p.get("source_system") or "unknown").strip() or "unknown"
        raw = float(p.get("pnl_pct", 0) or 0)
        pnl = max(-max_pnl_cap, min(max_pnl_cap, raw))
        if pnl > 0:
            by_sys[sys] = by_sys.get(sys, 0.0) + pnl
    pos_total = sum(by_sys.values())
    if pos_total <= 0:
        return None
    ranked = sorted(by_sys.items(), key=lambda x: x[1], reverse=True)
    top1_sys, top1_pnl = ranked[0]
    top3_pnl = sum(v for _, v in ranked[:3])
    top_sources = []
    for s, v in ranked[:5]:
        top_sources.append(
            {
                "source_system": s,
                "share_pct": round(100.0 * v / pos_total, 1),
                "pnl_capped_sum": round(v, 2),
            }
        )
    return {
        "positive_pnl_sum_capped": round(pos_total, 2),
        "top1_source_system": top1_sys,
        "top1_share_pct": round(100.0 * top1_pnl / pos_total, 1),
        "top3_share_pct": round(100.0 * top3_pnl / pos_total, 1),
        "top_sources": top_sources,
    }


def _is_verified_alpha_pick(pick: dict) -> bool:
    """Determine if a pick qualifies as 'Verified Alpha'.

    Verified Alpha includes:
    - Prediction market signals (Kalshi, Polymarket, consensus)
    - Copy trader signals with verified track records
    - High-score and consensus copy trader picks
    """
    source = str((pick or {}).get("source_system", "") or "").strip().lower()
    strategy = str((pick or {}).get("strategy", "") or "").strip().lower()

    # Prediction market sources
    if source in _VERIFIED_ALPHA_PM_SOURCES:
        return True

    # Copy trader sources with audit trail
    if source in _VERIFIED_ALPHA_COPY_SOURCES:
        return True

    # Strategy prefixes indicating verified copy trading
    if any(strategy.startswith(prefix) for prefix in _VERIFIED_ALPHA_COPY_PREFIXES):
        return True

    # Curated multi-asset strategies
    if (
        source == "multi_asset_copytrader"
        and strategy in _VERIFIED_ALPHA_CURATED_COPY_STRATEGIES
    ):
        return True

    # Picks with verified trader labels or strong forward track records
    # Normalize WR: could be stored as 0.60 (60%) or 60 (60%)
    forward_wr = _float((pick or {}).get("forward_wr"))
    if forward_wr > 1.5:  # Stored as percentage (e.g., 60 = 60%)
        forward_wr = forward_wr / 100.0
    forward_trades = int(_float((pick or {}).get("forward_trades", 0)))
    if forward_wr >= 0.55 and forward_trades >= 10:  # Tightened n>=5->10 (compromise) (2026-04-15): n>=5..9 picks had 66.7% WR; n>=5 passed 94%% of picks, no edge
        return True

    # v102: Expanded verified-alpha gates
    # Systems with history WR >= 55% on 20+ closed trades
    history_wr = _float((pick or {}).get("history_wr"))
    if history_wr > 1.5:
        history_wr = history_wr / 100.0
    history_trades = int(_float((pick or {}).get("history_trades", 0)))
    # 2026-04-05 (tweak #1): Add rolling freshness check. Stale history_wr was letting
    # alpha_engine (1094 closed picks, 34.5% realized WR) flood VA cohort and drag
    # realized WR from 55%+ down to 44%. Now require rolling_90d_wr or recent live
    # performance to confirm history is still applicable.
    if history_wr >= 0.55 and history_trades >= 20:
        _rolling_90d_wr = _float((pick or {}).get("rolling_90d_wr"))
        if _rolling_90d_wr > 1.5: _rolling_90d_wr = _rolling_90d_wr / 100.0
        _recent_wr = _float((pick or {}).get("strat_last10_wr") or (pick or {}).get("fwd_last10_wr") or 0)
        if _recent_wr > 1.5: _recent_wr = _recent_wr / 100.0
        # If we have recent data, it must still show edge (>=0.50). If no recent data,
        # fall through to other gates rather than promoting on stale history alone.
        if (_rolling_90d_wr >= 0.50) or (_recent_wr >= 0.50):
            return True
        if _rolling_90d_wr == 0 and _recent_wr == 0:
            # No recent data available — use history with caution, keep old behavior
            return True

    # Walk-forward validated picks (p-value < 0.05)
    wf_p = _float((pick or {}).get("wf_p_value"))
    if 0 < wf_p < 0.05:
        return True

    # v102: Robustness - check strat_fwd_wr fields if primary forward_wr is missing
    fwd_wr = _float(pick.get("strat_fwd_wr", pick.get("forward_wr")))
    if fwd_wr > 1.5:
        fwd_wr = fwd_wr / 100.0
    fwd_trades = int(_float(pick.get("strat_fwd_trades", pick.get("forward_trades", 0))))
    if fwd_wr >= 0.55 and fwd_trades >= 10:  # Tightened n>=5->10 (compromise) (2026-04-15): n>=5..9 picks had 66.7% WR; n>=5 passed 94%% of picks, no edge
        return True

    # High-score + high-trust picks (score >= 80, trust_score >= 6)
    score = _float((pick or {}).get("score", 0))
    trust = _float((pick or {}).get("trust_score", 0))
    if score >= 80 and trust >= 6:
        return True

    # High-conviction consensus with decent history
    agreement = int(_float(pick.get("agreement_count", 0)))
    if agreement >= 3 and fwd_wr >= 0.50 and fwd_trades >= 3:
        return True

    # 2026-04-05 (tweak #2): Explicit REALIZED ALPHA exemption.
    # Sources with >=100 closed picks at realized WR >=55% are auto-promoted to VA.
    # This whitelist was computed from 3500 closed picks: claude_gainer_st (540 closed,
    # 63.0% WR, +248% cum), kimi_riseoftheclaw (54, 57.4%, +37%), signal_validation
    # (21, 76.2%, +29%). Prevents under-representation of proven winners - previously
    # claude_gainer_st had only 2/35 VA slots despite being the best-realized source.
    _REALIZED_ALPHA_SOURCES = {
        "claude_gainer_st",       # 540 closed, 63.0% WR, +248% cum
        "signal_validation",      # 21 closed, 76.2% WR, +29% cum
        "dna_winner_picks",       # 57 closed, 56.1% WR, +42% cum
    }
    if source in _REALIZED_ALPHA_SOURCES:
        return True

    return False


def _normalize_wr_pct(value) -> float | None:
    wr = _float(value)
    if wr <= 0:
        return None
    if wr <= 1.5:
        wr *= 100.0
    if wr > 100:
        return None
    return round(wr, 2)


def _shrink_wr_pct(
    wr_pct: float | None, sample_size: int | float | None
) -> float | None:
    if wr_pct is None:
        return None
    sample = max(0, int(_float(sample_size)))
    weight = min(sample, 20) / 20.0
    return round(50.0 + (float(wr_pct) - 50.0) * weight, 2)


def _extract_verified_alpha_audit(pick: dict) -> dict | None:
    sample_candidates = [
        int(_float((pick or {}).get("history_trades"))),
        int(_float((pick or {}).get("forward_trades"))),
        int(_float((pick or {}).get("consensus_count"))),
    ]
    sample = max(sample_candidates) if sample_candidates else 0

    for field in (
        "history_wr_bayes",
        "profile_crypto_wr_bayes",
        "history_wr",
        "profile_crypto_wr",
        "forward_wr",
    ):
        wr_pct = _normalize_wr_pct((pick or {}).get(field))
        if wr_pct is None:
            continue
        shrunk = _shrink_wr_pct(wr_pct, sample)
        return {
            "wr_pct": wr_pct,
            "shrunk_wr_pct": shrunk,
            "sample_size": sample,
            "field": field,
        }
    return None


def _enrich_va_cohort_fields(pick: dict) -> None:
    """Attach verifiable cohort metadata for Verified Alpha rows (HF P0 truth layer)."""
    if not _is_verified_alpha_pick(pick):
        return
    if pick.get("va_cohort_id"):
        return
    audit = _extract_verified_alpha_audit(pick)
    pick["va_rule_version"] = "1"
    if audit:
        fld = str(audit.get("field") or "wr").replace(" ", "_")
        n = int(_float(audit.get("sample_size")))
        pick["va_cohort_id"] = "va_%s_n%d" % (fld, n)
        pick["va_cohort_n"] = n
        pick["va_cohort_basis"] = str(audit.get("field") or "")
        pick["va_cohort_wr_pct"] = audit.get("wr_pct")
    else:
        n = max(
            int(_float(pick.get("forward_trades", 0))),
            int(_float(pick.get("history_trades", 0))),
            int(_float(pick.get("strat_fwd_trades", 0))),
        )
        pick["va_cohort_id"] = "va_multi_gate"
        pick["va_cohort_n"] = n
        pick["va_cohort_basis"] = "composite_gate"
        pick["va_cohort_wr_pct"] = None


def _median(values: list[float]) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    mid = len(ordered) // 2
    if len(ordered) % 2:
        return ordered[mid]
    return (ordered[mid - 1] + ordered[mid]) / 2


def _closed_pick_identity(pick: dict) -> tuple:
    return (
        str((pick or {}).get("source_system") or ""),
        str((pick or {}).get("strategy") or ""),
        str((pick or {}).get("symbol") or ""),
        str((pick or {}).get("direction") or ""),
        str((pick or {}).get("timestamp") or ""),
        str((pick or {}).get("status") or ""),
    )


def _should_reserve_closed_pick_for_track_record(pick: dict) -> bool:
    source = str((pick or {}).get("source_system", "") or "").strip().lower()
    if source in _TRACK_RECORD_CLOSED_SOURCES:
        return True
    # Reserve non-crypto picks so they aren't crowded out by high-frequency crypto
    asset_class = str((pick or {}).get("asset_class") or (pick or {}).get("category") or "").upper().strip()
    if asset_class in _NON_CRYPTO_ASSET_CLASSES:
        return True
    return _is_verified_alpha_pick(pick)


_NC_ASSET_CLASSES = frozenset(
    {"FOREX", "EQUITY", "STOCK", "COMMODITY", "FUTURES", "ETF", "BOND"}
)
_NC_ALIAS_MAP = {
    "FX": "FOREX",
    "EQUITIES": "EQUITY",
    "STOCKS": "STOCK",
    "COMMODITIES": "COMMODITY",
    "FUTURE": "FUTURES",
    "BONDS": "BOND",
}


def _normalize_nc_asset(value) -> str:
    ac = str(value or "").upper().strip()
    return _NC_ALIAS_MAP.get(ac, ac)


def nc_asset_category_for_pick(pick: dict) -> str | None:
    """Non-crypto performance bucket: asset_class/category first, then symbol heuristics
    aligned with ``audit_dashboard/template.html`` ``matchCategory`` (forex =X, XAU/XAG, =F).
    Falls back to ``classify_asset`` so plain tickers (ETF, equity, bond) still bucket
    when feeders omit ``asset_class`` (fixes under-counted Futures / ETF / Bond cards).
    """
    for field in ("asset_class", "category"):
        normalized = _normalize_nc_asset(pick.get(field))
        if normalized == "MICRO_FUTURES":
            return "FUTURES"
        if normalized in _NC_ASSET_CLASSES:
            return normalized
    sym = str((pick or {}).get("symbol") or "").upper()
    if "=X" in sym:
        return "FOREX"
    if sym.startswith("XAU") or sym.startswith("XAG"):
        return "COMMODITY"
    if sym.endswith("=F"):
        return "FUTURES"
    if not sym:
        return None
    try:
        from audit_trail.asset_classification import AssetClass, classify_asset

        resolved = classify_asset(sym)
        if resolved in (AssetClass.CRYPTO, AssetClass.MEME, AssetClass.UNKNOWN):
            return None
        if resolved == AssetClass.MICRO_FUTURES:
            return "FUTURES"
        val = resolved.value
        if val in _NC_ASSET_CLASSES:
            return val
    except Exception:
        pass
    return None


def _dedupe_closed_trades_by_canonical_id(
    closed: list[dict],
) -> tuple[list[dict], int]:
    """Collapse duplicate closed rows that share the same ``id`` (institutional shadow rows,
    MySQL re-ingest, etc.). Keeps the copy whose ``pnl_pct`` best matches entry/exit-implied PnL.
    """
    from collections import defaultdict

    buckets: dict[str, list[dict]] = defaultdict(list)
    out_no_id: list[dict] = []
    for p in closed or []:
        if not isinstance(p, dict):
            continue
        pid = str((p.get("id") or "")).strip()
        if pid and pid.lower() not in ("null", "none", "-"):
            buckets[pid].append(p)
        else:
            out_no_id.append(p)
    merged: list[dict] = []
    dropped = 0

    def _implied_pnl_entry_exit(p: dict) -> float | None:
        e = _float(p.get("entry_price", 0) or 0)
        x = _float(p.get("exit_price", 0) or 0)
        if e <= 0 or x <= 0:
            return None
        d = str(p.get("direction", "LONG")).upper()
        if d == "SHORT":
            return round((e - x) / e * 100, 4)
        return round((x - e) / e * 100, 4)

    for _pid, group in buckets.items():
        if len(group) == 1:
            merged.append(group[0])
            continue

        def _quality_score(p: dict) -> float:
            stored = _float(p.get("pnl_pct", 0) or 0)
            imp = _implied_pnl_entry_exit(p)
            score = 0.0
            if imp is not None:
                score -= abs(stored - imp)
                if abs(stored - imp) < 0.05:
                    score += 100.0
            else:
                score -= min(500.0, abs(stored))
            if _float(p.get("exit_price", 0) or 0) > 0:
                score += 20.0
            if abs(stored) > 75:
                score -= 200.0
            er = str(p.get("exit_reason", "") or "").upper()
            if er in ("", "CLOSED", "UNKNOWN") and abs(stored) > 20:
                score -= 50.0
            return score

        best = max(group, key=_quality_score)
        merged.append(best)
        dropped += len(group) - 1

    return out_no_id + merged, dropped


def _build_recent_closed_picks(
    resolved_closed: list[dict],
    max_picks: int = MAX_CLOSED_PICKS,
    reserved_slots: int = RESERVED_TRACK_RECORD_CLOSED_PICKS,
    nc_reserved_slots: int = RESERVED_NON_CRYPTO_CLOSED_PICKS,
) -> list[dict]:
    """Build the published closed list with reservations for track-record and non-crypto.

    Two reservation passes run first (non-crypto + track-record) so that the
    payload cap never crowds out equity/forex/commodity/ETF history.

    Non-crypto reservation is balanced per asset class so smaller categories
    (ETF, FUTURES, BOND) don't get crowded out by larger ones (FOREX, EQUITY).
    """
    ordered = sorted(
        resolved_closed or [], key=lambda x: x.get("timestamp", ""), reverse=True
    )
    if len(ordered) <= max_picks:
        return ordered

    reserved_slots = max(0, min(int(reserved_slots), int(max_picks)))
    nc_reserved_slots = max(0, min(int(nc_reserved_slots), int(max_picks) - reserved_slots))
    seen: set[tuple] = set()

    # Pass 1: Reserve non-crypto closed picks, BALANCED per category.
    # Without per-category quota, FOREX/EQUITY (largest populations) crowd out
    # ETF/FUTURES/BOND entirely — drill-down modals then show empty tables.
    nc_reserved: list[dict] = []
    if nc_reserved_slots > 0:
        # Bucket non-crypto picks by category (same rules as compute_non_crypto_performance)
        nc_buckets: dict[str, list[dict]] = {}
        for pick in ordered:
            cat = nc_asset_category_for_pick(pick)
            if cat is None:
                continue
            nc_buckets.setdefault(cat, []).append(pick)

        # Per-category quota: at least floor(nc_reserved_slots / 7) per category,
        # but never more than what the category has. Remaining slots distributed
        # proportionally to category size.
        num_cats = len(_NC_ASSET_CLASSES)  # 7 categories
        base_quota = max(1, nc_reserved_slots // num_cats)
        quotas: dict[str, int] = {}
        for cat in _NC_ASSET_CLASSES:
            available = len(nc_buckets.get(cat, []))
            quotas[cat] = min(base_quota, available)

        # Distribute remaining slots (from unused small-category quota)
        # proportionally among categories that have more picks to offer.
        used = sum(quotas.values())
        remaining = nc_reserved_slots - used
        if remaining > 0:
            # Categories that can hold more
            expandable = [c for c in _NC_ASSET_CLASSES if len(nc_buckets.get(c, [])) > quotas[c]]
            while remaining > 0 and expandable:
                # Round-robin among expandable categories by remaining capacity
                expandable.sort(key=lambda c: -(len(nc_buckets.get(c, [])) - quotas[c]))
                progress = False
                for cat in list(expandable):
                    if remaining <= 0:
                        break
                    if len(nc_buckets.get(cat, [])) > quotas[cat]:
                        quotas[cat] += 1
                        remaining -= 1
                        progress = True
                    else:
                        expandable.remove(cat)
                if not progress:
                    break

        # Fill reservation per category quota (in timestamp desc order per bucket)
        for cat, bucket in nc_buckets.items():
            quota = quotas.get(cat, 0)
            for pick in bucket[:quota]:
                key = _closed_pick_identity(pick)
                if key in seen:
                    continue
                nc_reserved.append(pick)
                seen.add(key)

    # Pass 2: Reserve track-record picks (copy-traders, prediction markets)
    tr_reserved: list[dict] = []
    for pick in ordered:
        if not _should_reserve_closed_pick_for_track_record(pick):
            continue
        key = _closed_pick_identity(pick)
        if key in seen:
            continue
        tr_reserved.append(pick)
        seen.add(key)
        if len(tr_reserved) >= reserved_slots:
            break

    # Pass 3: Fill remaining slots with most recent picks
    recent_closed: list[dict] = nc_reserved + tr_reserved
    for pick in ordered:
        key = _closed_pick_identity(pick)
        if key in seen:
            continue
        recent_closed.append(pick)
        seen.add(key)
        if len(recent_closed) >= max_picks:
            break

    return sorted(
        recent_closed[:max_picks],
        key=lambda x: x.get("timestamp", ""),
        reverse=True,
    )


def _apply_issue186_exit_normalization(resolved_closed: list[dict]) -> int:
    """Refine legacy binary exit labels using TP/SL distance (issue #186).

    See ``normalize_exit_reason`` in ``quality_gates.py``. Skipped when env
    ``AUDIT_SKIP_EXIT_NORMALIZATION=1`` is set. Persists ``exit_reason_raw`` once
    for audit; sets ``exit_reason`` to the canonical refined value.
    """
    if os.environ.get("AUDIT_SKIP_EXIT_NORMALIZATION", "").strip() == "1":
        return 0
    if not resolved_closed:
        return 0
    changed = 0
    for p in resolved_closed:
        if not isinstance(p, dict):
            continue
        if "exit_reason_raw" not in p:
            p["exit_reason_raw"] = str(
                p.get("exit_reason") or p.get("close_reason") or ""
            )
        before_display = str(p.get("exit_reason") or "").strip().upper()
        p["exit_reason"] = p["exit_reason_raw"]
        try:
            after = normalize_exit_reason(p)
        except Exception:
            after = before_display or "UNKNOWN"
        if str(after).upper() != before_display:
            changed += 1
        p["exit_reason"] = after
    return changed


def _compute_verified_alpha_summary(
    active_picks: list[dict],
    smart_picks: list[dict],
    closed_picks: list[dict],
) -> dict:
    active_rows = [p for p in (active_picks or []) if _is_verified_alpha_pick(p)]
    smart_rows = [p for p in (smart_picks or []) if _is_verified_alpha_pick(p)]
    closed_rows = [p for p in (closed_picks or []) if _is_verified_alpha_pick(p)]

    wins = losses = flat = 0
    total_pnl = 0.0
    for pick in closed_rows:
        pnl = _float(pick.get("pnl_pct"))
        total_pnl += pnl
        if pnl > 0:
            wins += 1
        elif pnl < 0:
            losses += 1
        else:
            flat += 1

    realized_total = wins + losses + flat
    realized_wr = round((wins / realized_total) * 100, 1) if realized_total else None
    expectancy = round(total_pnl / realized_total, 2) if realized_total else None

    source_mix = defaultdict(int)
    audited_rows = []
    shrunk_values = []
    raw_values = []
    weighted_sum = 0.0
    weighted_weight = 0.0
    for pick in active_rows:
        source_mix[str(pick.get("source_system") or "unknown")] += 1
        audit_meta = _extract_verified_alpha_audit(pick)
        if not audit_meta:
            continue
        audited_rows.append(audit_meta)
        raw_values.append(audit_meta["wr_pct"])
        if audit_meta["shrunk_wr_pct"] is not None:
            shrunk_values.append(audit_meta["shrunk_wr_pct"])
            weight = max(1.0, min(float(audit_meta["sample_size"] or 0), 20.0))
            weighted_sum += audit_meta["shrunk_wr_pct"] * weight
            weighted_weight += weight

    audited_weighted = (
        round(weighted_sum / weighted_weight, 1) if weighted_weight > 0 else None
    )
    audited_avg = round(sum(raw_values) / len(raw_values), 1) if raw_values else None
    audited_median = round(_median(shrunk_values), 1) if shrunk_values else None
    audited_sample_avg = (
        round(sum(a["sample_size"] for a in audited_rows) / len(audited_rows), 1)
        if audited_rows
        else None
    )

    note = (
        "No resolved verified-alpha trades yet; use audited source WR for upstream edge and the live verified-alpha mix for current portfolio composition."
        if realized_total == 0
        else "Verified-alpha realized WR reflects only the PM / auditable pro-trader cohort, separate from the all-systems headline."
    )

    return {
        "active_count": len(active_rows),
        "smart_count": len(smart_rows),
        "active_share_pct": round(
            len(active_rows) / max(len(active_picks or []), 1) * 100, 1
        ),
        "smart_share_pct": round(
            len(smart_rows) / max(len(smart_picks or []), 1) * 100, 1
        )
        if smart_picks
        else 0.0,
        "unique_sources": len(source_mix),
        "source_mix": dict(
            sorted(source_mix.items(), key=lambda item: (-item[1], item[0]))
        ),
        "realized": {
            "trades": realized_total,
            "wins": wins,
            "losses": losses,
            "flat": flat,
            "win_rate": realized_wr,
            "total_pnl_pct": round(total_pnl, 2),
            "expectancy": expectancy,
        },
        "audited": {
            "covered_active_picks": len(audited_rows),
            "avg_wr_pct": audited_avg,
            "weighted_wr_pct": audited_weighted,
            "median_wr_pct": audited_median,
            "avg_sample_size": audited_sample_avg,
        },
        # Slim list so peers / APIs need not re-run _is_verified_alpha_pick on the full book.
        "active_pick_refs": [
            {
                "id": pick.get("id"),
                "symbol": pick.get("symbol"),
                "source_system": pick.get("source_system"),
                "strategy": pick.get("strategy"),
                "direction": pick.get("direction") or pick.get("signal_type"),
            }
            for pick in active_rows
        ],
        "status_note": note,
    }


def _prepare_prediction_market_consensus_signal(raw_pick: dict) -> dict:
    pick = dict(raw_pick or {})
    consensus_data = pick.get("consensus_data", {}) or {}
    source_count = int(
        _float(
            pick.get("source_count")
            or consensus_data.get("source_category_count")
            or consensus_data.get("num_sources")
            or pick.get("agreement_count")
            or 0
        )
    )
    pick["agreement_count"] = source_count
    pick["source_count"] = source_count
    source_systems = (
        pick.get("pm_source_systems")
        or pick.get("source_systems")
        or pick.get("sources")
        or consensus_data.get("sources")
        or []
    )
    if isinstance(source_systems, str):
        source_systems = [s.strip() for s in source_systems.split(",") if s.strip()]
    deduped_sources = []
    seen_sources = set()
    for source_name in source_systems:
        clean_name = str(source_name or "").strip()
        if not clean_name or clean_name in seen_sources:
            continue
        seen_sources.add(clean_name)
        deduped_sources.append(clean_name)
    pick["pm_source_systems"] = deduped_sources
    if not pick.get("source_systems"):
        pick["source_systems"] = list(deduped_sources)

    if pick.get("high_conviction") is None:
        fwd_wr = _float(
            pick.get("forward_wr")
            or pick.get("strat_fwd_wr")
            or consensus_data.get("forward_wr")
            or 0
        )
        fwd_trades = int(
            _float(
                pick.get("forward_trades")
                or pick.get("strat_fwd_trades")
                or consensus_data.get("forward_trades")
                or 0
            )
        )
        consensus_bias = _float(
            consensus_data.get("consensus_score")
            or pick.get("consensus_score")
            or 0
        )
        pick["high_conviction"] = bool(
            consensus_data.get("high_conviction")
            or (
                source_count >= 3
                and fwd_wr >= 55
                and fwd_trades >= 8
                and consensus_bias >= 0
            )
        )

    pick["source_system"] = "prediction_market_consensus"
    if not pick.get("strategy"):
        pick["strategy"] = "prediction_market_consensus"
    if not pick.get("type_label"):
        pick["type_label"] = "🔮 PM Consensus"

    return pick


def _load_prediction_market_consensus_signals() -> tuple[list[dict], str | None]:
    primary_path = ROOT / "alpha_engine" / "data" / "prediction_market_picks.json"
    primary_raw = _safe_json(primary_path)
    primary_signals = []
    if isinstance(primary_raw, dict):
        primary_signals = primary_raw.get("picks", []) or []
    elif isinstance(primary_raw, list):
        primary_signals = primary_raw
    if primary_signals:
        return (
            [
                _prepare_prediction_market_consensus_signal(p)
                for p in primary_signals
                if isinstance(p, dict)
            ],
            str(primary_path),
        )

    fallback_path = (
        ROOT / "prediction_market_agents" / "data" / "consensus_signals.json"
    )
    fallback_raw = _safe_json(fallback_path)
    fallback_signals = []
    if isinstance(fallback_raw, dict):
        fallback_signals = fallback_raw.get("signals", []) or []
    elif isinstance(fallback_raw, list):
        fallback_signals = fallback_raw
    if fallback_signals:
        return (
            [
                _prepare_prediction_market_consensus_signal(p)
                for p in fallback_signals
                if isinstance(p, dict)
            ],
            str(fallback_path),
        )

    return ([], None)


def _refresh_verified_alpha_system_stats(
    systems: list[dict], active_picks: list[dict]
) -> None:
    """Refresh audited WR fallback fields from the final enriched active feed."""
    if not systems or not active_picks:
        return

    audit_by_system: dict[str, dict] = {}
    for pick in active_picks:
        if not _is_verified_alpha_pick(pick):
            continue
        audit_meta = _extract_verified_alpha_audit(pick)
        if not audit_meta:
            continue
        sys_name = str(pick.get("source_system") or "").strip()
        if not sys_name:
            continue
        bucket = audit_by_system.setdefault(
            sys_name,
            {
                "covered": 0,
                "weighted_sum": 0.0,
                "weighted_weight": 0.0,
                "sample_sum": 0.0,
            },
        )
        sample = max(1, int(_float(audit_meta.get("sample_size"))))
        effective_wr = audit_meta.get("shrunk_wr_pct")
        if effective_wr is None:
            effective_wr = audit_meta.get("wr_pct")
        if effective_wr is None:
            continue
        bucket["covered"] += 1
        bucket["weighted_sum"] += float(effective_wr) * sample
        bucket["weighted_weight"] += sample
        bucket["sample_sum"] += sample

    for system in systems:
        name = str((system or {}).get("name") or "").strip()
        stats = audit_by_system.get(name)
        if not stats or stats["weighted_weight"] <= 0:
            continue
        audited_wr = round(stats["weighted_sum"] / stats["weighted_weight"], 1)
        system["audited_wr_pct"] = audited_wr
        system["audited_wr_coverage"] = int(stats["covered"])
        system["audited_avg_sample_size"] = round(
            stats["sample_sum"] / stats["covered"], 1
        )
        if int(_float(system.get("resolved_picks"))) <= 0:
            system["win_rate_basis"] = "audited"
            system["display_win_rate_pct"] = audited_wr


def _derive_pm_trader_label(raw: dict) -> str | None:
    label = raw.get("trader_label")
    if label:
        return str(label)

    whale_data = (
        raw.get("whale_data") if isinstance(raw.get("whale_data"), dict) else {}
    )
    label = (
        raw.get("trader_name")
        or raw.get("username")
        or raw.get("user_name")
        or whale_data.get("username")
    )
    if label:
        return str(label)

    wallet = raw.get("trader_address") or whale_data.get("wallet")
    if not wallet:
        return None
    wallet = str(wallet)
    if len(wallet) <= 12:
        return wallet
    return f"{wallet[:8]}...{wallet[-4:]}"


def _derive_pm_type_label(raw: dict, dashboard_source_system: str) -> str:
    existing = raw.get("type_label")
    if existing:
        return str(existing)

    if dashboard_source_system == "pm_high_conviction" or raw.get("high_conviction"):
        return "🔮 PM High Conviction"

    source_hint = " ".join(
        [
            str(dashboard_source_system or ""),
            str(raw.get("source_system", "") or ""),
            str(raw.get("strategy", "") or ""),
        ]
    ).lower()
    if "kalshi" in source_hint:
        return "🔮 PM Kalshi"
    if "momentum" in source_hint:
        return "🔮 PM Momentum"

    origin = str(raw.get("signal_origin") or "").strip().lower()
    if origin == "vetted_wallet_copy":
        return "🔮 PM Vetted"
    if origin == "direct_position_inference":
        return "🔮 PM Whale"
    return "🔮 PM"


def _resolve_status(raw: dict, caller_status: str, pnl_val: float) -> str:
    """Preserve original WIN/LOSS status for closed picks instead of flattening to CLOSED.
    BUG FIX: _normalize_pick was destroying original status values, causing Agreement Matrix
    to show 0W/0L for all systems."""
    if caller_status != "CLOSED":
        return caller_status
    # Check original status from source data
    orig = (
        str(
            raw.get(
                "status",
                raw.get(
                    "outcome",
                    raw.get("exit_reason", raw.get("_resolved_exit_reason", "")),
                ),
            )
        )
        .upper()
        .strip()
    )
    if orig in (
        "WIN",
        "WON",
        "TP_HIT",
        "TP_1_5_HIT",
        "TP_2_0_HIT",
        "CLOSED_TP",
        "TAKE_PROFIT",
    ):
        return "WON"
    if orig in ("LOSS", "LOST", "SL_HIT", "CLOSED_SL", "STOP_LOSS"):
        return "LOST"
    if orig in ("TRAIL_SL", "TRAILING_STOP"):
        return "LOST"
    if orig in ("EXPIRED", "TIMEOUT", "TIME", "TIME_EXIT", "TIME_EXIT_AFTER_TP_1_5"):
        # Use PnL to determine win/loss for expired picks
        if pnl_val > 0:
            return "WON"
        elif pnl_val < 0:
            return "LOST"
        return "EXPIRED"
    # Recognize outcome_resolver exit reasons
    if orig in ("TP_HIT_RESOLVED", "EXIT_PRICE_RESOLVED", "PRICE_RESOLVED"):
        if pnl_val > 0:
            return "WON"
        elif pnl_val < 0:
            return "LOST"
        return "FLAT"
    if orig in ("SL_HIT_RESOLVED",):
        return "LOST"
    if orig in ("FLAT",):
        return "FLAT"
    # Fallback: use PnL to classify
    if pnl_val > 0:
        return "WON"
    elif pnl_val < 0:
        return "LOST"
    # 0-PnL picks that have no exit reason: mark as UNRESOLVED so dashboard
    # can distinguish them from genuine flat outcomes
    exit_reason = str(raw.get("exit_reason", "")).upper().strip()
    if not exit_reason and pnl_val == 0:
        return "UNRESOLVED"
    return "CLOSED"


def _coerce_closed_zero_pnl_from_outcome(
    raw: dict, caller_status: str, pnl_val: float
) -> float:
    """Use a tiny signed sentinel when a closed outcome is explicit but PnL is missing."""
    if caller_status != "CLOSED" or abs(pnl_val) > 1e-9:
        return pnl_val
    orig = (
        str(
            raw.get(
                "status",
                raw.get(
                    "outcome",
                    raw.get("exit_reason", raw.get("_resolved_exit_reason", "")),
                ),
            )
        )
        .upper()
        .strip()
    )
    if orig in {"LOSS", "LOST", "SL_HIT", "CLOSED_SL", "STOP_LOSS"}:
        return -0.01
    if orig in {"WIN", "WON", "TP_HIT", "CLOSED_TP", "TAKE_PROFIT"}:
        return 0.01
    return pnl_val


def _normalize_goldmine_closed_trade(raw: dict) -> dict:
    """Pre-normalize goldmine closed_trades.json schema to match _normalize_pick expectations.

    Goldmine uses: ticker, final_return_pct, entry_date, exit_date, algo_count.
    _normalize_pick expects: symbol, pnl_pct, timestamp, closed_at, strategy.
    Without this mapping, goldmine closed trades have no symbol/strategy -> fwdN=0 for all picks.
    """
    pick = dict(raw)
    # ticker -> symbol (pop to avoid duplicate)
    pick["symbol"] = pick.pop("ticker", pick.get("symbol", ""))
    # final_return_pct -> pnl_pct (sign already correct for most;
    # LOSS with frp=0 happens on "removed_from_consensus" exits)
    frp = float(pick.pop("final_return_pct", 0) or 0)
    pick["pnl_pct"] = frp
    # timestamps
    pick["closed_at"] = pick.get("exit_date")
    pick["timestamp"] = pick.get("entry_date")
    # Derive strategy from consensus_count (matching active handler) falling back to algo_count
    algo_n = int(pick.pop("consensus_count", None) or pick.pop("algo_count", 1) or 1)
    pick["strategy"] = "goldmine_%dx_consensus" % algo_n
    return pick


def _normalize_pick(raw, source_system: str, status: str = "OPEN") -> dict:
    """Normalize a pick from any source into a common schema."""
    if not isinstance(raw, dict):
        return {"symbol": "", "direction": "", "skip": True}  # malformed entry
    symbol = raw.get("symbol", raw.get("pair", raw.get("ticker", "")))
    direction = str(
        raw.get(
            "direction",
            raw.get("signal_type", raw.get("signal", raw.get("action", ""))),
        )
    ).upper()
    if "BUY" in direction or "LONG" in direction or direction == "OVER":
        direction = "LONG"
    elif "SELL" in direction or "SHORT" in direction or direction == "UNDER":
        direction = "SHORT"
    elif not direction or direction in ("", "NONE", "UNKNOWN"):
        # Infer from TP/SL vs entry: if TP > entry, it's LONG
        _e = _float(raw.get("entry_price", raw.get("entryPrice", raw.get("entry", 0))))
        _t = _float(
            raw.get(
                "take_profit",
                raw.get(
                    "target_price",
                    raw.get("targetPrice", raw.get("tp", raw.get("tp1_price", 0))),
                ),
            )
        )
        if _e and _t:
            direction = "LONG" if _t > _e else "SHORT"
        else:
            direction = "LONG"  # default assumption

    entry = raw.get(
        "entry_price", raw.get("entryPrice", raw.get("entry", raw.get("price", 0)))
    )
    tp_candidates = [
        "take_profit", "target_price", "targetPrice", "tp", "tp_price",
        "tp_price_1_5", "tp_pct", "suggested_tp_pct"
    ]
    tp = 0
    for k in tp_candidates:
        if raw.get(k) is not None:
            tp = raw.get(k)
            break

    sl_candidates = [
        "stop_loss", "stop_price", "stopPrice", "sl", "sl_price",
        "sl_pct", "suggested_sl_pct"
    ]
    sl = 0
    for k in sl_candidates:
        if raw.get(k) is not None:
            sl = raw.get(k)
            break
    conf = _extract_confidence(raw)
    strategy = raw.get("strategy", raw.get("strategy_name", raw.get("algorithm", "")))
    # Goldmine equity: align strategy with active consensus rows so closed ledger
    # forward stats join as goldmine_stocks::goldmine_Nx_consensus.
    if (
        not strategy
        and str(source_system).lower() == "goldmine_stocks"
    ):
        _gm_n = raw.get("consensus_count")
        if _gm_n is None:
            _gm_n = raw.get("algo_count")
        if _gm_n is not None:
            try:
                _gm_i = int(_gm_n)
                if _gm_i > 0:
                    strategy = "goldmine_%dx_consensus" % _gm_i
            except (TypeError, ValueError):
                pass
    # Consensus/aggregated picks often have strategy=null — build from available fields
    if not strategy:
        consensus_tier = raw.get("consensus_tier", "")
        src_systems = raw.get("source_systems", [])
        src_strategies = raw.get("source_strategies", {})
        if src_strategies and isinstance(src_strategies, dict):
            # Use the first strategy from the highest-priority system
            for prio_sys in [
                "battleground",
                "alpha_engine",
                "kimi_riseoftheclaw",
                "kimi",
            ]:
                if prio_sys in src_strategies:
                    strategy = src_strategies[prio_sys]
                    break
            if not strategy:
                strategy = next(iter(src_strategies.values()), "")
        if not strategy and src_systems:
            strategy = (
                f"{consensus_tier.lower()} consensus ({', '.join(src_systems[:3])})"
            )
        elif not strategy and consensus_tier:
            strategy = f"{consensus_tier.lower()} consensus"
    if not strategy:
        strategy = raw.get("source") or raw.get("source_system") or source_system
    asset_class = _derive_asset_class(
        symbol, raw=raw, source_system=source_system, strategy=strategy
    )
    # CRYPTO TAGGING FIX (2026-04-05): Explicit source-based crypto assignment
    # Fixes ~1,142+ untagged crypto picks from CEX integrations (okx_picks, bybit_picks, etc)
    # These copy trader intel sources are 99%+ crypto instruments
    if asset_class == "UNKNOWN" and source_system in (
        "copy_trader_intel",
        "copy_trader_highscore",
        "copy_trader_clones",
        "copy_trader_variations",
        "copy_trader_consensus",
    ):
        # If symbol doesn't match explicit non-crypto patterns, assume CRYPTO
        sym_upper = str(symbol or "").upper()
        is_futures_or_forex = any(
            sym_upper.endswith(sfx) for sfx in ["=F", "=X", ".TO", ".L", ".AX"]
        )
        if not is_futures_or_forex:
            asset_class = "CRYPTO"
    dashboard_source_system = _logical_dashboard_source_system(
        source_system, raw, asset_class
    )
    is_pm_pick = _is_prediction_market_pick(
        source_system, dashboard_source_system, raw, strategy
    )
    trader_label = (
        _derive_pm_trader_label(raw) if is_pm_pick else raw.get("trader_label")
    )
    type_label = (
        _derive_pm_type_label(raw, dashboard_source_system)
        if is_pm_pick
        else raw.get("type_label")
    )
    pm_source_systems = (
        raw.get("pm_source_systems", []) or raw.get("source_systems", []) or []
    )
    if isinstance(pm_source_systems, str):
        pm_source_systems = [
            s.strip() for s in pm_source_systems.split(",") if s.strip()
        ]
    source_count = raw.get("source_count")
    if source_count is None:
        consensus_data = raw.get("consensus_data", {}) or {}
        source_count = (
            consensus_data.get("source_category_count")
            or consensus_data.get("num_sources")
            or raw.get("consensus_count")
        )
    # Pass source_strategies through for frontend display
    source_strategies = raw.get("source_strategies", {})
    raw_status_u = str(raw.get("status", "") or "").upper()
    pipeline_status_u = str(status or "").upper()
    prefer_book_pnl = pipeline_status_u == "CLOSED" or raw_status_u in (
        "CLOSED",
        "WON",
        "LOST",
        "EXPIRED",
        "RESOLVED",
    )
    if prefer_book_pnl:
        pnl = raw.get(
            "net_pnl_pct",
            raw.get(
                "realized_pnl_pct",
                raw.get(
                    "final_return_pct",
                    raw.get(
                        "pnl_pct",
                        raw.get(
                            "actual_pnl_pct",
                            raw.get(
                                "plPercent",
                                raw.get(
                                    "unrealized_pnl_pct",
                                    raw.get(
                                        "_resolved_pnl_pct",
                                        raw.get("pnl_dollar", 0),
                                    ),
                                ),
                            ),
                        ),
                    ),
                ),
            ),
        )
    else:
        pnl = raw.get(
            "pnl_pct",
            raw.get(
                "actual_pnl_pct",
                raw.get(
                    "plPercent",
                    raw.get(
                        "unrealized_pnl_pct",
                        # 2026-04-14: goldmine_stocks closed_trades.json reports
                        # final_return_pct (e.g. -1.66, +11.88) — add it to the
                        # fallback chain so goldmine closes get real PnL instead
                        # of defaulting to 0 (which made every goldmine WIN look
                        # like a flat trade in the strategy leaderboard).
                        raw.get(
                            "final_return_pct",
                            raw.get("_resolved_pnl_pct", raw.get("pnl_dollar", 0)),
                        ),
                    ),
                ),
            ),
        )
    exit_reason = raw.get(
        "exit_reason",
        raw.get(
            "close_reason",
            raw.get(
                "resolved_reason",
                raw.get("outcome", raw.get("_resolved_exit_reason", "")),
            ),
        ),
    )

    pnl_val = _float(pnl)
    entry_val = _float(entry)
    exit_price = _float(
        raw.get(
            "exit_price",
            raw.get(
                "close_price",
                raw.get(
                    "current_price",
                    raw.get("currentPrice", raw.get("_resolved_price", 0)),
                ),
            ),
        )
    )
    if entry_val > 0 and exit_price <= 0 and pnl_val != 0 and status != "OPEN":
        if direction == "SHORT":
            exit_price = round(entry_val * (1 - pnl_val / 100), 8)
        else:
            exit_price = round(entry_val * (1 + pnl_val / 100), 8)

    # PnL normalization: prefer calculating from prices (no ambiguity),
    # fall back to reported value with careful fraction detection.
    if entry_val > 0 and exit_price > 0:
        # Always trust price-derived PnL over reported values
        if direction == "SHORT":
            pnl_val = round((entry_val - exit_price) / entry_val * 100, 4)
        else:
            pnl_val = round((exit_price - entry_val) / entry_val * 100, 4)
    elif pnl_val != 0 and -1.0 < pnl_val < 1.0:
        # No prices available — must decide if reported PnL is a fraction or percentage.
        # Only convert if it looks unambiguously like a fraction (e.g. 0.05 = 5%).
        # Values like -0.5 or +0.8 are ambiguous: could be -0.5% or -50%.
        # Use a tight threshold: only auto-convert values whose magnitude < 0.10
        # (i.e., < 10% when converted). Larger values stay as-is (treated as percentages).
        if abs(pnl_val) < 0.10:
            pnl_val = round(pnl_val * 100, 4)

    # Asset-aware cap at ingest: crypto may exceed ±100% legitimately; FX/equity
    # rows beyond ±200% are almost always pip/price corruption (see pnl_ingest_sanity).
    _pnl_pre_clamp = float(pnl_val)
    pnl_val, pnl_was_clamped = clamp_pnl_pct_for_pick(
        _pnl_pre_clamp, str(asset_class or "UNKNOWN").upper()
    )

    pnl_val = _coerce_closed_zero_pnl_from_outcome(raw, status, pnl_val)

    tp_val = _float(tp)
    sl_val = _float(sl)
    conf_val = conf  # Already a float from _extract_confidence()

    # Auto-compute missing TP/SL from ATR when available
    # A pick without exit levels is untradeable — estimate from ATR or % fallback
    if entry_val > 0:
        atr_val = _float(raw.get("atr_at_entry", raw.get("atr", 0)))
        if not tp_val and not sl_val:
            # No TP and no SL — use ATR if available, else asset-class defaults
            if atr_val > 0:
                if direction == "LONG":
                    tp_val = round(entry_val + 2.5 * atr_val, 8)
                    sl_val = round(entry_val - 1.5 * atr_val, 8)
                else:
                    tp_val = round(entry_val - 2.5 * atr_val, 8)
                    sl_val = round(entry_val + 1.5 * atr_val, 8)
            else:
                # Fallback: asset-class-appropriate TP/SL from policy caps
                _ac_defaults = {
                    "EQUITY": (0.08, 0.05),   # 8% TP, 5% SL
                    "ETF":    (0.05, 0.03),   # 5% TP, 3% SL
                    "FOREX":  (0.015, 0.01),  # 1.5% TP, 1% SL
                    "COMMODITY": (0.03, 0.02),# 3% TP, 2% SL
                    "FUTURES": (0.03, 0.02),  # 3% TP, 2% SL
                }
                _fb_tp, _fb_sl = _ac_defaults.get(
