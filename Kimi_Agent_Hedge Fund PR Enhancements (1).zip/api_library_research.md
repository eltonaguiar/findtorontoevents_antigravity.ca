# Comprehensive Research: Free APIs, Libraries & Data Sources by Asset Class

**Research Date**: 2026-05-11
**Purpose**: Identify free/low-cost data sources, open-source libraries, backtesting protocols, and new strategies by asset class for systematic trading research.

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Free APIs by Asset Class](#2-free-apis-by-asset-class)
   - 2.1 [Crypto](#21-crypto)
   - 2.2 [Equity](#22-equity)
   - 2.3 [Forex](#23-forex)
   - 2.4 [Commodity](#24-commodity)
   - 2.5 [Bond](#25-bond)
   - 2.6 [ETF](#26-etf)
   - 2.7 [Futures](#27-futures)
3. [GitHub Libraries for Speed-to-Quality](#3-github-libraries-for-speed-to-quality)
4. [Backtesting Protocol per Asset Class](#4-backtesting-protocol-per-asset-class)
5. [New Strategies to Research per Asset Class](#5-new-strategies-to-research-per-asset-class)
6. [Quick Edge Detection Report Algorithm](#6-quick-edge-detection-report-algorithm)
7. [Integration Roadmap & Priorities](#7-integration-roadmap--priorities)
8. [Appendix: Code Examples](#8-appendix-code-examples)

---

## 1. Executive Summary

| Asset Class | Primary API | Best Supplemental | Free Data Quality | Integration Effort |
|-------------|-------------|-------------------|-------------------|-------------------|
| **Crypto** | CoinGecko (10k/mo) + CCXT (exchange-native) | CryptoCompare (250k/mo) | High for prices; on-chain requires paid tier | 2-4 hrs |
| **Equity** | yfinance (unlimited scraping) | Finnhub (60/min) | High for OHLCV; fundamentals patchy | 1-3 hrs |
| **Forex** | Alpha Vantage (25/day) | FRED (macro, free) | Moderate; delayed | 2-4 hrs |
| **Commodity** | Yahoo Finance + Quandl (limited free) | OilPriceAPI (1k/mo) | Low-Medium; limited free futures data | 4-8 hrs |
| **Bond** | FRED (yield curve, free) | Yahoo Finance (bond ETFs) | High for Treasury yields | 1-2 hrs |
| **ETF** | yfinance | Finnhub (fund flows) | High | 1-2 hrs |
| **Futures** | Polygon.io (5/min free) + Yahoo | Quandl (limited) | Low on free tier; mostly US | 4-8 hrs |

**Key Insight**: No single free API covers all asset classes well. A **multi-API architecture** is required. For production reliability, yfinance should be treated as a "best effort" source with fallbacks to official APIs.

---

## 2. Free APIs by Asset Class

### 2.1 Crypto

#### Primary Data API: CoinGecko + CCXT

| Attribute | CoinGecko | CCXT (via Binance/Bybit) |
|-----------|-------------|--------------------------|
| **Free Tier** | 10,000 calls/month, 30 calls/min | Unlimited public market data |
| **API Key** | Demo key recommended but not required | None for public data |
| **Data Coverage** | 37M+ tokens across 250+ chains | Per-exchange (thousands of pairs) |
| **OHLCV History** | 1 year daily/hourly on free tier | Extensive (exchange-dependent) |
| **On-Chain Data** | Limited DEX trade data | None |
| **Data Quality** | Aggregator; 60s cache on free tier | Raw exchange data; real-time |
| **Integration** | REST JSON; simple Python SDK | Unified API across 120+ exchanges |
| **Effort Estimate** | 1-2 hours | 2-3 hours |

**CoinGecko Code Example:**
```python
import requests

def get_crypto_ohlc(coin_id="bitcoin", vs_currency="usd", days=365):
    url = f"https://api.coingecko.com/api/v3/coins/{coin_id}/ohlc"
    params = {"vs_currency": vs_currency, "days": days}
    r = requests.get(url, params=params)
    return r.json()  # returns [timestamp, open, high, low, close]
```

#### Supplemental APIs

| API | Purpose | Free Tier | Rate Limit | Integration |
|-----|---------|-----------|------------|-------------|
| **CryptoCompare** | Historical OHLCV, social volume | 250,000 calls/month | ~8,000/day | 1-2 hrs |
| **Glassnode** | On-chain metrics (MVRV, NUPL, SOPR) | UI only (daily, basic metrics). **API requires $999/yr Professional + add-on** | N/A for free | Manual download only |
| **TheBlock** | DeFi analytics, flows | No free API tier | N/A | Web scraping only |
| **Reddit API** | Meme coin sentiment | Free (OAuth) | 100 requests/min per OAuth client | 3-4 hrs |
| **Twitter/X API** | Social sentiment | Free tier: 500 posts/month read | 1 request/15 min app auth | 3-4 hrs |
| **Messari** | On-chain + market data | Free Basic UI; Enterprise for API | N/A | Manual only |
| **Binance API** | Free direct exchange data | Unlimited public endpoints | 1,200 weight/min | 1-2 hrs |

**Data Points We DON'T Currently Have (Free Tier Accessible):**
- Social volume/sentiment scores (CryptoCompare social)
- Exchange flow data (Glassnode UI can be scraped)
- Funding rates (Binance API, free)
- Long/short ratios (Binance API, free)
- DEX volume data (CoinGecko, free tier)

---

### 2.2 Equity

#### Primary Data API: Yahoo Finance (yfinance)

| Attribute | yfinance |
|-----------|----------|
| **Free Tier** | Unlimited (unofficial scraping) |
| **API Key** | None required |
| **Data Coverage** | Global equities, ETFs, mutual funds, options |
| **OHLCV History** | Decades of daily data; 1m intraday (7 days) |
| **Fundamentals** | Income statement, balance sheet, cash flow (patchy coverage) |
| **Data Quality** | Good for prices; fundamentals incomplete; options unreliable |
| **Risk** | Yahoo can block IP; not for production high-frequency |
| **Integration** | `pip install yfinance` |
| **Effort Estimate** | 30 minutes |

**yfinance Code Example:**
```python
import yfinance as yf

ticker = yf.Ticker("AAPL")
hist = ticker.history(period="5y", interval="1d")  # OHLCV + dividends + splits
info = ticker.info  # market cap, P/E, sector, etc.
```

#### Secondary API: Finnhub

| Attribute | Finnhub |
|-----------|---------|
| **Free Tier** | 60 calls/minute + WebSocket for 50 symbols |
| **API Key** | Required (free signup) |
| **Data Coverage** | 65,000+ global companies, stocks, ETFs, crypto, forex |
| **Real-Time** | Yes (US equities, slight delay on free tier) |
| **Alternative Data** | Reddit/Twitter sentiment, insider transactions, ESG, congressional trading |
| **Fundamentals** | 30+ years financial statements |
| **Effort Estimate** | 1-2 hours |

#### Supplemental APIs

| API | Purpose | Free Tier | Rate Limit | Integration |
|-----|---------|-----------|------------|-------------|
| **Alpha Vantage** | Technical indicators (50+ pre-computed) | 25 calls/day | 5/min | 1-2 hrs |
| **Polygon.io** | US tick data, options | 5 req/min | 5/min | 1-2 hrs |
| **IEX Cloud** | US equities | **DISCONTINUED Aug 2024** | N/A | N/A |
| **Finnhub** | Real-time quotes, sentiment | 60/min | 60/min | 1-2 hrs |
| **Quandl/NASDAQ Data Link** | Alternative data, macro | Limited free datasets | Dataset-dependent | 2-4 hrs |
| **FRED** | Macro context (unemployment, CPI, rates) | Unlimited (open) | No hard limit | 30 min |

**Data Points We DON'T Currently Have:**
- Pre-computed technical indicators (Alpha Vantage)
- Real-time US equity quotes (Finnhub free tier)
- Social media sentiment scores (Finnhub)
- Congressional trading activity (Finnhub alternative data)
- ESG scores (Finnhub)
- Earnings call transcripts (Finnhub paid)

---

### 2.3 Forex

#### Primary Data API: Alpha Vantage + FRED

| Attribute | Alpha Vantage (Forex) | FRED (Macro Context) |
|-----------|----------------------|---------------------|
| **Free Tier** | 25 calls/day | Unlimited (open access) |
| **API Key** | Required | Not required |
| **Data Coverage** | 150+ physical & digital currency pairs | US macro: rates, GDP, CPI, unemployment, yield curve |
| **OHLCV History** | Daily, weekly, monthly; intraday to 1min | Time series from 1960+ |
| **Data Quality** | Good for major pairs; thin for exotics | Authoritative (Federal Reserve) |
| **Latency** | End-of-day | Hours to days (not event-timed) |
| **Effort Estimate** | 1-2 hours | 30 minutes |

**Alpha Vantage Forex Example:**
```python
import requests

API_KEY = "YOUR_KEY"
url = "https://www.alphavantage.co/query"
params = {
    "function": "FX_DAILY",
    "from_symbol": "EUR",
    "to_symbol": "USD",
    "apikey": API_KEY
}
r = requests.get(url, params=params)
data = r.json()
```

#### Supplemental APIs

| API | Purpose | Free Tier | Rate Limit | Integration |
|-----|---------|-----------|------------|-------------|
| **Finnhub** | Forex OHLCV from 10+ brokers | 60/min free | 60/min | 1-2 hrs |
| **Open Exchange Rates** | 170+ currencies | Limited free (slower refresh) | Varies | 1 hr |
| **OANDA** | Institutional-grade FX rates | 7-day demo only (no permanent free tier) | N/A | 2-4 hrs |
| **FRED** | Policy rates, yield curves, CPI | Unlimited | Open | 30 min |
| **FXMacroData** | FX-specialized macro (200+ indicators, 18 currencies) | 14-day trial only | Unlimited on paid | 1-2 hrs |

**Data Points We DON'T Currently Have:**
- CFTC COT positioning data (free from CFTC, not from APIs above)
- Central bank policy rate decision timestamps (FXMacroData has this)
- Real-time forex broker feed aggregation (Finnhub)
- FX options implied volatility (mostly paid only)

---

### 2.4 Commodity

#### Primary Data API: Yahoo Finance + OilPriceAPI

| Attribute | Yahoo Finance (Commodity ETFs) | OilPriceAPI |
|-----------|------------------------------|-------------|
| **Free Tier** | Unlimited | 1,000 requests/month |
| **Coverage** | Oil, gas, gold, silver via ETFs (USO, GLD, SLV, etc.) | Brent, WTI, OPEC basket, natural gas |
| **Real-Time** | 15-min delayed | Sub-minute updates on paid |
| **Historical** | Full history for ETFs | Included in all plans |
| **Effort Estimate** | 30 min | 1-2 hrs |

#### Supplemental APIs

| API | Purpose | Free Tier | Integration |
|-----|---------|-----------|-------------|
| **Quandl/NASDAQ Data Link** | Futures, contango data | Limited free datasets | 2-4 hrs |
| **FRED** | Energy prices, PPI | Unlimited | 30 min |
| **EIA (US Energy Info)** | Oil inventories, production | Free (open government) | 1-2 hrs |
| **World Bank Open Data** | Global commodity prices | Free | 1-2 hrs |

**Data Points We DON'T Currently Have:**
- Futures curve data (contango/backwardation) — requires Quandl or exchange feeds
- CFTC COT for commodities (free from CFTC directly)
- Inventory levels (EIA API, free)
- Roll yield data (must compute from futures curves)

---

### 2.5 Bond

#### Primary Data API: FRED

| Attribute | FRED |
|-----------|------|
| **Free Tier** | Completely free, open access |
| **API Key** | Not required (recommended for tracking) |
| **Data Coverage** | US Treasury yields (1mo-30yr), corporate spreads, TIPS, municipal |
| **Historical Depth** | Decades to centuries for some series |
| **Data Quality** | Authoritative Federal Reserve data |
| **Series Examples** | `DGS10` (10Y yield), `T10Y2Y` (spread), `DFF` (Fed funds) |
| **Effort Estimate** | 30 minutes |

**FRED Example:**
```python
import requests

FRED_API_KEY = "YOUR_KEY"  # optional but recommended
series_id = "DGS10"  # 10-Year Treasury Constant Maturity Rate
url = f"https://api.stlouisfed.org/fred/series/observations"
params = {
    "series_id": series_id,
    "api_key": FRED_API_KEY,
    "file_type": "json",
    "observation_start": "2020-01-01"
}
r = requests.get(url, params=params)
data = r.json()
```

#### Supplemental APIs

| API | Purpose | Free Tier | Integration |
|-----|---------|-----------|-------------|
| **Yahoo Finance** | Bond ETFs (TLT, IEF, SHY, HYG) | Unlimited | 30 min |
| **Alpha Vantage** | Treasury yield data | 25/day | 1 hr |
| **FRED** | Yield curve, credit spreads, SOFR | Unlimited | 30 min |
| **US Treasury** | Auction data, issuance calendar | Free (open government) | 1 hr |

**Data Points We DON'T Currently Have:**
- Real-time yield curve shifts (FRED is delayed)
- Corporate bond spreads by rating (FRED has some series)
- Bond futures data (requires futures exchange API)
- Inflation breakevens (TIPS vs nominal, available on FRED)

---

### 2.6 ETF

#### Primary Data API: Yahoo Finance (yfinance)

| Attribute | Details |
|-----------|---------|
| **Free Tier** | Unlimited |
| **Coverage** | Global ETFs: equity, bond, commodity, sector, inverse, leveraged |
| **Data Points** | NAV, AUM (in `info`), expense ratio, holdings (limited) |
| **Historical** | Full price history |
| **Effort Estimate** | 30 minutes |

#### Supplemental APIs

| API | Purpose | Free Tier | Integration |
|-----|---------|-----------|-------------|
| **Finnhub** | Fund flows, real-time quotes | 60/min | 1 hr |
| **Alpha Vantage** | Sector performance | 25/day | 1 hr |
| **FRED** | Macro context for thematic ETFs | Unlimited | 30 min |

**Data Points We DON'T Currently Have:**
- Daily fund flow data (Finnhub has this)
- Holdings changes over time (mostly paid)
- Creation/redemption basket data (exchange-specific)

---

### 2.7 Futures

#### Primary Data API: Polygon.io + Yahoo Finance

| Attribute | Polygon.io | Yahoo Finance |
|-----------|------------|---------------|
| **Free Tier** | 5 requests/minute, 2 years daily | Unlimited |
| **Coverage** | US futures, equities, options | Futures via continuous contracts (limited) |
| **Tick Data** | Available on paid tiers | None |
| **Historical** | 2 years on free | Full for front-month continuous |
| **Effort Estimate** | 1-2 hours | 30 minutes |

#### Supplemental APIs

| API | Purpose | Free Tier | Integration |
|-----|---------|-----------|-------------|
| **Quandl/NASDAQ Data Link** | Continuous futures, back-adjusted | Limited free | 2-4 hrs |
| **TradingView** | Technical signals via webhook | 1 alert free; webhook on Plus | 2-3 hrs |
| **CME Group** | Settlement prices, volume | Free (delayed) | 1 hr |
| **Binance API** | Crypto futures (perpetual, quarterly) | Unlimited public | 1 hr |

**Data Points We DON'T Currently Have:**
- Back-adjusted continuous futures (Quandl or compute ourselves)
- Contango/roll yield by contract month
- Open interest by contract (CFTC COT)
- Commitment of Traders positioning (free CFTC download)

---

## 3. GitHub Libraries for Speed-to-Quality

### 3.1 Backtesting Engines

#### VectorBT (vectorbt)

| Attribute | Details |
|-----------|---------|
| **Problem Solved** | Fast, vectorized backtesting and parameter optimization at scale |
| **Key Feature** | Thinks in matrices -- thousands of configurations packed into NumPy arrays, accelerated with Numba/Rust |
| **Speed Profile** | 100x+ faster than event-driven engines for grid search |
| **Integration Effort** | 2-4 hours |
| **Learning Curve** | Moderate -- requires vectorized thinking |
| **Replaces** | Slow loop-based backtests, custom grid search code |
| **Best For** | Crypto/equity multi-asset parameter sweeps, ML label generation |
| **Asset Classes** | All (user provides data) |

```python
import vectorbt as vbt

# RSI strategy on BTC
price = vbt.YFData.download("BTC-USD", start="2020-01-01", end="2024-01-01").get("Close")
rsi = vbt.RSI.run(price, window=14)
entries = rsi.rsi_crossed_below(30)
exits = rsi.rsi_crossed_above(70)
portfolio = vbt.Portfolio.from_signals(price, entries, exits, freq="1d")
print(portfolio.stats())
```

#### Backtrader

| Attribute | Details |
|-----------|---------|
| **Problem Solved** | Flexible event-driven backtesting with live trading support |
| **Key Feature** | Hybrid architecture (vectorized indicators + event-driven simulation) |
| **Built-in Indicators** | 122+ technical indicators |
| **Integration Effort** | 3-6 hours |
| **Learning Curve** | Moderate-High |
| **Replaces** | Custom event-driven backtesters |
| **Live Trading** | Yes -- IBKR, Oanda, Alpaca integrations |
| **Asset Classes** | Equities, crypto, forex, futures |

#### Zipline / Zipline-Reloaded

| Attribute | Details |
|-----------|---------|
| **Problem Solved** | Academic-grade backtesting with Pipeline API for equity factors |
| **Key Feature** | Pipeline abstraction for universe selection and factor ranking |
| **Integration Effort** | 4-8 hours |
| **Learning Curve** | High |
| **Replaces** | Custom factor research frameworks |
| **Best For** | Equity factor investing, cross-sectional strategies |
| **Status** | Original Zipline stagnant; zipline-reloaded fork more active |
| **Asset Classes** | Primarily equities |

#### NautilusTrader

| Attribute | Details |
|-----------|---------|
| **Problem Solved** | Institutional-grade backtesting + live trading in one platform |
| **Key Feature** | Rust core for performance; native risk controls |
| **Integration Effort** | 8-16 hours |
| **Learning Curve** | Steep |
| **Replaces** | Separate research and production stacks |
| **Best For** | Funds needing production deployment from day one |
| **Asset Classes** | All |

#### QuantConnect Lean

| Attribute | Details |
|-----------|---------|
| **Problem Solved** | Cloud + local backtesting with 50+ built-in datasets |
| **Key Feature** | Free tier available; C# core with Python support |
| **Integration Effort** | 4-8 hours |
| **Learning Curve** | Medium-High |
| **Replaces** | Data infrastructure (they host it) |
| **Best For** | Teams wanting cloud backtesting without data engineering |
| **Asset Classes** | All (50+ datasets) |

### 3.2 Risk Management & Portfolio Optimization

#### PyPortfolioOpt

| Attribute | Details |
|-----------|---------|
| **Problem Solved** | Mean-variance optimization, Black-Litterman, CVaR optimization |
| **Key Feature** | Clean API for Markowitz optimization with practical constraints |
| **Integration Effort** | 1-2 hours |
| **Learning Curve** | Low |
| **Replaces** | Manual scipy.optimize portfolio code |
| **Asset Classes** | All (any returns covariance matrix) |

```python
from pypfopt import EfficientFrontier, risk_models, expected_returns

mu = expected_returns.mean_historical_return(prices_df)
S = risk_models.sample_cov(prices_df)
ef = EfficientFrontier(mu, S)
ef.max_sharpe()
weights = ef.clean_weights()
```

#### Riskfolio-Lib

| Attribute | Details |
|-----------|---------|
| **Problem Solved** | Advanced risk budgeting, hierarchical clustering, OWA optimization |
| **Key Feature** | 50+ risk measures; Black-Litterman; factor models |
| **Integration Effort** | 2-4 hours |
| **Learning Curve** | Moderate |
| **Replaces** | Complex CVXPY risk model implementations |
| **Asset Classes** | All |

### 3.3 Statistical Analysis

| Library | Problem Solved | Integration Effort | Replaces |
|---------|---------------|-------------------|----------|
| **arch** | GARCH, EGARCH, HARCH volatility modeling | 2-4 hrs | Custom volatility estimation |
| **statsmodels** | Time-series regression, ARIMA, cointegration tests | 1-2 hrs | Manual regression code |
| **scipy** | Statistical tests, optimization, distributions | 1 hr | Math module implementations |
| **QuantStats** | Portfolio analytics, tear sheets, drawdown analysis | 1 hr | Custom performance reporting |

### 3.4 Machine Learning for Trading

| Library | Problem Solved | Integration Effort | Best For |
|---------|---------------|-------------------|----------|
| **scikit-learn** | Classification, regression, clustering | 2-4 hrs | Feature-based signal generation |
| **XGBoost / LightGBM** | Gradient boosting for tabular market data | 2-4 hrs | Non-linear factor models |
| **Prophet** | Time-series forecasting with seasonality | 1-2 hrs | Macro/volume forecasting |
| **PyTorch/TensorFlow** | Deep learning for sequence data | 8-16 hrs | LSTM/Transformer price models |

### 3.5 Data Handling

| Library | Problem Solved | Integration Effort | Replaces |
|---------|---------------|-------------------|----------|
| **pandas** | Tabular data manipulation | 0 hrs (baseline) | N/A -- baseline |
| **polars** | Fast columnar DataFrames, query optimization | 2-4 hrs | pandas for large datasets (>1M rows) |
| **dask** | Out-of-core distributed computing | 4-8 hrs | pandas for memory-bound operations |
| **pyarrow** | Zero-copy data interchange, Parquet | 1-2 hrs | CSV parsing, data serialization |

**Polars Performance Note**: Polars is 5-50x faster than pandas on grouped/aggregated workloads and supports streaming for datasets larger than RAM. Use it when processing tick data or large historical panels.

### 3.6 Visualization

| Library | Problem Solved | Integration Effort | Best For |
|---------|---------------|-------------------|----------|
| **plotly** | Interactive web-based charts | 1-2 hrs | Dashboards, user-facing visualizations |
| **bokeh** | Interactive server-based dashboards | 2-4 hrs | Streaming real-time dashboards |
| **matplotlib** | Static publication-quality charts | 0 hrs (baseline) | Research reports |
| **hvplot** | High-level interactive plotting for large data | 1-2 hrs | Polars/Panel integration |

### 3.7 Execution & Exchange Connectivity

#### CCXT

| Attribute | Details |
|-----------|---------|
| **Problem Solved** | Unified API across 120+ crypto exchanges |
| **Key Feature** | One codebase trades on any exchange |
| **Integration Effort** | 2-4 hours |
| **Learning Curve** | Low |
| **Replaces** | Exchange-specific API wrappers |
| **Coverage** | Binance, Coinbase, Kraken, Bybit, OKX, etc. |

```python
import ccxt

exchange = ccxt.binance()
ohlcv = exchange.fetch_ohlcv("BTC/USDT", timeframe="1d", limit=500)
# ohlcv is [[timestamp, open, high, low, close, volume], ...]
```

### 3.8 Alternative Data

| Library | Problem Solved | Integration Effort | Replaces |
|---------|---------------|-------------------|----------|
| **psaw** | Pushshift Reddit API wrapper (historical posts) | 2-3 hrs | Reddit scraping |
| **tweepy** | Twitter/X API access | 2-3 hrs | Manual Twitter API calls |
| **praw** | Reddit API (current posts) | 1-2 hrs | Raw Reddit API calls |
| **yahooquery** | Faster Yahoo Finance batch queries | 1 hr | yfinance for bulk fundamentals |

---

## 4. Backtesting Protocol per Asset Class

### 4.1 Universal Backtesting Checklist

Before asset-class specifics, every backtest must include:

1. **Survivorship bias elimination** -- Use point-in-time universes (not today's constituents)
2. **Look-ahead bias elimination** -- No future data in signal calculation
3. **Transaction costs** -- Spread + slippage + commission model
4. **Benchmark** -- Appropriate passive benchmark for each asset class
5. **Walk-forward** -- Out-of-sample periods never seen during optimization
6. **Minimum sample** -- Sufficient trades for statistical significance
7. **Multiple engines** -- Cross-validate with at least 2 backtesters when possible

### 4.2 Crypto Backtesting Protocol

| Component | Specification |
|-----------|-------------|
| **Data Requirements** | OHLCV (1h or 1d), funding rates, exchange volume. Minimum 2 years of data |
| **Walk-Forward** | In-sample: 18 months; Out-of-sample: 6 months; Roll monthly |
| **Transaction Cost Model** | Spread = 5-10 bps for majors, 15-30 bps for alts. Commission = 5-10 bps. Slippage = 1-5 bps |
| **Benchmark** | Buy-and-hold BTC or equal-weight top 10 index |
| **Minimum Sample** | 100+ trades in OOS for Sharpe inference; 300+ for drawdown claims |
| **Statistical Tests** | PSR (Probabilistic Sharpe Ratio) > 0.95, DSR (Deflated SR) > 0.95, bootstrap 10,000 paths |
| **Exchange Simulation** | Account for exchange downtime, funding payments, margin requirements |

### 4.3 Equity Backtesting Protocol

| Component | Specification |
|-----------|-------------|
| **Data Requirements** | OHLCV (daily), split/dividend adjusted, fundamentals quarterly. Minimum 5 years |
| **Walk-Forward** | In-sample: 4 years; Out-of-sample: 1 year; Roll quarterly |
| **Transaction Cost Model** | Spread = 1-5 bps for large caps, 5-15 bps for small caps. Commission = 0 bps (assume retail free). Slippage = 1-3 bps |
| **Benchmark** | S&P 500 or sector-matched ETF |
| **Minimum Sample** | 50+ round-trip trades in OOS; 200+ for cross-sectional factor strategies |
| **Statistical Tests** | PSR > 0.95, alpha significance (t-stat > 2), bootstrap, turnover analysis |
| **Universe Constraints** | Account for delistings, IPO lock-ups, index reconstitution effects |

### 4.4 Forex Backtesting Protocol

| Component | Specification |
|-----------|-------------|
| **Data Requirements** | OHLCV (daily or 4h), rollover-adjusted. Minimum 10 years (to capture multiple regimes) |
| **Walk-Forward** | In-sample: 7 years; Out-of-sample: 3 years; Roll annually |
| **Transaction Cost Model** | Spread = 0.5-2 pips for majors, 3-10 pips for crosses. Commission = 0. Slippage = 0.1-0.5 pips |
| **Benchmark** | Equal-weight G10 basket or 60/40 carry basket |
| **Minimum Sample** | 200+ trades in OOS |
| **Statistical Tests** | PSR > 0.95, DSR, bootstrap, regime-conditional Sharpe (trending vs ranging) |
| **Special Consideration** | Account for weekend gaps, central bank intervention events, rollovers |

### 4.5 Commodity Backtesting Protocol

| Component | Specification |
|-----------|-------------|
| **Data Requirements** | Futures curve (multiple tenors), contango/backwardation, spot via ETFs. Minimum 10 years |
| **Walk-Forward** | In-sample: 7 years; Out-of-sample: 3 years; Roll annually |
| **Transaction Cost Model** | Spread = 1-3 bps for liquid contracts, 5-15 bps for thin. Roll cost = explicit. Commission = 1-3 bps |
| **Benchmark** | S&P GSCI or Bloomberg Commodity Index |
| **Minimum Sample** | 100+ trades in OOS |
| **Statistical Tests** | PSR > 0.95, bootstrap, curve-conditional analysis |
| **Special Consideration** | Roll yield must be modeled explicitly; storage/seasonality for physical commodities |

### 4.6 Bond Backtesting Protocol

| Component | Specification |
|-----------|-------------|
| **Data Requirements** | Treasury yields (1mo-30yr), credit spreads, duration-matched prices. Minimum 15 years |
| **Walk-Forward** | In-sample: 10 years; Out-of-sample: 5 years; Roll annually |
| **Transaction Cost Model** | Spread = 0.5-2 bps for Treasuries, 5-20 bps for corporates. Commission = 0.5 bps. Slippage = 0.1-0.5 bps |
| **Benchmark** | Barclays/Bloomberg Aggregate Bond Index or duration-matched Treasury |
| **Minimum Sample** | 50+ regime shifts (rate cycles); 100+ for tactical trades |
| **Statistical Tests** | PSR > 0.95, duration-adjusted returns, curve-conditional analysis |
| **Special Consideration** | Reinvestment assumptions, convexity effects, yield curve shift decomposition |

### 4.7 ETF Backtesting Protocol

| Component | Specification |
|-----------|-------------|
| **Data Requirements** | NAV, market price, premium/discount, volume. Minimum 5 years |
| **Walk-Forward** | In-sample: 3 years; Out-of-sample: 1 year; Roll quarterly |
| **Transaction Cost Model** | Spread = 1-5 bps for liquid, 5-20 bps for thematic. Commission = 0. Slippage = 1-3 bps |
| **Benchmark** | Underlying index or category-matched ETF |
| **Minimum Sample** | 50+ rebalancing events |
| **Statistical Tests** | PSR > 0.95, tracking error analysis, premium/discount exploitation |
| **Special Consideration** | NAV deviation, creation/redemption arbitrage, tax efficiency |

### 4.8 Futures Backtesting Protocol

| Component | Specification |
|-----------|-------------|
| **Data Requirements** | Continuous contract (back-adjusted), volume, open interest. Minimum 10 years |
| **Walk-Forward** | In-sample: 7 years; Out-of-sample: 3 years; Roll annually |
| **Transaction Cost Model** | Spread = 1 tick for liquid, 2-5 ticks for thin. Commission = $1-5/contract. Slippage = 1-2 ticks. **Roll cost explicit** |
| **Benchmark** | CTA/managed futures index (BarclayHedge or SG CTA Index) |
| **Minimum Sample** | 200+ trades in OOS |
| **Statistical Tests** | PSR > 0.95, DSR, bootstrap, margin-to-equity ratio analysis |
| **Special Consideration** | Contract rollover timing, margin calls, limit moves |

---

## 5. New Strategies to Research per Asset Class

### 5.1 Crypto (3-5 Strategies)

#### 1. Cross-Sectional Momentum with Volatility Filter
- **Description**: Rank cryptos by 30-day momentum; trade only when 30-day realized vol < 80th percentile to avoid crash periods
- **Academic Reference**: Bri Plotnik systematic crypto series (2025); Asness Value/Momentum
- **Expected Performance**: Sharpe 0.8-1.2 (conservative), 15-25% annualized alpha vs BTC buy-and-hold
- **Data Requirements**: OHLCV for top 50 coins (CoinGecko + CCXT)
- **Implementation Effort**: 8-16 hours using VectorBT

#### 2. Funding Rate Arbitrage
- **Description**: Long spot / short perpetual when funding rate > threshold; capture funding payments
- **Academic Reference**: Binance perpetual futures research; DeFi rate arbitrage literature
- **Expected Performance**: 10-20% annualized, low vol (0.5-0.8 Sharpe)
- **Data Requirements**: Funding rates (Binance API, free), spot prices
- **Implementation Effort**: 8-12 hours

#### 3. BTC-Neutral Residual Mean Reversion
- **Description**: Regress altcoin returns on BTC, trade residuals when z-score > 2
- **Academic Reference**: Bri Plotnik (2025) -- BTC-neutral residuals
- **Expected Performance**: 8-15% annualized, market-neutral
- **Data Requirements**: OHLCV for top 30 coins
- **Implementation Effort**: 8-12 hours

#### 4. On-Chain MVRV/Z-Score Cycle Strategy
- **Description**: Use Glassnode MVRV ratio and NUPL to identify cycle tops/bottoms
- **Academic Reference**: Glassnode research; Woo (2019)
- **Expected Performance**: Timing-based; reduces drawdowns by 30-50%
- **Data Requirements**: Glassnode metrics (free tier UI -- scrape or manual export)
- **Implementation Effort**: 4-8 hours

#### 5. Social Sentiment Alpha for Meme Coins
- **Description**: Use Reddit/Twitter velocity (posts per hour) as leading indicator for meme coin pumps
- **Academic Reference**: PulseReddit dataset (2025); social media momentum literature
- **Expected Performance**: Highly variable; 5-10% edge in short windows
- **Data Requirements**: Reddit API + CoinGecko prices
- **Implementation Effort**: 12-20 hours

### 5.2 Equity (3-5 Strategies)

#### 1. F-Score Value Quality Combo
- **Description**: Piotroski F-Score (9-point quality) + low P/E or low P/B for value tilt
- **Academic Reference**: Piotroski (2000) -- "Value Investing: The Use of Historical Financial Statement Information"
- **Expected Performance**: 5-10% annual alpha vs market, higher in small-caps
- **Data Requirements**: Quarterly fundamentals (yfinance or Alpha Vantage)
- **Implementation Effort**: 8-16 hours

#### 2. Short-Term Reversal with Volume Filter
- **Description**: Buy past 1-month losers, sell winners; filter for high-volume names to ensure liquidity
- **Academic Reference**: Jegadeesh (1990); "Evidence of Predictable Behavior of Security Returns"
- **Expected Performance**: 3-6% annual alpha; works best in small-caps, non-January months
- **Data Requirements**: Daily OHLCV
- **Implementation Effort**: 4-8 hours

#### 3. Sector Momentum Rotation
- **Description**: Monthly rotate into top 3 performing S&P 500 sectors from past 12 months
- **Academic Reference**: Moskowitz & Grinblatt (1999) -- "Do Industries Explain Momentum?"
- **Expected Performance**: 2-5% annual alpha vs S&P 500; defensive during bear markets
- **Data Requirements**: Sector ETF prices (yfinance)
- **Implementation Effort**: 4-8 hours

#### 4. Earnings Surprise Post-Event Drift
- **Description**: Buy companies with large positive earnings surprises; hold 1-3 months
- **Academic Reference**: Bernard & Thomas (1989) -- "Post-Earnings-Announcement Drift"
- **Expected Performance**: 4-8% annual alpha; requires timely earnings data
- **Data Requirements**: Earnings calendars + EPS actual vs estimate (Finnhub)
- **Implementation Effort**: 8-12 hours

#### 5. Low Volatility Anomaly (Betting Against Beta)
- **Description**: Long low-beta / short high-beta stocks, rebalanced monthly
- **Academic Reference**: Frazzini & Pedersen (2014) -- "Betting Against Beta"
- **Expected Performance**: 3-5% annual alpha with lower volatility than market
- **Data Requirements**: Daily OHLCV for stock universe
- **Implementation Effort**: 8-12 hours

### 5.3 Forex (3-5 Strategies)

#### 1. G10 Carry Trade with Volatility Scaling
- **Description**: Long 3 highest-yielding G10 currencies / short 3 lowest; scale position by inverse volatility
- **Academic Reference**: Brunnermeier et al. (2009); "Carry Trades and Global Foreign Exchange Volatility"
- **Expected Performance**: 2-5% annual alpha; Sharpe 0.4-0.6; drawdowns in crisis periods
- **Data Requirements**: Daily FX rates + central bank policy rates (FRED + Alpha Vantage)
- **Implementation Effort**: 8-12 hours

#### 2. Momentum Trend Following (50/200 MACross)
- **Description**: Long when 50-day MA > 200-day MA; short when opposite
- **Academic Reference**: Lewellen (2002); "Momentum and Autocorrelation in Stock Returns"
- **Expected Performance**: 1-3% annual alpha; works in trending regimes only
- **Data Requirements**: Daily FX rates
- **Implementation Effort**: 2-4 hours

#### 3. COT Positioning Contrarian
- **Description**: Fade extreme non-commercial positioning from CFTC Commitment of Traders
- **Academic Reference**: Roder (2014); "The COT Report as a Trading Tool"
- **Expected Performance**: 2-4% annual alpha; signals are infrequent but reliable
- **Data Requirements**: CFTC COT reports (free weekly download)
- **Implementation Effort**: 4-8 hours

#### 4. PPP Deviation Reversion
- **Description**: Trade currencies far from purchasing power parity implied levels
- **Academic Reference**: Rogoff (1996); "The Purchasing Power Parity Puzzle"
- **Expected Performance**: 1-2% annual alpha; very slow, requires multi-year holding
- **Data Requirements**: FX rates + Big Mac / OECD PPP indices (OECD free data)
- **Implementation Effort**: 8-12 hours

#### 5. Macro Surprise Trading (NFP, CPI, ECB)
- **Description**: Trade directionally based on surprise vs consensus for major macro releases
- **Academic Reference**: FXMacroData research; Andersen et al. (2003)
- **Expected Performance**: 3-6% annual alpha; high precision required on timing
- **Data Requirements**: Macro surprise data (FXMacroData trial or manual consensus)
- **Implementation Effort**: 12-20 hours

### 5.4 Commodity (3-5 Strategies)

#### 1. Commodity Momentum with Term Structure Filter
- **Description**: Cross-sectional momentum on commodities; select contracts on curve with best roll yield
- **Academic Reference**: De Groot, Karstanje & Zhou (2014) -- "Exploiting Commodity Momentum Along the Futures Curves"
- **Expected Performance**: Sharpe 0.7-1.0 vs 0.5 for generic momentum; 50%+ turnover reduction
- **Data Requirements**: Futures curve data (multiple tenors; Quandl or compute from Yahoo)
- **Implementation Effort**: 12-20 hours

#### 2. Carry (Term Structure) Strategy
- **Description**: Long backwardated commodities / short contangoed commodities
- **Academic Reference**: Erb & Harvey (2006); "The Tactical and Strategic Value of Commodity Futures"
- **Expected Performance**: 4-8% annual alpha; positive roll yield capture
- **Data Requirements**: Front vs second-month futures prices
- **Implementation Effort**: 4-8 hours

#### 3. Hedging Pressure Strategy
- **Description**: Trade against hedgers; long commodities where hedgers are net short (hedging pressure negative)
- **Academic Reference**: Basu & Miffre (2013); "Capturing the Premium in Hedging Pressure"
- **Expected Performance**: 3-6% annual alpha
- **Data Requirements**: CFTC COT for commodities (free)
- **Implementation Effort**: 8-12 hours

#### 4. Idiosyncratic Volatility Strategy
- **Description**: Long low idiosyncratic volatility commodities / short high idiosyncratic vol
- **Academic Reference**: Miffre et al. (2013); "Idiosyncratic Volatility in Commodity Futures"
- **Expected Performance**: 2-5% annual alpha
- **Data Requirements**: Daily returns + GSCI factor regression
- **Implementation Effort**: 8-12 hours

#### 5. Seasonality in Natural Gas / Heating Oil
- **Description**: Exploit winter/summer demand patterns in energy commodities
- **Academic Reference**: Commodity seasonality literature; "Gas Storage Arbitrage"
- **Expected Performance**: 3-6% annual in specific months; requires precise timing
- **Data Requirements**: 20+ years of monthly data
- **Implementation Effort**: 4-8 hours

### 5.5 Bond (3-5 Strategies)

#### 1. Yield Curve Steepener/Flattener
- **Description**: Long 2Y + short 10Y (steepener) or inverse (flattener) based on Fed policy regime
- **Academic Reference**: Ilmanen (2011) -- "Expected Returns"; WisdomTree (2026)
- **Expected Performance**: 2-4% annual alpha in directional rate environments
- **Data Requirements**: Treasury yields 1mo-30yr (FRED)
- **Implementation Effort**: 4-8 hours

#### 2. Duration Rotation Based on Yield Curve Slope
- **Description**: Extend duration when curve is steep; shorten when flat/inverted
- **Academic Reference**: Fama & French (1993); term structure literature
- **Expected Performance**: 1-3% annual alpha vs constant duration
- **Data Requirements**: Treasury yields (FRED)
- **Implementation Effort**: 4-8 hours

#### 3. Credit Spread Cycle Strategy
- **Description**: High yield when spreads > 75th percentile; Investment grade when spreads < 25th percentile
- **Academic Reference**: HYW (high yield research); cycle-dependent risk premia
- **Expected Performance**: 2-5% annual alpha; credit risk exposure
- **Data Requirements**: BAA-AAA spread, HYG/TLT prices (FRED + yfinance)
- **Implementation Effort**: 4-8 hours

#### 4. Real Yield / TIPS Inflation Hedge
- **Description**: Long TIPS when breakeven inflation < expected; Long nominal when breakeven > expected
- **Academic Reference**: "TIPS and the Inflation Risk Premium" (d'Amico et al.)
- **Expected Performance**: 1-3% inflation-adjusted alpha
- **Data Requirements**: TIPS yields, nominal yields, CPI (FRED)
- **Implementation Effort**: 4-8 hours

#### 5. Rolling Down the Yield Curve
- **Description**: Buy bonds at maturities where curve is steepest; capture capital appreciation as maturity shortens
- **Academic Reference**: "Roll Down Strategy" (Morningstar, Schwab); fixed income textbooks
- **Expected Performance**: 0.5-1.5% annual alpha above yield
- **Data Requirements**: Full yield curve (FRED)
- **Implementation Effort**: 4-8 hours

### 5.6 ETF (3-5 Strategies)

#### 1. ETF Premium/Discount Arbitrage
- **Description**: Buy ETFs trading at discount to NAV; sell at premium (intraday)
- **Academic Reference**: Ben-David et al. (2018); "ETF Arbitrage and Market Fragility"
- **Expected Performance**: 1-3% annual; requires real-time NAV data
- **Data Requirements**: NAV + market price (yfinance has end-of-day)
- **Implementation Effort**: 8-16 hours

#### 2. Factor Rotation (Value/Momentum/Quality)
- **Description**: Monthly rotate among factor ETFs based on recent 6-month performance
- **Academic Reference**: Arnott et al. (2021); "Factor Rotation"
- **Expected Performance**: 2-4% annual alpha vs equal-weight factors
- **Data Requirements**: Factor ETF prices (VLUE, MTUM, QUAL, etc.)
- **Implementation Effort**: 4-8 hours

#### 3. Smart Beta Momentum Overlay
- **Description**: Add momentum overlay to broad market ETF allocation
- **Academic Reference**: Asness et al. (2013); "The Value and Momentum Premium"
- **Expected Performance**: 1-3% annual alpha with lower drawdowns
- **Data Requirements**: ETF prices + risk-free rate
- **Implementation Effort**: 4-8 hours

### 5.7 Futures (3-5 Strategies)

#### 1. Managed Futures / Trend Following
- **Description**: Time-series momentum across 20+ futures markets; long when price > 12M MA, short when below
- **Academic Reference**: Hurst et al. (2013); "Demystifying Managed Futures"
- **Expected Performance**: 3-6% annual alpha; crisis alpha positive; Sharpe 0.4-0.6
- **Data Requirements**: 20+ futures markets continuous contracts
- **Implementation Effort**: 16-24 hours

#### 2. Carry in Futures Markets
- **Description**: Long futures in backwardation; short in contango (cross-asset)
- **Academic Reference**: Koijen et al. (2018); "Carry"
- **Expected Performance**: 4-8% annual alpha; works across asset classes
- **Data Requirements**: Front vs second-month prices for each market
- **Implementation Effort**: 8-16 hours

#### 3. Open Interest / Volume Signals
- **Description**: Trade in direction of rising OI + volume (confirmation) or fade extreme readings
- **Academic Reference**: CFTC COT literature
- **Expected Performance**: 2-4% annual alpha
- **Data Requirements**: Volume, OI (CME free delayed + CFTC)
- **Implementation Effort**: 4-8 hours

---

## 6. Quick Edge Detection Report Algorithm

### Purpose
Run daily to answer: **"Do we have any edge today, and where?"**

### Inputs Needed

1. **Price data**: Daily OHLCV for all tracked instruments (from yfinance/Coingecko cache)
2. **Factor/signal data**: Pre-computed signals from each strategy module
3. **Risk metrics**: Current volatility, correlation matrix, drawdown status
4. **Macro snapshot**: FRED data -- yield curve, VIX proxy, FX rates
5. **Sentiment**: Google Trends, Reddit activity (optional)

### Computation Steps

```python
# Pseudocode for Daily Edge Detection

def daily_edge_report():
    # 1. Fetch all data (from local cache or APIs)
    prices = load_price_data()
    signals = compute_all_signals(prices)
    
    # 2. Evaluate each strategy on its most recent OOS period
    edge_scores = {}
    for asset_class in ASSET_CLASSES:
        for strategy in STRATEGIES[asset_class]:
            # Compute recent Sharpe (last 63 trading days)
            recent_returns = strategy.simulate(prices, lookback=63)
            sharpe = recent_returns.mean() / recent_returns.std() * np.sqrt(252)
            
            # Compute PSR (Probabilistic Sharpe Ratio)
            psr = compute_psr(recent_returns, benchmark_sharpe=0)
            
            # Compute win rate and skew
            win_rate = (recent_returns > 0).mean()
            skew = recent_returns.skew()
            
            # Composite edge score: 0-100
            edge = min(100, max(0, 
                psr * 40 +                    # PSR weight 40%
                (sharpe > 0.5) * 25 +       # Sharpe threshold 25%
                win_rate * 20 +             # Win rate 20%
                (skew > 0) * 15             # Positive skew 15%
            ))
            
            edge_scores[(asset_class, strategy.name)] = {
                "edge_score": edge,
                "psr": psr,
                "sharpe": sharpe,
                "win_rate": win_rate,
                "skew": skew,
                "current_signal": strategy.latest_signal(),
                "regime": detect_regime(prices[asset_class])
            }
    
    # 3. Identify top 5 edges today
    top_edges = sorted(edge_scores.items(), key=lambda x: x[1]["edge_score"], reverse=True)[:5]
    
    # 4. Identify strategies in "danger zone" (PSR < 0.5)
    danger = {k: v for k, v in edge_scores.items() if v["psr"] < 0.5 and v["sharpe"] < 0}
    
    # 5. Generate report
    return {
        "date": today(),
        "top_edges": top_edges,
        "danger_zone": danger,
        "market_regime": get_macro_regime(),
        "correlation_warning": max_correlation_exceeded(),
        "recommended_action": generate_action(top_edges, danger)
    }
```

### Output Format (Daily JSON Report)

```json
{
  "date": "2026-05-11",
  "market_regime": "risk_on",
  "top_edges": [
    {
      "asset_class": "crypto",
      "strategy": "funding_rate_arbitrage",
      "edge_score": 87,
      "psr": 0.95,
      "sharpe": 1.2,
      "current_signal": "long_spot_short_perp",
      "regime": "contango"
    },
    {
      "asset_class": "commodity",
      "strategy": "carry_term_structure",
      "edge_score": 72,
      "psr": 0.82,
      "sharpe": 0.8,
      "current_signal": "long_gas_short_oil"
    }
  ],
  "danger_zone": [
    {
      "asset_class": "equity",
      "strategy": "short_term_reversal",
      "edge_score": 12,
      "psr": 0.2,
      "sharpe": -0.3,
      "note": "Momentum regime -- reversal failing"
    }
  ],
  "correlation_warning": false,
  "recommended_action": "Deploy 50% to crypto funding arb, 25% to commodity carry. Reduce equity reversal exposure."
}
```

### How to Present to Users

1. **Morning Dashboard**: HTML/email with top 3 edges, color-coded (green/yellow/red)
2. **Slack/Telegram Bot**: Short message with today's edge and action
3. **Historical Tracking**: Plot edge scores over time to detect regime shifts
4. **Alerting**: Email when PSR drops below 0.5 for any active strategy

---

## 7. Integration Roadmap & Priorities

### Phase 1: Foundation (Week 1-2)
- [ ] Set up yfinance daily data pipeline for equities, ETFs, bonds
- [ ] Set up CoinGecko + CCXT pipeline for crypto
- [ ] Set up FRED macro data fetcher
- [ ] Install VectorBT + PyPortfolioOpt + QuantStats
- [ ] Create unified DataFrame cache (Parquet format, Polars-compatible)

### Phase 2: Core Strategies (Week 3-4)
- [ ] Implement Crypto cross-sectional momentum (VectorBT)
- [ ] Implement Equity F-Score value strategy (yfinance fundamentals)
- [ ] Implement Bond yield curve steepener/flatener (FRED)
- [ ] Implement Forex carry trade (Alpha Vantage + FRED)

### Phase 3: Advanced Data (Week 5-6)
- [ ] Integrate Finnhub for real-time equity quotes + sentiment
- [ ] Integrate Alpha Vantage technical indicators (50+ pre-computed)
- [ ] Set up CFTC COT downloader for FX + commodity positioning
- [ ] Add Binance funding rate + open interest for crypto

### Phase 4: Production Polish (Week 7-8)
- [ ] Build daily Edge Detection Report
- [ ] Cross-validate all strategies with second backtester (Backtrader)
- [ ] Add PSR/DSR computation to all strategies
- [ ] Create interactive Plotly dashboard
- [ ] Add risk management layer (PyPortfolioOpt + Riskfolio-Lib)

### Paid Tier Upgrade Points (When Free Tiers Hit)
| API | Free Limit | Trigger for Upgrade | Paid Cost |
|-----|-----------|--------------------|-----------|
| Alpha Vantage | 25/day | Need >25 calls/day or intraday | $49.99/mo |
| CoinGecko | 10k/mo | Need real-time or >10k calls | $129/mo |
| Finnhub | 60/min | Need >60/min or >50 WebSocket symbols | $50/mo |
| Polygon.io | 5/min | Need tick data or US options | $29/mo |
| Glassnode | No API on free | Need on-chain API programmatically | $999+/yr |

---

## 8. Appendix: Code Examples

### A. Unified Data Fetcher Class

```python
import yfinance as yf
import requests
import polars as pl
from typing import Optional, Dict
import os

class UnifiedDataFetcher:
    """Fetches data from multiple free sources with fallback logic."""
    
    def __init__(self):
        self.alpha_vantage_key = os.getenv("ALPHA_VANTAGE_KEY", "")
        self.finnhub_key = os.getenv("FINNHUB_KEY", "")
        self.coingecko_key = os.getenv("COINGECKO_KEY", "")
        
    def get_equity_ohlcv(self, symbol: str, period: str = "5y") -> pl.DataFrame:
        """Primary: yfinance. Fallback: Finnhub."""
        try:
            ticker = yf.Ticker(symbol)
            df = ticker.history(period=period, interval="1d")
            return pl.from_pandas(df.reset_index())
        except Exception as e:
            print(f"yfinance failed for {symbol}: {e}")
            # Fallback logic here
            return pl.DataFrame()
    
    def get_crypto_ohlcv(self, symbol: str, exchange: str = "binance") -> pl.DataFrame:
        """Primary: CCXT direct from exchange. Secondary: CoinGecko."""
        import ccxt
        ex = getattr(ccxt, exchange)()
        ohlcv = ex.fetch_ohlcv(symbol, timeframe="1d", limit=1000)
        df = pl.DataFrame(
            ohlcv,
            schema=["timestamp", "open", "high", "low", "close", "volume"],
            orient="row"
        )
        return df.with_columns(
            pl.from_epoch("timestamp", time_unit="ms").alias("date")
        )
    
    def get_macro_series(self, series_id: str) -> pl.DataFrame:
        """Fetch from FRED. No API key required."""
        url = "https://api.stlouisfed.org/fred/series/observations"
        params = {
            "series_id": series_id,
            "file_type": "json",
            "observation_start": "2000-01-01"
        }
        r = requests.get(url, params=params)
        data = r.json()["observations"]
        return pl.DataFrame(data).select([
            pl.col("date").str.to_date(),
            pl.col("value").cast(pl.Float64, strict=False)
        ])
```

### B. PSR (Probabilistic Sharpe Ratio) Implementation

```python
import numpy as np
from scipy.stats import norm

def probabilistic_sharpe_ratio(
    returns: np.ndarray,
    benchmark_sharpe: float = 0,
    skewness: Optional[float] = None,
    kurtosis: Optional[float] = None
) -> float:
    """
    Compute PSR as in Bailey & Lopez de Prado (2012).
    PSR = Probability that observed Sharpe > benchmark Sharpe.
    """
    n = len(returns)
    sharpe = returns.mean() / returns.std() * np.sqrt(252)
    
    if skewness is None:
        skewness = np.mean(((returns - returns.mean()) / returns.std()) ** 3)
    if kurtosis is None:
        kurtosis = np.mean(((returns - returns.mean()) / returns.std()) ** 4)
    
    # Variance of Sharpe estimator
    sharpe_var = (
        (1 + 0.5 * sharpe**2 - skewness * sharpe + (kurtosis - 3) / 4 * sharpe**2)
        / (n - 1)
    )
    
    psr = norm.cdf((sharpe - benchmark_sharpe) / np.sqrt(sharpe_var))
    return psr
```

### C. DSR (Deflated Sharpe Ratio) Sketch

```python
def deflated_sharpe_ratio(
    returns: np.ndarray,
    num_trials: int,
    skewness: float,
    kurtosis: float,
    target_sharpe: float = 0
) -> float:
    """
    DSR adjusts PSR for multiple trials / selection bias.
    Reference: Bailey & Lopez de Prado (2014).
    """
    n = len(returns)
    sharpe = returns.mean() / returns.std() * np.sqrt(252)
    
    # Expected maximum Sharpe under null (independent trials)
    # Approximation via Euler-Mascheroni constant
    gamma = 0.5772156649
    emc = np.sqrt(2 * np.log(num_trials)) - gamma / np.sqrt(2 * np.log(num_trials))
    
    # Variance of Sharpe
    sr_var = (
        (1 + 0.5 * sharpe**2 - skewness * sharpe + (kurtosis - 3) / 4 * sharpe**2)
        / (n - 1)
    )
    
    # Deflated benchmark
    deflated_benchmark = target_sharpe + emc * np.sqrt(sr_var)
    
    dsr = norm.cdf((sharpe - deflated_benchmark) / np.sqrt(sr_var))
    return dsr
```

### D. Bootstrap Backtest Validation

```python
def bootstrap_sharpe(returns: np.ndarray, n_bootstrap: int = 10000) -> Dict:
    """Bootstrap confidence intervals for Sharpe ratio."""
    n = len(returns)
    sharpe_ratios = []
    
    for _ in range(n_bootstrap):
        sample = np.random.choice(returns, size=n, replace=True)
        if sample.std() > 0:
            sr = sample.mean() / sample.std() * np.sqrt(252)
            sharpe_ratios.append(sr)
    
    sr_array = np.array(sharpe_ratios)
    return {
        "sharpe_mean": sr_array.mean(),
        "sharpe_median": np.median(sr_array),
        "ci_5": np.percentile(sr_array, 5),
        "ci_95": np.percentile(sr_array, 95),
        "prob_positive": (sr_array > 0).mean(),
        "prob_gt_benchmark": (sr_array > 0.5).mean()  # vs 0.5 Sharpe
    }
```

### E. Quick Edge Report Generator

```python
import json
from datetime import datetime
from dataclasses import dataclass

@dataclass
class StrategyResult:
    name: str
    asset_class: str
    edge_score: float
    psr: float
    sharpe: float
    win_rate: float
    current_signal: str

class EdgeReport:
    def __init__(self, strategies: list):
        self.strategies = strategies
        
    def generate(self) -> dict:
        scores = []
        for s in self.strategies:
            # Compute composite edge score
            edge = min(100, max(0,
                s.psr * 40 +
                (s.sharpe > 0.5) * 25 +
                s.win_rate * 20 +
                (s.sharpe > 0 and s.win_rate > 0.5) * 15
            ))
            scores.append({
                "strategy": s.name,
                "asset_class": s.asset_class,
                "edge_score": round(edge, 1),
                "psr": round(s.psr, 3),
                "sharpe": round(s.sharpe, 3),
                "win_rate": round(s.win_rate, 3),
                "signal": s.current_signal
            })
        
        scores.sort(key=lambda x: x["edge_score"], reverse=True)
        
        return {
            "date": datetime.now().strftime("%Y-%m-%d"),
            "top_edges": scores[:5],
            "danger_zone": [s for s in scores if s["psr"] < 0.5],
            "recommended_action": self._generate_action(scores[:3])
        }
    
    def _generate_action(self, top: list) -> str:
        actions = [f"{s['asset_class']}:{s['strategy']} ({s['edge_score']})" for s in top]
        return f"Deploy capital to: {' | '.join(actions)}"
    
    def to_json(self) -> str:
        return json.dumps(self.generate(), indent=2)
```

---

## Key Takeaways & Action Items

1. **Immediate Wins (This Week)**:
   - Set up `yfinance` + `ccxt` + `coingecko` pipelines
   - Install `VectorBT` and run a simple RSI strategy on BTC
   - Pull FRED yield curve data and visualize

2. **Data Architecture Priority**:
   - Use **Polars** for all new data pipelines (faster, lower memory)
   - Store cached data in **Parquet** format (columnar, compressible)
   - Implement **multi-source fallback** (yfinance -> Finnhub -> Alpha Vantage)

3. **Statistical Rigor**:
   - Never claim edge without **PSR > 0.95**
   - Always report **DSR** when multiple strategies tested
   - Cross-validate with **second backtester** when possible
   - Use **walk-forward** only -- no in-sample optimization claims

4. **Paid API Escalation Path**:
   - Start entirely free; upgrade only when hitting rate limits
   - First upgrade priority: **Finnhub** ($50/mo) for real-time + sentiment
   - Second: **CoinGecko Analyst** ($129/mo) for real-time crypto + DEX data
   - Third: **Glassnode** ($999/yr) only if on-chain signals prove valuable

5. **Risk Management**:
   - Use **PyPortfolioOpt** for mean-variance + CVaR optimization
   - Monitor **correlation breakdown** during risk-on/risk-off regimes
   - Implement **max drawdown circuit breakers** in all live strategies

---

*Research compiled for systematic trading infrastructure development.*
