# UI/UX Audit Report: findtorontoevents.ca/audit
## Unified Audit Dashboard - Investor Experience Redesign

**Auditor:** Senior UX Strategist, Financial Trading Dashboards  
**Date:** 2026-04-29  
**Scope:** Active Picks discovery, investable signal flow, risk communication, filter/tab architecture, mobile/desktop optimization  
**Core Question:** *"Can a trader make the right decision in under 10 seconds?"*

---

## Executive Summary

The current /audit dashboard is a **data-rich but decision-poor** interface. It contains ~1.16MB of HTML/JS with 13 tabs, 9+ action buttons, and multiple overlapping filter systems. An investor landing on this page faces **decision paralysis**: they see "Smart Picks", "High Conviction", "Verified Alpha", "Best Score", and "Proven Only" all competing for attention without a clear hierarchy of which button leads to investable picks.

**Thesis:** The optimal user flow must answer three questions in sequence: (1) *Where are the best picks?* (2) *Why should I trust them?* (3) *How much should I risk?* Currently, the UI answers question #1 with 6 different buttons and never answers question #3 at all.

---

## 1. Current State Analysis

### 1.1 Existing Tabs (13 Total)

| Tab | Purpose | Investment Relevance |
|-----|---------|-------------------|
| Overview | Summary stats, performance alerts | Low - informational only |
| **Active Picks** | Currently open/unresolved picks | **HIGH - primary trading surface** |
| Verified Alpha | Prediction-market + auditable pro-trader rows | High - but subset of Active |
| **Smart Picks** | AI-curated picks via ML pipeline | **HIGH - but unverified on closed data** |
| US Equity Picks | Long-term value + swing equity | Medium - new, building track record |
| Closed Picks | Resolved picks with P&L | High - for verification/learning |
| Dashboards | External system links | Low - navigation only |
| Strat. Leaderboard | Strategy performance rankings | Medium - for research |
| Permutations | Symbol-strategy-direction combos | Medium - for edge discovery |
| Performance | Period-based P&L stats | Medium - for portfolio review |
| Score Tracker | Score-vs-actual correlation | Low - for model validation |
| ML Health | ML pipeline diagnostics | Low - for developers |
| Links | Quick links to other systems | Low - navigation only |

### 1.2 Existing Action Buttons (Above Filter Bar)

| Button | Action | Risk |
|--------|--------|------|
| **Best Score** | Dashboard-score preset | "Not the same as Smart Picks backend" - confusing |
| **Proven Only** | Trust registry filter (PROVEN/DEVELOPING) | "Does NOT run live closed-pick query" - stale data risk |
| **In Profit** | Currently profitable picks moving toward target | Recency bias - ignores why they might reverse |
| **Export CSV** | Data export | Neutral |
| **Smart Picks** | Curated feed filter | "Cannot be verified as edge on closed data" - disclaimers buried in tooltip |
| **Verified Alpha** | Auditable pro-trader rows | Subset of active picks - overlap unclear |
| **High Conviction** | `hc_filter.js` gates + per-asset validated edge | **Best documented filter** but still has purple "legacy elite crypto overlay" ambiguity |

### 1.3 Active Picks Table Columns (Current)

| Column | Type | Usability Issue |
|--------|------|-----------------|
| Symbol | string | OK |
| Dir | string (LONG/SHORT) | OK - color-coded green/red |
| Strategy | string | No per-strategy-symbol-direction WR shown |
| Entry | number | OK |
| TP | number | OK - green |
| SL | number | OK - red |
| Current | number | OK |
| Unreal. PnL% | number | OK - color-coded |
| Opened (EST) | datetime | OK |
| Age | duration | OK |
| Confidence | number | Users don't know what 0.8 vs 0.6 means |
| Score | number | Users don't know how score maps to expected WR |
| Trust | tier | OK with color coding |

### 1.4 Current Tier System (Code-Revealed)

| Tier | Score Range | Color | Icon | Current Issue |
|------|-------------|-------|------|---------------|
| S-Tier (70+) | >= 70 | Green | Trophy | Rare - thresholds may be too high |
| A-Tier (55-70) | 55-70 | Yellow | Gold Medal | "Good" but degrading at L100 |
| B-Tier (40-55) | 40-55 | Orange | Silver Medal | Best B-tier, but still B-tier |
| C-Tier (<40) | < 40 | Gray | Down Arrow | Value destroyer, SUSPENDED |

**Critical Finding:** The tier labels in the code use score bands (S-Tier 70+, A-Tier 55-70, etc.), but these are strategy-level scores applied to picks. Users see `Score: 58` and `elite_grade: A` but have no intuition for what that means in terms of expected win rate or profit factor.

---

## 2. Optimal User Flow Diagram

### 2.1 Primary Flow: "I Want to Invest Now"

```
LAND on /audit
    ↓
┌─────────────────────────────────────────────────────────┐
│  HERO: "Today's High-Conviction Picks"                 │
│  Count: 12 picks | 8 Crypto | 3 Equity | 1 Forex      │
│  [View All Investable Picks →]                         │
└─────────────────────────────────────────────────────────┘
    ↓
ACTIVE PICKS tab (auto-opened, gold border)
    ↓
PRE-FILTERED VIEW: "Investable Only" toggle ON by default
    ↓
┌─────────────────────────────────────────────────────────┐
│  PICK CARD (per row):                                  │
│  BTCUSDT  LONG  |  S-Tier 🏆  |  FWD WR: 72% (n=47)   │
│  Entry: 84,200 | TP: 91,800 (+9.0%) | SL: 80,400       │
│  Strategy: drawdown_recovery_rsi | Verified: ✅ GOLDEN │
│  [Copy Setup]  [Size Position]  [View Details →]       │
└─────────────────────────────────────────────────────────┘
    ↓
USER DECISION (Target: < 10 seconds):
    → Click [Copy Setup] → Pre-filled order form
    → Click [Size Position] → Risk calculator popup
    → Click [View Details] → Full pick analysis
```

### 2.2 Secondary Flow: "I Want to Verify Before Trusting"

```
LAND on /audit
    ↓
Click "Closed Picks" tab
    ↓
FILTER: Same strategy + symbol + direction as pick of interest
    ↓
SEE: Historical track record for THIS specific combo
    ↓
RETURN to Active Picks with verified confidence
```

### 2.3 Tertiary Flow: "I Want to Discover New Edges"

```
LAND on /audit
    ↓
Click "Strategy Leaderboard" tab
    ↓
SORT by: FWD WR% (descending), then by Sample Size
    ↓
DRILL INTO: Strategy detail → Symbol-direction breakdown
    ↓
JUMP TO: Active Picks filtered by that strategy
```

---

## 3. Information Hierarchy (What to Show, In What Order)

### 3.1 The 10-Second Hierarchy

For an investor making a trade decision, information must be presented in this order:

| Priority | Element | Time Budget | Format |
|----------|---------|-------------|--------|
| **1** | **What is the pick?** (Symbol, Direction, Tier) | 0-2s | Big text, color-coded |
| **2** | **Why should I trust it?** (FWD WR%, n=, Grade) | 2-4s | Badge + number + sample size |
| **3** | **What could I make/lose?** (TP%, SL%, R:R) | 4-6s | Green/red numbers, ratio callout |
| **4** | **How long has this edge existed?** (Age, Decay) | 6-8s | Subtle, with decay warning if >48h |
| **5** | **How much should I risk?** (Position size hint) | 8-10s | Mini-calculator or % hint |

### 3.2 What NOT to Show in the First 10 Seconds

These elements create noise and should be behind an expand/collapse or in a detail view:

- Confidence score (internal ML metric, not actionable)
- Trust tier label (redundant with tier badge)
- Source system name (e.g., "ml_gatekeeper::quan_engine")
- Strategy name with version numbers
- Penalty breakdown (score component details)
- Exit reason history
- Permutation matrix

### 3.3 The "Confidence Stack"

Every pick should display its **Confidence Stack** - a vertical list of which quality gates it passed:

```
┌─ Confidence Stack ─┐
│ ✅ Score >= 55     │  ← Green = passed
│ ✅ Trust >= 6      │  ← Green = passed
│ ✅ FWD WR >= 45%   │  ← Green = passed
│ ⚠️  Age > 24h       │  ← Yellow = warning
│ ❌ Regime mismatch  │  ← Red = failed (but still shown)
└────────────────────┘
```

This replaces the opaque single "Score: 58" with **transparent, inspectable gate results**.

---

## 4. Pick Presentation Standards

### 4.1 The Pick Card (Row Design)

**Current:** Dense table row with 13 columns.  
**Proposed:** Card-based row with primary, secondary, and expandable zones.

```
┌──────────────────────────────────────────────────────────────────────┐
│  BTCUSDT      🏆 S-Tier        FWD WR 72% (n=47)      🟢 LONG     │
│  ─────────────────────────────────────────────────────────────────  │
│  Entry: $84,200    TP: $91,800 (+9.0%)    SL: $80,400 (-4.5%)    │
│  R:R = 2.0    |    Strategy: drawdown_recovery    |    Age: 3h    │
│  ─────────────────────────────────────────────────────────────────  │
│  [Copy Setup]    [Size: 2% Risk]    [Details ▼]    [🚫 Skip]      │
└──────────────────────────────────────────────────────────────────────┘
```

### 4.2 Color Scheme (Semantic, Not Decorative)

| Color | Meaning | Usage |
|-------|---------|-------|
| **Green (#22c55e)** | GO / Positive / LONG direction / S-Tier / In Profit | Direction badge, TP value, PnL+, S-Tier border |
| **Red (#ef4444)** | STOP / Negative / SHORT direction / SL hit / BANNED | Direction badge, SL value, PnL-, CRITICAL alert |
| **Yellow (#f59e0b)** | CAUTION / A-Tier / Medium confidence / Age > 24h | A-Tier badge, WARNING alerts, stale data |
| **Orange (#fb923c)** | PROBATION / B-Tier / Small sample (n<20) | B-Tier badge, MEDIUM alerts |
| **Purple (#a78bfa)** | ELITE / Verified / Multi-system consensus | Verified Alpha badge, Smart Picks indicator |
| **Cyan (#22d3ee)** | INFO / Actionable / Link | Column headers, sort indicators, refresh buttons |
| **Gray (#94a3b8)** | INACTIVE / C-Tier / No data / Disabled | C-Tier, expired picks, disabled buttons |

### 4.3 The Tier Badge System

**Current:** Score number + hidden grade mapping.  
**Proposed:** Always-visible badge with expected performance annotation.

| Badge | Score | Expected WR | Expected PF | Risk Level | Action |
|-------|-------|-------------|-------------|------------|--------|
| 🏆 S-Tier | 70+ | 75-85% | > 3.0 | LOW | Full size |
| 🥇 A-Tier | 55-70 | 55-65% | 1.5-2.5 | MEDIUM | Standard size |
| 🥈 B-Tier | 40-55 | 45-55% | 1.0-1.5 | ELEVATED | Half size |
| 🔻 C-Tier | <40 | <40% | < 1.0 | HIGH | Do not trade |
| ⛔ F-Tier | BANNED | N/A | N/A | TOXIC | Hidden by default |

### 4.4 Position Sizing Guidance (NEW - Not Currently Present)

Every investable pick should include a **sizing hint** based on Kelly Criterion (fractional):

```
Kelly % = (WR × R:R - (1-WR)) / R:R
Suggested = Kelly × 0.25 (quarter-Kelly for safety)
```

Example:
```
┌─ Position Size Suggestion ─┐
│ WR: 72% | R:R: 2.0        │
│ Kelly: 44% → Suggest: 11%  │
│ [Use 11%] [Use 5%] [Custom]│
└────────────────────────────┘
```

---

## 5. Filter / Tab Recommendations

### 5.1 Proposed Tab Architecture (5 Tabs, Not 13)

**Principle:** Tabs should represent **investor mental models**, not **data sources**.

| Tab | Content | Primary User |
|-----|---------|--------------|
| **🔥 Live Picks** | Active, investable, pre-filtered | Day trader / Active investor |
| **📊 Scoreboard** | Closed picks, verified track records | Verification researcher |
| **🧠 Strategies** | Leaderboard + per-strategy drilldown | Systematic trader |
| **⚙️ Filters** | Advanced filtering + custom views | Power user |
| **📚 Learn** | Guides, definitions, how to read metrics | New user |

**What happens to the other 8 tabs?**
- Overview stats → Merged into Live Picks header
- Verified Alpha → Merged as a filter toggle within Live Picks
- Smart Picks → Merged as a filter toggle within Live Picks
- US Equity Picks → Sub-filter within Live Picks (asset class)
- Dashboards / Links → Moved to footer
- Permutations / Performance / Score Tracker / ML Health → Moved to "Filters" tab under "Advanced Analytics"

### 5.2 The "Live Picks" Tab - Detailed Structure

```
┌──────────────────────────────────────────────────────────────────────┐
│  🔥 LIVE PICKS                    Last update: 3 min ago            │
│  ─────────────────────────────────────────────────────────────────  │
│  [All] [Crypto] [Equity] [Forex] [Commodity]  ← Asset class chips  │
│  ─────────────────────────────────────────────────────────────────  │
│  PRESET FILTERS:                                                   │
│  [🧠 Smart] [⭐ High Conviction] [✅ Verified Alpha] [🏆 S-Tier]   │
│  [Clear All]                                                       │
│  ─────────────────────────────────────────────────────────────────  │
│  SORT BY: Score ▾  |  SHOWING: 24 of 156 (investable only)         │
│  ─────────────────────────────────────────────────────────────────  │
│                                                                     │
│  ┌─ PICK CARD 1 ─────────────────────────────────────────────────┐ │
│  │ BTCUSDT  LONG  |  🏆 S-Tier  |  FWD WR 72% (n=47)            │ │
│  │ Entry: $84,200 → TP: $91,800 (+9.0%) | SL: $80,400 (-4.5%)  │ │
│  │ [Copy Setup]  [Size: 11%]  [Details ▼]                       │ │
│  └──────────────────────────────────────────────────────────────┘ │
│                                                                     │
│  ┌─ PICK CARD 2 ─────────────────────────────────────────────────┐ │
│  │ NVDA  LONG  |  🥇 A-Tier  |  FWD WR 61% (n=23)               │ │
│  │ Entry: $124.50 → TP: $142.00 (+14%) | SL: $115.00 (-7.6%)    │ │
│  │ ⚠️  Age: 18h  |  Decay risk: MODERATE                        │ │
│  │ [Copy Setup]  [Size: 8%]  [Details ▼]                        │ │
│  └──────────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────────────┘
```

### 5.3 Filter Button Hierarchy (Single Source of Truth)

**Current Problem:** 6 buttons do overlapping things.  
**Solution:** One primary entry point with **layered filters**.

| Layer | Control | Default State |
|-------|---------|---------------|
| **Asset Class** | Chip buttons: All / Crypto / Equity / Forex / Commodity | "All" |
| **Quality Gate** | Toggles: Smart Picks / High Conviction / Verified Alpha | All OFF (show all) |
| **Tier Floor** | Slider or chips: S-only / S+A / S+A+B / All | "S+A" (hide C-tier) |
| **Direction** | Chips: LONG / SHORT / Both | "Both" |
| **Time Filter** | Age: <6h / <24h / <48h / All | "<48h" |
| **Custom** | Symbol search, Score range, Trust range | Empty |

**The "High Conviction" button** should be the **primary CTA** for new investors. When clicked:
1. It auto-applies the validated edge filters (per asset class)
2. It shows an explainer panel: "Showing picks with statistically verified edge. Crypto: WR 60.3% on N=562. Equity: WR 68.1% on N=72."
3. It persists as the default view for returning users

---

## 6. Risk Communication

### 6.1 The "Risk Spectrum" Bar

Instead of discrete tier badges alone, show a **continuous risk spectrum** for each pick:

```
RISK: [████████░░░░░░░░░░░░]  LOW-MEDIUM (42/100)
       ↑ Green zone = comfortable
       Yellow = elevated attention needed
       Red = significant risk of loss
```

Risk score computed from:
- Historical WR% (weight: 40%)
- R:R ratio (weight: 20%)
- Sample size confidence (weight: 15%)
- Age decay (weight: 15%)
- Regime alignment (weight: 10%)

### 6.2 Decay Indicators (NEW)

**Current Issue:** No visual indication that old picks lose edge.  
**Solution:** Age-based decay warnings.

| Age | Indicator | Message |
|-----|-----------|---------|
| < 6h | 🟢 Fresh | "Recently generated - edge likely valid" |
| 6-24h | 🟡 Standard | "Within normal holding window" |
| 24-48h | 🟠 Stale | "Edge may be decaying - verify before entry" |
| > 48h | 🔴 Expired | "Pick approaching time exit - avoid new entry" |

### 6.3 The "Sample Size Warning"

| Sample Size (n) | Visual | Interpretation |
|-------------------|--------|----------------|
| n < 10 | ⚠️  Red dot | "Tiny sample - could be luck" |
| 10-29 | 🟡 Yellow dot | "Small sample - monitor closely" |
| 30-99 | 🟢 Green dot | "Adequate sample - statistically meaningful" |
| 100+ | 🟢 Double green | "Large sample - reliable edge" |

This should be displayed next to the FWD WR%: `FWD WR 72% (n=47) 🟡`

### 6.4 Communicating "This Is Risky" Without Scaring Users

**Wrong:** "This pick is high risk. You could lose money." (Scare tactic, no context)  
**Right:** "This pick has a 45% historical win rate with 2:1 R:R. Expected value is +0.35% per trade, but 55% of trades lose. Size accordingly."

Key principles:
1. **Always pair risk with expected value** - Risk without reward context is meaningless
2. **Use percentages, not absolutes** - "45% WR" not "You will probably lose"
3. **Offer sizing guidance** - "Suggest 5% position" converts abstract risk into concrete action
4. **Show the path to verification** - "This strategy has 47 resolved trades. Click to see history."

---

## 7. Mobile vs Desktop Optimization

### 7.1 Desktop (>1024px)

- Full table view with all columns
- Side-by-side pick cards (2-3 per row)
- Advanced filter panel (always visible)
- Keyboard shortcuts (1-9 for quick picks, Enter to expand)
- Multi-tab monitoring (live + closed simultaneously)

### 7.2 Tablet (768-1024px)

- Collapsible filter panel (hamburger menu)
- Single-column pick cards
- Swipe between tabs
- Sticky header with summary stats

### 7.3 Mobile (<768px) - Critical Differences

**Current Issue:** The audit page has `overflow-x: auto` on tables with `min-width: 800px`, forcing horizontal scroll on mobile. This is **unusable** for decision-making.

**Mobile-First Redesign:**

```
┌─────────────────────────────────┐
│  🔥 LIVE PICKS     🔔 3 alerts  │
├─────────────────────────────────┤
│  [All] [Crypto] [Equity]        │
├─────────────────────────────────┤
│  ┌─ BTCUSDT  LONG  🏆 ──────┐ │
│  │ $84,200 → $91,800 (+9%)   │ │
│  │ FWD WR: 72% (n=47) 🟡      │ │
│  │ R:R 2.0 | Age 3h | Fresh   │ │
│  │ [Copy] [Size: 11%] [▼]     │ │
│  └───────────────────────────┘ │
│  ┌─ NVDA  LONG  🥇 ──────────┐ │
│  │ $124.50 → $142.00 (+14%)  │ │
│  │ FWD WR: 61% (n=23) 🟡      │ │
│  │ ⚠️  Age 18h - Stale         │ │
│  │ [Copy] [Size: 8%] [▼]      │ │
│  └───────────────────────────┘ │
│  ┌─ ETHUSDT SHORT 🔻 ────────┐ │
│  │ C-Tier - Hidden by default │ │
│  └───────────────────────────┘ │
├─────────────────────────────────┤
│  [🏆] [🥇] [🥈] [🔻] Tier    │
│  [Smart] [HC] [VA] Filters    │
└─────────────────────────────────┘
```

**Mobile-Specific Features:**
- **Swipe to dismiss** a pick (archive it from your view)
- **Long-press to copy** setup to clipboard
- **Bottom sheet** for position sizing calculator
- **Push notifications** for new S-tier picks
- **One-tap order** integration with connected exchanges

### 7.4 The "Mobile Decision Stack"

On mobile, the 10-second rule is even more critical. Reduce to 4 decisions:

1. **Symbol + Direction** (big, top)
2. **Tier + FWD WR** (badge, below)
3. **TP/SL + R:R** (numbers, compact)
4. **One primary action** (Copy / Size / Skip)

Everything else (strategy name, confidence, penalties, source system) goes behind the [▼] expand.

---

## 8. Specific Recommendations for Current Issues

### 8.1 FWD WR% at Strategy-Symbol-Direction Level

**Current:** FWD WR shown at strategy-level only.  
**Fix:** Show **three levels** of WR with progressive disclosure:

```
FWD WR: 72% (n=47) ▼
  ├─ Strategy overall: 68% (n=312)
  ├─ Strategy + Symbol: 72% (n=47) ← THIS IS THE KEY NUMBER
  └─ Strategy + Symbol + Direction: 75% (n=23)
```

The **Strategy + Symbol** level is the most predictive and should be the primary displayed value.

### 8.2 "L20", "L50", "L100" Meaning

**Current:** No explanation in UI.  
**Fix:** Rename with inline tooltip:

| Old Label | New Label | Tooltip |
|-----------|-----------|---------|
| L20 | Last 20 Trades | "Win rate over the most recent 20 resolved trades. Short-term momentum indicator." |
| L50 | Last 50 Trades | "Win rate over the most recent 50 resolved trades. Medium-term trend." |
| L100 | Last 100 Trades | "Win rate over the most recent 100 resolved trades. Long-term baseline." |

Visual: Show as a **mini sparkline** or **3-dot indicator**:
```
Momentum: ●●● (L20=72% > L50=61% > L100=58%) → Improving
Momentum: ●●○ (L20=45% < L50=58% < L100=62%) → Degrading ⚠️
```

### 8.3 Visual Gate Pass Indicators

**Current:** No visual indication of which picks passed which gates.  
**Fix:** The "Confidence Stack" (Section 3.3) + **gate pass badges** on each pick card.

### 8.4 Position Sizing Guidance

**Current:** Completely absent.  
**Fix:** Add a "Size Position" button that opens:
- Kelly calculator (with fractional adjustment)
- Account balance input (or auto-detect from connected exchange)
- Risk % suggestion based on tier
- Max drawdown warning if position exceeds 25% of portfolio

### 8.5 Kill-Switch / Decay Indicator

**Current:** Absent.  
**Fix:**
1. **Age-based decay** (Section 6.2)
2. **Rolling window WR%** - If L20 WR drops below L100 WR by >15pp, show "⚠️ Momentum degrading" badge
3. **Auto-archive** - Picks older than 48h auto-move to "Expired" section
4. **Regime shift alert** - If market regime changes (e.g., BULLISH → BEARISH), all counter-trend picks get red border

---

## 9. Implementation Priority Matrix

| Priority | Feature | Effort | Impact | User |
|----------|---------|--------|--------|------|
| **P0 - Must Have** | Simplified tab structure (5 tabs) | Medium | Very High | All |
| **P0 - Must Have** | High Conviction as primary CTA | Low | Very High | New |
| **P0 - Must Have** | Per-strategy-symbol FWD WR display | Medium | Very High | All |
| **P0 - Must Have** | Mobile card-based layout | High | Very High | Mobile |
| **P1 - Should Have** | Confidence Stack gate indicators | Medium | High | All |
| **P1 - Should Have** | Position sizing calculator | Medium | High | All |
| **P1 - Should Have** | Decay indicators (age + momentum) | Low | High | All |
| **P1 - Should Have** | Sample size warning dots | Low | High | All |
| **P2 - Nice to Have** | Risk spectrum bar | Medium | Medium | All |
| **P2 - Nice to Have** | One-tap exchange integration | High | Medium | Power |
| **P2 - Nice to Have** | Push notifications for S-tier | Medium | Medium | Power |
| **P2 - Nice to Have** | Keyboard shortcuts (desktop) | Low | Low | Power |

---

## 10. Answer to User's Original Question

> "In terms of user interface on findtorontoevents.ca/audit --> 'active picks' where would the users ideally find the items to invest in? Would they use --> 'high-conviction picks' button? smart picks (filter? tab)? .. verified alpha?"

### The Definitive Answer:

**Users should click "HIGH CONVICTION"** as the primary entry point to find investable picks.

**Why:**
1. It is the **only button** with a statistically verified, per-asset-class edge manifest:
   - Crypto: FWD WR >= 45% + Score >= 55 + Trust >= 6 → 60.3% WR on N=562
   - Equity: FWD WR >= 55% + Score >= 50 + Trust >= 5 → 68.1% WR on N=72
   - Forex: FWD WR >= 55% + Score >= 40 + Trust >= 5 → 65.8% WR on N=73

2. It applies **both** the shared `hc_filter.js` gates AND per-asset validated-edge gates

3. It has the **best documented methodology** (MERCURYPROMPT.md)

**However, the current UI has these problems:**

| Problem | Why It Confuses Users |
|---------|----------------------|
| 6 competing filter buttons | No clear hierarchy - users don't know which to trust |
| "Smart Picks" tooltip disclaimer | "Cannot be verified as edge on closed data" - but still prominently displayed |
| "Best Score" != Smart Picks backend | Two different scoring systems with similar names |
| "Proven Only" uses stale registry | Doesn't run live closed-pick query |
| No per-strategy-symbol-direction WR | Strategy-level WR masks symbol-specific performance |

### Recommended Fix:

Replace the 6-button filter bar with:

```
┌─ FIND PICKS TO INVEST ──────────────────────────────────────────┐
│  [🔥 HIGH CONVICTION] ← PRIMARY (default, pre-selected)       │
│  [🧠 Smart Picks] [✅ Verified Alpha] [🏆 S-Tier Only]        │
│  ─────────────────────────────────────────────────────────────  │
│  Showing picks with statistically verified per-asset edge:      │
│  • Crypto: 60.3% WR (N=562) | • Equity: 68.1% WR (N=72)      │
└─────────────────────────────────────────────────────────────────┘
```

Make **High Conviction the default view** for all users. Advanced users can toggle to Smart Picks or Verified Alpha, but new investors should land on the statistically defensible filter.

---

## Appendix A: Current Button Tooltip Analysis (What the UI Actually Says)

| Button | Tooltip Text | User Interpretation Risk |
|--------|-------------|-------------------------|
| Best Score | "Dashboard-score preset only. Useful for exploration, but not the same as the Smart Picks backend." | User thinks they're getting Smart Picks but aren't |
| Proven Only | "Does NOT run a live closed-pick query. For the actual empirically-validated edge, look for ML-enhanced strategies with confidence 0.8-0.9." | Stale data - user sees old "proven" picks that may now be losing |
| Smart Picks | "Closed-pick analysis shows the underlying confluence/score fields are missing from most historical records, so the Smart Picks filter cannot be verified as an edge on closed data." | **This is a major red flag buried in a tooltip** |
| High Conviction | "RECOMMENDED (all asset classes): Applies hc_filter.js gates + stamped S/A/B tier path." | Correctly labeled as recommended, but purple highlight ambiguity |
| Verified Alpha | "Filter Active Picks down to verified prediction-market and auditable pro-trader rows." | Unclear overlap with High Conviction - are these subsets? supersets? |

---

## Appendix B: Data Verification Notes

This audit is based on:
1. Live HTML/CSS/JS extraction from findtorontoevents.ca/audit (1.16MB payload)
2. Update logs from /updates/ documenting filter logic and scoring changes
3. Code-level analysis of `hc_filter.js`, `applySmartPicks()`, `renderVerifiedAlpha()`, and tier thresholds
4. The MERCURYPROMPT.md edge manifest (2026-04-14)

All tier thresholds, WR statistics, and gate parameters were verified against the live embedded JavaScript constants (`HC_GATE_PARAMS_EMBEDDED`) and the `passesValidatedEdgePerClass()` function.

---

*Report generated for orchestrator integration. All recommendations are designed around the core principle: "Can a trader make the right decision in under 10 seconds?"*
