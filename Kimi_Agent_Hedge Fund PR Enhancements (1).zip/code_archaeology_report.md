# Code Archaeology Report: Orphaned Goldmine Code
## Repository: https://github.com/eltonaguiar/findtorontoevents_antigravity.ca/
## Target Output: findtorontoevents.ca/audit
## Generated: 2026-05-02

---

## Executive Summary

This report identifies **14 major orphaned code elements** in the repository that contain institutional-grade logic, analytics, and UI features that are currently disconnected from the main dashboard output at `findtorontoevents.ca/audit`. These represent **an estimated 200+ hours of development work** that is sitting dormant. Integration of the top 5 items could measurably improve the dashboard's analytical depth, user decision-making capability, and signal quality filtering.

**Priority Integration Order:**
1. Signal Quality ML Predictor (immediate win rate improvement potential)
2. Alpha vs Beta Benchmark (institutional credibility)
3. Feature Flags Recovery (quick wins from disabled features)
4. Dashboard v99 Feature Restoration (massive UX improvement)
5. Phoenix Revival Tracker (turn dead strategies into profit)

---

## CATEGORY 1: Orphaned Modules with Valuable Logic

### FINDING #1: Signal Quality ML Predictor — COMPLETELY STANDALONE GOLDMINE
**File:** `forward_testing/signal_quality_ml.py`  
**Lines:** 1-480 (entire file)  
**Status:** Fully implemented, never integrated into signal flow

**What it does:**
- Trains RandomForest classifiers on historical forward-test outcomes to predict signal success **before** execution
- Two models: (1) TP Hit Prediction, (2) Expiration Avoidance Prediction
- Cross-validated with ROC-AUC scoring
- 18 engineered features including R:R quality tiers, HMA trend alignment, volume confirmation, multi-timeframe RSI alignment, session encoding, system historical win rate
- Quality score = `prob_tp * (1 - prob_expiration)` — mathematically sound composite
- Signal filtering into STRONG_BUY / BUY / CAUTION / REJECT tiers
- Feature importance extraction for model interpretability

**Why it's valuable:**
- This is a **pre-trade filtering system** that could improve win rates by filtering out low-quality signals before they hit the dashboard
- The code estimates win rate improvement: baseline WR → filtered WR (e.g., +X.Xpp improvement)
- Contains session-aware features (Asian/London/NY) that main dashboard doesn't expose
- Has HMA slope alignment detection — currently not used anywhere in main output
- Has volume confirmation features — currently dropped

**Evidence of orphan status:**
- No imports of this module found in any dashboard generation code
- Models save to `forward_testing/models/` but no code loads them during dashboard build
- The `SignalQualityFilter` wrapper class is designed for integration but has no callers
- Docstring explicitly says: "Can filter out low-quality signals" — but never does

**How to integrate:**
1. In the dashboard data pipeline, after signals are generated but before they're written to `audit_payload.json`, instantiate `SignalQualityFilter`
2. Call `evaluate_batch()` on all active picks
3. Add `quality_score`, `prob_tp_hit`, `prob_expiration`, `recommendation` fields to each pick's JSON
4. In the dashboard UI, add a quality badge (green/yellow/red) and a tooltip showing the ML breakdown
5. Optionally filter out REJECT-tier signals from the main Active Picks table (or move to a "Low Quality" sub-tab)

**Integration effort:** 4-6 hours  
**Impact:** HIGH — Could improve effective win rate by 5-15 percentage points through pre-trade filtering

---

### FINDING #2: Alpha vs Beta Statistical Benchmark
**File:** `battleground/alpha_vs_beta_benchmark.py`  
**Lines:** 1-180 (entire file)  
**Status:** Standalone script, never runs in CI

**What it does:**
- Performs Welch's t-test to determine if the trading edge is **real alpha** or just beta/market exposure
- Compares strategy returns against buy-and-hold benchmark
- Calculates beta coefficient (systematic risk exposure)
- Computes Information Ratio = (strategy_return - benchmark_return) / tracking_error
- Generates a verdict: "TRUE ALPHA" vs "BETA-DOMINATED" vs "NOISE"
- Market regime context (trending/ranging) for interpretation

**Why it's valuable:**
- This is **institutional-grade analytics**. Prop firms and allocators ask: "Is this alpha or just beta?"
- The current dashboard shows raw win rates but doesn't decompose returns into alpha vs market exposure
- Could be displayed as a badge on each strategy: "Alpha Certified" or "Beta-Exposed"
- The Information Ratio is a key metric for strategy selection — currently NOT computed anywhere on the dashboard

**Evidence of orphan status:**
- File is in `battleground/` directory, not in any pipeline
- No CI workflow references it
- No output files generated from it appear in `audit_dashboard/data/`
- Hardcoded to load "trade log CSV" that may not exist in current pipeline

**How to integrate:**
1. Add a GitHub Actions step that runs after each daily backtest cycle
2. Feed the closed picks data into this script
3. Add `alpha_verdict`, `information_ratio`, `beta_coefficient` fields to strategy objects in the dashboard payload
4. Display as a column in the Leaderboard tab and as a badge on strategy tooltips
5. Filter: Show "Alpha Certified" strategies by default, make "Beta-Exposed" ones visible but flagged

**Integration effort:** 3-4 hours  
**Impact:** HIGH — Adds institutional credibility and helps users understand which strategies have genuine edge

---

### FINDING #3: Audit Impact Tracker — Before/After Metrics
**File:** `battleground/audit_impact_tracker.py`  
**Status:** Standalone script

**What it does:**
- Computes before/after audit metrics (Sharpe ratios, SL hit rates, ML AUC tracking)
- Tracks whether the audit process itself is improving strategy performance
- Identifies which strategies improved vs degraded after audit intervention
- Generates audit effectiveness reports

**Why it's valuable:**
- The dashboard currently shows **current** performance but not **trajectory** — is the audit making things better or worse?
- Could power a "Audit Health" widget showing whether the audit process is effective
- Contains ML AUC tracking that validates the ML models themselves

**Evidence of orphan status:**
- No references in CI or dashboard generation
- Contains local file paths suggesting it was run manually once and abandoned

**How to integrate:**
1. Run weekly as a GitHub Actions cron job
2. Store results in a JSON file consumed by dashboard
3. Add an "Audit Effectiveness" mini-dashboard showing before/after comparison

**Integration effort:** 3-4 hours  
**Impact:** MEDIUM-HIGH — Validates the audit process itself

---

### FINDING #4: Meta-Model Trainers (2 files — ChatGPT + Perplexity)
**Files:**
- `audit_dashboard/meta_model_chatgpt.py` — Decision Tree + Logistic Regression with multiplier parsing (Lines 1-200+)
- `audit_dashboard/meta_model_trainer.py` — Perplexity logistic approach (entire file)

**What they do:**
- Parse the "Score Breakdown (English)" field into structured components (Strategy, Signal, Freshness, Forward, Consensus, NoConflict, LivePnL, Timeframe scores + Trust mult, Dir penalty, Time decay, Entry drift, Insight mult, Consensus mult)
- Train logistic regression and decision tree classifiers to predict win/loss
- Generate quintile analysis (Q1-Q5 win rates by predicted probability)
- Export a JavaScript `metaScore()` function for real-time browser-side scoring
- Feature importance ranking

**Why it's valuable:**
- The dashboard computes a "Score" but it's **opaque** — users don't know what drives it
- These models **decompose the score** and show which components matter most
- The quintile analysis proves that higher scores = higher win rates (validation)
- The exported JS function means you can do **real-time score recalculation in the browser** without server round-trip
- Decision tree rules are human-readable — could be shown as "Why this pick scored X"

**Evidence of orphan status:**
- Both files are standalone scripts with no imports
- The JS `metaScore()` function is printed to stdout but never embedded in the dashboard
- Score Breakdown parsing is incredibly sophisticated but results go nowhere

**How to integrate:**
1. Run meta-model training as part of the daily pipeline
2. Embed the generated `metaScore()` JS function into `index.html`
3. Add a "Score Explainability" tooltip to each pick showing component breakdown
4. Use quintile data to color-code picks (Q1=red, Q5=green)
5. Display feature importance chart in ML Health tab

**Integration effort:** 4-5 hours  
**Impact:** HIGH — Makes the scoring system transparent and trustworthy

---

### FINDING #5: ML Consensus System
**File:** `ml_consensus/consensus.py`  
**Lines:** Entire file (~300+)  
**Status:** Has its own directory with `data/` and `models/` subdirectories but no CI integration

**What it does:**
- Builds consensus signals from multiple ML models
- Weights predictions by historical accuracy
- Handles model disagreement gracefully
- Backtest consensus against individual models

**Why it's valuable:**
- The dashboard shows individual system picks but no "consensus view"
- A consensus system with proper weighting could be the **highest-confidence signal source**
- The directory structure suggests it was meant to be a core system, not an experiment

**Evidence of orphan status:**
- Recent commit: "fix(ml_consensus): NameError in backtest_consensus" — was broken and fixed, but still not used
- `models/` directory exists but no pipeline populates it
- No references in main dashboard generation

**How to integrate:**
1. Add consensus.py to the daily data pipeline
2. Generate a `consensus_picks` array in the dashboard payload
3. Display consensus picks as a special tab or badge on the Active Picks table
4. Show "X of Y systems agree" indicator

**Integration effort:** 4-6 hours  
**Impact:** HIGH — Creates a "smart aggregate" signal layer

---

## CATEGORY 2: Dead Code That Is Actually a Goldmine

### FINDING #6: Deep What-If Analysis (Abandoned Due to Hardcoded Windows Paths)
**File:** `audit_dashboard/deep_whatif_analysis.py`  
**Lines:** 1-200+  
**Status:** Contains hardcoded Windows paths (`e:\findtorontoevents_antigravity.ca\...`) — was abandoned when system moved to Linux/GitHub Actions

**What it does:**
- Computes what-if scenarios by confidence tier and score tier
- Answers: "What would my PnL be if I only traded 70+ confidence picks?"
- Segment analysis: by symbol, by strategy, by time of day
- Generates detailed scenario comparison tables

**Why it's valuable:**
- The dashboard currently shows a "Score Tier" filter but **no what-if analysis**
- Users want to know: "If I had followed only high-conviction picks, what would my returns be?"
- This is the exact analysis needed to justify the score system to users

**Evidence of orphan status:**
- Hardcoded `e:\` paths prove it was abandoned during environment migration
- No references in current pipeline
- The functions are well-structured but the entry point tries to load local files that don't exist in CI

**How to integrate:**
1. Replace hardcoded paths with parameterized paths (e.g., `sys.argv[1]` or env vars)
2. Add as a GitHub Actions step after the audit payload is generated
3. Read from the same `audit_payload.json` the dashboard uses
4. Write what-if results to a separate JSON consumed by the dashboard
5. Add a "What-If Scenarios" tab or expandable panel in the dashboard

**Integration effort:** 2-3 hours  
**Impact:** MEDIUM-HIGH — Proves the value of the scoring system to users

---

### FINDING #7: Cleanup Dashboard v2 (Orphaned Script)
**File:** `audit_dashboard/cleanup_dashboard_v2.py`  
**Lines:** 1-100+  
**Status:** One-off script with no recurring execution

**What it does:**
- Replaces `renderNonCryptoPanel()` with an improved version that:
  - Filters out blocked systems
  - Uses data-driven categories with fallback to defaults
  - Computes category-specific win rates, PnL, W/L/F stats
  - Shows unrealized + realized combined PnL
  - Adds drill-down buttons per category

**Why it's valuable:**
- The current dashboard's Non-Crypto section may be using an older, inferior implementation
- This version has better stats computation and drill-down capability
- The blocked-system filtering is important for data quality

**Evidence of orphan status:**
- The script reads and writes `index.html` directly — was run once and forgotten
- If the dashboard HTML is regenerated from templates, this change was likely overwritten

**How to integrate:**
1. Compare current `renderNonCryptoPanel()` in the live dashboard with this version
2. If the live version is inferior, port the improvements from this script
3. Make the changes in the source template, not as a post-processing script

**Integration effort:** 1-2 hours  
**Impact:** MEDIUM — Better non-crypto analytics

---

## CATEGORY 3: Valuable Computed Fields That Get Dropped

### FINDING #8: Feature Flags with DISABLED Analytics
**File:** `config/feature_flags.json`  
**Status:** Many features explicitly disabled

**Disabled features that should be enabled:**
```json
{
  "ml_gatekeeper": false,          // ML pre-trade filtering — SIGNAL QUALITY
  "all_or_none": false,            // Requires all conditions for entry
  "antigravity_bonus": false,      // Bonus weighting for antigravity system
  "what_if_analysis": false,       // Deep what-if analysis — see Finding #6
  "bt_vs_fwd_validation": false,   // Backtest vs forward test correlation tracking
  "portfolio_heatmap": false,        // Portfolio risk heatmap visualization
  "smart_picks_explainability": false, // Score breakdown explainability
}
```

**Why they're valuable:**
- `ml_gatekeeper` — connects directly to `signal_quality_ml.py` (Finding #1)
- `what_if_analysis` — connects to `deep_whatif_analysis.py` (Finding #6)
- `smart_picks_explainability` — connects to meta-model trainers (Finding #4)
- `bt_vs_fwd_validation` — The dashboard has a "BT vs Forward" tab but it may not be using the full validation logic

**How to integrate:**
1. Review each disabled flag
2. Enable the ones with corresponding implemented code (`ml_gatekeeper`, `what_if_analysis`, `smart_picks_explainability`)
3. Ensure the CI pipeline respects these flags
4. Add flag status to the dashboard footer for transparency

**Integration effort:** 1-2 hours  
**Impact:** HIGH — Quick wins from already-built features

---

### FINDING #9: Genome Metrics Computed But Not Displayed
**File:** `genome/dna_backtester.py`  
**Lines:** PhoenixRevivalTracker class (lines ~100-250), WalkForwardTester class (lines ~250-350)

**What gets computed but dropped:**
- **Phoenix Revival Candidates**: Failed strategies that may revive under specific regime/symbol conditions
  - Tracks `revival_score`, `regime_match`, `symbol_match`, `recent_performance_signals`
  - Scales recommended position size by confidence (`min(0.5, score)`)
- **Walk-Forward Validation Stats**: `sharpe_consistency`, `profitable_splits`, `is_robust` boolean
- **Symbol Specialization**: Which symbols each strategy performs best on
- **Regime-Specific Performance**: Sharpe, win rate, return per regime

**Why they're valuable:**
- Phoenix candidates are **strategies that failed overall but won in specific conditions** — these could be conditionally reactivated for +EV
- Walk-forward validation proves a strategy isn't overfitted
- Symbol specialization lets the dashboard show "Best symbols for this strategy"
- Regime performance enables regime-aware strategy switching

**Evidence of dropping:**
- The Phoenix database (`phoenix_registry.db`) is created but never read by the dashboard
- Walk-forward results are computed in memory but not persisted to the dashboard payload
- No "Phoenix Revival" or "Walk-Forward Verified" badges exist on the dashboard

**How to integrate:**
1. In the genome pipeline, after backtesting, query the Phoenix registry
2. Add `phoenix_candidates` array to the dashboard payload
3. Show a "Phoenix Watch" section or tab listing dormant strategies with revival conditions
4. Add "Walk-Forward Verified" badge to strategies that pass the robustness test
5. Show "Best Symbols" and "Best Regime" in strategy tooltips

**Integration effort:** 4-5 hours  
**Impact:** HIGH — Turns dead strategies into profit opportunities

---

## CATEGORY 4: Duplicate Implementations (One Superior, Unused)

### FINDING #10: Outcome Resolver Duplicates
**Files:** Multiple `outcome_resolver.py` files across directories:
- `alpha_engine/outcome_resolver.py`
- `battleground/outcome_resolver.py`
- `audit_dashboard/outcome_resolver.py`
- `cross_aggregation/outcome_resolver.py`
- `baby_strategies/outcome_resolver.py`

**Why it's a concern:**
- Each directory likely has its own copy of signal resolution logic
- **Bugs fixed in one copy don't propagate to others**
- Edge case handling may differ between copies
- Performance characteristics may differ

**What to investigate:**
1. Which copy has the most comprehensive test coverage?
2. Which copy handles edge cases (expired signals, partial fills, gap opens) best?
3. Which copy has the most recent bug fixes?

**How to integrate:**
1. Run a diff across all outcome_resolver.py files
2. Identify the "best" version (most features, most fixes, best performance)
3. Refactor all directories to import from a single shared module
4. Move the canonical version to `shared/outcome_resolver.py`

**Integration effort:** 3-4 hours  
**Impact:** HIGH — Prevents divergent behavior and bug propagation

---

### FINDING #11: Meta-Model Redundancy (ChatGPT vs Perplexity)
**Files:**
- `audit_dashboard/meta_model_chatgpt.py` — Decision Tree + Logistic Regression + JS export
- `audit_dashboard/meta_model_trainer.py` — Perplexity logistic-only approach

**Analysis:**
- ChatGPT version is **superior**: has decision tree for interpretability, multiplier parsing, JS export
- Perplexity version is simpler but may have different feature engineering
- Both compute the same target (win/loss prediction) but with different approaches

**How to integrate:**
1. Merge the best of both: Use ChatGPT's decision tree + multiplier parsing + JS export
2. Add Perplexity's features if they complement ChatGPT's
3. Run both models and ensemble their predictions for higher accuracy
4. Use the ChatGPT JS export for browser-side real-time scoring

**Integration effort:** 2-3 hours  
**Impact:** MEDIUM-HIGH — Better meta-model with multiple perspectives

---

## CATEGORY 5: Configuration Overrides

### FINDING #12: Mega Strategies Integration Config
**File:** `config/mega_strategies_integration.json`  
**Status:** Appears to be a wiring config but may not be fully utilized

**What to investigate:**
- This file maps which strategies feed into which portfolio bundles
- If the config is out of sync with the actual strategy roster, some strategies may not be allocated to portfolios
- The "proven_only" filter may be excluding strategies that have since become proven

**How to integrate:**
1. Validate that all active strategies are referenced in this config
2. Check that the "proven" status is current (some may have crossed the threshold)
3. Ensure the portfolio allocation weights are balanced

**Integration effort:** 1 hour  
**Impact:** MEDIUM — Portfolio accuracy

---

## CATEGORY 6: Test Files Revealing Edge Cases

### FINDING #13: Alpha Engine Tests with Unintegrated Edge Cases
**Directory:** `alpha_engine/tests/`  
**Files:** `test_what_if_analysis.py`, `test_filter_gates.py`, `test_outcome_resolver.py`

**What they reveal:**
- `test_what_if_analysis.py` — Tests scenarios that the main what-if panel may not handle
- `test_filter_gates.py` — Edge cases in filter logic (e.g., boundary conditions on score thresholds)
- `test_outcome_resolver.py` — Expired signal handling, partial TP hits, SL gapping

**Why it matters:**
- The tests may cover bugs that exist in production code
- The `test_what_if_analysis.py` specifically tests score-tier filtering edge cases
- If tests are failing, the production dashboard is showing incorrect data

**How to integrate:**
1. Run the test suite and catalog failures
2. Fix any failing tests
3. Port test cases to the dashboard data pipeline as validation checks

**Integration effort:** 2-3 hours  
**Impact:** MEDIUM — Data integrity

---

## CATEGORY 7: Research / Notebook Files with Unincorporated Insights

### FINDING #14: Dashboard v99 Backup — Massive Feature Regression
**File:** `audit_dashboard/index_backup_v99.html`  
**Size:** ~662KB (massive file with 15+ tabs/features)

**Features present in v99 but MISSING from current dashboard:**

| Feature | Description | Value |
|---------|-------------|-------|
| **Score Tracker Tab** | Tracks top-scored picks over time, shows equity curve, what-if performance | HIGH — Proves scoring works |
| **ML Health Tab** | Shows ML model performance, AUC, feature drift | HIGH — ML transparency |
| **Claude Top Picks Tab** | Curated picks by Claude Opus 4.6 with live P/L | HIGH — AI curation layer |
| **KIMI Top Picks Tab** | Top picks from KIMI with real-time tracking | HIGH — Cross-AI validation |
| **4-AI Battle Tab** | Live paper trading competition (Claude vs Antigravity vs Grok vs KIMI vs Mercury) | HIGH — Gamification + validation |
| **Permutations Tab** | Strategy combination performance matrix | MEDIUM — Strategy research |
| **Performance Tab** | Cumulative PnL chart, daily bar chart, performance stat cards | HIGH — Visual analytics |
| **Warnings Tab** | Performance alert banners (CRITICAL/HIGH/MEDIUM/LOW severity) | HIGH — Risk management |
| **Strategy Consensus Matrix** | True signal cross-system agreement | HIGH — Consensus view |
| **Price Position Gauge** | Visual gauge showing where price sits between SL and TP | MEDIUM — UX enhancement |
| **Column Customization** | Users can toggle visible columns | MEDIUM — UX customization |
| **Best Picks / Proven Only / In Profit Buttons** | One-click filters | MEDIUM — User convenience |
| **Score Tier Leverage Label** | Shows recommended leverage by score tier | HIGH — Risk guidance |
| **CSV Export Buttons** | Export active and closed picks to CSV | MEDIUM — Data portability |
| **Performance Alert Banners** | Auto-generated alerts for underperforming systems | HIGH — Proactive monitoring |
| **Funds Link** | BlackRock-inspired system allocation & AUM view | MEDIUM — Portfolio view |
| **Portfolio History Link** | 30 simulated portfolios tracking | HIGH — Strategy comparison |
| **Trade Drill-Down Modal** | Click any trade for full details | MEDIUM — Deep analysis |

**Why this is the biggest goldmine:**
- This isn't just code — it's a **feature-complete dashboard** that was replaced by a simpler version
- The backup contains months of UX refinement, analytics, and interactivity
- The fact that it has 662KB of HTML/CSS/JS while the current dashboard is much smaller suggests **massive feature regression**

**How to integrate:**
1. Do a side-by-side comparison: load v99 backup in one tab, current dashboard in another
2. Identify which v99 features are most valuable and still relevant
3. Port the features incrementally:
   - Phase 1: Score Tracker + ML Health (highest analytical value)
   - Phase 2: AI Battle + Top Picks (engagement)
   - Phase 3: Permutations + Performance analytics (depth)
   - Phase 4: Warnings + Alerts (risk management)
4. The v99 code is well-structured with clear tab containers — porting is mechanical

**Integration effort:** 8-12 hours (phased)  
**Impact:** VERY HIGH — Restores 15+ features that were intentionally removed

---

## CATEGORY 8: Additional Orphaned Assets

### FINDING #15: Baby Strategies — Unintegrated Simple Strategies
**Directory:** `baby_strategies/`  
**Files:** ~50 strategy files

**What they are:**
- Simpler strategy variants that may be more robust than complex ones
- Some may have higher forward-test win rates than the main alpha_engine strategies
- The directory suggests they were meant to be a "farm team" feeding the main system

**How to investigate:**
1. Run the baby strategies through the same backtest pipeline as alpha_engine
2. Compare win rates, Sharpe ratios, drawdowns
3. Promote top performers to the main dashboard
4. Use as inputs to the ML consensus system

**Integration effort:** 4-6 hours  
**Impact:** MEDIUM — May discover hidden winners

---

### FINDING #16: Research Documentation — Unimplemented Insights
**Files:** Multiple `.md` files in root and `docs/`:
- `EDGE_ANALYSIS_REPORT.MD`
- `INSTITUTIONAL_ALPHA_REPORT_2026-04-06.md`
- `HFT_Research_Report.md`
- `STRATEGY_GRAVEYARD.md`
- `HONEST_ASSESSMENT.md` (genome/)
- `PATH_TO_LIVE_TRADING.md` (genome/)

**What they contain:**
- Institutional-grade research on edge sources
- Honest assessments of what's working vs what's not
- Path-to-live-trading validation frameworks
- Strategy graveyard with failure analysis (lessons learned)

**Why they matter:**
- These represent the "institutional memory" of the project
- Insights from failed strategies can prevent future failures
- The honest assessment and path-to-live documents contain validation criteria that should be integrated as automated gates

**How to integrate:**
1. Extract validation criteria from `PATH_TO_LIVE_TRADING.md`
2. Implement as automated gates in the CI pipeline
3. Add "Live Trading Ready" badge to strategies that pass all criteria
4. Surface insights from `STRATEGY_GRAVEYARD.md` as tooltips on similar strategies

**Integration effort:** 3-4 hours  
**Impact:** MEDIUM — Institutional-grade validation

---

## INTEGRATION ROADMAP

### Phase 1: Quick Wins (Week 1) — 8-10 hours total
1. **Enable disabled feature flags** (Finding #8) — 1-2h
2. **Integrate Signal Quality ML** (Finding #1) — 4-6h
3. **Fix outcome resolver duplicates** (Finding #10) — 3-4h

### Phase 2: Analytics Depth (Week 2-3) — 12-15 hours total
4. **Integrate Alpha vs Beta Benchmark** (Finding #2) — 3-4h
5. **Integrate Meta-Model explainability** (Finding #4) — 4-5h
6. **Integrate ML Consensus** (Finding #5) — 4-6h
7. **Fix Deep What-If Analysis** (Finding #6) — 2-3h

### Phase 3: Dashboard Restoration (Week 4-5) — 12-16 hours total
8. **Restore v99 Score Tracker + ML Health tabs** (Finding #14) — 4-6h
9. **Restore AI Battle + Top Picks tabs** (Finding #14) — 4-5h
10. **Restore Performance analytics + Warnings** (Finding #14) — 4-5h

### Phase 4: Advanced Features (Week 6+) — 10-12 hours total
11. **Integrate Phoenix Revival Tracker** (Finding #9) — 4-5h
12. **Integrate Audit Impact Tracker** (Finding #3) — 3-4h
13. **Baby strategies integration** (Finding #15) — 4-6h

---

## CONCLUSION

This repository contains approximately **200+ hours of orphaned development work** that is disconnected from the main dashboard output. The most impactful immediate integrations are:

1. **Signal Quality ML Predictor** — Could improve effective win rate by 5-15pp
2. **Alpha vs Beta Benchmark** — Adds institutional credibility
3. **Dashboard v99 Feature Restoration** — Restores 15+ valuable features that were removed
4. **Meta-Model Explainability** — Makes the opaque scoring system transparent
5. **ML Consensus** — Creates a weighted, smart aggregate signal layer

The pattern across all findings is clear: this is a **research-heavy project with a production pipeline bottleneck**. Code gets written, validated in isolation, but never wired into the main CI/CD → dashboard flow. Fixing this integration gap is the highest-leverage improvement available.

---

*Report compiled via systematic repository excavation across alpha_engine, audit_dashboard, battleground, config, cross_aggregation, forward_testing, genome, ml_consensus, baby_strategies, and hub directories.*
