# Sports Betting System Analysis & Enhancement Strategy
## FindTorontoEvents.ca Live Monitor — April 2026

---

## Executive Summary

The Sports Bet Winner Finder at findtorontoevents.ca represents a well-architected paper betting tracker with a solid analytical foundation (situational scoring, Kelly Criterion sizing, CLV tracking) but critical gaps in data infrastructure, market coverage, and prediction market integration. This analysis, conducted across 12 research dimensions, identifies eight strategic insights and a prioritized four-tier implementation roadmap. The highest-ROI action is upgrading The Odds API to the paid tier ($20/month for 1-minute refresh), which immediately unlocks steam move detection, arbitrage capture, and real-time line analysis that are currently impossible with the 2-3 hour free-tier refresh cycle. The most significant strategic opportunity is integrating prediction markets (Kalshi/Polymarket) via the Prediction Hunt unified API ($49/month Dev tier), which enables cross-platform arbitrage between traditional sportsbooks and prediction market contracts — a structural edge that pure value betting cannot match.

---

## 1. Current System Assessment

### 1.1 Performance Snapshot (as of April 25, 2026)

The system is tracking a $1,000 starting bankroll that has grown to $1,065.06, representing a 25.3% return on investment across 41 settled tickets (9 wins, 15 losses, 17 voided). The win rate of 37.5% (wins over wins-plus-losses) and 44.4% CLV beat rate on 9 tracked tickets are below the benchmarks for professional-grade sports betting systems — which typically target 52-55% win rates and greater than 55% positive CLV rates. However, with only 24 directional bets settled (excluding voids), the sample size remains statistically insufficient for meaningful performance evaluation. The Wilson 95% confidence interval on the win rate is wide, reflecting genuine uncertainty about whether the current edge is sustainable or a product of variance.

| Metric | Current | World-Class Benchmark | Gap |
|--------|---------|----------------------|-----|
| Win Rate (ML) | 37.5% | 52-55% | -14.5 to -17.5 pp |
| ROI | 25.3% | 3-8% (long-term) | Above benchmark* |
| CLV Positive % | 44.4% | Greater than 55% | -10.6 pp |
| ML Features | 35+ | 50-200 | -15 to -165 |
| Data Sources | 7+ | 10-15 | -3 to -8 |
| Odds Refresh | 2-3 hours | Less than 1 minute | Critical gap |
| Bankroll | $1,065 | $5,000-50,000 | Scaling needed |

*The 25.3% ROI reflects a small sample size and is not expected to be sustainable at long-term scale. The apparent outperformance is likely driven by variance rather than genuine alpha at this sample size.

### 1.2 Architecture Strengths

The system demonstrates several sophisticated design decisions that differentiate it from basic odds comparison tools. The situational scoring module incorporates five research-backed factors with academic citations: back-to-back fatigue (drawing on Dean Oliver's 2004 Basketball on Paper research), rest advantage (Entine and Small 2008), turnover margin significance (Biro 2017), team ERA weighting (MDPI 2021), and injury report integration. This multi-factor approach to game state assessment exceeds the sophistication of most free or low-cost betting tools. The quarter-Kelly position sizing demonstrates sound bankroll management discipline, and the auto-betting circuit breakers ($100 daily loss limit, $800 bankroll floor) show risk management awareness that protects against catastrophic drawdown.

The GitHub repository reveals a mature CI/CD pipeline with 105,587+ commits across 376 branches, automated pick updates via GitHub Actions, and a modular architecture spanning audit dashboards, data pipelines, ML engines (v3.1 with XGB ensemble), and backtesting frameworks. The PHP-plus-Python ensemble approach (PHP heuristics with Python ML overlay) is pragmatic given the codebase's evolution.

### 1.3 Critical Gaps Identified

Seven capabilities are missing from the current system that represent the highest-priority enhancement opportunities:

1. **No arbitrage detection** — The system compares odds across 6+ books but does not flag guaranteed-profit opportunities where combined implied probabilities fall below 100%. This is Priority 5 in the user's own Research section.

2. **No real-time line movement tracking** — The 2-3 hour refresh cycle makes steam move detection, reverse line movement identification, and live arbitrage capture structurally impossible.

3. **No prediction market integration** — Kalshi and Polymarket offer sports contracts that can diverge from traditional book odds, creating cross-platform arbitrage opportunities.

4. **No weather integration** — Outdoor sports (NFL, MLB, CFL, MLS) are materially affected by weather conditions that are not currently factored into the situational scoring.

5. **No reverse line movement tracking** — This sharp money signal (line moves opposite to public betting percentages) is identified as Priority 2 in the Research section.

6. **No sport-specific models** — The current universal model applies the same heuristics across all sports, missing sport-specific dynamics.

7. **Insufficient training data for ML activation** — With 9 directional bets, the ML model cannot activate reliably. The benchmark requires 50-200+ settled bets for meaningful training.

---

## 2. Ontario Sportsbook Landscape & Mispricing Opportunities

### 2.1 Licensed Operator Analysis

Ontario's regulated sports betting market, launched in April 2022 under iGaming Ontario, now includes approximately 50 licensed operators. The ten most relevant for the Canadian-focused bettor are:

| Operator | Key Strength | Odds Quality | Live Betting | CAD Banking |
|----------|-------------|--------------|--------------|-------------|
| Tooniebet | Live betting, 24h withdrawals | High | Excellent | Interac, cards |
| bet365 | Superior odds pricing, cash-out | Very High | Excellent | Full CAD |
| FanDuel | Top mobile app | High | Excellent | Full CAD |
| BetMGM | Deep coverage, promotions | High | Good | Full CAD |
| Sports Interaction (SIA) | Canadian-localized markets | Medium | Good | Interac |
| NorthStar Bets | Canadian promotions | Medium | Good | Interac |
| Bet99 | Intuitive design | Medium | Good | Interac |
| TonyBet | Sportsbook-casino combo | Medium | Good | Full CAD |
| OLG Proline+ | Government-run | Medium (improved) | Good | OLG direct |
| Betway | Global brand presence | High | Excellent | Full CAD |

### 2.2 OLG Proline+ — The Historical Soft Target

The Ontario Lottery and Gaming Corporation's Proline+ platform has historically been known among sharp bettors for offering worse odds than international competitors — with vigorish (book margin) estimated at 15-20% compared to 4-6% at sharp books like Pinnacle. However, post-regulation competitive pressure appears to have narrowed this gap. A 2025 Dimers review found Proline+ odds "on par with market averages," suggesting the historical inefficiency may have partially corrected. The system should conduct its own ongoing Proline+ odds comparison against bet365 and Pinnacle to quantify current mispricing rather than relying on outdated assumptions.

### 2.3 Canadian-Specific Market Factors

Three structural factors create unique opportunities in the Ontario market. First, Canadian bettors show predictable biases toward home teams (particularly Maple Leafs, Raptors, Blue Jays), Canadian players, and popular narratives, which can inflate lines on the public side. Second, newer entrants like Tooniebet and NorthStar Bets may employ less sophisticated pricing models than established operators, creating temporary soft lines during market share acquisition phases. Third, OLG Proline+ restricts certain bet types (no single-game betting was the historical constraint that was lifted in 2021), and some legacy pricing habits may persist.

### 2.4 Promotional Exploitation

Ontario books offer recurring promotions — parlay insurance, odds boosts, risk-free bets, and deposit matches — that create positive expected value opportunities when used selectively. BetMGM and FanDuel in particular are aggressive with promotional offers for Ontario customers. A systematic promotional calendar tracker, tracking EV of each offer, could add 2-5% annual ROI with minimal risk.

---

## 3. Prediction Market Integration (Kalshi & Polymarket)

### 3.1 Kalshi — CFTC-Regulated Exchange

Kalshi operates as a Commodity Futures Trading Commission-regulated prediction exchange, offering event contracts on sports outcomes. The platform's sports offering includes NBA, WNBA, NFL, and college basketball moneylines, with expansion ongoing. In April 2026, Kalshi confirmed active partnership discussions with the NBA — a development that would significantly expand available sports contracts. Kalshi's key structural advantage is the absence of stake limits (unlike the $850 cap at PredictIt), allowing meaningful position sizes.

The Kalshi API uses RSA-PSS key pair authentication with session tokens expiring every 30 minutes, enforcing a 10 requests/second rate limit. A Python SDK is available via `pip install kalshi-python`. The platform charges fees on contracts, which means the breakeven win rate is higher than the implied probability — a factor that must be included in any cross-platform arbitrage calculation.

### 3.2 Polymarket — Decentralized Prediction Market

Polymarket has emerged as the world's largest prediction market, achieving a $9 billion valuation following a $2 billion investment from the parent company of the New York Stock Exchange in October 2025. The platform has secured exclusive sports partnerships with the NHL and MLB (competing with Kalshi for NHL partnership, with both platforms holding different team-level deals — e.g., Chicago Blackhawks-Kalshi and New York Rangers-Polymarket).

Polymarket's sports coverage is extensive: NBA, WNBA, NFL, college football, MLB, KBO (Korean baseball), e-sports, tennis, soccer (EPL, La Liga, Bundesliga, MLS, Champions League), hockey, golf, MMA, chess, motorsports, boxing, and cricket. Contract types span moneylines, spreads, totals, and multi-leg parlays. The platform operates on the Polygon blockchain using USDC stablecoin, with three distinct APIs: the Gamma API (public, for market discovery), the Data API (public, for positions and trades), and the CLOB API (authenticated, for order placement).

Critically, only 0.51% of Polymarket wallets have achieved profits exceeding $1,000, indicating that the platform is overwhelmingly a negative-sum environment for retail participants. However, this also means that informed participants with genuine edge can extract significant value from uninformed counterparties.

### 3.3 Prediction Hunt — The Unified API Gateway

The most important infrastructure discovery for this analysis is the Prediction Hunt v2 API, which provides unified access to Kalshi, Polymarket, PredictIt, ProphetX, and Opinion through a single REST interface with a simple API key header. Polymarket acquired Dome (the only YC-backed cross-platform prediction market API) in early 2026, leaving Prediction Hunt as the primary independent cross-platform aggregation service.

| Endpoint | Purpose | Tier Required |
|----------|---------|---------------|
| `GET /api/v2/matching-markets/sports` | Cross-platform sports market matching | Free |
| `GET /api/v2/arb` | Live arbitrage signals (15-sec delay) | Dev ($49/mo) |
| `GET /api/v2/ev` | Live positive-EV signals | Dev ($49/mo) |
| `GET /api/v2/prices/history` | OHLC candle data (1m to 1d intervals) | All tiers |
| `GET /api/v2/orderbook` | Live orderbook snapshot | All tiers |

The `/api/v2/matching-markets/sports` endpoint is particularly valuable: it groups equivalent markets across platforms by sport and league, returning a `MarketMatchGroup` object containing the same event's contracts on Kalshi, Polymarket, and other platforms with prices side-by-side. A complete NBA cross-platform arb scanner requires only a single HTTP call — no wallet setup, no Web3 SDK, no session token refresh logic.

Pricing tiers range from Free (1 req/sec, 1,000 requests/month) to Dev ($49/month, 20 req/sec, includes arbitrage and EV signals) to Pro ($249/month, 100 req/sec, all WebSocket channels). For a sports betting analytics system, the Dev tier represents exceptional value — it provides pre-computed arbitrage signals that would require weeks of engineering time to replicate manually.

### 3.4 Cross-Platform Arbitrage Mechanics

The arbitrage calculation between prediction markets follows a straightforward three-step process:

**Step 1 — Gross Spread Calculation**: Add the YES price on one platform to the NO price on the other. If the sum is less than $1.00, a gross opportunity exists. Gross Spread = $1.00 - (YES price + NO price). If the gross spread is zero or negative, no arbitrage exists regardless of fees.

**Step 2 — Fee Calculation**: Each platform charges different fees. Kalshi charges a fee on each contract traded, while Polymarket charges no explicit trading fees but has spread costs. These fees must be subtracted from the gross spread.

**Step 3 — Net Profit**: Net Profit = Gross Spread - (Platform Fees). If net profit is positive, the trade is viable. Typical viable arb opportunities in prediction markets range from 2-5 cents per dollar traded, with windows lasting minutes to hours depending on market liquidity.

In addition to Kalshi-Polymarket arbitrage, the system should monitor for sportsbook-to-prediction-market value opportunities — where a sportsbook's implied probability diverges significantly from the prediction market's consensus price. When the prediction market prices an outcome at 60 cents (implying 60% probability) but a sportsbook offers +180 odds (implying 35.7% probability), this represents a potential value bet if the prediction market is the more efficient price discovery mechanism.

---

## 4. Polymarket Wallet Intelligence & Copy-Trading Signals

### 4.1 Top Sports-Focused Wallets

Analysis of Polymarket's on-chain data reveals distinct trading strategies among profitable sports-focused wallets. The following six wallets represent the most instructive patterns for the user's system:

| Wallet | Strategy | Estimated Profit | Key Characteristics |
|--------|----------|-----------------|---------------------|
| Swiss Tony | Soccer underdog specialist | High volume, variable | Greater than 60% entries below 50 cents; EPL, Serie A, UCL focus |
| HyperLiquid0xb | MLB deep analysis | $1.4M+ | $755K single baseball win; deep domain expertise |
| RN1 | Underdog picker | Medium | Greater than 60% entries below 50 cents across sports |
| distinct-baguette | Automated crypto arb | $448K | 26,756 trades, $17 average profit per trade; pure automation |
| ColdMath | Weather niche specialist | High | 96% win rate; Buenos Aires, Cape Town, Dallas temperature markets |
| 0x1979/0x1d003/0xd1eb | Bot-driven strategies | Variable | Automated execution, high frequency |

### 4.2 Strategic Patterns

Three patterns emerge from wallet analysis that should inform the system's design. First, **domain specialization dominates** — the most profitable wallets focus on narrow niches (HyperLiquid0xb on MLB, ColdMath on weather, Swiss Tony on soccer) rather than trading across all markets. This validates the insight that the user should adopt a "narrow and deep" approach rather than "broad and shallow." Second, **underdog picking is a viable strategy on Polymarket** — Swiss Tony and RN1 both take positions below 50 cents more than 60% of the time, suggesting the platform may systematically overprice favorites due to retail bias toward likely outcomes. Third, **automation scales** — distinct-baguette's 26,756 trades at $17 average profit demonstrates that small-edge, high-frequency strategies can compound meaningfully.

### 4.3 Wallet Tracking Implementation

The Polymarket Data API provides public endpoints for wallet tracking: `GET /positions?user={address}` returns current positions, `GET /activity?user={address}` returns on-chain activity, and `GET /value?user={address}` returns total position value. A "whale alert" system could monitor these endpoints at 5-minute intervals for significant position changes by tracked wallets, cross-referencing with traditional sportsbook odds to identify value opportunities when sharp prediction market money disagrees with book pricing.

---

## 5. GitHub Libraries & Algorithms

### 5.1 Top Integration Candidates

Twelve open-source libraries were evaluated for integration potential with the existing PHP/Python stack:

| Library | Language | Purpose | Integration Effort | Priority |
|---------|----------|---------|-------------------|----------|
| sports-betting (georgedouzas) | Python | Backtesting, value bets, GUI | Medium | High |
| surebet (danielcardeenas) | Python | Real-time arb scanning | Medium | High |
| penaltyblog | Python | Dixon-Coles model for soccer/hockey | Low | Medium |
| SportsArbFinder (carterlasalle) | Python | The Odds API multi-region arb | Low | High |
| NBA-ML-Sports-Betting | Python | XGBoost/Neural Net for NBA | Medium | Medium |
| sports-ai-bettor | Python | RandomForest + Kelly Criterion | Low | Medium |
| nflalgorithm | Python | Position-specific NFL models | Medium | Low |
| value-bet-finder-multi-sport | Python | Multi-sport value finder | Low | Medium |
| sports-betting-steam-moves | Python | Steam move detection + XGBoost | Medium | High |
| alpha-football | Python | Market-neutral football arb | High | Medium |
| goto_conversion | Python | Odds conversion (Kaggle winner) | Low | Medium |
| flumine | Python | Betfair trading framework | High | Low |

### 5.2 Key Algorithms for Implementation

**Dixon-Coles Model**: This correlation-adjusted Poisson model is the gold standard for low-scoring sports (soccer, hockey) where standard Poisson underestimates draw probability. The model introduces a rho (correlation) parameter that adjusts for the dependence between home and away team scoring, along with time-decay weighting that discounts older results. Implementation via the `penaltyblog` Python library.

**Steam Move Detection**: The SHARP detection framework identifies coordinated line movements across multiple books: Size/Speed (how much and how fast), Historical context (comparison to typical movement), Across-board consistency (how many books moved), Reverse line movement (movement opposite to public betting), and Pattern recognition (syndicate signatures). The Sharp Sports API offers sub-50ms latency steam move alerts, or a Python implementation can be built using 1-minute odds snapshots.

**Kelly Criterion with Fractional Sizing**: The current quarter-Kelly approach is sound. The formula f* = (bp - q) / b where b = odds-1, p = win probability, q = 1-p, should be maintained with the 25% fractional multiplier to control variance given the small sample size.

---

## 6. Niche Sports & Underexplored Markets

### 6.1 Women's Sports — The "Soft Lines" Opportunity

Women's sports betting markets exhibit structural inefficiencies that knowledgeable bettors can exploit. Research identifies several root causes: limited historical data availability, less sharp bookmaker attention and investment in pricing models, slower adjustment to news (particularly in WNBA), softer opening lines before professional money enters, and public betting patterns that inflate odds on popular teams or players. The WNBA specifically shows these characteristics, as do women's soccer and the Professional Women's Hockey League (PWHL — the Canadian women's hockey league that replaced the collapsed PHF in 2023).

### 6.2 E-sports — Fastest Growing Betting Vertical

E-sports betting is the fastest-growing segment of the online wagering market, backed by celebrity investors including Drake, The Weeknd, and Steph Curry. The four primary titles for betting are League of Legends (annual Worlds tournament, regional leagues LCS/LEC/LCK), Counter-Strike 2 (Major tournaments, tier-1 team circuits), Dota 2 (The International with multi-million dollar prize pools), and Valorant (Riot Games' tactical shooter with growing competitive scene).

Unique bet types in e-sports create edges unavailable in traditional sports: first blood (first kill in LoL/Dota 2), pistol round winner (CS2/Valorant), first Roshan (Dota 2), map winner within series, total kills, and player-specific performance props. Game-specific knowledge requirements create higher barriers to entry and therefore softer lines from bookmakers who lack internal e-sports expertise. Tooniebet is rated the top Ontario sportsbook for e-sports, with embedded live streams and deep market coverage.

### 6.3 Canadian-Specific Sports

The Canadian Football League (CFL) represents a unique opportunity due to its small team pool (nine teams), predictable schedule, and lower bookmaker investment in pricing models compared to the NFL. The Canadian Premier League (CPL) — Canada's top-tier soccer league with eight teams — is a growing league where bookmaker expertise is limited and lines may be softer than established European leagues. The National Lacrosse League (NLL), while smaller, features uniquely Canadian/American indoor lacrosse with devoted regional followings that create local knowledge advantages.

---

## 7. Regulatory & Tax Considerations

### 7.1 Tax Status — Canada's Unique Advantage

Canada's treatment of gambling winnings represents a significant structural advantage for recreational bettors. Under Paragraph 40(2)(F) of the Income Tax Act, gambling winnings from sports betting, casino play, and lotteries are NOT taxable for recreational players. This contrasts sharply with the United States, where winnings are taxable income, and the United Kingdom, where betting duty is effectively built into odds. The tax savings effectively increase realized ROI by 15-33% compared to professional-classified bettors.

The critical distinction is between "recreational" and "professional" gambling status. Professional gamblers — defined as those whose primary income derives from gambling, who maintain organized profit tracking systems, and who demonstrate expert-level knowledge — must declare winnings as business income subject to 15-33% federal tax plus provincial tax. Ontario provincial rates range from 5.05% to 13.16% depending on income bracket.

### 7.2 Prediction Market Access for Canadians

Kalshi, as a CFTC-regulated exchange, is accessible to Canadian residents who can complete the know-your-customer verification process. Polymarket, operating on the Polygon blockchain, is accessible to anyone with a cryptocurrency wallet and USDC tokens, though Canadian cryptocurrency regulations require reporting of gains when converting crypto back to fiat. Neither platform is explicitly prohibited for Canadian residents, though users should be aware that prediction market regulation in Canada remains an evolving area without explicit legislative guidance.

### 7.3 Account Limitation Avoidance

All regulated Ontario sportsbooks reserve the right to limit accounts that demonstrate consistent winning patterns — a practice known as "gubbing." While specific limitation policies are not publicly documented, sharp betting communities report that bet365 and FanDuel are particularly aggressive with account limitations. Strategies to extend account longevity include: maintaining consistent bet sizes (avoiding sudden large wagers), mixing in recreational-looking bets on popular teams, avoiding obvious arbitrage patterns, and rotating activity across multiple bookmaker accounts rather than concentrating volume at a single operator.

---

## 8. Strategic Insight Synthesis

### 8.1 The Prediction Market Arbitrage Edge

Cross-platform arbitrage between sportsbooks and prediction markets represents a fundamentally different type of edge than traditional value betting. Where value betting relies on probability estimation accuracy (inherently uncertain), arbitrage relies on price discrepancies between platforms (mathematically certain when properly executed). The Prediction Hunt API's `/api/v2/arb` endpoint delivers pre-computed arbitrage signals with a 15-second delay — at $49/month for the Dev tier, this is likely the highest-ROI subscription the user can add. A single successful arbitrage trade on a $100 stake returning 3% gross ($3) pays for 18% of the monthly subscription cost.

### 8.2 Domain Specialization at Small Scale

With only 9 directional bets settled, attempting to build universal machine learning models is premature. The Polymarket wallet analysis reveals that the most profitable strategies are domain-specific — HyperLiquid0xb's deep MLB knowledge, ColdMath's weather niche expertise, Swiss Tony's soccer specialization. The user should adopt the same approach: pick 1-2 sports (NHL and NBA are the natural choices given Canadian market knowledge and data availability), develop deep domain-specific features, and achieve consistent positive CLV before expanding. The existing situational scoring system is actually more sophisticated than most competitors at this price point — the gap is data freshness, not analytical depth.

### 8.3 The Odds API Bottleneck

The $20/month paid tier for The Odds API (upgrading from 2-3 hour refresh to 1-minute refresh) has higher expected value than any algorithmic enhancement. Without real-time data, the system cannot detect steam moves, cannot capture arbitrage opportunities, cannot track line movement velocity, and cannot meaningfully assess CLV. This upgrade is the foundational dependency for nearly all other enhancements.

### 8.4 Women's Sports and E-sports as "Greenfield" Markets

The combination of market-immature categories (women's sports and e-sports) with Ontario-specific books creates a "triple inefficiency": new sports, new betting markets, and geographically-focused operators. Adding WNBA, PWHL, CS2, and LoL as tracked sports targets markets where less sharp money competes, bookmakers invest less in pricing sophistication, and domain expertise creates genuine information advantages.

---

## 9. Implementation Roadmap

### Tier 1: Immediate (Less Than 1 Week, Less Than $100)

**Action 1.1 — Upgrade The Odds API to Paid Tier** ($20/month)
- Unlocks 1-minute refresh rate (currently 2-3 hours)
- Enables steam move detection, arbitrage capture, real-time CLV tracking
- Single highest-impact infrastructure improvement

**Action 1.2 — Integrate Prediction Hunt API Free Tier** ($0)
- Test `/api/v2/matching-markets/sports` endpoint for NBA and NHL
- Display Kalshi/Polymarket prices alongside book odds in UI
- Validate cross-platform price divergence frequency

**Action 1.3 — Add WNBA as Pilot Niche Market** (Development effort)
- Leverage existing NBA data infrastructure for WNBA
- Track soft line opportunities identified in research
- Test domain specialization hypothesis with minimal incremental work

**Action 1.4 — Deploy Steam Move Detection MVP** (Development effort)
- Use Sharp Sports API or Python-based detection (code samples available)
- Alert on 3+ books moving same direction by 0.5+ points within 15 minutes
- Integrate with existing Discord/email notification system

### Tier 2: Short-Term (1-4 Weeks, Less Than $500)

**Action 2.1 — Subscribe to Prediction Hunt Dev Tier** ($49/month)
- Unlocks `/api/v2/arb` and `/api/v2/ev` signal endpoints
- 20 req/sec rate limit, WebSocket prices channel
- Automated cross-platform arbitrage alerts

**Action 2.2 — Integrate Weather API** (OpenWeatherMap free tier)
- Add weather factors to situational scoring for outdoor sports (NFL, MLB, CFL, MLS)
- Wind speed, temperature, precipitation as graded factors
- Academic research supports weather impact on totals and spread outcomes

**Action 2.3 — Develop NHL-Specific Situational Model** (Development effort)
- Add hockey-specific factors: goalie confirmed starter, defensive pairings, special teams efficiency
- Leverage existing balldontlie/NHL API data infrastructure
- Focus on Canadian market where local knowledge advantage is strongest

**Action 2.4 — Add CS2 and LoL as E-sports Pilots** (Development effort)
- Match winner, map winner, first blood markets
- Integrate with HLTV.org (CS2) and gol.gg (LoL) data sources
- Target Tooniebet and Betway odds for comparison

**Action 2.5 — Build Polymarket Whale Tracker** (Development effort)
- Monitor Swiss Tony (soccer) and HyperLiquid0xb (MLB) positions via Data API
- Alert on significant position changes
- Cross-reference with sportsbook odds for value bet signals

### Tier 3: Medium-Term (1-3 Months)

**Action 3.1 — Full Kalshi/Polymarket Price Comparison Module**
- Automated cross-platform price display for all major events
- Integrated arbitrage calculator with fee adjustment
- Historical arb frequency analysis by sport and market type

**Action 3.2 — Dixon-Coles Model Implementation**
- Deploy via `penaltyblog` library for soccer and hockey totals
- Correlation-adjusted Poisson with time-decay weighting
- Backtest against historical results for calibration

**Action 3.3 — E-sports Prop Market Integration**
- First blood, pistol round, map winner derivatives
- Game-specific momentum indicators
- Live odds comparison for in-play e-sports

**Action 3.4 — Reverse Line Movement Detection**
- Track public betting percentages vs. line movement
- Alert when 70%+ public on one side but line moves other way
- Integration with steam move alerts for composite sharp signal

**Action 3.5 — Promotional Calendar Tracker**
- Systematic tracking of Ontario book promotions
- EV calculator for each promotional offer
- Automated alert for +EV promotional opportunities

### Tier 4: Long-Term (3-6 Months)

**Action 4.1 — ML Model Activation**
- Requires 200+ settled directional bets for reliable training
- XGBoost ensemble with isotonic calibration
- Sport-specific models (not universal)
- Walk-forward validation framework

**Action 4.2 — Real-Money Execution**
- Small unit sizes (0.5-1% of bankroll per bet)
- Account rotation across 5+ Ontario books
- Continued paper tracking for model validation alongside real bets

**Action 4.3 — Account Rotation System**
- Distribute betting volume across operators
- Avoid concentration patterns that trigger limitations
- Maintain recreational betting appearance profiles

**Action 4.4 — Live/In-Play Betting Module**
- Real-time odds comparison during games
- Momentum detection algorithms
- Automated alert system for live value opportunities

---

## 10. Risk Factors & Mitigations

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Account limitations by Ontario books | High | High | Rotate across 5+ operators; maintain recreational profile |
| Prediction market price convergence | Medium | Medium | Monitor arb frequency; diversify signal sources |
| Insufficient sample size for ML activation | High | Medium | Use heuristic models until 200+ bets; focus on CLV not win rate |
| API service disruption | Low | High | Maintain fallback data sources; local caching layer |
| Regulatory changes (prediction markets) | Medium | Medium | Monitor CFTC/iGaming Ontario announcements; maintain flexibility |
| Overestimation of edge (variance) | High | High | Wilson confidence intervals; conservative Kelly fraction; circuit breakers |
| Professional gambler tax reclassification | Low | Very High | Maintain recreational documentation; do not report as primary income |

---

## 11. Success Metrics

| Metric | Current Target | 3-Month Target | 6-Month Target |
|--------|---------------|----------------|----------------|
| Settled directional bets | 24 | 100 | 250 |
| CLV positive rate | 44.4% | Greater than 55% | Greater than 60% |
| ROI (paper tracked) | 25.3% | 5-10% (normalized) | 3-8% (sustainable) |
| Arbitrage opportunities captured | 0 | 10+ | 50+ |
| Steam moves detected | 0 | 100+ | 500+ |
| Sports covered | 7 | 11 | 15 |
| Data sources integrated | 7+ | 12+ | 15+ |
| Odds refresh interval | 2-3 hours | 1 minute | 1 minute (real-time) |
| ML model status | Inactive (data insufficient) | Training mode | Active with 52%+ WR |

---

*Analysis conducted April 26, 2026. All data sourced from public APIs, documentation, and licensed operator disclosures. Ontario residents should verify current regulatory status before engaging with prediction markets. Gambling winnings are not taxable for recreational players under Canadian law; maintain documentation to support recreational classification if required.*
