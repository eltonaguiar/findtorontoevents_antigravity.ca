# Sports Betting Research & Analysis Plan

## Objective
Comprehensive analysis of the user's sports betting platform (findtorontoevents.ca) with deep research on prediction market integration, algorithmic betting strategies, Canadian market opportunities, and mispricing/arbitrage vectors.

## Stage 1 — Baseline Assessment & Landscape Scan
**Goal**: Review current site, map Ontario/Canada sportsbook landscape, identify prediction market opportunities.
- **Sub-agents** (parallel):
  1. **Site_Reviewer**: Review findtorontoevents.ca/live-monitor/sports-betting.html — assess current features, data sources, integration points
  2. **Ontario_Market_Scout**: Research OLG Proline+, Betway CA, Tooniebet, bet365, FanDuel, BetMGM, Sports Interaction, NorthStar Bets, Bet99, TonyBet — APIs, odds formats, available markets, limitations
  3. **Prediction_Market_Researcher**: Research Kalshi, Polymarket, and other prediction markets — sports contracts available, API access, notable wallets, pricing mechanisms

## Stage 2 — Algorithmic & Technical Deep Dive
**Goal**: Find GitHub libraries, betting algorithms, statistical models, and technical infrastructure for sports betting automation.
- **Skill**: `deep-research-swarm`
- **Sub-agents** (parallel):
  1. **Algo_Hunter**: Search GitHub for sports betting libraries (arbitrage detectors, odds compilers, Kelly criterion calculators, expected value models, Poisson distribution models, Elo-based predictors)
  2. **Polymarket_Wallet_Analyst**: Analyze top Polymarket wallets focused on sports betting — track performance, strategies, bet types
  3. **Mispricing_Detector**: Research arbitrage/mispricing detection between sportsbooks — middling, line shopping, correlated parlays, promotional exploitation

## Stage 3 — Attack Vector Identification & Strategy Synthesis
**Goal**: Identify overlooked sports, bet types, and strategies for the Canadian market.
- **Sub-agents** (parallel):
  1. **Unexplored_Sports_Analyst**: Research niche sports, props, live betting, e-sports, Canadian-specific sports (CPL, CFL, lacrosse, hockey derivatives)
  2. **Integration_Strategist**: Synthesize prediction market + sportsbook integration opportunities, API architectures, real-time odds aggregation

## Stage 4 — Final Report Assembly
**Goal**: Compile all research into actionable strategic document.
- **Skill**: `report-writing` → `docx`
- Deliverable: Comprehensive report with findings, recommendations, and implementation roadmap

## Key Research Questions
1. What does the current site offer vs. what's missing?
2. Which Ontario sportsbooks have accessible APIs or scrapable odds?
3. What sports contracts exist on Kalshi/Polymarket and how do they compare to traditional sportsbook lines?
4. What open-source algorithms exist for edge detection and bet sizing?
5. Which Polymarket wallets are successfully trading sports and what are their returns?
6. What mispricing opportunities exist between Canadian books?
7. What sports/bet types are underexploited in the Canadian market?
8. How can prediction markets be integrated with traditional sportsbook offerings?
