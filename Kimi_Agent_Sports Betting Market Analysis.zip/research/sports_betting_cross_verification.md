# Cross-Verification: Sports Betting Analysis

## High Confidence Findings (Confirmed by ≥2 independent sources)

### 1. Prediction Market API Landscape
- **Prediction Hunt v2 API** is the leading unified cross-platform API covering Kalshi, Polymarket, PredictIt, ProphetX, and Opinion [^66^][^78^][^75^]
- Kalshi API uses RSA-PSS authentication, 10 req/s rate limit [^66^][^69^][^70^]
- Polymarket has three APIs: Gamma (public), Data (public), CLOB (auth required) [^67^][^68^]
- Polymarket acquired Dome API (YC-backed competitor) in early 2026 [^66^]

### 2. Kalshi Sports Market Details
- CFTC-regulated since Nov 2020 [^36^]
- NBA partnership talks ongoing (April 2026) [^36^]
- Fees on contracts require higher win rates than implied probability [^24^]
- Python SDK available: `pip install kalshi-python` [^69^]
- Has live + historical data tier partitioning (Feb 2026) [^69^]

### 3. Polymarket Sports Ecosystem
- $9B valuation, NHL/MLB partnerships [^3^][^28^]
- 0.51% of wallets profitable over $1,000 [^3^]
- Sports markets: NBA, WNBA, NFL, CFB, MLB, KBO, e-sports, tennis, soccer (EPL, La Liga, Bundesliga, MLS, UCL), hockey, golf, MMA [^28^]
- Uses USDC on Polygon [^3^]

### 4. Top Polymarket Sports Wallets
- **Swiss Tony**: Most active, >60% entries below 50c (underdog), soccer specialist [^3^][^15^][^20^]
- **HyperLiquid0xb**: $1.4M+ profit, $755K single baseball win, MLB specialist [^3^]
- **distinct-baguette**: Automated crypto arb, 26,756 trades, $448K profit [^3^]
- **ColdMath**: Weather niche, 96% win rate [^3^]

### 5. Canadian Gambling Tax Status
- Gambling winnings NOT taxable for recreational players (Paragraph 40(2)(F)) [^83^][^84^][^87^][^88^]
- Professional gamblers pay 15-33% income tax [^84^]
- Interest on winnings is taxable [^83^]
- Ontario: 5.05%-13.16% on gambling interest income [^84^]

### 6. Ontario Sports Betting Market
- Regulated since April 2022 (iGaming Ontario) [^88^]
- OLG Proline+ now has competitive odds (on par with market) [^72^]
- Bill C-218 legalized single-event betting Aug 2021 [^79^]

### 7. E-sports Betting in Canada
- Legal, growing market [^79^][^80^][^86^]
- Major titles: LoL, CS2, Dota 2, Valorant [^79^][^81^]
- Tooniebet ranked #1 for e-sports [^86^]
- Live betting + props available [^79^]

### 8. Women's Sports - Soft Lines Opportunity
- "Softer lines" in women's sports due to market immaturity [^82^]
- Limited data, less sharp action, slower news adjustment [^82^]
- WNBA specifically mentioned as having exploitable inefficiencies [^82^]

### 9. Open-Source Libraries
- **sports-betting** (georgedouzas): PyPI package with GUI, backtesting [^42^]
- **surebet** (danielcardeenas): Real-time arb scanning [^40^]
- **penaltyblog**: Dixon-Coles model [^53^][^54^]
- **SportsArbFinder**: The Odds API multi-region arb [^29^]
- **NBA-ML-Sports-Betting**: XGBoost/Neural Net for NBA [^43^]

### 10. Steam Move Detection
- Sharp Sports API offers real-time steam move alerts (<50ms latency) [^73^]
- Steam moves detected across 50+ books [^73^]
- Python code available for detection [^74^]
- HubersEdge.com has steam/RLM detection across multiple books [^76^]

---

## Medium Confidence Findings (Single authoritative source)

### 11. Cross-Platform Arbitrage Math
- Prediction Hunt has `/api/v2/arb` endpoint with 15-second delay [^66^]
- Gross spread = $1.00 - (YES price + NO price); if > 0, arb exists [^77^]
- Fees must be subtracted from gross spread for net profit [^77^]

### 12. Sharp Sports API Capabilities
- Real-time sharp vs. public percentages [^73^]
- Reverse line movement detection [^73^]
- Covers NFL, NBA, MLB, NHL, soccer, UFC, tennis, golf [^73^]

### 13. OLG Proline+ Odds Quality
- Single reviewer found odds "on par with market averages" [^72^]
- Contradicts historical reputation of poor Proline odds
- May reflect post-regulation improvement

### 14. CFL Predictive Modeling
- CFL good for prediction due to small team pool, clear calendar [^65^]
- SportMonks offers ML prediction API for football [^64^]
- Less data availability than NFL/NBA

---

## Conflict Zones

### C1. OLG Proline+ Odds Quality
- **Historical view**: Proline had ~15-20% vig vs. 4-6% at Pinnacle (widely reported pre-2022)
- **Current view** (2025): Dimers review found "fair odds on par with market averages" [^72^]
- **Resolution**: Post-regulation (April 2022) OLG likely improved odds to compete. Need fresh comparison data.

### C2. Prediction Market vs. Sportsbook Efficiency
- **View A**: Prediction markets are MORE efficient (collective wisdom, no vig structure)
- **View B**: Prediction markets are LESS efficient (retail-heavy, less liquidity, 0.51% profitable wallets)
- **Resolution**: Likely depends on market type - major events may be efficient, niche events inefficient

### C3. ML Model Efficacy for Sports Betting
- **View A**: ML models can achieve 52-55% win rate (professional standard)
- **View B**: HubersEdge claims 65% hit rate NBA/NCAAB, 26%+ ROI NHL
- **Resolution**: Different metrics (win rate vs. ROI), different markets, sample size questions

---

## Low Confidence Findings

### L1. Specific Arb Frequency in Ontario
- No data on how often pure arbitrage occurs specifically in Ontario market
- Likely very rare, short-lived windows

### L2. Account Limitation Policies
- Individual book policies not publicly documented
- Based on anecdotal reports from betting communities

### L3. Real Execution Slippage
- User's system is paper-only
- No data on real-world bet placement success rates
