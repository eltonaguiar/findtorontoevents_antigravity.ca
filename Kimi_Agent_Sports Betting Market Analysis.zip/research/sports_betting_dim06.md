# Dimension 06: Polymarket Wallet Analysis & Whale Strategies

## Scope
Analysis of profitable Polymarket wallets focused on sports betting, their strategies, returns, and copy-trading potential.

## Current State
- Polymarket: 0.51% of wallets profitable over $1,000
- Only 314,000 active traders across $9B+ volume
- Sports is a major category alongside politics

## Key Wallets to Analyze
1. Swiss Tony - Most active sports trader, underdog picker, soccer specialist
2. HyperLiquid0xb - $1.4M+ profits, MLB specialist
3. RN1 - Underdog picker pattern
4. 0x1979, 0x1d003, 0xd1eb - Bot-driven crypto wallets
5. ColdMath - Weather market niche specialist

## Key Research Questions
1. What are the actual returns of top sports-focused wallets?
2. Can wallet copy-trading be automated?
3. What patterns distinguish profitable sports traders?
4. How does domain specialization manifest in sports wallets?
5. What's the latency requirement for copying whale trades?
6. Tools: PolyTrack, Polywhaler, Dune Analytics, Arkham Intelligence

## Expected Sources
- Polymarket on-chain data (Dune Analytics)
- Wallet tracking platforms
- Copy-trading analyses
- On-chain transaction analysis
