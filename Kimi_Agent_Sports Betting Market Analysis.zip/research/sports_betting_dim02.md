# Dimension 02: Ontario/Canada Sportsbook Market Deep Dive

## Scope
Comprehensive analysis of the Ontario licensed sportsbook market, APIs, odds quality, and mispricing opportunities. Focus on OLG Proline+, Betway, Tooniebet, bet365, FanDuel, BetMGM, Sports Interaction, NorthStar Bets, Bet99, TonyBet.

## Current State
- Ontario sports betting market launched April 2022 (first Canadian province to regulate)
- iGaming Ontario regulates all operators
- Multiple licensed operators now active with varying odds quality
- User's system currently uses The Odds API covering bet365, FanDuel, DraftKings, BetMGM, PointsBet, Caesars

## Key Evidence Needed
1. Which Ontario books have the softest lines?
2. OLG Proline+ odds quality vs. international books
3. API availability for each Ontario operator
4. Scraper feasibility for non-API books
5. Promotional exploitation opportunities
6. Market-specific factors (Canadian public bias patterns)

## Tensions and Counter-Arguments
- Ontario books may have different line-setting approaches than US/international books
- Regulatory restrictions on certain bet types
- Account limitations and KYC requirements
- Tax implications on winnings

## Expected Sources
- iGaming Ontario reports
- Sports betting forums (Reddit r/sportsbook, r/OntarioGambling)
- Odds comparison sites
- Operator websites and terms
- Academic market efficiency studies
