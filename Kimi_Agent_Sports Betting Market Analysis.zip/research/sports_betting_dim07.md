# Dimension 07: Niche Sports & Underexplored Canadian Markets

## Scope
Identification of sports and bet types that are underexploited in the Canadian market, including CFL, Canadian university sports, CPL, lacrosse, and other niche opportunities.

## Current State
- User's system covers: NHL, NBA, NFL, MLB, CFL, MLS, NCAAF, NCAAB
- CFL is Canadian-specific but may have limited data availability
- No coverage of: Canadian Premier League (soccer), NLL (lacrosse), curling, Canadian university football/hockey

## Key Research Questions
1. Which niche sports have the most inefficient betting markets?
2. CFL betting models and data sources
3. Canadian Premier League (CPL) soccer - growing league with potentially soft lines
4. National Lacrosse League (NLL) - uniquely Canadian/American sport
5. Player props vs. team markets - which are less efficient?
6. E-sports betting in Ontario (CS2, LoL, Dota 2, Valorant)
7. Women's sports markets (WNBA, PWHL, women's soccer)
8. Live/in-play betting opportunities

## Expected Sources
- Sports betting forums focusing on niche markets
- CFL analytics communities
- Canadian soccer analytics
- Women's sports betting analysis
- E-sports betting platforms
