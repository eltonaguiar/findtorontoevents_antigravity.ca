# Dimension 05: Arbitrage & Mispricing Detection Strategies

## Scope
Deep analysis of arbitrage opportunities, mispricing detection, and value betting strategies specifically applicable to the Canadian/Ontario market.

## Current State
- User's system compares 9+ books but has NO arbitrage detection
- Identified as Priority 5 in user's research section
- Current EV-based grading exists but no pure arb scanning

## Types of Arbitrage to Research
1. Pure arbitrage (implied probabilities < 100% across books)
2. Cross-book value betting (+EV at one book vs. consensus)
3. Cross-platform arbitrage (sportsbook vs. prediction market)
4. Steam chasing (follow sharp money quickly)
5. Middling (bet both sides at different lines)
6. Promotional exploitation (boosts, parlay insurance)
7. Correlated parlay exploitation

## Key Research Questions
1. How often do pure arbitrage opportunities arise in Ontario market?
2. What's the typical arb window duration?
3. Which books are slowest to adjust (best for steam chasing)?
4. Cross-platform arb: sportsbook vs. Kalshi/Polymarket pricing gaps?
5. OLG Proline+ mispricing frequency vs. sharper books
6. Automated execution frameworks and their legality

## Expected Sources
- Arbitrage betting communities
- Academic papers on market efficiency
- Sports betting automation tools
- Legal analysis of automated betting in Ontario
