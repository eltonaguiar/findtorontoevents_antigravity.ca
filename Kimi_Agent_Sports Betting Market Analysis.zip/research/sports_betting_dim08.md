# Dimension 08: ML/AI Model Architectures for Sports Betting

## Scope
Analysis of machine learning and AI approaches for sports prediction, including feature engineering, model selection, calibration, and backtesting frameworks.

## Current State
- User's system has 35+ ML features, Python ensemble
- Uses scraper data (ESPN, balldontlie, NHL API, MLB Stats API, NBA CDN, BallDontLie, TheSportsDB)
- ML model not yet fully activated due to insufficient training data (9 bets)
- PHP heuristic + Python ensemble approach

## Key Algorithms to Research
1. Dixon-Coles model (Poisson + correlation parameter for draws)
2. Elo ratings with uncertainty quantification
3. XGBoost/LightGBM for win probability prediction
4. Ensemble methods (stacking, blending)
5. Bayesian updating (Beta-Binomial for win rates)
6. Neural networks for player-level predictions
7. Time-series models for form tracking
8. Isotonic calibration for probability calibration

## Key Research Questions
1. What's the minimum dataset size for reliable ML sports predictions?
2. Which features have highest predictive power?
3. How to handle class imbalance in sports outcomes?
4. Walk-forward validation vs. cross-validation?
5. How to calibrate predicted probabilities?
6. Sport-specific vs. universal models?

## Expected Sources
- Kaggle sports prediction competitions
- Academic papers on sports forecasting
- ML engineering blogs
- Open-source sports prediction repositories
