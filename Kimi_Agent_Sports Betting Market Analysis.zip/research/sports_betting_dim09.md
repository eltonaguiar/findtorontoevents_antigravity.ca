# Dimension 09: Sharp Money Detection & Steam Move Tracking

## Scope
Analysis of sharp money detection methods, steam move tracking, reverse line movement identification, and real-time alert systems.

## Current State
- User has CLV tracking (new) but no steam move detection
- Reverse line movement identified as Priority 2 in research section
- No real-time line movement alerts
- 2-3 hour refresh interval too slow for sharp markets

## Key Concepts
1. Steam moves - synchronized line movements across multiple books
2. Reverse line movement - line moves opposite to public betting
3. SHARP detection method (Size/Speed, Historical context, Across-board consistency, Reverse line movement, Pattern recognition)
4. Line movement velocity and acceleration
5. Betting percentages vs. money percentages

## Key Research Questions
1. What tools exist for real-time steam detection?
2. MomentumOdds.com and similar platforms
3. How to build a steam move alert system?
4. What's the correlation between steam following and CLV?
5. Which books are most reliable as sharp indicators?
6. How to avoid false signals (public steam vs. sharp steam)?

## Expected Sources
- Steam move tracking platforms
- Sharp betting communities
- Line movement analysis tools
- Academic papers on market efficiency
