# Dimension 11: Regulatory, Tax & Operational Considerations

## Scope
Analysis of legal, regulatory, tax, and operational considerations for sports betting automation and prediction market participation in Canada.

## Current State
- Ontario regulated market since April 2022
- User's system is paper trading only
- No real money at risk currently

## Key Areas
1. Ontario iGaming regulations for automated betting tools
2. Account limitations and KYC requirements
3. Tax treatment of sports betting winnings in Canada
4. Prediction market access for Canadians (Kalshi, Polymarket)
5. Cryptocurrency regulations affecting Polymarket
6. Data scraping legality (terms of service)
7. Responsible gambling requirements

## Key Research Questions
1. Is automated betting allowed under Ontario regulations?
2. Can Canadians legally use Kalshi and Polymarket?
3. How are betting winnings taxed in Ontario?
4. What are the account limitation policies of major books?
5. How to structure operations to avoid limitations?
6. What responsible gambling measures are required?

## Expected Sources
- iGaming Ontario official site
- Canadian tax authority guidance
- Legal analysis of prediction markets
- Terms of service for major operators
