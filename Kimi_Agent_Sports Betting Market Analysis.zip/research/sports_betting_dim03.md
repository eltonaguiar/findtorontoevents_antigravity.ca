# Dimension 03: Prediction Market Integration (Kalshi & Polymarket)

## Scope
Analysis of Kalshi and Polymarket sports contracts, API access, pricing mechanisms, and integration opportunities with traditional sportsbook betting systems.

## Current State
- Kalshi: CFTC-regulated, NBA partnership talks (April 2026), no stake limits
- Polymarket: $9B valuation, NHL/MLB partnerships, decentralized on Polygon
- Both offer sports: NBA, NHL, NFL, MLB, soccer, tennis, e-sports
- User's system has NO prediction market integration currently

## Key Evidence Needed
1. Kalshi API documentation and sports contract endpoints
2. Polymarket API (CTP API) for sports market data
3. Pricing comparison: prediction markets vs. sportsbook odds
4. Cross-platform arbitrage opportunities
5. Notable sports-focused wallets on Polymarket
6. Regulatory status for Canadians using these platforms
7. Contract types: moneylines, spreads, totals, parlays

## Tensions
- Kalshi requires USDC/fiat; Polymarket requires crypto (USDC on Polygon)
- Canadian regulatory uncertainty for prediction markets
- Different fee structures (Kalshi charges fees on contracts)
- Information asymmetry: prediction market prices may differ from book odds

## Expected Sources
- Kalshi API docs (docs.kalshi.com)
- Polymarket CTP API docs
- Academic papers on prediction market efficiency
- Polymarket on-chain data (Dune Analytics)
- Trading strategy analyses
