# Dimension 10: Real-Time Data Infrastructure & APIs

## Scope
Analysis of data sources, APIs, and infrastructure needed for real-time sports betting analytics, including odds feeds, scores, weather, and injury data.

## Current State
- The Odds API (free tier, 2-3h refresh)
- ESPN APIs with failover + 2h cache
- Scraper pipeline for 4 sports
- 86/500 API credits remaining

## Data Sources to Evaluate
1. The Odds API paid tier ($20/mo for 1-min refresh)
2. Odds-API.io (250+ bookmakers)
3. Sportradar (official data provider)
4. Betfair API (exchange odds for market making)
5. OpenWeatherMap API (free tier for weather)
6. ESPN API (scores, injuries)
7. balldontlie API (NBA)
8. NHL API
9. MLB Stats API
10. RapidAPI sports endpoints

## Key Research Questions
1. What's the best odds API for Ontario-specific books?
2. How much does paid tier improve refresh rate?
3. WebSocket vs. polling architectures
4. Weather API integration for outdoor sports
5. Injury data sources and reliability
6. Cost-benefit analysis of data subscriptions

## Expected Sources
- API documentation and pricing pages
- Developer reviews and comparisons
- Sports betting tech blogs
