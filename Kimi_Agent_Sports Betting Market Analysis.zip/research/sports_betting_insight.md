# Insight Extraction: Sports Betting Enhancement Strategy

## Insight 1: Prediction Market Arbitrage is the Highest-ROI Integration

**Insight**: Cross-platform arbitrage between sportsbooks and prediction markets (Kalshi/Polymarket) offers a structural edge that traditional value betting cannot match — it represents RISK-FREE profit when executed correctly, fundamentally different from the probabilistic edge of +EV betting.

**Derived From**:
- Dim 03 (Prediction Market Integration): Kalshi + Polymarket both offer sports contracts [^36^][^28^]
- Dim 05 (Arbitrage Strategies): Cross-platform arb math shows gross spread = $1.00 - (YES + NO price) [^77^]
- Dim 10 (Data Infrastructure): Prediction Hunt API offers `/api/v2/arb` endpoint with pre-computed signals [^66^]

**Rationale**: The user's current system only compares traditional sportsbooks. Adding prediction markets creates a new dimension of comparison where contracts on the same event can be priced differently due to platform-specific user bases. The Prediction Hunt API ($49/mo Dev tier) handles all the cross-platform matching, delivering arbitrage signals directly.

**Implications**: 
- Integrate Prediction Hunt API as the intelligence layer for cross-platform arb detection
- Display Kalshi/Polymarket prices alongside traditional book odds
- Auto-alert when gross spread > fee threshold

**Confidence**: High

---

## Insight 2: Women's Sports + E-sports Represent "Greenfield" Inefficiency Markets

**Insight**: The convergence of two market-immature categories (women's sports and e-sports) with the user's Ontario focus creates a unique "triple inefficiency" — new sports + new betting markets + geographically-specific books = significantly softer lines than mainstream men's sports.

**Derived From**:
- Dim 07 (Niche Sports): Women's sports have "soft lines" due to market immaturity, limited data, slower news adjustment [^82^]
- Dim 07 (Niche Sports): E-sports betting is fastest-growing market with unique props [^79^][^81^]
- Dim 02 (Ontario Market): Ontario-specific books (Tooniebet, NorthStar) may have less sophisticated e-sports pricing

**Rationale**: The user's system currently covers only traditional men's sports (NHL, NBA, NFL, MLB, CFL, MLS). Adding WNBA, PWHL, women's soccer, CS2, LoL, Dota 2, and Valorant would target markets where:
1. Less sharp money competes for edges
2. Bookmakers invest less in pricing models
3. Public bias creates more mispricing
4. Domain expertise barrier is higher (game-specific knowledge)

**Implications**:
- Prioritize adding WNBA and PWHL (Canadian women's hockey league) as first niche markets
- Add CS2 and LoL as primary e-sports (largest markets, most data)
- Develop game-specific features (first blood props for LoL, pistol round for CS2)

**Confidence**: High

---

## Insight 3: The "Tax-Free Edge" — Canada's Gambling Tax Law Creates Structural Advantage

**Insight**: Canada's tax-free treatment of recreational gambling winnings (Paragraph 40(2)(F)) means Canadian bettors keep 100% of profits vs. significant tax drag in other jurisdictions. Combined with Kalshi (CFTC-regulated, no stake limits) and Ontario's regulated market, Canadian residents have access to one of the world's most favorable betting tax environments.

**Derived From**:
- Dim 11 (Regulatory): Gambling winnings NOT taxable for recreational players [^83^][^84^]
- Dim 11 (Regulatory): Only professional gamblers pay 15-33% income tax
- Dim 03 (Prediction Markets): Kalshi is CFTC-regulated, accessible to Canadians
- Dim 02 (Ontario Market): iGaming Ontario regulated since 2022

**Rationale**: US bettors face complex state-by-state taxation. UK bettors pay no tax but have limited market access. Canadian recreational bettors get the best of both worlds — no tax on winnings + access to both regulated domestic books AND CFTC-regulated prediction markets. This is a unique structural advantage.

**Implications**:
- Maintain recreational (not professional) gambler status to preserve tax exemption
- Keep detailed records to prove recreational status if questioned
- Structure operations to avoid "professional gambler" classification
- The tax savings effectively increase ROI by 15-33% vs. professional classification

**Confidence**: High

---

## Insight 4: Domain Specialization Beats Generalist ML at Current Data Scale

**Insight**: Given the user's current sample size (9 directional bets, 35 ML features), attempting to build universal ML models is premature. The Polymarket wallet analysis reveals that the most profitable strategies are domain-specific (HyperLiquid0xb's MLB expertise, ColdMath's weather niche, Swiss Tony's soccer focus). The user should adopt a "narrow and deep" approach rather than "broad and shallow."

**Derived From**:
- Dim 06 (Polymarket Wallets): Top traders specialize in specific domains [^3^]
- Dim 01 (Current System): Only 9 settled bets — insufficient for ML training
- Dim 08 (ML Architectures): 50-200 features needed for world-class models
- Dim 01 (Current System): Benchmark shows 52-55% WR is world-class; user's 22.2% ML is far below

**Rationale**: The 10,000-hour rule applies to sports betting just as it does to prediction markets. Rather than building a universal model that underperforms across all sports, the user should:
1. Pick 1-2 sports to dominate (recommendation: NHL + NBA for Canadian market)
2. Develop deep domain features (player matchup data, coaching tendencies, referee patterns)
3. Build sport-specific models rather than universal ones
4. Only expand to new sports after achieving consistent +CLV in core markets

**Implications**:
- Freeze universal ML model; pivot to sport-specific heuristics
- Focus data collection on NHL + NBA depth (not breadth across all sports)
- Track referee assignments, line combinations, defensive pairings
- Use quarter-Kelly with domain-specific confidence adjustments

**Confidence**: High

---

## Insight 5: The Odds API Free Tier is the Primary Bottleneck

**Insight**: The user's 2-3 hour refresh rate on The Odds API free tier creates a compounding disadvantage — it prevents steam move detection, arbitrage capture, AND live betting analysis. The $20/mo paid tier (1-min refresh) has higher ROI potential than any algorithmic improvement.

**Derived From**:
- Dim 01 (Current System): 2-3 hour refresh rate identified as gap
- Dim 09 (Sharp Money): Steam moves last seconds to minutes [^46^]
- Dim 05 (Arbitrage): Arb windows extremely short
- Dim 10 (Data Infrastructure): The Odds API paid tier = $20/mo for 1-min refresh

**Rationale**: No matter how sophisticated the prediction model, stale data eliminates edge. The $20/mo investment unlocks:
1. Steam move detection (currently impossible)
2. Arbitrage capture (currently impossible)
3. Real-time line movement tracking (currently impossible)
4. Closing line value tracking in near-real-time

At the user's current bankroll ($1,065), a single captured arbitrage opportunity could pay for years of API access.

**Implications**:
- Upgrade to The Odds API paid tier ($20/mo) as HIGHEST priority action
- Simultaneously evaluate Sharp Sports API for sharp money data
- Consider Prediction Hunt API Dev tier ($49/mo) for cross-platform arb signals

**Confidence**: High

---

## Insight 6: Polymarket Wallet Copy-Trading is a Viable "Signal Layer"

**Insight**: Tracking and copying profitable sports-focused Polymarket wallets (Swiss Tony for soccer, HyperLiquid0xb for MLB) provides an independent signal source that can be integrated with the user's existing book comparison system. This creates a "wisdom of sharp crowds" overlay.

**Derived From**:
- Dim 06 (Polymarket Wallets): Swiss Tony, HyperLiquid0xb have trackable on-chain activity [^3^]
- Dim 03 (Prediction Markets): Polymarket Data API has `/positions?user={address}` endpoint [^67^]
- Dim 09 (Sharp Money): Whale/sharp wallet tracking analogous to steam move detection

**Rationale**: Polymarket sports traders are domain specialists with proven track records. Their on-chain activity is public and queryable. By monitoring their positions, the user can:
1. Get early signals on mispriced soccer/MLB markets
2. Cross-reference with traditional book odds for value bets
3. Identify when sharp prediction market money disagrees with book odds

**Implications**:
- Use Polymarket Data API to track Swiss Tony (soccer) and HyperLiquid0xb (MLB) positions
- Build "whale alert" system for significant position changes
- Cross-reference whale picks with user's existing book comparison
- Add "prediction market consensus" as a new grading factor

**Confidence**: Medium (on-chain tracking is reliable but wallet strategies may change)

---

## Insight 7: The "Attack Vector Hierarchy" — Prioritized Opportunity Map

**Insight**: When all research dimensions are synthesized, a clear priority hierarchy emerges for the user's next actions. Rather than pursuing all opportunities simultaneously, a sequenced approach maximizes expected value:

**Tier 1 (Immediate, <1 week, <$100)**:
1. Upgrade The Odds API to paid tier ($20/mo) — unlocks real-time data
2. Add WNBA + CS2 as test niche markets
3. Integrate Prediction Hunt API free tier for cross-platform price display

**Tier 2 (Short-term, 1-4 weeks, <$500)**:
4. Build steam move detection system (Python, Sharp Sports API data)
5. Add weather integration (OpenWeatherMap API, free tier)
6. Develop NHL-specific situational model (Canadian market expertise)

**Tier 3 (Medium-term, 1-3 months)**:
7. Implement Kalshi/Polymarket price comparison for major events
8. Build Polymarket whale tracking dashboard
9. Add e-sports prop markets (first blood, map winners)
10. Develop Dixon-Coles model for soccer/hockey totals

**Tier 4 (Long-term, 3-6 months)**:
11. Full ML model activation (requires 200+ settled bets)
12. Real-money execution with small unit sizes
13. Account rotation system to avoid limitations

**Derived From**: All 12 dimensions synthesized

**Confidence**: High

---

## Insight 8: The "Situational Scoring Gap" — User's Current Differentiator

**Insight**: The user's existing situational scoring system (B2B fatigue, rest advantage, turnover margin, team ERA, injury reports) is actually MORE sophisticated than most competitors at this price point ($0-50/mo tools). The gap is not in analytical sophistication but in data freshness and market coverage. Doubling down on situational analysis while fixing data infrastructure creates a defensible edge.

**Derived From**:
- Dim 01 (Current System): 5 situation factors with academic citations
- Dim 02 (Ontario Market): Most Ontario bettors use basic tools or no tools
- Dim 08 (ML Architectures): User's heuristic approach is valid at small scale

**Rationale**: The Research & Future section of the site shows deep understanding of sports betting analytics (CLV, vig, sharp money, line balancing). This intellectual foundation, combined with the right data feeds, creates a sustainable edge.

**Implications**:
- Keep and enhance situational scoring (add weather, referee data)
- Don't abandon heuristics for ML too early
- Focus engineering effort on data infrastructure, not model complexity

**Confidence**: High
