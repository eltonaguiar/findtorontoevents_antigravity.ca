# Phase 1: Landscape Scan - Sports Betting Analysis & Enhancement

## Date: April 26, 2026

---

## 1. Current System Assessment (findtorontoevents.ca)

### Site Overview
- **Name**: "Sports Bet Winner Finder" by Find Toronto Events
- **URL**: https://findtorontoevents.ca/live-monitor/sports-betting.html
- **Description**: Value bets + line shopping across Canadian sportsbooks — paper betting tracker
- **Data Source**: The Odds API (refreshed every 2-3 hours)
- **Books Covered**: bet365, FanDuel, DraftKings, BetMGM, PointsBet, Caesars (Ontario/Canada legal)
- **Sports**: NHL, NBA, NFL, MLB, CFL, MLS, NCAAF, NCAAB

### Current Performance (as of April 25, 2026)
- **Bankroll**: $1,065.06 (+$65.06 from $1,000 start)
- **Settled Tickets**: 41 (W:9, L:15, P:0, V:17 voided)
- **Win Rate**: 37.5% (wins/(W+L), n=24 directional)
- **ROI**: 25.3% ($65.06 P&L)
- **CLV Beat Rate**: 44.4% on 9 tickets (avg CLV $0.6425)
- **Today's Picks**: 6 (Avg EV: 2.7%)

### Key Features
- Multi-Sport Situation Intelligence (LIVE) with research-backed scoring (0-30 bonus pts)
- Situation factors: back-to-back fatigue (Dean Oliver 2004), rest advantage (Entine & Small 2008), turnover margin (Biro 2017), team ERA (MDPI 2021), injury reports
- Auto-betting circuit breakers: $100/day loss limit, $800 bankroll floor
- Wilson ~95% CI on win rate
- Quarter-Kelly sizing
- Planned ML filter (mentioned)

### Site Tabs
- Today's Picks, Playoffs (NBA/NHL), Odds Comparison, My Bets, Performance, Pick History, Glossary, System Analysis, Research & Future

### Grading System
- STRONG TAKE, TAKE, LEAN, LOW EDGE, SKIP
- Based on EV% (50pts), book consensus (20pts), market type (15pts), CA-legal book (10pts), timing (5pts)

---

## 2. GitHub Repository Assessment

### Repository
- **URL**: https://github.com/eltonaguiar/findtorontoevents_antigravity.ca/
- **Commits**: 105,587+
- **Branches**: 376
- **Languages**: Python 54.8%, HTML 38.5%, JavaScript 3.1%, PHP 2.0%, TypeScript 1.4%
- **Contributors**: 10 (including github-actions[bot], eltonaguiar, claude, cursoragent, etc.)

### Key Modules (from repo structure)
- `audit_dashboard`, `audit_integration`, `audit_trail` - monitoring
- `backtest_results` - ML Engine v3.1: Daily training + XGB ensemble + calibration
- `battleground` - Audit impact tracker
- `bundle_registry` - Alpha Proven Edge bundle (7 forward-validated strategies)
- `crypto_ml_edge`, `crypto_gainer_ml`, `crypto_signal_engine` - crypto systems
- `cross_aggregation` - consensus outcomes
- `data_lake`, `data_pipeline`, `data_providers` - data infrastructure
- Multiple ML engines: `claude_gainer_ml`, `catboost_info`
- Sports betting appears integrated within the broader live-monitor system

### CI/CD
- Auto-update picks via GitHub Actions (hourly/daily)
- Automated backtesting and forward-validation

---

## 3. Ontario/Canada Sportsbook Landscape (April 2026)

### Top Licensed Ontario Sportsbooks [User input]
1. **Tooniebet** (4.9/5) - High ratings for live betting, quick withdrawals (24h)
2. **bet365** - Superior odds pricing, early cash-out options
3. **FanDuel** - Top mobile app
4. **BetMGM** - Deep sports coverage, promotions
5. **Sports Interaction (SIA)** - Localized in Canada, diverse markets
6. **NorthStar Bets** - "Proudly Canadian", tailored local promotions
7. **Bet99** - Intuitive design, Canadian sports focus
8. **TonyBet** - Sportsbook-casino combo, analytical live-betting focus

### OLG Proline+
- Ontario's government-run sports betting platform
- Often has worse odds than offshore/private competitors
- Potential for line comparison against sharper books

### Regulatory
- iGaming Ontario regulates all licensed operators
- Legal since April 2022 (Ontario was first province to regulate)

---

## 4. Prediction Market Landscape

### Kalshi
- CFTC-regulated prediction market (since Nov 2020)
- **NBA partnership talks ongoing** (April 2026) - discussing deals before next season [^36^]
- Offers sports contracts including WNBA, NBA moneylines
- XGB + Elo prior win probability model + Kelly-sized trading strategies exist on GitHub for WNBA Kalshi markets [^23^]
- **Key advantage**: No stake limits (unlike PredictIt)
- Fees: Charges fees on contracts, so break-even requires higher win rates than implied probability [^24^]
- Contracts priced 1c-99c, pay $1 if correct
- **Giannis Antetokounmpo** is Kalshi shareholder and ambassador (controversial) [^36^]
- Bryson DeChambeau has Kalshi contract

### Polymarket
- Decentralized prediction market on Polygon blockchain
- **$9 billion valuation** (ICE/NYSE parent invested $2B in Oct 2025) [^3^]
- **NBA, NHL, MLB partnerships** - NHL has exclusive deals with both Kalshi and Polymarket; MLB has exclusive with Polymarket [^28^][^36^]
- Individual team deals: Chicago Blackhawks-Kalshi, New York Rangers-Polymarket [^36^]
- Sports markets: NBA, WNBA, NFL, CFB, MLB, KBO, e-sports, tennis, soccer (EPL, La Liga, Bundesliga, MLS, UCL), hockey, golf, MMA, chess, motorsports, boxing, cricket [^28^]
- Contract types: moneylines, spreads, totals, multi-leg parlays
- Only 0.51% of wallets have achieved profits exceeding $1,000 [^3^]
- Uses USDC stablecoin on Polygon

### Top Polymarket Sports Traders/Strategies [^3^][^15^][^19^][^20^]
1. **Swiss Tony** - Most active by volume; >60% entries priced below 50c (underdog picker); EPL, Liga, Serie A, UCL; worst at Copa del Rey, UCL knockout, EFL Championship
2. **RN1** - Underdog picker, >60% entries below 50c
3. **HyperLiquid0xb** - Sports market specialist, $1.4M+ profits, $755K single baseball win; deep MLB knowledge
4. **ColdMath** - Weather trader (Buenos Aires, Cape Town, Dallas temperatures); pure niche play, 96% win rate
5. **distinct-baguette** - Automated crypto arbitrage, 26,756 trades, $448K profit, $17 avg/trade
6. **Car** - News-driven trading, $850K profit; never holds to settlement
7. **Domer** - Top overall trader; less alpha available but bigger opportunities; geopolitics/elections specialist

### Six Proven Polymarket Strategies (2025 analysis) [^3^]
1. **Information Arbitrage** - Cross-platform price differences
2. **Cross-Platform Arbitrage** - Buy low Polymarket, sell high Kalshi or vice versa
3. **High-Probability Bonds** - "Yes" on near-certain events, 1800% annualized
4. **Liquidity Provision** - Market making, capture spread
5. **Domain Specialization** - 10,000-hour rule; niche expertise (weather, specific leagues)
6. **Speed Trading** - React before market digests news (8 seconds on Powell speech)

---

## 5. GitHub Libraries & Algorithms

### Open-Source Sports Betting Libraries
1. **sports-betting** (georgedouzas) - PyPI package with GUI; dataloaders + bettors for backtesting and value bets; SoccerDataLoader; ClassifierBettor [^42^]
2. **surebet** (danielcardeenas) - Real-time arbitrage scanning software; Retriever-agnostic; H2H and 1x2 Arbers; fuzzy string matching [^40^]
3. **Surebet** (HintikkaKimmo) - Python library for odds conversion, arbitrage detection, value bet sizing [^39^]
4. **SportsArbFinder** (carterlasalle) - Uses The Odds API; multi-region (EU, US, UK, AU); interactive calculator [^29^]
5. **arbitrage-finder** (robbiehaynes) - Searches major sports events via The Odds API [^31^]
6. **flumine** - Python betting trading framework for Betfair (updated Apr 2026) [^27^]
7. **penaltyblog** - Dixon-Coles model Python implementation; football predictions; RPS metrics [^53^][^54^]
8. **sports-ai-bettor** (Monsterx411) - RandomForest classifier, value bet detection, Kelly Criterion, Streamlit dashboard [^18^]
9. **nflalgorithm** (mattleonard16) - NFL-specific ML with position-specific models, Kelly optimization, CLV tracking [^16^]
10. **NBA-Machine-Learning-Sports-Betting** (kyleskom) - XGBoost, Neural Networks, Logistic Regression for NBA moneyline and over/under [^43^]
11. **ml-mania-2026** (ledmaster) - Kaggle March Madness competition; routed LightGBM ensemble with bracket geometry, calibration [^37^]
12. **value-bet-finder-multi-sport** - Multi-sport value bet finder (Apr 2026) [^35^]
13. **sports-betting-steam-moves** - Steam-move detection with XGBoost + isotonic calibration, backtesting, Flask dashboard [^35^]
14. **alpha-football** - Programmatic market-neutral statistical arbitrage for European football [^35^]
15. **goto_conversion** - Odds conversion library; $47K prize money on Kaggle [^27^]

### Key Algorithms & Models
1. **Poisson Distribution** - Goal scoring modeling (soccer, hockey)
2. **Dixon-Coles** - Correlation-adjusted Poisson for low-scoring games; ρ (rho) parameter for draw correction; time-decay weighting [^47^][^51^][^53^][^55^]
3. **Kelly Criterion** - Optimal bet sizing; fractional Kelly (25-50%) for risk management [^25^]
4. **Elo Ratings** - Team strength estimation with uncertainty [^17^]
5. **XGBoost/LightGBM** - ML prediction models; ensemble approaches [^37^][^43^]
6. **Expected Value (EV)** - Edge = predicted probability - implied probability [^21^]
7. **Closing Line Value (CLV)** - Beat the closing line as primary performance metric
8. **Steam Move Detection** - Track synchronized line movements across books as sharp money signal [^46^][^48^][^49^]
9. **Reverse Line Movement** - Line moves opposite to public betting percentages [^49^]
10. **Bayesian Updating** - Sequential probability refinement with Beta-Binomial models [^17^]

---

## 6. Arbitrage & Mispricing Opportunities

### Types of Arbitrage
1. **Pure Arbitrage** - Combined implied probability < 100% across different books; rare, short-lived
2. **Cross-Book Value Betting** - Find +EV odds at one book vs. market consensus
3. **Steam Chasing** - Bet unmoved lines at slower books after sharp money moves lines at Pinnacle/other sharp books; window often < 5 minutes [^46^]
4. **Reverse Line Movement** - Public 70%+ on one side but line moves other way; sharp money signal [^49^]
5. **Middling** - Bet both sides at different spreads for potential win both ways
6. **Cross-Platform Arbitrage** - Sportsbook vs. prediction market (Kalshi/Polymarket) price divergence
7. **Promotional Exploitation** - Boosted odds, parlay insurance, risk-free bets

### Canadian-Specific Opportunities
- OLG Proline+ often has worse odds than offshore books (Proline historically had ~15-20% vig vs. 4-6% at Pinnacle)
- Newer Ontario books (Tooniebet, NorthStar) may have softer lines to attract customers
- CFL and Canadian university sports potentially less efficient markets
- Soccer (MLS) potentially mispriced vs. European soccer expertise

---

## 7. Key Narratives Identified

### Narrative 1: Prediction Markets Converging with Sports Betting
- NBA in talks with both Kalshi and Polymarket [^36^]
- NHL, MLB already have partnerships
- This is the next frontier: sportsbooks + prediction markets integration
- Opportunity to cross-reference odds between traditional books and prediction markets

### Narrative 2: ML/AI Becoming Standard in Sports Betting
- Multiple open-source ML sports betting libraries (sports-betting, NBA-ML, etc.)
- Real-time arbitrage + value-bet scanners now exist
- Steam move detection with ML pipelines
- The user's planned "ML filter" aligns with industry trend

### Narrative 3: Market Inefficiency in Niche Canadian Markets
- CFL, Canadian university sports, lacrosse potentially less efficient
- New Ontario operators may have softer lines
- OLG Proline+ vig significantly higher than international books

### Narrative 4: Sharp Money Detection as Key Signal
- Steam moves, reverse line movement, CLV as primary metrics
- Following smart wallets on Polymarket (whale copying)
- Books track sharp accounts and limit them

---

## 8. Controversies & Tensions

1. **Regulatory Uncertainty** - Prediction markets under CFTC, sports betting under state/provincial regulation; different rules
2. **Kalshi Celebrity Endorsement** - Giannis as shareholder creates potential conflict/perceived insider advantage
3. **Only 0.51% of Polymarket wallets profitable** - Most retail loses; prediction markets are zero-sum [^3^]
4. **Getting Limited by Books** - Sharp bettors consistently get account limited; need to rotate accounts
5. **Arbitrage Windows Extremely Short** - Steam moves last seconds to minutes; requires automation
6. **Paper Trading vs. Real Execution** - User's system is paper-only; real-world execution has slippage, rejected bets, limits

---

## 9. Gaps Requiring Deeper Investigation

1. Specific GitHub libraries for integrating Kalshi/Polymarket APIs with sports betting systems
2. Detailed analysis of OLG Proline+ odds vs. international books for mispricing
3. CFL and Canadian university sports betting models
4. Real-time arbitrage execution frameworks
5. Specific Polymarket wallet tracking for sports (not politics)
6. Steam move detection algorithms and their performance
7. Correlated parlay and promotional exploitation strategies
8. Player props modeling (undervalue vs. team-level markets)
9. Live/in-play betting algorithms and models
10. Weather, travel, and situational factors integration
