# Dimension 04: Open-Source Algorithms & GitHub Libraries

## Scope
Comprehensive catalog of open-source sports betting libraries, algorithms, and frameworks available on GitHub and PyPI, with assessment of relevance to the user's system.

## Current State
- User has custom PHP + Python ensemble
- Uses The Odds API for odds data
- Has scraper pipeline (ESPN, balldontlie, etc.)
- ML model uses 35+ features but insufficient training data

## Key Libraries Identified
1. sports-betting (georgedouzas) - PyPI, GUI, backtesting, value bets
2. surebet (danielcardeenas) - Real-time arbitrage scanning
3. penaltyblog - Dixon-Coles model, football predictions
4. flumine - Betfair trading framework
5. SportsArbFinder - The Odds API arbitrage
6. NBA-ML-Sports-Betting - XGBoost/Neural Net for NBA
7. sports-ai-bettor - RandomForest + Kelly Criterion
8. nflalgorithm - Position-specific NFL models
9. ml-mania-2026 - LightGBM ensemble with calibration
10. value-bet-finder-multi-sport - Multi-sport value finder

## Key Research Questions
1. Which libraries can be directly integrated into the current stack?
2. What algorithms are missing from the current implementation?
3. Dixon-Coles vs. current Poisson implementation?
4. Which libraries support Canadian/Ontario books?
5. What's the state-of-the-art for ML sports prediction in 2026?

## Expected Sources
- GitHub repositories
- PyPI documentation
- Academic papers on sports prediction models
- Kaggle competition solutions
